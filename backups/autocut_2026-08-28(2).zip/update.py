import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    idx = f.read()
idx = idx.replace('v3.0.1 (Chuẩn Hóa', 'v3.4.18 (Chuẩn Hóa')
with codecs.open('index.html', 'w', 'utf-8') as f:
    f.write(idx)

with codecs.open('sw.js', 'r', 'utf-8') as f:
    sw = f.read()
sw = sw.replace('v3.4.17', 'v3.4.18')
with codecs.open('sw.js', 'w', 'utf-8') as f:
    f.write(sw)

with codecs.open('version.json', 'r', 'utf-8') as f:
    vj = f.read()
vj = vj.replace('3.4.17', '3.4.18')
with codecs.open('version.json', 'w', 'utf-8') as f:
    f.write(vj)

with codecs.open('app.js', 'r', 'utf-8') as f:
    app = f.read()
app = app.replace("CURRENT_VERSION = '3.4.17'", "CURRENT_VERSION = '3.4.18'")

new_data = '''
        {
            id: 'WS-EXP-NEW-03',
            date: '2026-08-28',
            name: 'Thực nghiệm Thép mềm SCM420 H=30mm (Cắt Lỗ Phi 205 - Cấp 6)',
            material: 'SCM420',
            materialName: 'Thép mềm SCM420 (HB < 200)',
            passCount: 2,
            thickness: 30,
            cutLength: 644,
            multiPassDetails: [
                { pass: 'Pass 1', ti: 28, Po: 6, IP: 4, wire: 1, volt: 'High', vf: 60, maxSpeed: '200Hz', offset: 0.115, ampe: '4.1-4.2A', time: '3h08p' },
                { pass: 'Pass 2', ti: 16, Po: 5, IP: 2, wire: 2, volt: 'Low', vf: 40, maxSpeed: '150Hz', offset: 0.022, ampe: '0.1-0.2A', time: '1h12p' }
            ],
            measured: {
                ammeterA: 'P1: 4.1-4.2A | P2: 0.1-0.2A',
                totalMinutes: 260,
                totalTimeStr: '4h20p',
                actualDimension: '-0.015 mm (Lỗ phi 205mm, thực tế 204.985mm)',
                recommendedOffsetP1: '0.107 mm (Giảm 0.008 mm từ 0.115 mm)',
                recommendedMaxSpeed: 'P2 Remain: 0.022 mm (Giữ nguyên không đổi)'
            },
            notes: 'Cắt lỗ tròn 205mm. Lỗ bị nhỏ đi trung bình 0.015mm và bị ô van 0.01mm. Nguyên lý Lượng dư Tương đối: Chỉ cần giảm Offset Pass 1 đi 0.008mm (còn 0.107). Giữ nguyên Remain Pass 2 là 0.022. Hệ thống AutoCut sẽ tự dịch toàn bộ quỹ đạo 2 Pass ra ngoài.'
        },'''

app = app.replace('const WORKSHOP_EMPIRICAL_LIBRARY = [', 'const WORKSHOP_EMPIRICAL_LIBRARY = [' + new_data)

with codecs.open('app.js', 'w', 'utf-8') as f:
    f.write(app)
print('Done!')