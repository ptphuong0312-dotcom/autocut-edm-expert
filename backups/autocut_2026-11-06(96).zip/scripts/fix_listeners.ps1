$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
$newLines = [System.Collections.Generic.List[string]]::new()

$i = 0
while ($i -lt $lines.Length) {
    if ($lines[$i].Contains("[customTiInput, customPoInput")) {
        # Skip until wsBtnAnalyzeCustom
        while ($i -lt $lines.Length -and -not $lines[$i].Contains("if (wsBtnAnalyzeCustom)")) {
            $i++
        }
        $newLines.Add("    [customTiInput, customPoInput, customIpInput, customVoltInput, customVfInput, customWireInput].forEach(inp => {")
        $newLines.Add("        if (inp) {")
        $newLines.Add("            const handler = () => {")
        $newLines.Add("                syncCustomInputs('tab1');")
        $newLines.Add("                state.isCustomUserEdited = true;")
        $newLines.Add("                state.compareMode = 'custom';")
        $newLines.Add("                runCustomAnalysis(false);")
        $newLines.Add("            };")
        $newLines.Add("            inp.addEventListener('input', handler);")
        $newLines.Add("            inp.addEventListener('change', handler);")
        $newLines.Add("        }")
        $newLines.Add("    });")
        $newLines.Add("")
        $newLines.Add("    [wsCustomTiInput, wsCustomPoInput, wsCustomIpInput, wsCustomVoltInput, wsCustomVfInput, wsCustomWireInput].forEach(inp => {")
        $newLines.Add("        if (inp) {")
        $newLines.Add("            const handler = () => {")
        $newLines.Add("                syncCustomInputs('tab2');")
        $newLines.Add("                state.isCustomUserEdited = true;")
        $newLines.Add("                state.compareMode = 'custom';")
        $newLines.Add("                runCustomAnalysis(false);")
        $newLines.Add("            };")
        $newLines.Add("            inp.addEventListener('input', handler);")
        $newLines.Add("            inp.addEventListener('change', handler);")
        $newLines.Add("        }")
        $newLines.Add("    });")
        $newLines.Add("")
        continue
    }

    $newLines.Add($lines[$i])
    $i++
}

[System.IO.File]::WriteAllLines("app.js", $newLines, [System.Text.Encoding]::UTF8)
Write-Host "Fixed input listeners successfully."
