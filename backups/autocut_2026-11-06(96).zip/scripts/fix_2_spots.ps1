$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
$newLines = [System.Collections.Generic.List[string]]::new()

$i = 0
while ($i -lt $lines.Length) {
    # 1. Fix navTabs
    if ($lines[$i].Contains("// 1. TAB SWITCHING")) {
        $newLines.Add($lines[$i])
        $newLines.Add("    // ==========================================")
        $newLines.Add("    navTabs.forEach(tab => {")
        $newLines.Add("        tab.addEventListener('click', () => {")
        $newLines.Add("            navTabs.forEach(t => t.classList.remove('active'));")
        $newLines.Add("            tabContents.forEach(c => c.classList.remove('active'));")
        $newLines.Add("")
        $newLines.Add("            tab.classList.add('active');")
        $newLines.Add("            const target = tab.dataset.tab;")
        $newLines.Add("            document.getElementById(target).classList.add('active');")
        $newLines.Add("            if (target === 'tab-vf-research' && typeof updateTab1SyncPreview === 'function') {")
        $newLines.Add("                updateTab1SyncPreview();")
        $newLines.Add("            }")
        $newLines.Add("        });")
        $newLines.Add("    });")
        $newLines.Add("")
        # Skip until 2. LY THUYET DONG BO
        while ($i -lt $lines.Length -and -not $lines[$i].Contains("// 2. LÝ THUYẾT")) {
            $i++
        }
        continue
    }

    # 2. Fix end of render()
    if ($lines[$i].Contains("if (typeof renderLectureKnowledge === 'function')")) {
        $newLines.Add("        if (typeof renderLectureKnowledge === 'function') {")
        $newLines.Add("            renderLectureKnowledge();")
        $newLines.Add("        }")
        $newLines.Add("        if (typeof updateTab1SyncPreview === 'function') {")
        $newLines.Add("            updateTab1SyncPreview();")
        $newLines.Add("        }")
        $newLines.Add("    }")
        $newLines.Add("")
        # Skip until 6. COPY TABLE TO CLIPBOARD
        while ($i -lt $lines.Length -and -not $lines[$i].Contains("// 6. COPY TABLE TO CLIPBOARD")) {
            $i++
        }
        continue
    }

    $newLines.Add($lines[$i])
    $i++
}

[System.IO.File]::WriteAllLines("app.js", $newLines, [System.Text.Encoding]::UTF8)
Write-Host "Fixed 2 spots successfully."
