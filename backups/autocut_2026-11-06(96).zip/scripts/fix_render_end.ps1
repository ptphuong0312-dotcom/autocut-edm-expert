$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
$newLines = [System.Collections.Generic.List[string]]::new()

for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($line.Contains("updateTab1SyncPreview();") -and $i -gt 3720 -and $i -lt 3750) {
        $newLines.Add($line)
        $newLines.Add("        }")
        $newLines.Add("    }")
        $newLines.Add("")
        # Skip until 6. COPY TABLE TO CLIPBOARD
        while ($i -lt $lines.Length -and -not $lines[$i].Contains("// 6. COPY TABLE TO CLIPBOARD")) {
            $i++
        }
        $newLines.Add($lines[$i])
        continue
    }
    $newLines.Add($line)
}

[System.IO.File]::WriteAllLines("app.js", $newLines, [System.Text.Encoding]::UTF8)
Write-Host "Fixed render closing brace."
