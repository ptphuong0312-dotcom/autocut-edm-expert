
    const fs = require('fs');
    const code = fs.readFileSync('app.js', 'utf8');
    
    // Extract generateWorkshopRows and calculateWorkshopEDM
    // We can evaluate in sandbox
    const vm = require('vm');
    const sandbox = {
        console: console,
        Math: Math,
        WS_STRATEGY_CONFIGS: {
            1: { name: 'Cấp 1 - Cực Mịn', Wire: '1', RaStr: '~ 1.2' },
            2: { name: 'Cấp 2 - Siêu Mịn', Wire: '1', RaStr: '~ 1.6' },
            3: { name: 'Cấp 3 - Mịn Sáng', Wire: '1', RaStr: '~ 2.0' },
            4: { name: 'Cấp 4 - Tiêu Chuẩn Xưởng', Wire: '1', RaStr: '~ 2.5' },
            5: { name: 'Cấp 5 - Năng Suất Cao', Wire: '1', RaStr: '~ 2.8' },
            6: { name: 'Cấp 6 - Nhanh Phá Thô', Wire: '1', RaStr: '~ 3.2' },
            7: { name: 'Cấp 7 - Tốc Độ Tối Đa', Wire: '1', RaStr: '~ 3.6' }
        }
    };
    vm.createContext(sandbox);
    
    // Grab the function definitions
    const genMatch = code.match(/function generateWorkshopRows\(state\) \{[\s\S]*?return wsRows;\s*\}/);
    const calcMatch = code.match(/function calculateWorkshopEDM\(state\) \{[\s\S]*?return \{[\s\S]*?\};\s*\}/);
    
    if (!genMatch || !calcMatch) {
        console.error('Could not extract functions!');
        process.exit(1);
    }
    
    vm.runInContext(genMatch[0], sandbox);
    vm.runInContext(calcMatch[0], sandbox);
    
    console.log('Testing generateWorkshopRows for 1, 2, 3, 4, 5 passes:');
    for (let p = 1; p <= 5; p++) {
        const state = {
            thickness: 40,
            wsPassCount: p,
            wsStrategyLevel: 4,
            wsMaterial: 'SCM420',
            cutLength: 100
        };
        const rows = sandbox.generateWorkshopRows(state);
        console.log(`- Pass count ${p}: generated ${rows.length} rows`);
        rows.forEach((r, idx) => {
            console.log(`  Row ${idx+1} (${r.passName}): Ton=${r.ti}, Po=${r.Po}, IP=${r.IP}, Volt=${r.Voltage}, VF=${r.VF}, Wire=${r.Wire}, Offset=${r.offsetText}, Speed=${r.speedArea}, Ra=${r.Ra}`);
        });
    }
    
    console.log('\nTesting H=12mm 5-pass benchmark (5P-01):');
    const bState = {
        thickness: 12,
        wsPassCount: 5,
        wsStrategyLevel: 4,
        wsMaterial: 'SCM420',
        cutLength: 100
    };
    const bRows = sandbox.generateWorkshopRows(bState);
    bRows.forEach((r, idx) => {
        console.log(`  Pass ${idx+1}: Ton=${r.ti}, Po=${r.Po}, IP=${r.IP}, Volt=${r.Voltage}, VF=${r.VF}, Wire=${r.Wire}, Offset=${r.offsetText}, Ra=${r.Ra}`);
    });
    
    console.log('\nTesting calculateWorkshopEDM:');
    const calcRes = sandbox.calculateWorkshopEDM(bState);
    console.log(`  Calc output: ti=${calcRes.ti}, Po=${calcRes.Po}, IP=${calcRes.IP}, VF=${calcRes.VF}, offset=${calcRes.offset}, time_min=${calcRes.time_min.toFixed(2)}m`);
    