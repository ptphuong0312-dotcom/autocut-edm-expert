$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\WORKSHOP_DATA_BANK.md", [System.Text.Encoding]::UTF8)

$lines = $content -split "`r?`n"
Write-Host "=== SECTIONS IN WORKSHOP_DATA_BANK.MD ($($lines.Length) lines, $($content.Length) bytes) ==="
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match '^#{1,3}\s+(.*)') {
        Write-Host "Line $($i+1): $($lines[$i])"
    }
}
