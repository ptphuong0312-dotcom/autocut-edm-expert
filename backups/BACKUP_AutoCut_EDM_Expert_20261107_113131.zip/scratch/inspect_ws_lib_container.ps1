$root = (Get-Location).Path
$html = [System.IO.File]::ReadAllText("$root\index.html", [System.Text.Encoding]::UTF8)

$lines = $html -split "`r?`n"
Write-Host "Total lines in index.html: $($lines.Length)"

# Find ws-workshop-library-container
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'ws-workshop-library-container') {
        Write-Host "Found ws-workshop-library-container at line $($i+1):"
        for ($j = [Math]::Max(0, $i - 5); $j -lt [Math]::Min($lines.Length, $i + 40); $j++) {
            Write-Host "$($j+1): $($lines[$j])"
        }
        break
    }
}
