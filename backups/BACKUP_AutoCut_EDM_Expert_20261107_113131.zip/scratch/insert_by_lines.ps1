$root = (Get-Location).Path
$filePath = "$root\WORKSHOP_DATA_BANK.md"
$lines = [System.IO.File]::ReadAllLines($filePath, [System.Text.Encoding]::UTF8)

$table = [System.IO.File]::ReadAllLines("$root\scratch\table_to_insert.md", [System.Text.Encoding]::UTF8)

$targetLineIdx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'RAW DATA BANK') {
        $targetLineIdx = $i
        break
    }
}

if ($targetLineIdx -ge 0) {
    Write-Host "Found line index: $targetLineIdx (Line $($targetLineIdx+1))"
    $newLines = @()
    if ($targetLineIdx -gt 0) {
        $newLines += $lines[0..($targetLineIdx - 1)]
    }
    $newLines += $table
    $newLines += ""
    $newLines += $lines[$targetLineIdx..($lines.Length - 1)]
    [System.IO.File]::WriteAllLines($filePath, $newLines, [System.Text.Encoding]::UTF8)
    Write-Host "SUCCESS: Written $($newLines.Length) lines to WORKSHOP_DATA_BANK.md"
} else {
    Write-Host "ERROR: target not found"
}
