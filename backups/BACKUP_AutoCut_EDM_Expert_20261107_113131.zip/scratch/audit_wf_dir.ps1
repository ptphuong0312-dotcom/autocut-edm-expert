$root = (Get-Location).Path
$wf = Get-ChildItem -Path "$root\.agents\workflows" -Recurse -File | Select-Object @{Name='Path'; Expression={$_.FullName.Substring($root.Length+1)}}, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}}

Write-Host "=== .AGENTS/WORKFLOWS/ AUDIT ($($wf.Count) files) ==="
$wf | Format-Table -AutoSize
