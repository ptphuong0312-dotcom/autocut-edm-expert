$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\PROJECT_HISTORY.md", [System.Text.Encoding]::UTF8)

Write-Host "=== PROJECT_HISTORY.MD (First 40 lines) ==="
$lines = $content -split "`r?`n"
for ($i = 0; $i -lt [Math]::Min(40, $lines.Length); $i++) {
    Write-Host "$($i+1): $($lines[$i])"
}
