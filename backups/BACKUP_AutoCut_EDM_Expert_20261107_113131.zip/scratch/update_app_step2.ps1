$root = (Get-Location).Path
$appPath = "$root\app.js"
$js = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)

# 1. Update computeRowDynamics
$old1 = 'let hz = r.hz;'
$new1 = 'let hz = r.hz;' + "`r`n" + '                if (cur.ti !== undefined && cur.Po !== undefined && cur.ti > 0 && cur.Po >= 0) { hz = Math.round(1000000 / (cur.ti * (cur.Po + 2))); }'

# 2. Update onFieldChange to update ws-dyn-hz
$old2 = 'if (ampeEl) ampeEl.textContent = dyn.ampeDisplay;'
$new2 = 'if (ampeEl) ampeEl.textContent = dyn.ampeDisplay;' + "`r`n" + '                    const hzEl = document.getElementById("ws-dyn-hz-" + passIdx); if (hzEl) hzEl.textContent = dyn.hz + " Hz";'

# 3. Add Spec Lock
$old3 = 'function copyWorkshopTableToClipboard() {'
$new3 = '// [SPEC-LOCK: CLIPBOARD_EXPORT_CONTRACT_V66] - Do not change output format: 1 Pass: Pon..OFFSET, Multi-Pass: newline between passes' + "`r`n" + '    function copyWorkshopTableToClipboard() {'

# 4. Version bump
$old4 = 'const CURRENT_VERSION = "3.5.66";'
$new4 = 'const CURRENT_VERSION = "3.5.67";'

if ($js.Contains($old1) -and $js.Contains($old2) -and $js.Contains($old3) -and $js.Contains($old4)) {
    $js = $js.Replace($old1, $new1)
    $js = $js.Replace($old2, $new2)
    $js = $js.Replace($old3, $new3)
    $js = $js.Replace($old4, $new4)
    [System.IO.File]::WriteAllText($appPath, $js, [System.Text.Encoding]::UTF8)
    Write-Host "SUCCESS: app.js updated to v3.5.67!"
} else {
    Write-Host "ERROR: target blocks not matched"
    Write-Host "old1: $($js.Contains($old1))"
    Write-Host "old2: $($js.Contains($old2))"
    Write-Host "old3: $($js.Contains($old3))"
    Write-Host "old4: $($js.Contains($old4))"
}
