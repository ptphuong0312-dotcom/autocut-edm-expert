$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$missingList = @(
 'strategy-slider', 'strategy-level-badge', 'strategy-name-display', 'strategy-badge-display',
 'strategy-desc-display', 'thickness-input', 'thickness-slider', 'cut-length', 'total-time-text',
 'config-summary', 'table-body', 'notice-list', 'btn-copy-table', 'ws-config-summary',
 'ws-table-body', 'btn-mode-custom', 'btn-mode-theory', 'custom-mode-hint', 'analysis-table-title',
 'btn-analyze-custom', 'custom-ti', 'custom-po', 'custom-ip', 'custom-volt', 'custom-vf',
 'custom-wire', 'ws-btn-analyze-custom', 'ws-custom-ti', 'ws-custom-po', 'ws-custom-ip',
 'ws-custom-volt', 'ws-custom-vf', 'ws-custom-wire', 'analysis-container', 'comparison-table-element',
 'analysis-feedback-box', 'ws-analysis-feedback-box', 'btn-toggle-compact', 'compact-text',
 'btn-toggle-workshop', 'workshop-body', 'workshop-toggle-status', 'ws-comparison-table-element',
 'ws-dyn-offset-1', 'update-toast', 'ws-lib-subtab-content', 'ws-lib-toggle-btn', 'ws-lib-content',
 'ws-lib-toggle-icon', 'ws-lib-toggle-arrow'
)

$lines = $js -split "`r?`n"
$results = @{}

for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    foreach ($id in $missingList) {
        if ($line.Contains("'$id'") -or $line.Contains("""$id""")) {
            if (-not $results.ContainsKey($id)) {
                $results[$id] = @()
            }
            $results[$id] += ($i + 1)
        }
    }
}

Write-Host "=== MISSING IDS AND THEIR LINE NUMBERS IN APP.JS ==="
foreach ($key in ($results.Keys | Sort-Object)) {
    $lineNums = $results[$key] -join ', '
    Write-Host "$key (found on lines: $lineNums)"
}
