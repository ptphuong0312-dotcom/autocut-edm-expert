$root = (Get-Location).Path
$path = "$root\docs\OPTIMIZATION_HISTORY.md"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

$dot67 = @"

### 🚀 ĐỢT 67: NÂNG CẤP HỆ THỐNG BỘ NÃO TRI THỨC MASTER, KHÓA CƠ HỌC [SPEC-LOCK], HZ ĐỘNG & GATEKEEPER TOÀN NĂNG (v3.5.67)
* **Thời gian:** 2026-11-07 11:20 (GMT+7)
* **Bối cảnh & Chỉ thị từ SirPhuong:**
  - Nâng cấp toàn diện cơ chế chống quên và khóa cơ học chủ động để dự án phát triển lâu dài không tì vết.
  - Khảo sát sâu 3 vòng và giải quyết triệt để 12 kẽ hở vi mô (PWA Offline 404, Hz động Vùng 2, rò rỉ nút in A4, nạp kép token quy tắc...).
* **Các thay đổi đã triển khai:**
  1. **Tái cấu trúc Bộ Não Master:**
     - Thu gọn `GEMINI.md` xuống còn 41 dòng (4.6 KB) làm Bản Đồ Tri Thức Master & Bảng Định Tuyến Tác Vụ không bao giờ bị cắt cụt.
     - Ban hành 6 Sổ tay Quy chuẩn chuyên sâu trong `docs/rules/01..06.md` (mỗi file < 5 KB).
     - Bổ sung Bảng Chỉ Mục Ground Truth (19 bài cắt xưởng) vào đầu `WORKSHOP_DATA_BANK.md`.
  2. **Dọn dẹp rác & Phân tầng lưu trữ an toàn:**
     - Di chuyển 68 script nháp một lần vào `archive/scripts_archive/`.
     - Di chuyển code cũ (`app_backup.js`, `debug3.txt`) vào `archive/code_legacy/`.
     - Lưu trữ Đợt 1-50 vào `docs/archive/OPTIMIZATION_HISTORY_LEGACY.md`.
  3. **Sửa các lỗi vi mô cốt tử:**
     - `sw.js`: Xóa bỏ 2 file phantom 404 (`tailieu.txt`, `PROJECT_RULES.md`) để bảo đảm Service Worker pre-cache 100% offline hoàn hảo.
     - `app.js`: Tự động tính động Tần số máy $f = 10^6 / T$ và cập nhật `ws-dyn-hz` tức thì khi người dùng sửa Pon/Poff ở Vùng 1.
     - `style.css`: Ẩn `.results-header-actions` trong `@media print` để bản in A4 sạch đẹp, không bị rò rỉ nút bấm.
  4. **Thiết lập Khóa Cơ Học [SPEC-LOCK] & Cổng Gác Gatekeeper:**
     - Gắn `[SPEC-LOCK: CLIPBOARD_EXPORT_CONTRACT_V66]` bảo vệ định dạng xuất clipboard có dòng trống.
     - Xây dựng `scripts/verify_gatekeeper.ps1` (chạy PowerShell thuần túy 0 dependency) quét 7 chốt an toàn trong 1.5 giây.
* **Kết quả nghiệm thu kỹ thuật:**
  - **Pre-flight Gatekeeper (`verify_gatekeeper.ps1`):** ALL 7 GATES PASSED [100%].
  - **Đồng bộ phiên bản:** `v3.5.67` trên 5 tệp (`version.json`, `index.html`, `app.js`, `style.css`, `sw.js`).
"@

$nl = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$newContent = $content.TrimEnd() + $nl + $dot67.Trim() + $nl
[System.IO.File]::WriteAllText($path, $newContent, [System.Text.Encoding]::UTF8)
Write-Host "SUCCESS: OPTIMIZATION_HISTORY.md updated with Dot 67!"
