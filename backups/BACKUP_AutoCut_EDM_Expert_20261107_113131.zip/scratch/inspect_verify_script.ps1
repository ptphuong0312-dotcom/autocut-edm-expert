$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\scripts\verify_integrity.ps1", [System.Text.Encoding]::UTF8)

Write-Host "=== SCRIPTS/VERIFY_INTEGRITY.PS1 PREVIEW ==="
$content
