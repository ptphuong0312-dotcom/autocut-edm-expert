$root = (Get-Location).Path
$css = [System.IO.File]::ReadAllText("$root\style.css", [System.Text.Encoding]::UTF8)

$lines = $css -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match '\.chip-container|\.chips-scroll') {
        Write-Host "Line $($i+1): $($lines[$i])"
        for ($j = [Math]::Max(0, $i - 1); $j -lt [Math]::Min($lines.Length, $i + 12); $j++) {
            Write-Host "  $($j+1): $($lines[$j])"
        }
    }
}
