$root = (Get-Location).Path
$html = [System.IO.File]::ReadAllText("$root\index.html", [System.Text.Encoding]::UTF8)

$lines = $html -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'ws-quick-chips') {
        Write-Host "Found in index.html at line $($i+1):"
        for ($j = [Math]::Max(0, $i - 3); $j -lt [Math]::Min($lines.Length, $i + 15); $j++) {
            Write-Host "  $($j+1): $($lines[$j])"
        }
    }
}
