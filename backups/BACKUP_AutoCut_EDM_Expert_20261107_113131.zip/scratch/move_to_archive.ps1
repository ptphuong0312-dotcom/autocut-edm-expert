$root = (Get-Location).Path

# 1. Create directories
$dirs = @(
    "$root\archive\scripts_archive",
    "$root\archive\code_legacy",
    "$root\docs\archive"
)
foreach ($d in $dirs) {
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path $d -Force | Out-Null
        Write-Host "Created: $d"
    }
}

# 2. Files to keep in scripts/
$keepScripts = @(
    'verify_integrity.ps1',
    'verify_integrity.py',
    'verify_integrity.js',
    'audit_spark_gap.ps1',
    'audit_spark_gap.py',
    'audit_spark_gap.js',
    'backup.ps1',
    'backup.py',
    'generate_edm_pdf.py',
    'pdf_table_data.json',
    'preview_pdf.png',
    'test_app.js',
    'calc_engine.js'
)

# Move one-off scripts from scripts/ to archive/scripts_archive/
$allScripts = Get-ChildItem -Path "$root\scripts" -File
$movedCount = 0
foreach ($s in $allScripts) {
    if ($s.Name -notin $keepScripts) {
        Move-Item -Path $s.FullName -Destination "$root\archive\scripts_archive\$($s.Name)" -Force
        $movedCount++
    }
}
Write-Host "Moved $movedCount one-off scripts to archive/scripts_archive/"

# 3. Move root clutter to archive/code_legacy/
$rootClutter = @('app_backup.js', 'debug3.txt', 'backup.bat')
foreach ($f in $rootClutter) {
    $p = Join-Path $root $f
    if (Test-Path $p) {
        Move-Item -Path $p -Destination "$root\archive\code_legacy\$f" -Force
        Write-Host "Moved $f to archive/code_legacy/"
    }
}

# 4. Check results
Write-Host "Active scripts remaining in scripts/: $((Get-ChildItem "$root\scripts" -File).Count)"
