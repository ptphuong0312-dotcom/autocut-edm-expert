$root = (Get-Location).Path

$files = Get-ChildItem -Path $root -Recurse -File | Where-Object { 
    $_.FullName -notmatch '\\\.git\\' -and 
    $_.FullName -notmatch '\\backups\\' -and 
    $_.FullName -notmatch '\\scratch\\' -and
    $_.FullName -notmatch '\\node_modules\\'
}

Write-Host "=== PROJECT FILES SCANNED (EXCLUDING node_modules, .git, backups, scratch): $($files.Count) ==="

$extGroups = $files | Group-Object Extension | Select-Object Name, Count | Sort-Object Count -Descending
$extGroups | Format-Table -AutoSize

Write-Host "`n=== PROJECT FILES OVER 15 KB ==="
$oversized = $files | Where-Object { $_.Length -gt 15360 } | Select-Object @{Name='Path'; Expression={$_.FullName.Substring($root.Length+1)}}, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}} | Sort-Object Length -Descending
$oversized | Format-Table -AutoSize

Write-Host "`n=== MARKDOWN FILES OVER 10 KB (POTENTIAL READ/TOKEN RISK) ==="
$oversizedMd = $files | Where-Object { $_.Extension -eq '.md' -and $_.Length -gt 10240 } | Select-Object @{Name='Path'; Expression={$_.FullName.Substring($root.Length+1)}}, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}} | Sort-Object Length -Descending
$oversizedMd | Format-Table -AutoSize

Write-Host "`n=== UNTRACKED OR TEMPORARY SCRIPTS IN scripts/ ==="
$scripts = Get-ChildItem -Path "$root\scripts" -File | Select-Object Name, Length, LastWriteTime | Sort-Object LastWriteTime -Descending
Write-Host "Total files in scripts/: $($scripts.Count)"
$scripts | Format-Table -AutoSize
