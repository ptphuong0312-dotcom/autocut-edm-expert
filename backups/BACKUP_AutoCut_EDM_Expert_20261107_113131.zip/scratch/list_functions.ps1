$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$lines = $js -split "`r?`n"
$functions = @()

for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($line -match '^\s*(function\s+([a-zA-Z0-9_]+)|const\s+([a-zA-Z0-9_]+)\s*=\s*(async\s*)?\([^)]*\)\s*=>|const\s+([a-zA-Z0-9_]+)\s*=\s*function)') {
        $fnName = $Matches[2]
        if (-not $fnName) { $fnName = $Matches[3] }
        if (-not $fnName) { $fnName = $Matches[5] }
        $functions += [PSCustomObject]@{
            Line = $i + 1
            Name = $fnName
            Code = $line.Trim()
        }
    }
}

Write-Host "=== FUNCTIONS IN APP.JS ($($functions.Count)) ==="
$functions | Format-Table -AutoSize
