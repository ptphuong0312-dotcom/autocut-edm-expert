$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$lines = $js -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($line -match '(const|let|var)\s+(WS_|WORKSHOP_|EMPIRICAL_|BENCHMARK_|[A-Z0-9_]*DATA_BANK|[A-Z0-9_]*BENCHMARKS)') {
        Write-Host "Line $($i+1): $line"
    }
}
