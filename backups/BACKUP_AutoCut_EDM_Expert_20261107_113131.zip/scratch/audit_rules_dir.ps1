$root = (Get-Location).Path
$rules = Get-ChildItem -Path "$root\.agents\rules" -File | Select-Object Name, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}} | Sort-Object Name

Write-Host "=== .AGENTS/RULES/ AUDIT ($($rules.Count) files) ==="
$rules | Format-Table -AutoSize
