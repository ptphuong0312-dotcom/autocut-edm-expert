$root = (Get-Location).Path

$html = [System.IO.File]::ReadAllText("$root\index.html", [System.Text.Encoding]::UTF8)
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)
$css = [System.IO.File]::ReadAllText("$root\style.css", [System.Text.Encoding]::UTF8)
$sw = [System.IO.File]::ReadAllText("$root\sw.js", [System.Text.Encoding]::UTF8)
$vjson = [System.IO.File]::ReadAllText("$root\version.json", [System.Text.Encoding]::UTF8)

Write-Host "=== TAB BUTTONS IN INDEX.HTML ==="
$patternTabBtn = 'data-tab="([^"]+)"'
[regex]::Matches($html, $patternTabBtn) | ForEach-Object {
    Write-Host " Tab data-tab: $($_.Groups[1].Value)"
}

Write-Host "`n=== TAB CONTENT PANELS IN INDEX.HTML ==="
$patternTabPanels = 'id="(tab-[^"]+)"'
[regex]::Matches($html, $patternTabPanels) | ForEach-Object {
    Write-Host " Tab Panel ID: $($_.Groups[1].Value)"
}

Write-Host "`n=== VERSION STRINGS ACROSS FILES ==="
Write-Host "version.json: $vjson"

if ($html -match 'id="app-version"[^>]*>([^<]+)<') { Write-Host "index.html version badge: $($Matches[1])" }
if ($sw -match 'CACHE_NAME\s*=\s*[''"]([^''"]+)[''"]') { Write-Host "sw.js CACHE_NAME: $($Matches[1])" }
if ($js -match 'APP_VERSION\s*=\s*[''"]([^''"]+)[''"]') { Write-Host "app.js APP_VERSION: $($Matches[1])" }
if ($css -match 'v\d+\.\d+\.\d+') { Write-Host "style.css version mention: $($Matches[0])" }

Write-Host "`n=== APP.JS REFERENCES TO ELEMENT IDS IN INDEX.HTML ==="
$domIds = [System.Collections.Generic.HashSet[string]]::new()
$patternGetId = 'getElementById\([''"]([^''"]+)[''"]\)'
foreach ($m in [regex]::Matches($js, $patternGetId)) {
    [void]$domIds.Add($m.Groups[1].Value)
}

$missingIds = @()
foreach ($id in $domIds) {
    $search = 'id="' + $id + '"'
    $searchAlt = "id='$id'"
    if ($html.IndexOf($search) -lt 0 -and $html.IndexOf($searchAlt) -lt 0) {
        $missingIds += $id
    }
}
Write-Host "Total unique IDs referenced in app.js: $($domIds.Count)"
Write-Host "IDs in app.js that DO NOT EXIST in index.html ($($missingIds.Count)):"
$missingIds | ForEach-Object { Write-Host " - $_" }
