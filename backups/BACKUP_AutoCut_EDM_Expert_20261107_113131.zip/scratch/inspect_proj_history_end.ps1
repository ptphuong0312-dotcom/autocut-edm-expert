$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\PROJECT_HISTORY.md", [System.Text.Encoding]::UTF8)

$lines = $content -split "`r?`n"
Write-Host "Total lines in PROJECT_HISTORY.md: $($lines.Length)"
Write-Host "=== LAST 30 LINES ==="
for ($i = [Math]::Max(0, $lines.Length - 30); $i -lt $lines.Length; $i++) {
    Write-Host "$($i+1): $($lines[$i])"
}
