$root = (Get-Location).Path
$cssPath = "$root\style.css"
$css = [System.IO.File]::ReadAllText($cssPath, [System.Text.Encoding]::UTF8)

$oldPrint = '.control-panel, .header-actions, .app-footer, #btn-copy-table, .nav-tabs, .custom-input-box, .analysis-section, .modal-overlay {'
$newPrint = '.control-panel, .header-actions, .results-header-actions, .app-footer, #btn-copy-table, #ws-btn-copy-table, #ws-btn-reset-params, .nav-tabs, .custom-input-box, .analysis-section, .modal-overlay {'

$oldVer = 'v3.5.66'
$newVer = 'v3.5.67'

if ($css.Contains($oldPrint) -and $css.Contains($oldVer)) {
    $css = $css.Replace($oldPrint, $newPrint)
    $css = $css.Replace($oldVer, $newVer)
    [System.IO.File]::WriteAllText($cssPath, $css, [System.Text.Encoding]::UTF8)
    Write-Host "SUCCESS: style.css updated to v3.5.67 with print hide rules!"
} else {
    Write-Host "ERROR: Target not found in style.css"
    Write-Host "oldPrint: $($css.Contains($oldPrint))"
    Write-Host "oldVer: $($css.Contains($oldVer))"
}
