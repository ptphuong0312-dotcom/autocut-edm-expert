$root = (Get-Location).Path
$html = [System.IO.File]::ReadAllText("$root\index.html", [System.Text.Encoding]::UTF8)

Write-Host "=== INDEX.HTML OVERVIEW ==="
Write-Host "Length: $($html.Length) chars"

# Extract header, nav, sections
$matches = [regex]::Matches($html, '<section[^>]*id=["'']([^"'']+)["''][^>]*>')
Write-Host "`nSections found ($($matches.Count)):"
foreach ($m in $matches) {
    Write-Host " - $($m.Groups[1].Value)"
}

# Extract all elements with an id
$ids = [regex]::Matches($html, '\bid=["'']([^"'']+)["'']') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
Write-Host "`nTotal unique IDs in index.html: $($ids.Count)"
$ids | ForEach-Object { Write-Host " - $_" }
