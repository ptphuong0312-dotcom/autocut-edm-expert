$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\OPTIMIZATION_HISTORY.md", [System.Text.Encoding]::UTF8)
$lines = $content -split "`r?`n"

$legacyHeader = @(
"# OPTIMIZATION HISTORY LEGACY ARCHIVE (DOT 1 - DOT 50)",
"# DU AN: AUTOCUT SERVO EDM EXPERT (DK77 WIRE EDM)",
"*Owner: SirPhuong*",
"",
"---",
""
)
$legacyLines = $legacyHeader + $lines[61..301]
[System.IO.File]::WriteAllLines("$root\docs\archive\OPTIMIZATION_HISTORY_LEGACY.md", $legacyLines, [System.Text.Encoding]::UTF8)
Write-Host "Created docs/archive/OPTIMIZATION_HISTORY_LEGACY.md with $($legacyLines.Count) lines"

$header = @(
"# NHAT KY TOI UU HOA KY THUAT (OPTIMIZATION HISTORY)",
"# DU AN: AUTOCUT SERVO EDM EXPERT (DK77 WIRE EDM)",
"*Owner: SirPhuong*",
"*Legacy Archive: docs/archive/OPTIMIZATION_HISTORY_LEGACY.md*",
"",
"---",
""
)
$activeLines = $header + $lines[302..($lines.Length - 1)]
[System.IO.File]::WriteAllLines("$root\docs\OPTIMIZATION_HISTORY.md", $activeLines, [System.Text.Encoding]::UTF8)
Write-Host "Updated docs/OPTIMIZATION_HISTORY.md with $($activeLines.Count) lines"
