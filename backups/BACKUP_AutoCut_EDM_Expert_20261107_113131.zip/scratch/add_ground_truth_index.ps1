$root = (Get-Location).Path
$filePath = "$root\WORKSHOP_DATA_BANK.md"
$content = [System.IO.File]::ReadAllText($filePath, [System.Text.Encoding]::UTF8)

$table = [System.IO.File]::ReadAllText("$root\scratch\table_to_insert.md", [System.Text.Encoding]::UTF8)

$marker = "RAW DATA BANK"
$idx = $content.IndexOf($marker)
if ($idx -gt 0) {
    # Find start of that line (look backwards for ##)
    $lineStart = $content.LastIndexOf("##", $idx)
    $newContent = $content.Substring(0, $lineStart) + $table + "`r`n`r`n" + $content.Substring($lineStart)
    [System.IO.File]::WriteAllText($filePath, $newContent, [System.Text.Encoding]::UTF8)
    Write-Host "SUCCESS: Ground Truth Index Table inserted cleanly at position $lineStart"
} else {
    Write-Host "ERROR: Marker not found!"
}
