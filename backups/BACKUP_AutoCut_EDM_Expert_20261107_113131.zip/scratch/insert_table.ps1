$root = (Get-Location).Path
$path = "$root\WORKSHOP_DATA_BANK.md"
$text = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

# Find marker by regex looking for 'RAW DATA BANK'
$m = [regex]::Match($text, '##\s+PH[^\r\n]+RAW DATA BANK[^\r\n]*')
if ($m.Success) {
    Write-Host "Found marker at index: $($m.Index) -> $($m.Value)"
    $table = [System.IO.File]::ReadAllText("$root\scratch\table_to_insert.md", [System.Text.Encoding]::UTF8)
    
    $nl = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $newText = $text.Substring(0, $m.Index) + $table + $nl + $nl + $text.Substring($m.Index)
    [System.IO.File]::WriteAllText($path, $newText, [System.Text.Encoding]::UTF8)
    Write-Host "SUCCESS: Inserted Ground Truth Index table into WORKSHOP_DATA_BANK.md"
} else {
    Write-Host "ERROR: Regex match failed"
}
