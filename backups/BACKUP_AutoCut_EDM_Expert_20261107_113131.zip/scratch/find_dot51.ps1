$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\OPTIMIZATION_HISTORY.md", [System.Text.Encoding]::UTF8)

$lines = $content -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match '### 🚀 ĐỢT 51') {
        Write-Host "Found ĐỢT 51 at line $($i+1)"
        for ($j = [Math]::Max(0, $i - 3); $j -lt [Math]::Min($lines.Length, $i + 15); $j++) {
            Write-Host "$($j+1): $($lines[$j])"
        }
        break
    }
}
