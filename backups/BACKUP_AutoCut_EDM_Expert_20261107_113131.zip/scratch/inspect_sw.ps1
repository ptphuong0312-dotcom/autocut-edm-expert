$root = (Get-Location).Path
$sw = [System.IO.File]::ReadAllText("$root\sw.js", [System.Text.Encoding]::UTF8)

Write-Host "=== SW.JS FULL CONTENT ==="
$sw
