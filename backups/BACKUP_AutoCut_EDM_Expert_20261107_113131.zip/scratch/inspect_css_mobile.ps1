$root = (Get-Location).Path
$css = [System.IO.File]::ReadAllText("$root\style.css", [System.Text.Encoding]::UTF8)

# Check media queries in style.css
$matches = [regex]::Matches($css, '@media[^{]+\{')
Write-Host "=== MEDIA QUERIES IN STYLE.CSS ($($matches.Count)) ==="
foreach ($m in $matches) {
    Write-Host " - $($m.Value.Trim())"
}

# Check styles for #ws-quick-chips and .chip-container
$lines = $css -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'ws-quick-chips|\.chip-container|\.table-responsive|\.col-offset-cell') {
        Write-Host "Line $($i+1): $($lines[$i])"
    }
}
