$root = (Get-Location).Path

$files = Get-ChildItem -Path $root -Recurse -File | Where-Object { 
    $_.FullName -notmatch '\\\.git\\' -and 
    $_.FullName -notmatch '\\backups\\' -and 
    $_.FullName -notmatch '\\scratch\\' -and
    $_.FullName -notmatch '\\node_modules\\' -and
    ($_.Extension -in @('.js', '.html', '.css', '.json', '.md'))
}

# Regex using Unicode escapes:
# \u00C3 (Ã), \u00C2 (Â), \u00C4 (Ä) followed by high bytes
# \u00E1\u00BA (áº), \u00E1\u00BB (á»)
$pattern = '[\u00C2\u00C3\u00C4][\u0080-\u00BF]|\u00E1[\u00BA\u00BB]|C\u00E1o'

Write-Host "=== CHECKING FOR MOJIBAKE / ENCODING CORRUPTION ==="
$corruptedFiles = @()
foreach ($f in $files) {
    $content = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
    if ($content -match $pattern) {
        $corruptedFiles += [PSCustomObject]@{
            File = $f.FullName.Substring($root.Length+1)
            Match = $Matches[0]
        }
    }
}

if ($corruptedFiles.Count -eq 0) {
    Write-Host "SUCCESS: Zero mojibake patterns detected in active project files."
} else {
    Write-Host "WARNING: Mojibake detected in $($corruptedFiles.Count) files:"
    $corruptedFiles | Format-Table -AutoSize
}
