$root = (Get-Location).Path
$mf = [System.IO.File]::ReadAllText("$root\manifest.json", [System.Text.Encoding]::UTF8)

Write-Host "=== MANIFEST.JSON CONTENT ==="
$mf
