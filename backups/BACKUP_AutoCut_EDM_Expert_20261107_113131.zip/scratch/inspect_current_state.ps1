$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\CURRENT_STATE.md", [System.Text.Encoding]::UTF8)

Write-Host "=== CURRENT_STATE.MD PREVIEW ==="
$content
