$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$nullRisks = @(
 'strategySlider', 'strategyLevelBadge', 'strategyNameDisplay', 'strategyBadgeDisplay',
 'strategyDescDisplay', 'thicknessInput', 'thicknessSlider', 'cutLengthInput', 'totalTimeText',
 'configSummary', 'tableBody', 'noticeList', 'btnCopyTable', 'btnModeCustom', 'btnModeTheory',
 'customModeHint', 'analysisTableTitle', 'btnAnalyzeCustom', 'customTiInput', 'customPoInput',
 'customIpInput', 'customVoltInput', 'customVfInput', 'customWireInput', 'wsBtnAnalyzeCustom',
 'wsCustomTiInput', 'wsCustomPoInput', 'wsCustomIpInput', 'wsCustomVoltInput', 'wsCustomVfInput',
 'wsCustomWireInput', 'analysisContainer', 'comparisonTableElement', 'analysisFeedbackBox',
 'wsAnalysisFeedbackBox', 'btnToggleCompact', 'compactText', 'btnToggleWorkshop',
 'workshopBody', 'workshopToggleStatus', 'workshopTableElement'
)

$lines = $js -split "`r?`n"
$foundCalls = @()

for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($i -lt 165) { continue } # skip declarations
    foreach ($var in $nullRisks) {
        # Check if used with . (e.g. var.addEventListener, var.value, var.innerHTML) without if(var)
        if ($line -match "\b$var\.[a-zA-Z]") {
            $foundCalls += "Line $($i+1): $line"
        }
    }
}

Write-Host "=== DIRECT PROPERTY ACCESSES ON POTENTIALLY NULL DOM ELEMENTS: $($foundCalls.Count) ==="
$foundCalls | Select-Object -First 30 | ForEach-Object { Write-Host $_ }
if ($foundCalls.Count -gt 30) {
    Write-Host "... and $($foundCalls.Count - 30) more"
}
