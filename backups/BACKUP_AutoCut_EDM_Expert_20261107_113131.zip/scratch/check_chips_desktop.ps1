$root = (Get-Location).Path
$css = [System.IO.File]::ReadAllText("$root\style.css", [System.Text.Encoding]::UTF8)

$lines = $css -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match '#ws-quick-chips') {
        Write-Host "Line $($i+1): $($lines[$i])"
        for ($j = [Math]::Max(0, $i - 2); $j -lt [Math]::Min($lines.Length, $i + 15); $j++) {
            Write-Host "  $($j+1): $($lines[$j])"
        }
    }
}
