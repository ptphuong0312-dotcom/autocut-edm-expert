$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$lines = $js -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'btnPrint|window\.print') {
        Write-Host "Found at line $($i+1):"
        for ($j = [Math]::Max(0, $i - 3); $j -lt [Math]::Min($lines.Length, $i + 15); $j++) {
            Write-Host "  $($j+1): $($lines[$j])"
        }
    }
}
