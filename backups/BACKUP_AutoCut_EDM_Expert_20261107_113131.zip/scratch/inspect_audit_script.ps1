$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\scripts\audit_spark_gap.ps1", [System.Text.Encoding]::UTF8)

Write-Host "=== SCRIPTS/AUDIT_SPARK_GAP.PS1 PREVIEW (first 50 lines) ==="
$lines = $content -split "`r?`n"
for ($i = 0; $i -lt [Math]::Min(50, $lines.Length); $i++) {
    Write-Host "$($i+1): $($lines[$i])"
}
