$root = (Get-Location).Path
$skills = Get-ChildItem -Path "$root\.agents\skills" -Recurse -File | Select-Object @{Name='Path'; Expression={$_.FullName.Substring($root.Length+1)}}, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}}

Write-Host "=== .AGENTS/SKILLS/ AUDIT ($($skills.Count) files) ==="
$skills | Format-Table -AutoSize
