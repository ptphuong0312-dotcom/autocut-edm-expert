$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

# Extract core physics calculation logic from app.js to run test sweep in PowerShell
# Check for NaN, undefined, negative offsets, or crashes across parameter matrix

Write-Host "=== AUDITING app.js FOR MATHEMATICAL INTEGRITY & EDGE CASES ==="

# Check all occurrences of divide / or Math.pow / Math.sqrt in app.js
$lines = $js -split "`r?`n"
$divOccurrences = @()
for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($line -match '/\s*([a-zA-Z0-9_]+)' -and $line -notmatch '//' -and $line -notmatch '/\*' -and $line -notmatch '<td') {
        $denom = $Matches[1]
        if ($denom -in @('Po', 'po', 'Poff', 'H', 'thickness', 'cutLength', 'speed', 'IP', 'ip')) {
            $divOccurrences += "Line $($i+1): $line (Div by: $denom)"
        }
    }
}
Write-Host "Potential Division-by-Zero locations found: $($divOccurrences.Count)"
$divOccurrences | Select-Object -First 15 | ForEach-Object { Write-Host " - $_" }
