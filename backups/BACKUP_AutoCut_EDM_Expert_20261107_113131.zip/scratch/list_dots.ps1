$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\OPTIMIZATION_HISTORY.md", [System.Text.Encoding]::UTF8)

$lines = $content -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match '^###\s+(.*)') {
        Write-Host "Line $($i+1): $($lines[$i])"
    }
}
