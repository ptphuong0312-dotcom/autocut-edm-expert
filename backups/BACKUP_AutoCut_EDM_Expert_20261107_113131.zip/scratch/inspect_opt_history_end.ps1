$root = (Get-Location).Path
$content = [System.IO.File]::ReadAllText("$root\docs\OPTIMIZATION_HISTORY.md", [System.Text.Encoding]::UTF8)

$lines = $content -split "`r?`n"
Write-Host "Total lines in OPTIMIZATION_HISTORY.md: $($lines.Length)"
Write-Host "=== LAST 40 LINES ==="
for ($i = [Math]::Max(0, $lines.Length - 40); $i -lt $lines.Length; $i++) {
    Write-Host "$($i+1): $($lines[$i])"
}
