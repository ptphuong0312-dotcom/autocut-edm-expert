$root = (Get-Location).Path
$indexPath = "$root\index.html"
$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)

$html = $html.Replace('style.css?v=3.5.66', 'style.css?v=3.5.67')
$html = $html.Replace('app.js?v=3.5.66', 'app.js?v=3.5.67')
$html = $html.Replace('id="app-version-display">v3.5.66', 'id="app-version-display">v3.5.67')
[System.IO.File]::WriteAllText($indexPath, $html, [System.Text.Encoding]::UTF8)
Write-Host "SUCCESS: index.html updated to v3.5.67"

$verJsonPath = "$root\version.json"
$newJson = @'
{
  "version": "3.5.67",
  "buildTimestamp": 1794027500000,
  "releaseDate": "2026-11-07",
  "description": "Nâng cấp Hệ thống Bộ Não Tri Thức Master, Sổ tay Quy chuẩn docs/rules, Khóa cơ học [SPEC-LOCK], tính động Hz Vùng 2 và PWA Offline hoàn hảo."
}
'@
[System.IO.File]::WriteAllText($verJsonPath, $newJson, [System.Text.Encoding]::UTF8)
Write-Host "SUCCESS: version.json updated to 3.5.67"
