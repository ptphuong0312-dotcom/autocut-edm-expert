$root = (Get-Location).Path
$path = "$root\docs\PROJECT_HISTORY.md"
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)

$append = @"
| **v3.5.49** | 2026-10-31 | Phân tách tính riêng thép SCM420 & SCM440 trong Tab 3 | `autocut_2026-10-31(89).zip` |
| **v3.5.50** | 2026-11-01 | Tích hợp bài cắt STT 22 (H=12mm SCM420 chày Volt Low, Offset 0.095mm) | `autocut_2026-11-01(90).zip` |
| **v3.5.51** | 2026-11-02 | Tích hợp bài cắt STT 23 (H=200mm SCM420 cối, Offset 0.108mm) | `autocut_2026-11-02(91).zip` |
| **v3.5.54** | 2026-11-03 | Tối ưu hóa đa vòng SCM420 Vòng 5 cân bằng động học toàn cầu | `autocut_2026-11-03(92).zip` |
| **v3.5.56** | 2026-11-05 | Loại bỏ Tab 1 cũ, tái cấu trúc 3 Tab, nâng cấp Cẩm nang EDM & Ampe Vòng 5 | `autocut_2026-11-05(93).zip` |
| **v3.5.58** | 2026-11-06 | Chia bảng 2 Vùng dọc can thiệp trực tiếp, nút Trở Về Mặc Định & nạp thông số | `autocut_2026-11-06(94).zip` |
| **v3.5.60** | 2026-11-06 | Khắc phục cú pháp hàm sao chép, bổ sung kiểm thử Browser Headless | `autocut_2026-11-06(95).zip` |
| **v3.5.62** | 2026-11-06 | Mô hình toán - vật lý nhiệt động học Vòng 6 tối ưu hội tụ Fc thực & Fc máy | `autocut_2026-11-06(96).zip` |
| **v3.5.63** | 2026-11-07 | Tinh gọn 2 Tab hiện hành, loại bỏ Tab 2 cũ (nhập thông số), tối ưu Mobile | `autocut_2026-11-07(97).zip` |
| **v3.5.64** | 2026-11-07 | Tinh gọn 2 khung thông số, chuyển Offset về Vùng 2, phím chọn nhanh 200mm | `autocut_2026-11-07(98).zip` |
| **v3.5.66** | 2026-11-07 | Chuẩn hóa định dạng xuất / copy thông số có dòng trống giữa các Pass | `autocut_2026-11-07(99).zip` |
| **v3.5.67** | 2026-11-07 | Nâng cấp Bộ Não Master, 6 Sổ tay docs/rules, Khóa cơ học [SPEC-LOCK], Hz động & Gatekeeper | `autocut_2026-11-07(100).zip` |
"@

$nl = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$newContent = $content.TrimEnd() + $nl + $append.Trim() + $nl
[System.IO.File]::WriteAllText($path, $newContent, [System.Text.Encoding]::UTF8)
Write-Host "SUCCESS: PROJECT_HISTORY.md updated with recent versions up to v3.5.67!"
