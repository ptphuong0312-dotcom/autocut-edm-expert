$root = (Get-Location).Path
$js = [System.IO.File]::ReadAllText("$root\app.js", [System.Text.Encoding]::UTF8)

$lines = $js -split "`r?`n"
for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if ($line -match '\bWORKSHOP_EMPIRICAL_LIBRARY\b') {
        Write-Host "Line $($i+1): $line"
    }
}
