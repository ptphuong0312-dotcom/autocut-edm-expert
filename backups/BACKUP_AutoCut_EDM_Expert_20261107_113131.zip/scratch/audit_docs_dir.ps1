$root = (Get-Location).Path
$docs = Get-ChildItem -Path "$root\docs" -File | Select-Object Name, Length, @{Name='Lines'; Expression={(Get-Content $_.FullName | Measure-Object -Line).Lines}} | Sort-Object Length -Descending

Write-Host "=== DOCS/ DIRECTORY AUDIT ($($docs.Count) files) ==="
$docs | Format-Table -AutoSize
