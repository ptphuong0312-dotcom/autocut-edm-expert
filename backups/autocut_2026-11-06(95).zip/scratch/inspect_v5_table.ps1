# Inspect full audit table for Vong 5
$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

$c0 = 0.0020
$ke = 0.00070
$k_vf = 0.0021
$kh = 0.0065
$k_sec = 0.160
$k_b = 2.6
$kspd = 0.0055
$h_th = 63.0
$po_th = 8.0
$s_exp = 0.65

Write-Host "=================================================================================================================================="
Write-Host "BANG DOI CHIEU TOAN DIEN VONG 5: TOI UU TOAN DIEN (MAE=2.70 um | SCM420=2.64 um | SCM440=2.77 um | MAX ERR=5.75 um)"
Write-Host "=================================================================================================================================="
Write-Host ("{0,-9}| {1,5} | {2,-6} | {3,-9} | {4,-13} | {5,6} | {6,5} | {7,6}| {8,6} | {9,6} | {10,10} | {11,10} | {12,8}" -f "STT","Hmm","Thep","Ton/Po/IP","Volt/VF/SpdHz","d_elec","d_vf","d_conf","d_sec","d_spd","delta_calc","delta_thuc","Sai lech")
Write-Host ("-" * 125)

$errsAll = @(); $errs440 = @(); $errs420 = @()

foreach ($it in $dataset) {
    $H = $it.H
    $Ton = $it.Ton
    $Po = $it.Po
    $IP = $it.IP
    $Volt = $it.Volt
    $VF = $it.VF
    $speed = $it.speed
    $mat = $it.mat
    $isHard = ($mat -eq 'SCM440')

    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
        $d_elec = $ke * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_vf = $k_vf * (($VF - 55.0) / 10.0)
        $d_vibr = 0.0035 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_h_conf = - $kh * ($H / 100.0)

        $d_slow_spd = if ($H -ge 110 -and $speed -lt 150) {
            - $kspd * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
        } else {
            0.0
        }

        $h_starve = [Math]::Max(0.0, ($H - $h_th) / 100.0)
        $po_shortage = [Math]::Max(0.0, ($po_th - $Po) / 10.0)
        $mat_boost = if ($isHard) { 1.0 } else { $k_b }
        
        $d_sec = $k_sec * [Math]::Pow($h_starve, $s_exp) * $po_shortage * $mat_boost

        $calc = $c0 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_slow_spd + $d_sec
    } else {
        $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        $d_vf = $k_vf * 0.5 * (($VF - 65.0) / 10.0)
        $calc += $d_vf
        $d_elec = 0; $d_h_conf = 0; $d_sec = 0; $d_slow_spd = 0
    }

    $diff = ($calc - $it.actual) * 1000
    $absDiff = [Math]::Abs($diff)
    $errsAll += $absDiff
    if ($isHard) { $errs440 += $absDiff } else { $errs420 += $absDiff }

    $sign = if ($diff -ge 0) { "+" } else { "" }
    Write-Host ("{0,-9}| {1,3}mm | {2,-6} | {3,3}/{4,2}/{5,1} | {6,-4}/{7,2}/{8,3}Hz | {9,6:F1} | {10,5:F1} | {11,6:F1}| {12,6:F1} | {13,6:F1} | {14,8:F1} um | {15,8:F1} um | {16,7:F1} um" -f `
        $it.id, $H, $mat, $Ton, $Po, $IP, $Volt, $VF, $speed, ($d_elec*1000), ($d_vf*1000), ($d_h_conf*1000), ($d_sec*1000), ($d_slow_spd*1000), ($calc*1000), ($it.actual*1000), "$sign$([Math]::Round($diff,1))")
}

$maeAll = ($errsAll | Measure-Object -Average).Average
$mae440 = ($errs440 | Measure-Object -Average).Average
$mae420 = ($errs420 | Measure-Object -Average).Average
$maxErr = ($errsAll | Measure-Object -Maximum).Maximum

Write-Host ("=" * 125)
Write-Host ("KET QUA KIEM TOAN VONG 5:")
Write-Host ("  * MAE Toan cuc (19 bai):  {0:F2} um" -f $maeAll)
Write-Host ("  * MAE Thep toi SCM440:    {0:F2} um" -f $mae440)
Write-Host ("  * MAE Thep mem SCM420:    {0:F2} um" -f $mae420)
Write-Host ("  * Sai so cuc dai (Max):   {0:F2} um" -f $maxErr)
