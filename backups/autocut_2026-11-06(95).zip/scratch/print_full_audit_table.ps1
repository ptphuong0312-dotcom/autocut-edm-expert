# Print full audit table for the 4.70 um model
$c0 = 0.0026
$k_elec = 0.00072
$k_vf = 0.0021
$k_h_conf = 0.0075
$k_sec = 0.0350
$k_spd_deep = 0.0055

$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

Write-Host "=================================================================================================================================="
Write-Host "BANG DOI CHIEU TOAN DIEN 19 BAI CAT: MO HINH TOI UU TOAN CUC (MAE = 4.70 um | MAX ERROR = 10.57 um)"
Write-Host "=================================================================================================================================="
Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2}/{8,3}Hz | d_elec | d_vf  | d_conf| d_sec | d_spd | delta_calc | delta_thuc | Sai lech" -f "STT", "H", "Thep", "Ton", "Po", "IP", "Volt", "VF", "Spd")
Write-Host ("-" * 135)

foreach ($it in $dataset) {
    $H = $it.H
    $Ton = $it.Ton
    $Po = $it.Po
    $IP = $it.IP
    $Volt = $it.Volt
    $VF = $it.VF
    $speed = $it.speed
    $mat = $it.mat
    $isHard = ($mat -eq 'SCM440')

    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
        $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_vf = $k_vf * (($VF - 55.0) / 10.0)
        $d_vibr = 0.0035 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_h_conf = - $k_h_conf * ($H / 100.0)

        $d_spd_deep = if ($H -ge 110 -and $speed -lt 150) {
            - $k_spd_deep * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
        } else {
            0.0
        }

        $po_factor = [Math]::Max(0.0, (8.5 - $Po) / 10.0)
        $mat_k = if ($isHard) { 1.0 } else { 1.45 }
        $d_sec = $k_sec * [Math]::Pow($H / 100.0, 1.3) * $po_factor * $mat_k

        $calc = $c0 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_spd_deep + $d_sec
    } else {
        $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        $d_vf = $k_vf * 0.5 * (($VF - 65.0) / 10.0)
        $calc += $d_vf
        $d_elec = 0; $d_h_conf = 0; $d_sec = 0; $d_spd_deep = 0
    }

    $diff = ($calc - $it.actual) * 1000
    $sign = if ($diff -ge 0) { '+' } else { '' }

    Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2}/{8,3}Hz | {9,5:F1}  | {10,5:F1} | {11,5:F1} | {12,5:F1} | {13,5:F1} | {14,7:F1} um | {15,7:F1} um | {16,7} um" -f `
        $it.id, $H, $mat, $Ton, $Po, $IP, $Volt, $VF, $speed, ($d_elec*1000), ($d_vf*1000), ($d_h_conf*1000), ($d_sec*1000), ($d_spd_deep*1000), ($calc*1000), ($it.actual*1000), ($sign + $diff.ToString("F1")))
}
