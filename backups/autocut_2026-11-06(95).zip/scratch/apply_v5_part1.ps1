# ==============================================================================
# SCRIPT CAP NHAT TOAN DIEN VONG 5 (CHOICE A) VAO APP.JS & HE THONG
# ==============================================================================

$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)

# 1. Thay the khoi constants tai dong 2191-2203
$newConstants = @(
'        // 1.5. HỆ THỐNG CÔNG THỨC TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC EDM TOÀN NĂNG (RULE 10 - VÒNG 5 CÂN BẰNG TOÀN CẦU)'
'        // Hiệu chuẩn tinh chỉnh từ toàn bộ Ngân hàng Dữ liệu Thực nghiệm Xưởng (Tối ưu hóa SCM420 & SCM440)'
'        const C0 = 0.00200;          // Hằng số màng cách điện ion hóa ban đầu (+2.00 μm)'
'        const K_ELEC = 0.00070;      // Năng lượng xung đơn tối ưu (mm/sqrt(us*A))'
'        const K_VF = 0.00210;        // Hệ số bù trễ bước tiến VF (+2.10 μm / 10 vạch VF so với chuẩn 55)'
'        const K_VIBR = 0.00350;      // Hệ số mở rộng kerf do rung uốn cơ học dây Moly'
'        const K_H_CONF = 0.00650;    // Hệ số giới hạn áp lực thủy tĩnh rãnh sâu phôi cao (mm)'
'        const K_SPD = 0.00550;       // Hệ số bù giảm tốc phôi sâu (Speed < 150Hz khi H >= 110mm)'
'        const K_SEC_BASE = 0.160;    // Hệ số đánh lửa thứ cấp theo mạt xỉ dẻo tích tụ (mm)'
'        const K_RZ = 0.00120;        // Hệ số chiều sâu hố rỗ nhấp nhô phá thô Pass 1'
'        const H_THRESH = 63.0;       // Ngưỡng thấu vòi phun kép (H <= 63mm xối sạch phoi, H > 63mm mới sinh nghẽn phoi)'
'        const PO_THRESH = 8.0;       // Ngưỡng chu kỳ nghỉ Po xả phoi (Po <= 7 sinh nghẽn mạt xỉ)'
'        const S_EXP = 0.65;          // Lũy thừa suy giảm độ sâu rãnh nén mạt xỉ'
)

# Kiem tra vi tri dong 2191 (index 2190)
Write-Host "Dong 2191 goc: $($lines[2190])"

# Thay the lines[2190..2202] bang $newConstants
$linesNew = [System.Collections.Generic.List[string]]::new($lines)
$linesNew.RemoveRange(2190, 13)
$linesNew.InsertRange(2190, $newConstants)

[System.IO.File]::WriteAllLines("app.js", $linesNew, [System.Text.Encoding]::UTF8)
Write-Host "Updated constants in generateWorkshopRows successfully!"
