$appPath = "app.js"
$content = [System.IO.File]::ReadAllText($appPath, [System.Text.Encoding]::UTF8)
$contentNorm = $content.Replace("`r`n", "`n")

$target1 = @"
        // 1.5. HỆ THỐNG CÔNG THỨC TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC EDM TOÀN NĂNG (RULE 10)
        // Hiệu chuẩn tinh chỉnh từ toàn bộ Ngân hàng Dữ liệu Thực nghiệm Xưởng
        const C0 = 0.00200;          // Hằng số màng cách điện ion hóa ban đầu (+2.00 μm)
        const K_ELEC = 0.00070;      // Năng lượng xung đơn tối ưu (mm/sqrt(us*A))
        const DELTA_LOW = 0.00450;   // Hiệu ứng màng điện môi khi chạy điện áp thấp Volt Low
        const K_SLAG = 0.02000;      // Nén xỉ rãnh sâu tối ưu (mm)
        const K_VIBR = 0.00390;      // Hệ số mở rộng kerf do rung uốn cơ học dây Moly
        const K_RZ = 0.00120;        // Hệ số chiều sâu hố rỗ nhấp nhô phá thô Pass 1
        const K_VF = 0.00210;        // Hệ số bù trễ bước tiến VF (+2.10 μm / 10 vạch VF so với chuẩn 55)
        const K_PO = 0.00120;        // Hệ số chu kỳ & xả xỉ Po (mm / 10 nấc Po lệch so với chuẩn 5)
        const K_SEC = 0.00400;       // Hệ số đánh lửa thứ cấp theo mật độ mùn xỉ tích tụ (mm)
        const S_THRESH = 0.20;       // Ngưỡng mật độ mùn xỉ kích hoạt đánh lửa thứ cấp
        const slag_mat = isHard ? 1.0 : 0.80; // SCM420 phoi bết dính nhưng cào thoáng hơn (+1.8 - 4μm), giảm độ ghìm xỉ
"@
$target1Norm = $target1.Replace("`r`n", "`n").Trim()

Write-Host "Target 1 found with LF normalization: $($contentNorm.Contains($target1Norm))"
