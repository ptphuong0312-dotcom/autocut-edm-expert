# Print detailed SCM420 breakdown with the refined parameters
$scm420_data = @(
    @{ id='STT 22'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; actual=0.0050; desc='Chay Low 150Hz' },
    @{ id='STT 3';  H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; actual=0.0050; desc='Chay 150Hz' },
    @{ id='STT 18'; H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; actual=0.0080; desc='Chay 150Hz' },
    @{ id='STT 16'; H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0220; desc='Coi 187Hz' },
    @{ id='STT 21'; H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0280; desc='Coi 150Hz' },
    @{ id='STT 19'; H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; actual=0.0150; desc='Chay 150Hz' },
    @{ id='STT 7';  H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; actual=0.0050; desc='Chay 50Hz' },
    @{ id='STT 12'; H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; actual=0.0120; desc='Chay 100Hz' },
    @{ id='STT 15'; H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; actual=0.0300; desc='Coi 154Hz' },
    @{ id='STT 23'; H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; actual=0.0180; desc='Coi sieu day 60Hz' }
)

$c0 = 0.0020
$k_elec = 0.00070
$d_low = 0.0020
$k_vf = 0.0021
$k_h_conf = 0.0050
$k_sec = 0.1000
$k_deep = 0.0050

Write-Host "=========================================================================================================================="
Write-Host "CHI TIET PHAN TICH TINH CHINH CHO SCM420 (HB < 200)"
Write-Host "=========================================================================================================================="
Write-Host ("{0,-8} | {1,3}mm | Ton/Po/IP | Volt/VF | d_elec | d_conf | d_sec | d_deep | delta_calc | delta_thuc | Sai lech" -f "STT", "H")
Write-Host ("-" * 115)

foreach ($it in $scm420_data) {
    $H = $it.H
    $Ton = $it.Ton
    $Po = $it.Po
    $IP = $it.IP
    $Volt = $it.Volt
    $VF = $it.VF

    $u_ratio = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
    $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
    $d_low_val = if ($Volt -eq 'Low') { $d_low } else { 0.0 }
    $d_vf_val = $k_vf * (($VF - 55.0) / 10.0)
    
    $d_conf = - $k_h_conf * ($H / 100.0)
    $d_deep_slag = if ($H -gt 100) { - $k_deep * [Math]::Pow(($H - 100) / 100.0, 1.5) } else { 0.0 }
    $po_defect = [Math]::Max(0.0, (8.0 - $Po) / 10.0)
    $d_secondary = $k_sec * [Math]::Pow($H / 100.0, 1.5) * $po_defect

    if ($H -le 170) {
        $calc = $c0 + $d_elec + $d_low_val + $d_vf_val + $d_conf + $d_deep_slag + $d_secondary
    } else {
        $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }

    $diff = ($calc - $it.actual) * 1000
    $sign = if ($diff -ge 0) { '+' } else { '' }

    Write-Host ("{0,-8} | {1,3}mm | {2,3}/{3,2}/{4}  | {5,-4}/{6,2} | {7,5:F1}  | {8,6:F1} | {9,5:F1} | {10,6:F1} | {11,7:F1} um | {12,7:F1} um | {13,7} um" -f `
        $it.id, $H, $Ton, $Po, $IP, $Volt, $VF, ($d_elec*1000), ($d_conf*1000), ($d_secondary*1000), ($d_deep_slag*1000), ($calc*1000), ($it.actual*1000), ($sign + $diff.ToString("F1")))
}
