$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
for ($i = 4315; $i -le 4385; $i++) {
    Write-Host "$($i + 1): [$($lines[$i])]"
}
