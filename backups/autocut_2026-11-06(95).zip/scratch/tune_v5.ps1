$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

function Eval-Params($c0, $ke, $kh, $k_sec, $k_b, $kspd, $h_th, $po_th, $s_exp) {
    $errsAll = @(); $errs440 = @(); $errs420 = @()
    foreach ($it in $dataset) {
        $H = $it.H; $Ton = $it.Ton; $Po = $it.Po; $IP = $it.IP; $Volt = $it.Volt; $VF = $it.VF; $speed = $it.speed; $mat = $it.mat
        $isHard = ($mat -eq 'SCM440')
        if ($H -le 170) {
            $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
            $d_elec = $ke * [Math]::Sqrt($Ton * $IP) * $u_ratio
            $d_vf = 0.0021 * (($VF - 55.0) / 10.0)
            $d_vibr = 0.0035 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
            $d_h_conf = - $kh * ($H / 100.0)
            $d_slow_spd = if ($H -ge 110 -and $speed -lt 150) {
                - $kspd * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
            } else { 0.0 }
            $h_starve = [Math]::Max(0.0, ($H - $h_th) / 100.0)
            $po_shortage = [Math]::Max(0.0, ($po_th - $Po) / 10.0)
            $mat_boost = if ($isHard) { 1.0 } else { $k_b }
            $d_sec = $k_sec * [Math]::Pow($h_starve, $s_exp) * $po_shortage * $mat_boost
            $calc = $c0 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_slow_spd + $d_sec
        } else {
            $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
            $calc += 0.0021 * 0.5 * (($VF - 65.0) / 10.0)
        }
        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errsAll += $diff
        if ($isHard) { $errs440 += $diff } else { $errs420 += $diff }
    }
    $maeAll = ($errsAll | Measure-Object -Average).Average
    $mae440 = ($errs440 | Measure-Object -Average).Average
    $mae420 = ($errs420 | Measure-Object -Average).Average
    $maxErr = ($errsAll | Measure-Object -Maximum).Maximum
    return @{ MAE=$maeAll; MAE440=$mae440; MAE420=$mae420; MaxErr=$maxErr }
}

$best_v5 = @{ MaxErr=999; MAE=999 }
for ($kspd = 0.0050; $kspd -le 0.0075; $kspd += 0.0005) {
    for ($k_sec = 0.140; $k_sec -le 0.170; $k_sec += 0.010) {
        for ($k_b = 2.4; $k_b -le 3.2; $k_b += 0.2) {
            for ($s_exp = 0.65; $s_exp -le 0.85; $s_exp += 0.05) {
                for ($c0 = 0.0020; $c0 -le 0.0024; $c0 += 0.0002) {
                    for ($ke = 0.00070; $ke -le 0.00074; $ke += 0.00002) {
                        for ($kh = 0.0060; $kh -le 0.0075; $kh += 0.0005) {
                            $res = Eval-Params $c0 $ke $kh $k_sec $k_b $kspd 63.0 8.0 $s_exp
                            # Score balancing MAE and MaxErr
                            $score = $res.MAE * 0.4 + $res.MAE420 * 0.3 + $res.MaxErr * 0.3
                            $curr_best_score = $best_v5.MAE * 0.4 + $best_v5.MAE420 * 0.3 + $best_v5.MaxErr * 0.3
                            if ($score -lt $curr_best_score) {
                                $best_v5 = $res
                                $best_v5.c0 = $c0; $best_v5.ke = $ke; $best_v5.kh = $kh
                                $best_v5.k_sec = $k_sec; $best_v5.k_b = $k_b; $best_v5.kspd = $kspd; $best_v5.s_exp = $s_exp
                            }
                        }
                    }
                }
            }
        }
    }
}

Write-Host ("BEST V5: MAE_All={0:F2} | SCM440={1:F2} | SCM420={2:F2} | MaxErr={3:F2}" -f $best_v5.MAE, $best_v5.MAE440, $best_v5.MAE420, $best_v5.MaxErr)
Write-Host ("Params: c0={0} ke={1} kh={2} k_sec={3} k_b={4} kspd={5} s_exp={6}" -f $best_v5.c0, $best_v5.ke, $best_v5.kh, $best_v5.k_sec, $best_v5.k_b, $best_v5.kspd, $best_v5.s_exp)
