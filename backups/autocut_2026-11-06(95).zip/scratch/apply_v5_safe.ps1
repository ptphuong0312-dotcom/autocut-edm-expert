# Pure ASCII script to update app.js cleanly
$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)

# 1. Update constants in generateWorkshopRows (lines 2191-2203, 0-indexed: 2190..2202)
Write-Host "Line 2191: $($lines[2190])"

$lines[2190] = '        // 1.5. HE THONG CONG THUC TOAN - VAT LY NHIET DONG HOC EDM TOAN NANG (RULE 10 - VONG 5 CAN BANG TOAN CAU)'
$lines[2191] = '        // Hieu chuan tinh chinh tu toan bo Ngan hang Du lieu Thuc nghiem Xuong (Toi uu hoa SCM420 & SCM440)'
$lines[2192] = '        const C0 = 0.00200;          // Hang so mang cach dien ion hoa ban dau (+2.00 um)'
$lines[2193] = '        const K_ELEC = 0.00070;      // Nang luong xung don toi uu (mm/sqrt(us*A))'
$lines[2194] = '        const K_VF = 0.00210;        // He so bu tre buoc tien VF (+2.10 um / 10 vach VF so voi chuan 55)'
$lines[2195] = '        const K_VIBR = 0.00350;      // He so mo rong kerf do rung uon co hoc day Moly'
$lines[2196] = '        const K_H_CONF = 0.00650;    // He so gioi han ap luc thuy tinh ranh sau phoi cao (mm)'
$lines[2197] = '        const K_SPD = 0.00550;       // He so bu giam toc phoi sau (Speed < 150Hz khi H >= 110mm)'
$lines[2198] = '        const K_SEC_BASE = 0.160;    // He so danh lua thu cap theo mat xi deo tich tu (mm)'
$lines[2199] = '        const K_RZ = 0.00120;        // He so chieu sau ho ro nhap nho pha tho Pass 1'
$lines[2200] = '        const H_THRESH = 63.0;       // Nguong thau voi phun kep (H <= 63mm xoi sach phoi, H > 63mm moi sinh nghen phoi)'
$lines[2201] = '        const PO_THRESH = 8.0;       // Nguong chu ky nghi Po xa phoi (Po <= 7 sinh nghen mat xi)'
$lines[2202] = '        const S_EXP = 0.65;          // Luy thua suy giam do sau ranh nen mat xi'

[System.IO.File]::WriteAllLines("app.js", $lines, [System.Text.Encoding]::UTF8)
Write-Host "Updated constants successfully!"
