$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
for ($i = 2335; $i -le 2360; $i++) {
    Write-Host "$($i + 1): [$($lines[$i])]"
}
