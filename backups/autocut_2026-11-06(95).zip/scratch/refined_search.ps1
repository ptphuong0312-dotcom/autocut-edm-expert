# Refined Multi-Variable Physics Search
# Testing non-linear speed effect and enhanced secondary discharge

$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

function Eval-Refined($c0, $k_elec, $k_vf, $k_h_conf, $k_sec, $k_speed_deep) {
    $errsAll = @()
    $errs440 = @()
    $errs420 = @()

    foreach ($it in $dataset) {
        $H = $it.H
        $Ton = $it.Ton
        $Po = $it.Po
        $IP = $it.IP
        $Volt = $it.Volt
        $VF = $it.VF
        $speed = $it.speed
        $mat = $it.mat
        $isHard = ($mat -eq 'SCM440')

        if ($H -le 170) {
            $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
            $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
            $d_vf = $k_vf * (($VF - 55.0) / 10.0)

            # Rung uốn dây
            $d_vibr = 0.0035 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)

            # Khả năng phá khe suy giảm theo H (SirPhuong)
            $d_h_conf = - $k_h_conf * ($H / 100.0)

            # Giảm tốc sâu: chỉ khi H >= 100 và speed < 150
            $d_spd_deep = if ($H -ge 100 -and $speed -lt 150) {
                - $k_speed_deep * ((150.0 - $speed) / 100.0) * ($H / 100.0)
            } else {
                0.0
            }

            # Thoát phoi khó & Đánh lửa thứ cấp (SirPhuong)
            # Tỷ lệ thuận với mật độ xỉ và nghịch với Po
            $rho = ($it.I / ($Po + 2.0)) * ($H / 100.0)
            # Khi Po <= 7 ở phôi trung bình (75-95mm), đánh lửa thứ cấp rất mạnh
            $po_factor = [Math]::Max(0.0, (8.5 - $Po) / 10.0)
            $mat_k = if ($isHard) { 1.0 } else { 1.40 }
            $d_sec = $k_sec * [Math]::Pow($H / 100.0, 1.3) * $po_factor * $mat_k

            $calc = $c0 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_spd_deep + $d_sec
        } else {
            # H > 170mm: Phân vùng thống kê xưởng Rule 17
            $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
            $d_vf = $k_vf * 0.5 * (($VF - 65.0) / 10.0)
            $calc += $d_vf
        }

        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errsAll += $diff
        if ($isHard) { $errs440 += $diff } else { $errs420 += $diff }
    }

    $mae = ($errsAll | Measure-Object -Average).Average
    $mae440 = ($errs440 | Measure-Object -Average).Average
    $mae420 = ($errs420 | Measure-Object -Average).Average
    $maxErr = ($errsAll | Measure-Object -Maximum).Maximum
    return @{ MAE=$mae; MAE440=$mae440; MAE420=$mae420; MaxErr=$maxErr }
}

$best_res = @{ MAE=999 }

for ($c = 0.0025; $c -le 0.0038; $c += 0.0003) {
    for ($ke = 0.0007; $ke -le 0.0010; $ke += 0.00005) {
        for ($kh = 0.0060; $kh -le 0.0140; $kh += 0.0020) {
            for ($ks = 0.0300; $ks -le 0.0800; $ks += 0.0100) {
                for ($kspd = 0.0050; $kspd -le 0.0150; $kspd += 0.0030) {
                    $r = Eval-Refined $c $ke 0.0021 $kh $ks $kspd
                    $score = $r.MAE * 0.4 + $r.MAE420 * 0.4 + $r.MAE440 * 0.2
                    if ($score -lt ($best_res.MAE * 0.4 + $best_res.MAE420 * 0.4 + $best_res.MAE440 * 0.2)) {
                        $best_res = $r
                        $best_res.c = $c
                        $best_res.ke = $ke
                        $best_res.kh = $kh
                        $best_res.ks = $ks
                        $best_res.kspd = $kspd
                    }
                }
            }
        }
    }
}

Write-Host "================================================================================="
Write-Host "BEST REFINED MULTI-VARIABLE MODEL:"
Write-Host ("  MAE Toan cuc: {0:F2} um" -f $best_res.MAE)
Write-Host ("  MAE SCM440 (28-32 HRC): {0:F2} um" -f $best_res.MAE440)
Write-Host ("  MAE SCM420 (HB < 200):  {0:F2} um" -f $best_res.MAE420)
Write-Host ("  Max Error: {0:F2} um" -f $best_res.MaxErr)
Write-Host "---------------------------------------------------------------------------------"
Write-Host ("Parameters: C0={0:F4}, K_elec={1:F5}, K_h_conf={2:F4}, K_sec={3:F4}, K_spd_deep={4:F4}" -f $best_res.c, $best_res.ke, $best_res.kh, $best_res.ks, $best_res.kspd)
