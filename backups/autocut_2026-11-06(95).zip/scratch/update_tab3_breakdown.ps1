$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)

# Find start of tbody.innerHTML = `
$idxStart = -1
for ($i = 4310; $i -le 4340; $i++) {
    if ($lines[$i] -match 'tbody\.innerHTML = `') {
        $idxStart = $i + 1
        break
    }
}
Write-Host "idxStart: $idxStart (Line: $($idxStart + 1))"

# Find end of tbody.innerHTML (before </tr>\n`;)
$idxEnd = -1
for ($i = $idxStart; $i -le $idxStart + 60; $i++) {
    if ($lines[$i] -match 'OFFSET BÙ DAO 1 PASS') {
        $idxEnd = $i + 4 # closing </tr> and `;
        break
    }
}
Write-Host "idxEnd: $idxEnd (Line: $($idxEnd + 1))"

[string[]]$newRows = @(
'                <tr>'
'                    <td><strong>C<sub>0</sub></strong> (Màng cách điện ban đầu)</td>'
'                    <td>Điện trở suất dung dịch nhũ tương &amp; ion hóa ban đầu</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.c0 * 1000).toFixed(2)} μm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.c0 * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr>'
'                    <td><strong>d<sub>elec</sub></strong> (Bộc phá xung điện theo Volt)</td>'
'                    <td>Năng lượng đơn xung: K<sub>elec</sub> &times; &radic;(Ton &times; IP) &times; U<sub>ratio</sub> (${isHigh ? ''Volt High 27V (1.0x)'' : ''Volt Low 22V (0.815x) co tia lửa''})</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_elec * 1000).toFixed(2)} μm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_elec * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr>'
'                    <td><strong>d<sub>h_conf</sub></strong> (Khả năng bung tia lửa phôi cao)</td>'
'                    <td>Áp lực thủy tĩnh &amp; nén xỉ rãnh sâu giam hãm plasma: -K<sub>h_conf</sub> &times; (H/100)</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">${(res.d_h_conf * 1000).toFixed(2)} μm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">${(res.d_h_conf * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr>'
'                    <td><strong>d<sub>vibr</sub></strong> (Rung uốn cơ học dây Moly)</td>'
'                    <td>${H <= 170 ? ''Xung lực nổ plasma làm võng dây: K_vibr &times; (H/100)² &times; (IP/5)'' : ''Kiến trúc Phân vùng Kép Rule 17: Hội tụ êm về chuẩn xưởng 0.1150 mm''}</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr style="background: rgba(244, 63, 94, 0.06);">'
'                    <td><strong style="color: #f43f5e;">d<sub>sec</sub></strong> (Đánh lửa thứ cấp do nghẽn xỉ dẻo)</td>'
'                    <td>Kích hoạt khi H &gt; 63mm (lõi đói áp lực xả) và Po &le; 7: K<sub>sec</sub> &times; (h<sub>starve</sub>)<sup>0.65</sup> &times; po<sub>shortage</sub> &times; K<sub>mat</sub></td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">+${(res.d_sec * 1000).toFixed(2)} μm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e; font-weight: 700;">+${(res.d_sec_vf * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr style="background: rgba(245, 158, 11, 0.08); border-top: 1px dashed var(--accent-amber);">'
'                    <td><strong style="color: var(--accent-amber);">d<sub>vf</sub></strong> (Hiệu ứng trễ bước tiến VF)</td>'
'                    <td>Thời gian ngâm tia lửa do tốc độ tiến bàn máy: K<sub>vf</sub> &times; (VF - 55)/10</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--text-muted);">0.00 μm (VF chuẩn 55)</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-weight: 700;">${signVf + (res.d_vf * 1000).toFixed(2)} μm</td>'
'                </tr>'
'                <tr style="font-weight: 700; background: rgba(0,0,0,0.3); border-top: 2px solid var(--border-color);">'
'                    <td>TỔNG LƯỢNG CÀO PHÔI (&delta;)</td>'
'                    <td>Khoảng cách từ mép dây Moly đến vách phôi thép đặc</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight); font-size: 13px;">${(res.gap * 1000).toFixed(2)} μm<br><span style="font-size: 11px; font-weight: 400; color: var(--text-secondary);">${res.gap.toFixed(4)} mm</span></td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-size: 13px;">${(res.gap_vf * 1000).toFixed(2)} μm<br><span style="font-size: 11px; font-weight: 400; color: var(--text-secondary);">${res.gap_vf.toFixed(4)} mm</span></td>'
'                </tr>'
'                <tr style="font-weight: 800; background: rgba(0, 240, 255, 0.08); border-top: 1px solid var(--accent-cyan);">'
'                    <td style="color: var(--accent-cyan);">OFFSET BÙ DAO 1 PASS (O<sub>1P</sub>)</td>'
'                    <td>R<sub>dây</sub> (0.090 mm) + Lượng cào phôi (&delta;)</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-cyan); font-size: 15px;">${res.offset.toFixed(4)} mm</td>'
'                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-size: 15px;">${res.offset_vf.toFixed(4)} mm</td>'
'                </tr>'
)

$linesList = [System.Collections.Generic.List[string]]::new($lines)
$linesList.RemoveRange($idxStart, ($idxEnd - $idxStart + 1))
$linesList.InsertRange($idxStart, [System.Collections.Generic.IEnumerable[string]]$newRows)

[System.IO.File]::WriteAllLines("app.js", $linesList, [System.Text.Encoding]::UTF8)
Write-Host "Updated vf-breakdown-tbody successfully!"
