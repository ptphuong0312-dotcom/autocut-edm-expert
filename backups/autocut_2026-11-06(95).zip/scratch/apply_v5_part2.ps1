# Pure ASCII script to update baseGap, gap, and Pass 2 in generateWorkshopRows
$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)

# Find line with "const u_ratio_base = baseVolt"
$idxBase = -1
for ($i = 2270; $i -le 2315; $i++) {
    if ($lines[$i] -match "const u_ratio_base = baseVolt") {
        $idxBase = $i
        break
    }
}
Write-Host "idxBase: $idxBase (Line: $($idxBase + 1))"

# Find line with "baseGap = C0 +"
$idxBaseEnd = -1
for ($i = $idxBase; $i -le $idxBase + 20; $i++) {
    if ($lines[$i] -match "baseGap = C0 \+") {
        $idxBaseEnd = $i
        break
    }
}
Write-Host "idxBaseEnd: $idxBaseEnd (Line: $($idxBaseEnd + 1))"

$newBaseGapLines = @(
'            // Tinh toan gioi han tan so p1_hz'
'            let p1_hz;'
'            if (H <= 40) p1_hz = 200;'
'            else if (H <= 170) p1_hz = Math.round(200 - (H - 40) * (200 - 150) / (170 - 40));'
'            else p1_hz = Math.round(150 - (Math.min(300, H) - 170) * (150 - 50) / (300 - 170));'
''
'            const u_ratio_base = baseVolt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_base = K_ELEC * Math.sqrt(baseTon * baseIP) * u_ratio_base;'
'            const d_vf_base = K_VF * ((baseVF - 55.0) / 10.0);'
'            const d_vibr_base = K_VIBR * Math.pow(H / 100.0, 2) * (baseIP / 5.0);'
'            const d_h_conf_base = - K_H_CONF * (H / 100.0);'
'            const d_spd_base = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;'
'            const h_starve_base = Math.max(0.0, (H - H_THRESH) / 100.0);'
'            const po_shortage_base = Math.max(0.0, (PO_THRESH - basePo) / 10.0);'
'            const mat_boost_base = isHard ? 1.0 : 2.60;'
'            const d_sec_base = K_SEC_BASE * Math.pow(h_starve_base, S_EXP) * po_shortage_base * mat_boost_base;'
'            baseGap = C0 + d_elec_base + d_vf_base + d_vibr_base + d_h_conf_base + d_spd_base + d_sec_base;'
)

$linesList = [System.Collections.Generic.List[string]]::new($lines)
$linesList.RemoveRange($idxBase, ($idxBaseEnd - $idxBase + 1))
$linesList.InsertRange($idxBase, $newBaseGapLines)

# Find line with "const u_ratio_actual = Volt ==="
$idxActual = -1
for ($i = $idxBase + 20; $i -le $idxBase + 80; $i++) {
    if ($linesList[$i] -match "const u_ratio_actual = Volt ===") {
        $idxActual = $i
        break
    }
}
Write-Host "idxActual: $idxActual (Line: $($idxActual + 1))"

# Find line with "gap = C0 + d_elec_actual"
$idxActualEnd = -1
for ($i = $idxActual; $i -le $idxActual + 20; $i++) {
    if ($linesList[$i] -match "gap = C0 \+ d_elec_actual") {
        $idxActualEnd = $i
        break
    }
}
Write-Host "idxActualEnd: $idxActualEnd (Line: $($idxActualEnd + 1))"

$newActualGapLines = @(
'            const u_ratio_actual = Volt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_actual = K_ELEC * Math.sqrt(Ton * IP) * u_ratio_actual;'
'            const d_vf_actual = K_VF * ((VF - 55.0) / 10.0);'
'            const d_vibr_actual = K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);'
'            const d_h_conf_actual = - K_H_CONF * (H / 100.0);'
'            const d_spd_actual = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;'
'            const h_starve_actual = Math.max(0.0, (H - H_THRESH) / 100.0);'
'            const po_shortage_actual = Math.max(0.0, (PO_THRESH - Po) / 10.0);'
'            const mat_boost_actual = isHard ? 1.0 : 2.60;'
'            const d_sec_actual = K_SEC_BASE * Math.pow(h_starve_actual, S_EXP) * po_shortage_actual * mat_boost_actual;'
'            gap = C0 + d_elec_actual + d_vf_actual + d_vibr_actual + d_h_conf_actual + d_spd_actual + d_sec_actual;'
)

$linesList.RemoveRange($idxActual, ($idxActualEnd - $idxActual + 1))
$linesList.InsertRange($idxActual, $newActualGapLines)

# Find Pass 2 block
$idxP2 = -1
for ($i = $idxActual + 30; $i -le $idxActual + 90; $i++) {
    if ($linesList[$i] -match "const Rz_p1 = K_RZ") {
        $idxP2 = $i
        break
    }
}
Write-Host "idxP2: $idxP2 (Line: $($idxP2 + 1))"

# Find delta_2_calc line
$idxP2End = -1
for ($i = $idxP2; $i -le $idxP2 + 10; $i++) {
    if ($linesList[$i] -match "const delta_2_calc =") {
        $idxP2End = $i
        break
    }
}
Write-Host "idxP2End: $idxP2End (Line: $($idxP2End + 1))"

$newP2Lines = @(
'            const Rz_p1 = K_RZ * Math.sqrt(Ton * IP) * u_ratio_actual;'
'            const u_ratio_p2 = p2_volt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_p2 = K_ELEC * Math.sqrt(p2_ton * p2_ip) * u_ratio_p2;'
'            const d_h_conf_p2 = - K_H_CONF * (H / 100.0) * 0.5;'
'            const delta_2_calc = C0 + d_elec_p2 + d_h_conf_p2;'
)

$linesList.RemoveRange($idxP2, ($idxP2End - $idxP2 + 1))
$linesList.InsertRange($idxP2, $newP2Lines)

# Find duplicate "let p1_hz;" around line 2415
for ($i = $idxP2 + 10; $i -le $idxP2 + 40; $i++) {
    if ($linesList[$i] -match "let p1_hz;") {
        $linesList[$i] = '        // p1_hz da duoc tinh toan o tren'
        Write-Host "Replaced duplicate let p1_hz at line: $($i + 1)"
        break
    }
}

[System.IO.File]::WriteAllLines("app.js", $linesList, [System.Text.Encoding]::UTF8)
Write-Host "Part 2 updated successfully!"
