import os
import json
import re

ws = r"d:\OneDrive\Antigravity\Cat_Day_EDM"

# 1. Update index.html
html_path = os.path.join(ws, "index.html")
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace Section 2 results-header and tables in index.html
old_section2 = """                        <div style="display: flex; gap: 8px; align-items: center;">
                            <button type="button" class="btn btn-sm btn-outline" id="ws-btn-reset-params" style="border-color: rgba(251, 191, 36, 0.5); color: var(--accent-amber); font-size: 11.5px; padding: 5px 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; border-radius: 6px; cursor: pointer;" title="Khôi phục lại toàn bộ thông số tính toán chuẩn ban đầu của App">
                                <span>🔄 Trở Về Mặc Định</span>
                            </button>
                            <button class="btn btn-sm btn-copy" id="ws-btn-copy-table">📋 Copy Bảng</button>
                        </div>
                    </div>

                    <!-- VÙNG 1: THÔNG SỐ ĐIỆN XUNG & BÙ DAO OFFSET (XẾP DỌC) -->
                    <div style="margin-bottom: 16px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(14, 165, 233, 0.25); border-radius: var(--radius-sm); padding: 12px 14px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 6px;">
                            <h3 style="font-size: 13px; color: var(--accent-cyan); margin: 0; display: flex; align-items: center; gap: 6px;">
                                <span>⚡</span> VÙNG 1: THÔNG SỐ ĐIỆN XUNG &amp; BÙ DAO OFFSET <span style="font-size: 11px; color: var(--text-secondary); font-weight: 400;">(Có thể thay đổi trực tiếp)</span>
                            </h3>
                            <span style="font-size: 11px; color: var(--accent-amber);">💡 Chỉnh Pon, Poff, IP, Volt, VF &rarr; Offset &amp; Vùng 2 tự tính lại</span>
                        </div>
                        <div class="table-responsive">
                            <table class="edm-table workshop-table" id="ws-edm-table-vung1">
                                <thead>
                                    <tr>
                                        <th class="sticky-col">P</th>
                                        <th>Pon (μs)</th>
                                        <th>Poff (Po)</th>
                                        <th>IP (Sò)</th>
                                        <th>Volt</th>
                                        <th>VF</th>
                                        <th>Wire</th>
                                        <th style="color: var(--accent-amber); font-size: 13px;">OFFSET (mm)</th>
                                    </tr>
                                </thead>
                                <tbody id="ws-table-body-vung1">
                                    <!-- Injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- VÙNG 2: NĂNG SUẤT BỀ MẶT & ĐỘNG HỌC MÁY (XẾP DỌC BÊN DƯỚI) -->
                    <div style="margin-bottom: 16px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(139, 92, 246, 0.25); border-radius: var(--radius-sm); padding: 12px 14px;">
                        <div style="margin-bottom: 8px;">
                            <h3 style="font-size: 13px; color: var(--accent-purple); margin: 0; display: flex; align-items: center; gap: 6px;">
                                <span>📊</span> VÙNG 2: NĂNG SUẤT &amp; ĐỘNG HỌC MÁY <span style="font-size: 11px; color: var(--text-secondary); font-weight: 400;">(Tự động tính toán phản ứng theo Vùng 1)</span>
                            </h3>
                        </div>
                        <div class="table-responsive">
                            <table class="edm-table workshop-table" id="ws-edm-table-vung2">
                                <thead>
                                    <tr>
                                        <th class="sticky-col">P</th>
                                        <th>Fc thực (mm²/p)</th>
                                        <th>Fc máy (H40)</th>
                                        <th>Giới hạn (Hz)</th>
                                        <th>Ampe kế (A)</th>
                                        <th>Ra (μm)</th>
                                    </tr>
                                </thead>
                                <tbody id="ws-table-body-vung2">
                                    <!-- Injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>"""

new_section2 = """                        <div class="results-header-actions">
                            <button type="button" class="btn btn-sm btn-outline" id="ws-btn-reset-params" title="Khôi phục lại toàn bộ thông số tính toán chuẩn ban đầu của App">
                                <span>🔄 Trở Về Mặc Định</span>
                            </button>
                            <button class="btn btn-sm btn-copy" id="ws-btn-copy-table">📋 Copy Bảng</button>
                        </div>
                    </div>

                    <!-- VÙNG 1: THÔNG SỐ ĐẦU VÀO (XẾP DỌC) -->
                    <div class="ws-zone-card ws-zone-vung1">
                        <div class="ws-zone-header">
                            <h3 class="ws-zone-title ws-title-vung1">
                                <span>⚡</span> VÙNG 1: THÔNG SỐ ĐẦU VÀO <span class="ws-zone-subtitle">(Điện xung &amp; Bước tiến - Có thể sửa trực tiếp)</span>
                            </h3>
                            <span class="ws-zone-hint">💡 Chỉnh Pon, Poff, IP, Volt, VF, Wire &rarr; Vùng 2 tự tính lại</span>
                        </div>
                        <div class="table-responsive">
                            <table class="edm-table workshop-table" id="ws-edm-table-vung1">
                                <thead>
                                    <tr>
                                        <th class="sticky-col">P</th>
                                        <th>Pon (μs)</th>
                                        <th>Poff (Po)</th>
                                        <th>IP (Sò)</th>
                                        <th>Volt</th>
                                        <th>VF</th>
                                        <th>Wire</th>
                                    </tr>
                                </thead>
                                <tbody id="ws-table-body-vung1">
                                    <!-- Injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- VÙNG 2: KẾT QUẢ ĐẦU RA (OFFSET, NĂNG SUẤT & ĐỘNG HỌC MÁY - XẾP DỌC) -->
                    <div class="ws-zone-card ws-zone-vung2">
                        <div class="ws-zone-header">
                            <h3 class="ws-zone-title ws-title-vung2">
                                <span>📊</span> VÙNG 2: KẾT QUẢ ĐẦU RA <span class="ws-zone-subtitle">(Bù dao Offset, Năng suất &amp; Động học máy)</span>
                            </h3>
                            <span class="ws-zone-hint ws-hint-vung2">⚡ Tự động tính toán phản ứng theo Vùng 1</span>
                        </div>
                        <div class="table-responsive">
                            <table class="edm-table workshop-table" id="ws-edm-table-vung2">
                                <thead>
                                    <tr>
                                        <th class="sticky-col">P</th>
                                        <th class="col-offset-header" style="color: var(--accent-amber); font-size: 13px; font-weight: 800;">OFFSET (mm)</th>
                                        <th>Fc thực (mm²/p)</th>
                                        <th>Fc máy (H40)</th>
                                        <th>Giới hạn (Hz)</th>
                                        <th>Ampe kế (A)</th>
                                        <th>Ra (μm)</th>
                                    </tr>
                                </thead>
                                <tbody id="ws-table-body-vung2">
                                    <!-- Injected by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>"""

assert old_section2 in html, "Could not find old_section2 in index.html"
html = html.replace(old_section2, new_section2, 1)

# Bump version in index.html to v3.5.59
html = html.replace("style.css?v=3.5.58", "style.css?v=3.5.59", 1)
html = html.replace("app.js?v=3.5.58", "app.js?v=3.5.59", 1)
html = html.replace(
    'id="app-version-display">v3.5.58',
    'id="app-version-display">v3.5.59'
)

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("[OK] index.html updated successfully to v3.5.59")

# 2. Update app.js
app_path = os.path.join(ws, "app.js")
with open(app_path, "r", encoding="utf-8") as f:
    app_js = f.read()

# Replace Vùng 1 and Vùng 2 row rendering in app.js
old_vung_render = """            // Render VÙNG 1: Thông số điện xung & Bù dao Offset
            wsTableBodyVung1.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="ti" min="1" max="250" value="${dyn.tiVal}" title="Pon (μs)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="Po" min="1" max="40" value="${dyn.poVal}" title="Poff (Po)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="IP" min="1" max="10" value="${dyn.ipVal}" title="IP (Sò)"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Voltage" title="Điện áp">
                            <option value="High" ${dyn.voltVal === 'High' ? 'selected' : ''}>High</option>
                            <option value="Low" ${dyn.voltVal === 'Low' ? 'selected' : ''}>Low</option>
                        </select>
                    </td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="VF" min="1" max="99" value="${dyn.vfVal}" title="VF"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Wire" title="Tốc độ dây">
                            <option value="1" ${dyn.wireVal == '1' ? 'selected' : ''}>1</option>
                            <option value="2" ${dyn.wireVal == '2' ? 'selected' : ''}>2</option>
                            <option value="3" ${dyn.wireVal == '3' ? 'selected' : ''}>3</option>
                        </select>
                    </td>
                    <td class="val-offset fw-bold" style="color:var(--accent-amber); font-size:13.5px;"><span id="ws-dyn-offset-${idx}">${dyn.offsetDisplay}</span> mm</td>
                </tr>
                `;
            }).join('');

            // Render VÙNG 2: Năng suất & Động học máy
            wsTableBodyVung2.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><span id="ws-dyn-fc-${idx}" style="color:var(--accent-amber); font-weight:600;">${dyn.speedArea}</span></td>
                    <td><strong id="ws-dyn-fch40-${idx}" style="color:var(--accent-amber);">${dyn.speedAreaH40}</strong></td>
                    <td><strong id="ws-dyn-hz-${idx}" style="color:var(--accent-amber);">${dyn.hz} Hz</strong></td>
                    <td><strong id="ws-dyn-ampe-${idx}" style="color:var(--accent-amber); font-size:13px;">${dyn.ampeDisplay}</strong></td>
                    <td class="val-ra"><span id="ws-dyn-ra-${idx}">${dyn.Ra}</span></td>
                </tr>
                `;
            }).join('');"""

new_vung_render = """            // Render VÙNG 1: Thông số đầu vào (Điện xung & Bước tiến)
            wsTableBodyVung1.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="ti" min="1" max="250" value="${dyn.tiVal}" title="Pon (μs)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="Po" min="1" max="40" value="${dyn.poVal}" title="Poff (Po)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="IP" min="1" max="10" value="${dyn.ipVal}" title="IP (Sò)"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Voltage" title="Điện áp">
                            <option value="High" ${dyn.voltVal === 'High' ? 'selected' : ''}>High</option>
                            <option value="Low" ${dyn.voltVal === 'Low' ? 'selected' : ''}>Low</option>
                        </select>
                    </td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="VF" min="1" max="99" value="${dyn.vfVal}" title="VF"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Wire" title="Tốc độ dây">
                            <option value="1" ${dyn.wireVal == '1' ? 'selected' : ''}>1</option>
                            <option value="2" ${dyn.wireVal == '2' ? 'selected' : ''}>2</option>
                            <option value="3" ${dyn.wireVal == '3' ? 'selected' : ''}>3</option>
                        </select>
                    </td>
                </tr>
                `;
            }).join('');

            // Render VÙNG 2: Kết quả đầu ra (OFFSET, Năng suất & Động học máy)
            wsTableBodyVung2.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td class="val-offset fw-bold col-offset-cell" style="color:var(--accent-amber); font-size:14px; background: rgba(245, 158, 11, 0.08);"><strong id="ws-dyn-offset-${idx}">${dyn.offsetDisplay}</strong> mm</td>
                    <td><span id="ws-dyn-fc-${idx}" style="color:var(--accent-cyan); font-weight:600;">${dyn.speedArea}</span></td>
                    <td><strong id="ws-dyn-fch40-${idx}" style="color:var(--accent-cyan);">${dyn.speedAreaH40}</strong></td>
                    <td><strong id="ws-dyn-hz-${idx}" style="color:var(--text-primary);">${dyn.hz} Hz</strong></td>
                    <td><strong id="ws-dyn-ampe-${idx}" style="color:var(--accent-green); font-size:13px;">${dyn.ampeDisplay}</strong></td>
                    <td class="val-ra"><span id="ws-dyn-ra-${idx}">${dyn.Ra}</span></td>
                </tr>
                `;
            }).join('');"""

assert old_vung_render in app_js, "Could not find old_vung_render in app.js"
app_js = app_js.replace(old_vung_render, new_vung_render, 1)

# Bump version in app.js
app_js = app_js.replace('const CURRENT_VERSION = "3.5.58";', 'const CURRENT_VERSION = "3.5.59";', 1)

with open(app_path, "w", encoding="utf-8") as f:
    f.write(app_js)
print("[OK] app.js updated successfully to v3.5.59")

# 3. Update style.css
css_path = os.path.join(ws, "style.css")
with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

# Add dedicated classes for Dual Zone cards and mobile optimization
new_styles = """
/* ====================================================
   WORKSHOP DUAL-ZONE CONTAINER & TABLE STYLES (v3.5.59)
   ==================================================== */
.ws-zone-card {
    margin-bottom: 14px;
    border-radius: var(--radius-sm);
    padding: 12px 14px;
    transition: all 0.2s ease;
}
.ws-zone-vung1 {
    background: rgba(15, 23, 42, 0.65);
    border: 1px solid rgba(14, 165, 233, 0.3);
}
.ws-zone-vung2 {
    background: rgba(15, 23, 42, 0.65);
    border: 1px solid rgba(139, 92, 246, 0.3);
}
.ws-zone-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
    flex-wrap: wrap;
    gap: 6px;
}
.ws-zone-title {
    font-size: 13px;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 6px;
}
.ws-title-vung1 {
    color: var(--accent-cyan);
}
.ws-title-vung2 {
    color: var(--accent-purple);
}
.ws-zone-subtitle {
    font-size: 11px;
    color: var(--text-secondary);
    font-weight: 400;
}
.ws-zone-hint {
    font-size: 11px;
    color: var(--accent-amber);
}
.ws-hint-vung2 {
    color: rgba(167, 139, 250, 0.9);
}

.results-header-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}
#ws-btn-reset-params {
    border-color: rgba(251, 191, 36, 0.5);
    color: var(--accent-amber);
    font-size: 11.5px;
    padding: 5px 12px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border-radius: 6px;
    cursor: pointer;
    background: rgba(251, 191, 36, 0.08);
    transition: all 0.2s ease;
}
#ws-btn-reset-params:hover {
    background: rgba(251, 191, 36, 0.18);
    border-color: var(--accent-amber);
}

/* TỐI ƯU CỘT OFFSET Ở ĐẦU VÙNG 2 */
.col-offset-header {
    background: rgba(245, 158, 11, 0.12) !important;
    border-left: 1px solid rgba(245, 158, 11, 0.3);
    border-right: 1px solid rgba(245, 158, 11, 0.3);
    text-shadow: 0 0 8px rgba(245, 158, 11, 0.3);
}
.col-offset-cell {
    border-left: 1px solid rgba(245, 158, 11, 0.25);
    border-right: 1px solid rgba(245, 158, 11, 0.25);
}

/* ====================================================
   MOBILE RESPONSIVENESS ENHANCEMENTS (max-width: 768px)
   ==================================================== */
@media (max-width: 768px) {
    .results-header {
        flex-direction: column;
        align-items: stretch;
        gap: 8px;
    }
    .results-header-actions {
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px;
    }
    .results-header-actions .btn {
        width: 100%;
        justify-content: center;
        text-align: center;
        padding: 7px 4px;
        font-size: 11.5px;
        min-height: 36px;
    }

    .ws-zone-card {
        padding: 8px 6px;
        margin-bottom: 10px;
    }
    .ws-zone-header {
        margin-bottom: 6px;
    }
    .ws-zone-title {
        font-size: 12px;
    }
    .ws-zone-subtitle {
        font-size: 10px;
    }
    .ws-zone-hint {
        font-size: 10.5px;
    }

    /* Table cells & inputs on Mobile */
    .edm-table th, .edm-table td {
        padding: 7px 4px;
        font-size: 12px;
    }
    .edm-table th {
        font-size: 10.5px;
        padding: 6px 3px;
        letter-spacing: 0;
    }
    .ws-cell-input {
        width: 50px;
        padding: 4px 2px;
        font-size: 12.5px;
    }
    .ws-cell-select {
        padding: 4px 2px;
        font-size: 11px;
    }
    .pass-badge {
        padding: 3px 5px;
        font-size: 10.5px;
    }
    .col-offset-header, .col-offset-cell {
        font-size: 13px !important;
        padding-left: 6px !important;
        padding-right: 6px !important;
    }
    .col-offset-cell strong {
        font-size: 13.5px !important;
    }
}

@media (max-width: 480px) {
    .ws-cell-input {
        width: 46px;
        padding: 3px 1px;
        font-size: 12px;
    }
    .ws-cell-select {
        padding: 3px 1px;
        font-size: 10.5px;
    }
    .edm-table th, .edm-table td {
        padding: 6px 2px;
    }
    .pass-badge {
        padding: 2px 3px;
        font-size: 9.5px;
    }
}
"""

css += new_styles

with open(css_path, "w", encoding="utf-8") as f:
    f.write(css)
print("[OK] style.css updated with mobile optimizations")

# 4. Update sw.js
sw_path = os.path.join(ws, "sw.js")
with open(sw_path, "r", encoding="utf-8") as f:
    sw_js = f.read()

sw_js = sw_js.replace("autocut-v3.5.58", "autocut-v3.5.59", 1)
with open(sw_path, "w", encoding="utf-8") as f:
    f.write(sw_js)
print("[OK] sw.js updated to autocut-v3.5.59")

# 5. Update version.json
ver_path = os.path.join(ws, "version.json")
with open(ver_path, "r", encoding="utf-8") as f:
    vdata = json.load(f)

vdata["version"] = "3.5.59"
vdata["buildTimestamp"] = 1793970000000
vdata["releaseDate"] = "2026-11-06"
vdata["description"] = "Chuyển cột OFFSET xuống đầu Vùng 2 để phân chuẩn rạch ròi Đầu Vào (Vùng 1) vs Đầu Ra (Vùng 2); tối ưu hóa giao diện và trải nghiệm bảng thông số trên thiết bị di động Mobile."

with open(ver_path, "w", encoding="utf-8") as f:
    json.dump(vdata, f, ensure_ascii=False, indent=2)
print("[OK] version.json updated to v3.5.59")
