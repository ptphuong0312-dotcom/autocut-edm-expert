# Scratch script to test physics variations for Vong 4
$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

function Test-Model($c0, $k_elec, $k_vf, $k_h_conf, $k_sec_base, $k_sec_420_boost, $k_spd_slow, $h_thresh, $sec_exp, $po_thresh) {
    $errsAll = @(); $errs440 = @(); $errs420 = @()

    foreach ($it in $dataset) {
        $H = $it.H
        $Ton = $it.Ton
        $Po = $it.Po
        $IP = $it.IP
        $Volt = $it.Volt
        $VF = $it.VF
        $speed = $it.speed
        $mat = $it.mat
        $isHard = ($mat -eq 'SCM440')

        if ($H -le 170) {
            $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
            $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
            $d_vf = $k_vf * (($VF - 55.0) / 10.0)
            $d_vibr = 0.0035 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
            $d_h_conf = - $k_h_conf * ($H / 100.0)

            # Deep slot feed constraint
            $d_slow_spd = if ($H -ge 110 -and $speed -lt 150) {
                - $k_spd_slow * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
            } else {
                0.0
            }

            # Secondary Sparking model
            $h_starve = [Math]::Max(0.0, ($H - $h_thresh) / 100.0)
            $po_shortage = [Math]::Max(0.0, ($po_thresh - $Po) / 10.0)
            $mat_boost = if ($isHard) { 1.0 } else { $k_sec_420_boost }
            
            $d_sec = $k_sec_base * [Math]::Pow($h_starve, $sec_exp) * $po_shortage * $mat_boost

            $calc = $c0 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_slow_spd + $d_sec
        } else {
            # H > 170mm: Phân vùng thống kê xưởng Rule 17
            $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
            $d_vf = $k_vf * 0.5 * (($VF - 65.0) / 10.0)
            $calc += $d_vf
        }

        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errsAll += $diff
        if ($isHard) { $errs440 += $diff } else { $errs420 += $diff }
    }

    $maeAll = ($errsAll | Measure-Object -Average).Average
    $mae440 = ($errs440 | Measure-Object -Average).Average
    $mae420 = ($errs420 | Measure-Object -Average).Average
    $maxErr = ($errsAll | Measure-Object -Maximum).Maximum
    return @{ MAE=$maeAll; MAE440=$mae440; MAE420=$mae420; MaxErr=$maxErr }
}

# Grid search varying h_thresh, po_thresh, sec_exp, k_sec_420_boost
$best = @{ MAE=999; MAE420=999; MaxErr=999 }

foreach ($h_th in @(55.0, 60.0, 65.0)) {
    foreach ($po_th in @(8.0, 8.5, 9.0)) {
        foreach ($s_exp in @(0.8, 1.0, 1.2)) {
            foreach ($k_b in @(1.8, 2.0, 2.2, 2.5, 2.8, 3.0)) {
                foreach ($k_sec in @(0.050, 0.070, 0.090, 0.110)) {
                    foreach ($c0 in @(0.0020, 0.0022, 0.0024)) {
                        foreach ($ke in @(0.00070, 0.00072, 0.00074)) {
                            foreach ($kh in @(0.0050, 0.0060, 0.0070)) {
                                foreach ($kspd in @(0.0070, 0.0080, 0.0090)) {
                                    $res = Test-Model $c0 $ke 0.0021 $kh $k_sec $k_b $kspd $h_th $s_exp $po_th
                                    # Target: lowest MAE SCM420 while keeping Global MAE and MaxErr low
                                    if ($res.MAE420 -lt 4.5 -and $res.MaxErr -lt 8.5) {
                                        Write-Host ("FOUND! MAE_All={0:F2} | SCM440={1:F2} | SCM420={2:F2} | MaxErr={3:F2} | h_th={4} po_th={5} exp={6} kb={7} ksec={8} c0={9} ke={10}" -f $res.MAE, $res.MAE440, $res.MAE420, $res.MaxErr, $h_th, $po_th, $s_exp, $k_b, $k_sec, $c0, $ke)
                                    }
                                    if ($res.MAE -lt $best.MAE) {
                                        $best = $res
                                        $best.h_th = $h_th; $best.po_th = $po_th; $best.s_exp = $s_exp; $best.k_b = $k_b; $best.k_sec = $k_sec; $best.c0 = $c0; $best.ke = $ke; $best.kh = $kh; $best.kspd = $kspd
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

Write-Host "--------------------------------------------------"
Write-Host ("OVERALL BEST: MAE_All={0:F2} | SCM440={1:F2} | SCM420={2:F2} | MaxErr={3:F2}" -f $best.MAE, $best.MAE440, $best.MAE420, $best.MaxErr)
Write-Host ("Params: c0={0} ke={1} kh={2} k_sec={3} k_b={4} kspd={5} h_th={6} po_th={7} s_exp={8}" -f $best.c0, $best.ke, $best.kh, $best.k_sec, $best.k_b, $best.kspd, $best.h_th, $best.po_th, $best.s_exp)
