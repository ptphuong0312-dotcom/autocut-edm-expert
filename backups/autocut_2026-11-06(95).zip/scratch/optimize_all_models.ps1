# Comprehensive Multi-Model Physics Optimization Script
# Author: Antigravity AI Engine
# Target: Minimize MAE and RMSE across all 19 benchmark cuts, specifically for SCM420 (HB < 200)

$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; grp='1P SCM440'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   grp='1P SCM440'; H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   grp='1P SCM440'; H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   grp='1P SCM440'; H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; grp='1P SCM440'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  grp='1P SCM440'; H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; grp='1P SCM440'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  grp='1P SCM440'; H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  grp='1P SCM440'; H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  grp='1P SCM420'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   grp='1P SCM420'; H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  grp='1P SCM420'; H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  grp='1P SCM420'; H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  grp='1P SCM420'; H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  grp='1P SCM420'; H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   grp='1P SCM420'; H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  grp='1P SCM420'; H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  grp='1P SCM420'; H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  grp='1P SCM420'; H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

Write-Host ("Loaded {0} cuts ({1} SCM440, {2} SCM420)" -f $dataset.Count, ($dataset | Where-Object { $_.mat -eq 'SCM440' }).Count, ($dataset | Where-Object { $_.mat -eq 'SCM420' }).Count)
