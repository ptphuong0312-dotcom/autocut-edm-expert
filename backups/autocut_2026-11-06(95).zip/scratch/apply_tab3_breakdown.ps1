$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)

# Find start of tbody.innerHTML = `
$idxStart = -1
for ($i = 4300; $i -le 4350; $i++) {
    if ($lines[$i] -match 'tbody\.innerHTML = `') {
        $idxStart = $i + 1
        break
    }
}
Write-Host "idxStart: $idxStart (Line: $($idxStart + 1))"

# Find end of tbody.innerHTML
$idxEnd = -1
for ($i = $idxStart; $i -le $idxStart + 80; $i++) {
    if ($lines[$i] -match 'OFFSET B') {
        $idxEnd = $i + 4
        break
    }
}
Write-Host "idxEnd: $idxEnd (Line: $($idxEnd + 1))"

$newRows = [System.IO.File]::ReadAllLines("scratch\new_breakdown_rows.txt", [System.Text.Encoding]::UTF8)

$linesList = [System.Collections.Generic.List[string]]::new($lines)
$linesList.RemoveRange($idxStart, ($idxEnd - $idxStart + 1))
$linesList.InsertRange($idxStart, [System.Collections.Generic.IEnumerable[string]]$newRows)

[System.IO.File]::WriteAllLines("app.js", $linesList, [System.Text.Encoding]::UTF8)
Write-Host "Updated vf-breakdown-tbody successfully from file!"
