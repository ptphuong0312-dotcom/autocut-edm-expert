# Deep Analysis of 10 SCM420 Cuts
$scm420_data = @(
    @{ id='STT 22'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; actual=0.0050; desc='Chay Low 150Hz' },
    @{ id='STT 3';  H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; actual=0.0050; desc='Chay 150Hz' },
    @{ id='STT 18'; H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; actual=0.0080; desc='Chay 150Hz' },
    @{ id='STT 16'; H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0220; desc='Coi 187Hz' },
    @{ id='STT 21'; H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0280; desc='Coi 150Hz' },
    @{ id='STT 19'; H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; actual=0.0150; desc='Chay 150Hz' },
    @{ id='STT 7';  H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; actual=0.0050; desc='Chay 50Hz' },
    @{ id='STT 12'; H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; actual=0.0120; desc='Chay 100Hz' },
    @{ id='STT 15'; H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; actual=0.0300; desc='Coi 154Hz' },
    @{ id='STT 23'; H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; actual=0.0180; desc='Coi sieu day 60Hz' }
)

Write-Host "=========================================================================================="
Write-Host "PHAN TICH 10 BAI CAT SCM420 (HB < 200)"
Write-Host "=========================================================================================="
foreach ($it in $scm420_data) {
    $act_um = $it.actual * 1000
    Write-Host ("{0,-8} | H={1,3}mm | Ton={2,3} | Po={3,2} | IP={4} | Volt={5,-4} | VF={6,2} | delta={7,5:F1} um | {8}" -f $it.id, $it.H, $it.Ton, $it.Po, $it.IP, $it.Volt, $it.VF, $act_um, $it.desc)
}
