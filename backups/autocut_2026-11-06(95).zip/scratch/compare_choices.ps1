# Compare Baseline (v3.5.53), Choice A (Vong 5), Choice B (Vong 4) side by side
$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

# 1. Baseline v3.5.53
function Calc-Baseline($H, $Ton, $Po, $IP, $Volt, $VF, $mat) {
    $isHard = ($mat -eq 'SCM440')
    $sm = if ($isHard) { 1.0 } else { 0.80 }
    $km = if ($isHard) { 1.0 } else { 1.25 }
    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = 0.00067 * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low = if ($Volt -eq 'Low' -or $Volt -eq 'L') { 0.00450 } else { 0.0 }
        $d_slag = - 0.00280 * ($H / 100.0) * ($sm / [Math]::Max(1.0, $IP / 4.0))
        $d_vibr = 0.00390 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_vf = 0.00210 * (($VF - 55.0) / 10.0)
        $d_po = - 0.00120 * (($Po - 5.0) / 10.0)
        $s_raw = (($Ton * $IP) / ($Po * 25.0)) * ($H / 100.0) * $km
        $d_sec = if ($s_raw -gt 0.20) {
            (0.00400 * ($s_raw - 0.20)) / (1.0 + 1.5 * [Math]::Pow($H / 100.0, 2))
        } else { 0.0 }
        return 0.00360 + $d_elec + $d_low + $d_slag + $d_vibr + $d_vf + $d_po + $d_sec
    } else {
        $gap170 = 0.00360 + (0.00067 * [Math]::Sqrt($Ton * $IP) * 1.0) + (- 0.00280 * 1.70 * $sm / [Math]::Max(1.0, $IP / 4.0)) + (0.00390 * [Math]::Pow(1.70, 2) * ($IP / 5.0))
        $gapBase = $gap170 + ($H - 170) * (0.0250 - $gap170) / (300 - 170)
        $d_vf = 0.00210 * 0.5 * (($VF - 65.0) / 10.0)
        return $gapBase + $d_vf
    }
}

# 2. Choice A (Vong 5)
function Calc-ChoiceA($H, $Ton, $Po, $IP, $Volt, $VF, $speed, $mat) {
    $isHard = ($mat -eq 'SCM440')
    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
        $d_elec = 0.00070 * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_vf = 0.00210 * (($VF - 55.0) / 10.0)
        $d_vibr = 0.00350 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_h_conf = - 0.00650 * ($H / 100.0)
        $d_slow_spd = if ($H -ge 110 -and $speed -lt 150) {
            - 0.00550 * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
        } else { 0.0 }
        $h_starve = [Math]::Max(0.0, ($H - 63.0) / 100.0)
        $po_shortage = [Math]::Max(0.0, (8.0 - $Po) / 10.0)
        $mat_boost = if ($isHard) { 1.0 } else { 2.60 }
        $d_sec = 0.160 * [Math]::Pow($h_starve, 0.65) * $po_shortage * $mat_boost
        return 0.00200 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_slow_spd + $d_sec
    } else {
        $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        return $calc + 0.00210 * 0.5 * (($VF - 65.0) / 10.0)
    }
}

# 3. Choice B (Vong 4)
function Calc-ChoiceB($H, $Ton, $Po, $IP, $Volt, $VF, $speed, $mat) {
    $isHard = ($mat -eq 'SCM440')
    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
        $d_elec = 0.00070 * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_vf = 0.00210 * (($VF - 55.0) / 10.0)
        $d_vibr = 0.00350 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_h_conf = - 0.00700 * ($H / 100.0)
        $d_slow_spd = if ($H -ge 110 -and $speed -lt 150) {
            - 0.00750 * ((150.0 - $speed) / 100.0) * [Math]::Pow($H / 100.0, 1.2)
        } else { 0.0 }
        $h_starve = [Math]::Max(0.0, ($H - 63.0) / 100.0)
        $po_shortage = [Math]::Max(0.0, (8.0 - $Po) / 10.0)
        $mat_boost = if ($isHard) { 1.0 } else { 2.80 }
        $d_sec = 0.160 * [Math]::Pow($h_starve, 0.70) * $po_shortage * $mat_boost
        return 0.00200 + $d_elec + $d_vf + $d_vibr + $d_h_conf + $d_slow_spd + $d_sec
    } else {
        $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        return $calc + 0.00210 * 0.5 * (($VF - 65.0) / 10.0)
    }
}

Write-Host "EXPORTING SIDE-BY-SIDE VALUES..."
foreach ($it in $dataset) {
    $goc = Calc-Baseline $it.H $it.Ton $it.Po $it.IP $it.Volt $it.VF $it.mat
    $a = Calc-ChoiceA $it.H $it.Ton $it.Po $it.IP $it.Volt $it.VF $it.speed $it.mat
    $b = Calc-ChoiceB $it.H $it.Ton $it.Po $it.IP $it.Volt $it.VF $it.speed $it.mat
    $act = $it.actual
    
    $err_goc = ($goc - $act) * 1000
    $err_a = ($a - $act) * 1000
    $err_b = ($b - $act) * 1000

    $s_goc = if ($err_goc -ge 0) { "+$([Math]::Round($err_goc,1))" } else { "$([Math]::Round($err_goc,1))" }
    $s_a   = if ($err_a -ge 0)   { "+$([Math]::Round($err_a,1))" }   else { "$([Math]::Round($err_a,1))" }
    $s_b   = if ($err_b -ge 0)   { "+$([Math]::Round($err_b,1))" }   else { "$([Math]::Round($err_b,1))" }

    Write-Host ("{0,-8} | {1,3}mm | {2,-6} | Act:{3,4:F1} | Goc:{4,4:F1} ({5,5}) | ChA:{6,4:F1} ({7,5}) | ChB:{8,4:F1} ({9,5})" -f `
        $it.id, $it.H, $it.mat, ($act*1000), ($goc*1000), $s_goc, ($a*1000), $s_a, ($b*1000), $s_b)
}
