$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
for ($i = 2189; $i -le 2205; $i++) {
    Write-Host "$($i + 1): [$($lines[$i])]"
}
