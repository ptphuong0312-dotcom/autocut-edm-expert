# Experiment: Optimizing SCM420 (HB < 200) Parameters
$scm420_data = @(
    @{ id='STT 22'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; actual=0.0050; I=2.6 },
    @{ id='STT 3';  H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; actual=0.0050; I=4.1 },
    @{ id='STT 18'; H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; actual=0.0080; I=3.3 },
    @{ id='STT 16'; H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0220; I=3.4 },
    @{ id='STT 21'; H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; actual=0.0280; I=3.5 },
    @{ id='STT 19'; H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; actual=0.0150; I=2.7 },
    @{ id='STT 7';  H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; actual=0.0050; I=3.6 },
    @{ id='STT 12'; H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; actual=0.0120; I=3.8 },
    @{ id='STT 15'; H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; actual=0.0300; I=2.9 },
    @{ id='STT 23'; H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; actual=0.0180; I=2.9 }
)

# Test various parameterizations for SCM420
# Let's see how low we can get the MAE for SCM420!

function Test-SCM420($c0, $k_elec, $d_low, $k_h_conf, $k_sec, $k_slag_deep, $k_vf) {
    $errs = @()
    foreach ($it in $scm420_data) {
        $H = $it.H
        $Ton = $it.Ton
        $Po = $it.Po
        $IP = $it.IP
        $Volt = $it.Volt
        $VF = $it.VF

        $u_ratio = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low_val = if ($Volt -eq 'Low') { $d_low } else { 0.0 }
        $d_vf_val = $k_vf * (($VF - 55.0) / 10.0)
        
        # Suy giảm phá khe theo H
        $d_conf = - $k_h_conf * ($H / 100.0)

        # Nghẽn xỉ phôi sâu (H > 100mm)
        $d_deep_slag = if ($H -gt 100) { - $k_slag_deep * [Math]::Pow(($H - 100) / 100.0, 1.5) } else { 0.0 }

        # Đánh lửa thứ cấp khi Po ngắn (Po <= 7) kết hợp H trung bình
        $po_defect = [Math]::Max(0.0, (8.0 - $Po) / 10.0)
        $d_secondary = $k_sec * [Math]::Pow($H / 100.0, 1.5) * $po_defect

        if ($H -le 170) {
            $calc = $c0 + $d_elec + $d_low_val + $d_vf_val + $d_conf + $d_deep_slag + $d_secondary
        } else {
            # H > 170 uses statistical convergence
            $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        }

        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errs += $diff
    }
    return ($errs | Measure-Object -Average).Average
}

$best_mae = 999
$best_params = @{}

for ($c = 0.0020; $c -le 0.0040; $c += 0.0005) {
    for ($ke = 0.0006; $ke -le 0.0010; $ke += 0.00005) {
        for ($kh = 0.0050; $kh -le 0.0150; $kh += 0.0020) {
            for ($ks = 0.0300; $ks -le 0.1000; $ks += 0.0100) {
                for ($kd = 0.0050; $kd -le 0.0250; $kd += 0.0050) {
                    $mae = Test-SCM420 $c $ke 0.0020 $kh $ks $kd 0.0021
                    if ($mae -lt $best_mae) {
                        $best_mae = $mae
                        $best_params = @{ c=$c; ke=$ke; kh=$kh; ks=$ks; kd=$kd }
                    }
                }
            }
        }
    }
}

Write-Host ("BEST SCM420 MAE: {0:F2} um" -f $best_mae)
Write-Host ("Parameters: C0={0:F4}, K_elec={1:F5}, K_h_conf={2:F4}, K_sec={3:F4}, K_deep={4:F4}" -f $best_params.c, $best_params.ke, $best_params.kh, $best_params.ks, $best_params.kd)
