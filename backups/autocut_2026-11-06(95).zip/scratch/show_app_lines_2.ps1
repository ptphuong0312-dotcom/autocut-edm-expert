$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
for ($i = 2280; $i -le 2305; $i++) {
    Write-Host "$($i + 1): [$($lines[$i])]"
}
