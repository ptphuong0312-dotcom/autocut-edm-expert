# Comprehensive Optimization of Complete Continuous Physical Model
$dataset = @(
    # SCM440 benchmark cuts (9 cuts)
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; speed=150; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; speed=200; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; speed=180; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; speed=100; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; speed=150; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; speed=150; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; speed=60;  mat='SCM440'; actual=0.0225; I=2.9 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; speed=50;  mat='SCM440'; actual=0.0200; I=3.7 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; speed=50;  mat='SCM440'; actual=0.0250; I=3.8 },

    # SCM420 benchmark cuts (10 cuts)
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; speed=150; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; speed=150; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; speed=150; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; speed=187; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; speed=150; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; speed=150; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; speed=50;  mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; speed=100; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; speed=154; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; speed=60;  mat='SCM420'; actual=0.0180; I=3.7 }
)

function Eval-Comprehensive($c0, $k_elec, $k_vf, $k_speed, $k_h_conf, $k_sec, $k_mat_420) {
    $errsAll = @()
    $errs440 = @()
    $errs420 = @()

    foreach ($it in $dataset) {
        $H = $it.H
        $Ton = $it.Ton
        $Po = $it.Po
        $IP = $it.IP
        $Volt = $it.Volt
        $VF = $it.VF
        $speed = $it.speed
        $mat = $it.mat
        $isHard = ($mat -eq 'SCM440')

        if ($H -le 170) {
            $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 0.815 }
            $d_elec = $k_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
            $d_vf = $k_vf * (($VF - 55.0) / 10.0)
            $d_speed = $k_speed * (($speed - 150.0) / 100.0)

            # Khả năng phá khe suy giảm khi phôi cao (SirPhuong)
            $d_h_conf = - $k_h_conf * ($H / 100.0)

            # Thoát phoi khó & Đánh lửa thứ cấp do tích tụ xỉ (SirPhuong)
            $rho = ($it.I / ($Po + 2.0)) * ($H / 100.0)
            $mat_mult = if ($isHard) { 1.0 } else { $k_mat_420 }
            $d_sec = $k_sec * [Math]::Pow($rho, 1.8) * $mat_mult

            $calc = $c0 + $d_elec + $d_vf + $d_speed + $d_h_conf + $d_sec
        } else {
            # H > 170mm: Phân vùng thống kê xưởng Rule 17
            $calc = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
            $d_vf = $k_vf * 0.5 * (($VF - 65.0) / 10.0)
            $calc += $d_vf
        }

        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errsAll += $diff
        if ($isHard) { $errs440 += $diff } else { $errs420 += $diff }
    }

    $mae = ($errsAll | Measure-Object -Average).Average
    $mae440 = ($errs440 | Measure-Object -Average).Average
    $mae420 = ($errs420 | Measure-Object -Average).Average
    $maxErr = ($errsAll | Measure-Object -Maximum).Maximum
    return @{ MAE=$mae; MAE440=$mae440; MAE420=$mae420; MaxErr=$maxErr }
}

Write-Host "Running comprehensive grid search..."
$best = @{ MAE=999; MAE420=999; MaxErr=999 }

for ($c = 0.0020; $c -le 0.0040; $c += 0.0004) {
    for ($ke = 0.0006; $ke -le 0.0010; $ke += 0.00005) {
        for ($ksp = 0.0020; $ksp -le 0.0080; $ksp += 0.0015) {
            for ($kh = 0.0060; $kh -le 0.0140; $kh += 0.0020) {
                for ($ks = 0.0200; $ks -le 0.0600; $ks += 0.0080) {
                    for ($km = 1.20; $km -le 1.80; $km += 0.15) {
                        $res = Eval-Comprehensive $c $ke 0.0021 $ksp $kh $ks $km
                        # We want both low total MAE and specifically low SCM420 MAE
                        $score = $res.MAE * 0.5 + $res.MAE420 * 0.5
                        if ($score -lt ($best.MAE * 0.5 + $best.MAE420 * 0.5)) {
                            $best = $res
                            $best.c = $c
                            $best.ke = $ke
                            $best.ksp = $ksp
                            $best.kh = $kh
                            $best.ks = $ks
                            $best.km = $km
                        }
                    }
                }
            }
        }
    }
}

Write-Host "================================================================================="
Write-Host "OPTIMAL CONTINUOUS PHYSICS MODEL RESULTS:"
Write-Host ("  MAE Toan cuc: {0:F2} um" -f $best.MAE)
Write-Host ("  MAE SCM440 (28-32 HRC): {0:F2} um" -f $best.MAE440)
Write-Host ("  MAE SCM420 (HB < 200):  {0:F2} um" -f $best.MAE420)
Write-Host ("  Max Error: {0:F2} um" -f $best.MaxErr)
Write-Host "---------------------------------------------------------------------------------"
Write-Host ("Parameters: C0={0:F4}, K_elec={1:F5}, K_speed={2:F4}, K_h_conf={3:F4}, K_sec={4:F4}, K_mat_420={5:F2}" -f $best.c, $best.ke, $best.ksp, $best.kh, $best.ks, $best.km)
