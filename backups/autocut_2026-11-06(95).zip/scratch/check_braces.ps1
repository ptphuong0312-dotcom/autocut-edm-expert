$text = [System.IO.File]::ReadAllText('app.js')
$opens = ($text.ToCharArray() | Where-Object { $_ -eq '{' }).Count
$closes = ($text.ToCharArray() | Where-Object { $_ -eq '}' }).Count
Write-Host "Braces balance: Opens = $opens, Closes = $closes, Diff = $($opens - $closes)"
if ($opens -eq $closes) { Write-Host "PERFECT BRACKET BALANCE!" } else { Write-Error "MISMATCHED BRACKETS!" }
