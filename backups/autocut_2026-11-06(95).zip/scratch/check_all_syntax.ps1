$text = [System.IO.File]::ReadAllText('app.js')
$opParen = ($text.ToCharArray() | Where-Object { $_ -eq '(' }).Count
$clParen = ($text.ToCharArray() | Where-Object { $_ -eq ')' }).Count
$opBracket = ($text.ToCharArray() | Where-Object { $_ -eq '[' }).Count
$clBracket = ($text.ToCharArray() | Where-Object { $_ -eq ']' }).Count
Write-Host "Parens: Opens = $opParen, Closes = $clParen, Diff = $($opParen - $clParen)"
Write-Host "Brackets: Opens = $opBracket, Closes = $clBracket, Diff = $($opBracket - $clBracket)"
