# Comprehensive script to apply Vong 5 Choice A to app.js
$lines = [System.IO.File]::ReadAllLines("app.js", [System.Text.Encoding]::UTF8)
$linesList = [System.Collections.Generic.List[string]]::new($lines)

# --- PART A: Constants in generateWorkshopRows (around line 2191) ---
$idxC0 = -1
for ($i = 2185; $i -le 2205; $i++) {
    if ($linesList[$i] -match "const C0 =") {
        $idxC0 = $i
        break
    }
}
Write-Host "idxC0: $idxC0"
# Constants range: from line 2191 (comment) to line with slag_mat
$idxConstStart = $idxC0 - 2
$idxConstEnd = -1
for ($i = $idxC0; $i -le $idxC0 + 15; $i++) {
    if ($linesList[$i] -match "const slag_mat =") {
        $idxConstEnd = $i
        break
    }
}
Write-Host "idxConstStart: $idxConstStart, idxConstEnd: $idxConstEnd"

[string[]]$newConstants = @(
'        // 1.5. HE THONG CONG THUC TOAN - VAT LY NHIET DONG HOC EDM TOAN NANG (RULE 10 - VONG 5 CAN BANG TOAN CAU)'
'        // Hieu chuan tinh chinh tu toan bo Ngan hang Du lieu Thuc nghiem Xuong (Toi uu hoa SCM420 & SCM440)'
'        const C0 = 0.00200;          // Hang so mang cach dien ion hoa ban dau (+2.00 um)'
'        const K_ELEC = 0.00070;      // Nang luong xung don toi uu (mm/sqrt(us*A))'
'        const K_VF = 0.00210;        // He so bu tre buoc tien VF (+2.10 um / 10 vach VF so voi chuan 55)'
'        const K_VIBR = 0.00350;      // He so mo rong kerf do rung uon co hoc day Moly'
'        const K_H_CONF = 0.00650;    // He so gioi han ap luc thuy tinh ranh sau phoi cao (mm)'
'        const K_SPD = 0.00550;       // He so bu giam toc phoi sau (Speed < 150Hz khi H >= 110mm)'
'        const K_SEC_BASE = 0.160;    // He so danh lua thu cap theo mat xi deo tich tu (mm)'
'        const K_RZ = 0.00120;        // He so chieu sau ho ro nhap nho pha tho Pass 1'
'        const H_THRESH = 63.0;       // Nguong thau voi phun kep (H <= 63mm xoi sach phoi, H > 63mm moi sinh nghen phoi)'
'        const PO_THRESH = 8.0;       // Nguong chu ky nghi Po xa phoi (Po <= 7 sinh nghen mat xi)'
'        const S_EXP = 0.65;          // Luy thua suy giam do sau ranh nen mat xi'
'        const slag_mat = isHard ? 1.0 : 0.80;'
)

$linesList.RemoveRange($idxConstStart, ($idxConstEnd - $idxConstStart + 1))
$linesList.InsertRange($idxConstStart, [System.Collections.Generic.IEnumerable[string]]$newConstants)
Write-Host "[OK] Part A applied."

# --- PART B: baseGap in generateWorkshopRows ---
$idxBase = -1
for ($i = 2270; $i -le 2320; $i++) {
    if ($linesList[$i] -match "const u_ratio_base = baseVolt") {
        $idxBase = $i
        break
    }
}
$idxBaseEnd = -1
for ($i = $idxBase; $i -le $idxBase + 20; $i++) {
    if ($linesList[$i] -match "baseGap = C0 \+") {
        $idxBaseEnd = $i
        break
    }
}
Write-Host "idxBase: $idxBase, idxBaseEnd: $idxBaseEnd"

[string[]]$newBaseGap = @(
'            // Tinh toan gioi han tan so p1_hz de ap dung he so giam toc phoi sau d_spd'
'            let p1_hz;'
'            if (H <= 40) p1_hz = 200;'
'            else if (H <= 170) p1_hz = Math.round(200 - (H - 40) * (200 - 150) / (170 - 40));'
'            else p1_hz = Math.round(150 - (Math.min(300, H) - 170) * (150 - 50) / (300 - 170));'
''
'            const u_ratio_base = baseVolt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_base = K_ELEC * Math.sqrt(baseTon * baseIP) * u_ratio_base;'
'            const d_vf_base = K_VF * ((baseVF - 55.0) / 10.0);'
'            const d_vibr_base = K_VIBR * Math.pow(H / 100.0, 2) * (baseIP / 5.0);'
'            const d_h_conf_base = - K_H_CONF * (H / 100.0);'
'            const d_spd_base = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;'
'            const h_starve_base = Math.max(0.0, (H - H_THRESH) / 100.0);'
'            const po_shortage_base = Math.max(0.0, (PO_THRESH - basePo) / 10.0);'
'            const mat_boost_base = isHard ? 1.0 : 2.60;'
'            const d_sec_base = K_SEC_BASE * Math.pow(h_starve_base, S_EXP) * po_shortage_base * mat_boost_base;'
'            baseGap = C0 + d_elec_base + d_vf_base + d_vibr_base + d_h_conf_base + d_spd_base + d_sec_base;'
)

$linesList.RemoveRange($idxBase, ($idxBaseEnd - $idxBase + 1))
$linesList.InsertRange($idxBase, [System.Collections.Generic.IEnumerable[string]]$newBaseGap)
Write-Host "[OK] Part B applied."

# --- PART C: gap in generateWorkshopRows ---
$idxActual = -1
for ($i = $idxBase + 20; $i -le $idxBase + 80; $i++) {
    if ($linesList[$i] -match "const u_ratio_actual = Volt ===") {
        $idxActual = $i
        break
    }
}
$idxActualEnd = -1
for ($i = $idxActual; $i -le $idxActual + 20; $i++) {
    if ($linesList[$i] -match "gap = C0 \+ d_elec_actual") {
        $idxActualEnd = $i
        break
    }
}
Write-Host "idxActual: $idxActual, idxActualEnd: $idxActualEnd"

[string[]]$newActualGap = @(
'            const u_ratio_actual = Volt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_actual = K_ELEC * Math.sqrt(Ton * IP) * u_ratio_actual;'
'            const d_vf_actual = K_VF * ((VF - 55.0) / 10.0);'
'            const d_vibr_actual = K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);'
'            const d_h_conf_actual = - K_H_CONF * (H / 100.0);'
'            const d_spd_actual = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;'
'            const h_starve_actual = Math.max(0.0, (H - H_THRESH) / 100.0);'
'            const po_shortage_actual = Math.max(0.0, (PO_THRESH - Po) / 10.0);'
'            const mat_boost_actual = isHard ? 1.0 : 2.60;'
'            const d_sec_actual = K_SEC_BASE * Math.pow(h_starve_actual, S_EXP) * po_shortage_actual * mat_boost_actual;'
'            gap = C0 + d_elec_actual + d_vf_actual + d_vibr_actual + d_h_conf_actual + d_spd_actual + d_sec_actual;'
)

$linesList.RemoveRange($idxActual, ($idxActualEnd - $idxActual + 1))
$linesList.InsertRange($idxActual, [System.Collections.Generic.IEnumerable[string]]$newActualGap)
Write-Host "[OK] Part C applied."

# --- PART D: Pass 2 in generateWorkshopRows ---
$idxP2 = -1
for ($i = $idxActual + 30; $i -le $idxActual + 90; $i++) {
    if ($linesList[$i] -match "const Rz_p1 = K_RZ") {
        $idxP2 = $i
        break
    }
}
$idxP2End = -1
for ($i = $idxP2; $i -le $idxP2 + 10; $i++) {
    if ($linesList[$i] -match "const delta_2_calc =") {
        $idxP2End = $i
        break
    }
}
Write-Host "idxP2: $idxP2, idxP2End: $idxP2End"

[string[]]$newP2 = @(
'            const Rz_p1 = K_RZ * Math.sqrt(Ton * IP) * u_ratio_actual;'
'            const u_ratio_p2 = p2_volt === ''High'' ? 1.0 : 0.815;'
'            const d_elec_p2 = K_ELEC * Math.sqrt(p2_ton * p2_ip) * u_ratio_p2;'
'            const d_h_conf_p2 = - K_H_CONF * (H / 100.0) * 0.5;'
'            const delta_2_calc = C0 + d_elec_p2 + d_h_conf_p2;'
)

$linesList.RemoveRange($idxP2, ($idxP2End - $idxP2 + 1))
$linesList.InsertRange($idxP2, [System.Collections.Generic.IEnumerable[string]]$newP2)

# Remove duplicate let p1_hz
for ($i = $idxP2 + 10; $i -le $idxP2 + 40; $i++) {
    if ($linesList[$i] -match "let p1_hz;") {
        $linesList[$i] = '        // p1_hz da duoc tinh toan o tren'
        Write-Host "Replaced duplicate let p1_hz at line: $($i + 1)"
        break
    }
}
Write-Host "[OK] Part D applied."

# --- PART E: WS_LIB_BENCHMARK_JOBS[1] calcOffsets (all 19 jobs) ---
$offsets = @{
    'Ton: 20, Toff: 5, IP: 3, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz"'  = '0,0988'
    'Ton: 16, Toff: 6, IP: 3, Wire: 1, Volt: "L", VF: 60, maxSpeed: "150Hz"'  = '0,0963'
    'Ton: 32, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "200Hz"'  = '0,1003'
    'Ton: 36, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "180Hz"'  = '0,1003'
    'Ton: 44, Toff: 7, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz"'  = '0,0997'
    'Ton: 44, Toff: 8, IP: 4, Wire: 1, Volt: "H", VF: 57, maxSpeed: "150Hz"'  = '0,0987'
    'Ton: 70, Toff: 7, IP: 3, Wire: 1, Volt: "L", VF: 50, maxSpeed: "100Hz"'  = '0,0981'
    'Ton: 55, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "187Hz"'  = '0,1094'
    'Ton: 70, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 61, maxSpeed: "150Hz"'  = '0,1034'
    'Ton: 80, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "150Hz"'  = '0,1185'
    'Ton: 82, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz"'  = '0,1087'
    'Ton: 100, Toff: 10, IP: 5, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz"' = '0,1068'
    'Ton: 120, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "50Hz"'   = '0,0987'
    'Ton: 100, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 60, maxSpeed: "100Hz"'  = '0,1052'
    'Ton: 120, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "154Hz"' = '0,1143'
    'Ton: 135, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "60Hz"'  = '0,1068'
    'Ton: 120, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "60Hz"'  = '0,1102'
    'Ton: 135, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 75, maxSpeed: "50Hz"'  = '0,1156'
    'Ton: 120, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "50Hz"'   = '0,1150'
}

$updatedCount = 0
for ($i = 3700; $i -le 3900; $i++) {
    if ($i -ge $linesList.Count) { break }
    foreach ($k in $offsets.Keys) {
        if ($linesList[$i].Contains($k)) {
            $linesList[$i] = [System.Text.RegularExpressions.Regex]::Replace($linesList[$i], 'calcOffset: "[^"]+"', "calcOffset: `"$($offsets[$k])`"")
            $updatedCount++
            break
        }
    }
}
Write-Host "[OK] Part E: Updated $updatedCount benchmark calcOffsets."

# --- PART F: Tab 3 Constants & calcBaseSparkGap / calcVFSparkGap ---
$idxTab3Const = -1
for ($i = 4050; $i -le 4150; $i++) {
    if ($linesList[$i] -match "const VF_C0 =") {
        $idxTab3Const = $i
        break
    }
}
$idxTab3End = -1
for ($i = $idxTab3Const; $i -le $idxTab3Const + 15; $i++) {
    if ($linesList[$i] -match "const VF_S_THRESH =") {
        $idxTab3End = $i
        break
    }
}
Write-Host "idxTab3Const: $idxTab3Const, idxTab3End: $idxTab3End"

[string[]]$newTab3Constants = @(
'    const VF_C0 = 0.00200;          // Hang so mang cach dien ban dau (+2.00 um)'
'    const VF_K_ELEC = 0.00070;      // Nang luong xung don toi uu (mm/sqrt(us*A))'
'    const VF_K_VF = 0.00210;        // He so bu tre buoc tien VF (+2.10 um / 10 vach VF so voi chuan 55)'
'    const VF_K_VIBR = 0.00350;      // Rung uon co hoc day Moly (mm)'
'    const VF_K_H_CONF = 0.00650;    // He so gioi han ap luc thuy tinh ranh sau phoi cao (mm)'
'    const VF_K_SPD = 0.00550;       // He so bu giam toc phoi sau (Speed < 150Hz khi H >= 110mm)'
'    const VF_K_SEC = 0.160;         // He so danh lua thu cap theo mat xi deo tich tu (mm)'
'    const VF_H_THRESH = 63.0;       // Nguong thau voi phun kep (H <= 63mm xoi sach phoi)'
'    const VF_PO_THRESH = 8.0;       // Nguong chu ky nghi Po xa phoi (Po <= 7 sinh nghen mat xi)'
'    const VF_S_EXP = 0.65;          // Luy thua suy giam do sau ranh nen mat xi'
)

$linesList.RemoveRange($idxTab3Const, ($idxTab3End - $idxTab3Const + 1))
$linesList.InsertRange($idxTab3Const, [System.Collections.Generic.IEnumerable[string]]$newTab3Constants)
Write-Host "[OK] Part F1: Tab 3 Constants applied."

# Tab 3 calcBaseSparkGap implementation
$idxCalcBase = -1
for ($i = $idxTab3Const + 10; $i -le $idxTab3Const + 30; $i++) {
    if ($linesList[$i] -match "function calcBaseSparkGap") {
        $idxCalcBase = $i
        break
    }
}
# Find end of calcBaseSparkGap (return {...})
$idxCalcBaseEnd = -1
for ($i = $idxCalcBase; $i -le $idxCalcBase + 60; $i++) {
    if ($linesList[$i] -match "kerf: 0.180 \+ 2.0 \* gap") {
        $idxCalcBaseEnd = $i + 2
        break
    }
}
Write-Host "idxCalcBase: $idxCalcBase, idxCalcBaseEnd: $idxCalcBaseEnd"

[string[]]$newCalcBaseSparkGap = @(
'    function calcBaseSparkGap(H, Ton, IP, Volt, material = ''SCM440'', speed = 150) {'
'        const isHard = (material === ''SCM440'' || material === ''30HRC'');'
'        const u_ratio = (Volt === ''High'' || Volt === ''H'') ? 1.0 : 0.815;'
'        const d_elec = VF_K_ELEC * Math.sqrt(Math.max(1, Ton) * Math.max(1, IP)) * u_ratio;'
'        const d_h_conf = - VF_K_H_CONF * (H / 100.0);'
'        let d_vibr, gap, d_sec, d_spd;'
''
'        if (H <= 170) {'
'            d_vibr = VF_K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);'
'            d_spd = (H >= 110 && speed < 150) ? - VF_K_SPD * ((150.0 - speed) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;'
'            const h_starve = Math.max(0.0, (H - VF_H_THRESH) / 100.0);'
'            const po_shortage = Math.max(0.0, (VF_PO_THRESH - 5.0) / 10.0); // Po chuan = 5'
'            const mat_boost = isHard ? 1.0 : 2.60;'
'            d_sec = VF_K_SEC * Math.pow(h_starve, VF_S_EXP) * po_shortage * mat_boost;'
'            gap = VF_C0 + d_elec + d_h_conf + d_vibr + d_spd + d_sec;'
'        } else {'
'            const gap170 = 0.0187;'
'            const targetGap300 = 0.0250;'
'            gap = gap170 + (H - 170) * (targetGap300 - gap170) / (300 - 170);'
'            d_vibr = gap - (VF_C0 + d_elec + d_h_conf);'
'            d_sec = 0.0;'
'            d_spd = 0.0;'
'        }'
''
'        return {'
'            c0: VF_C0,'
'            u_ratio: u_ratio,'
'            d_elec: d_elec,'
'            d_h_conf: d_h_conf,'
'            d_vibr: d_vibr,'
'            d_spd: d_spd,'
'            d_sec: d_sec,'
'            gap: gap,'
'            offset: 0.090 + gap,'
'            kerf: 0.180 + 2.0 * gap'
'        };'
'    }'
)

$linesList.RemoveRange($idxCalcBase, ($idxCalcBaseEnd - $idxCalcBase + 1))
$linesList.InsertRange($idxCalcBase, [System.Collections.Generic.IEnumerable[string]]$newCalcBaseSparkGap)
Write-Host "[OK] Part F2: calcBaseSparkGap applied."

# Tab 3 calcVFSparkGap implementation
$idxCalcVF = -1
for ($i = $idxCalcBase + 25; $i -le $idxCalcBase + 50; $i++) {
    if ($linesList[$i] -match "function calcVFSparkGap") {
        $idxCalcVF = $i
        break
    }
}
$idxCalcVFEnd = -1
for ($i = $idxCalcVF; $i -le $idxCalcVF + 30; $i++) {
    if ($linesList[$i] -match "diff_um = \(gap_vf - base\.gap\)") {
        $idxCalcVFEnd = $i
        break
    }
}
Write-Host "idxCalcVF: $idxCalcVF, idxCalcVFEnd: $idxCalcVFEnd"

[string[]]$newCalcVF = @(
'    function calcVFSparkGap(H, Ton, IP, Volt, VF, Po = 5, material = ''SCM440'', speed = 150) {'
'        const base = calcBaseSparkGap(H, Ton, IP, Volt, material, speed);'
'        let d_vf, d_sec_vf, d_po;'
'        const isHard = (material === ''SCM440'' || material === ''30HRC'');'
''
'        if (H <= 170) {'
'            d_vf = VF_K_VF * ((VF - 55.0) / 10.0);'
'            const h_starve = Math.max(0.0, (H - VF_H_THRESH) / 100.0);'
'            const po_shortage_vf = Math.max(0.0, (VF_PO_THRESH - Po) / 10.0);'
'            const mat_boost = isHard ? 1.0 : 2.60;'
'            d_sec_vf = VF_K_SEC * Math.pow(h_starve, VF_S_EXP) * po_shortage_vf * mat_boost;'
'            d_po = d_sec_vf - base.d_sec; // Do lech bu theo chu ky Po thuc te'
'        } else {'
'            d_vf = VF_K_VF * 0.5 * ((VF - 65.0) / 10.0);'
'            d_sec_vf = 0.0;'
'            d_po = 0.0;'
'        }'
'        const gap_vf = base.c0 + base.d_elec + base.d_h_conf + base.d_vibr + base.d_spd + d_vf + d_sec_vf;'
'        const diff_um = (gap_vf - base.gap) * 1000.0;'
)

$linesList.RemoveRange($idxCalcVF, ($idxCalcVFEnd - $idxCalcVF + 1))
$linesList.InsertRange($idxCalcVF, [System.Collections.Generic.IEnumerable[string]]$newCalcVF)
Write-Host "[OK] Part F3: calcVFSparkGap applied."

# Save updated app.js
[System.IO.File]::WriteAllLines("app.js", $linesList, [System.Text.Encoding]::UTF8)
Write-Host "ALL PARTS APPLIED TO APP.JS SUCCESSFULLY!"
