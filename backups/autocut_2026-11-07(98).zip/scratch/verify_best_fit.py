import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

dataset = [
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "target": 280, "low": 275, "high": 285, "read": "275 - 285", "L": 128.0, "t_real": 19.833},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "target": 170, "low": 165, "high": 175, "read": "165 - 175", "L": 30.0, "t_real": 8.667},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "target": 135, "low": 130, "high": 140, "read": "130 - 140", "L": 30.0, "t_real": 9.600},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "target": 80,  "low": 75,  "high": 85,  "read": "75 - 85", "L": 27.0, "t_real": 14.333},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "target": 55,  "low": 50,  "high": 65,  "read": "50 - 65", "L": 22.3, "t_real": 17.667},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "target": 55,  "low": 50,  "high": 65,  "read": "50 - 65", "L": 50.3, "t_real": 73.000},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "target": 60,  "low": 55,  "high": 65,  "read": "55 - 65", "L": 65.6, "t_real": 48.000},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "target": 55,  "low": 50,  "high": 60,  "read": "50 - 60", "L": None, "t_real": None},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "target": 40,  "low": 35,  "high": 45,  "read": "35 - 45", "L": 76.0, "t_real": 75.000},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "target": 35,  "low": 30,  "high": 40,  "read": "30 - 40", "L": None, "t_real": None},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "target": 35,  "low": 30,  "high": 40,  "read": "30 - 40", "L": 28.4, "t_real": 36.000},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "target": 23,  "low": 18,  "high": 28,  "read": "18 - 28", "L": 32.3, "t_real": 59.000},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "target": 25,  "low": 15,  "high": 35,  "read": "15 - 35", "L": 43.6, "t_real": 77.000},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "target": 16,  "low": 12,  "high": 20,  "read": "12 - 20", "L": 76.1, "t_real": 180.00},
]

a_ton, a_ip, k_b, g_h, k_soft, p_exp = (0.25, 0.5, 126, 0.06, 1.0, 0.7)

print(f"{'Bài':<7} | {'H':<3} | {'Đọc trên máy':<14} | {'Fc máy Tính':<12} | {'Trạng thái':<14} | {'Fc thực Tính':<14} | {'t thực':<7} | {'t tính':<7}")
print("-" * 92)
for j in dataset:
    H = j['H']
    Ton = j['Ton']
    Po = j['Po']
    IP = j['IP']
    VF = j['VF']
    isHard = (j['mat'] == 'SCM440')
    
    duty = 1.0 / (Po + 2.0)
    ep_factor = math.pow(Ton / 40.0, a_ton) * math.pow(IP / 4.0, a_ip)
    duty_factor = duty / (1.0 / 7.0)
    
    slag_loss = 1.0 - (0.0008 * max(0, H - 40)) if isHard else (1.0 - 0.0012 * max(0, H - 40))
    slag_loss = max(0.65, slag_loss)
    
    vf_factor = 1.0 + (VF - 55.0) * 0.006
    mat_factor = 1.0 if isHard else k_soft
    
    fc_thuc = k_b * ep_factor * math.pow(duty_factor, p_exp) * slag_loss * vf_factor * mat_factor
    fc_thuc = fc_thuc * math.pow(40.0 / max(20.0, H), g_h)
    
    fc_may = fc_thuc * (40.0 / H)
    fc_may = min(fc_may, 280.0)
    
    r_may = round(fc_may)
    in_range = "TRONG KHOẢNG" if (j['low'] <= r_may <= j['high']) else f"LỆCH ({r_may - j['target']:+})"
    
    # Tính thời gian t_calc
    ft = fc_may / 40.0
    t_calc = (j['L'] / ft) if j['L'] else None
    t_calc_str = f"{t_calc:.1f}p" if t_calc else "--"
    t_real_str = f"{j['t_real']:.1f}p" if j['t_real'] else "--"
    
    print(f"{j['name']:<7} | {j['H']:<3} | {j['read']:<14} | {r_may:<12} | {in_range:<14} | {round(fc_thuc):<14} | {t_real_str:<7} | {t_calc_str:<7}")
