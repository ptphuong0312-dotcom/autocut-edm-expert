import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

# Mô phỏng chính xác thuật toán hiện tại trong generateWorkshopRows (app.js dòng 2480-2524)
def calc_current_fc(H, Ton, Po, IP, Volt, VF, isHard):
    toff = Ton * (Po + 1)
    true_cycle = Ton + toff
    duty = Ton / true_cycle

    eta_eff = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.38)
    if Ton > 80:
        eta_eff = min(0.92, eta_eff)

    if isHard:
        if H > 80:
            eta_eff *= max(0.65, 1.0 - (H - 80) * 0.0010)
    else:
        if H > 50:
            eta_eff *= max(0.55, 1.0 - (H - 50) * 0.0016)

    u_arc = 22 if Volt == 'Low' else 27
    i_peak = IP * 2.8
    power_watts = u_arc * i_peak * duty

    Cm = 0.0140
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea = round(mrr_vol / B)
    feedRate = round(speedArea / H, 2)
    speedAreaH40 = round(feedRate * 40)
    return speedArea, speedAreaH40, feedRate

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 170},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 135},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55, 'note_fc': 80},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60, 'note_fc': 35},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65, 'note_fc': 16},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 23},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54, 'note_fc': 57},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76, 't_min': 75, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55, 'note_fc': 40},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57, 'note_fc': 57},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61, 'note_fc': 60},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 25},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62, 'note_fc': 70},
    {'name': '2P-14 P1', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54, 'note_fc': 57},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65, 'note_fc': 280},
]

print(f"{'Bài cắt':<10} {'H':<4} {'Ft thực':<8} {'FcThực Đo':<10} {'FcThực Tính':<12} {'ΔFcThực':<8} | {'FcMáy Gốc':<10} {'FcMáy Tính':<11} {'ΔFcMáy':<8}")
print("-" * 90)

diff_thuc_list = []
diff_may_list = []

for r in runs:
    fc_thuc_do = (r['L'] * r['H']) / r['t_min']
    ft_thuc_do = r['L'] / r['t_min']
    fc_may_goc = ft_thuc_do * 40 # Hoặc r['note_fc']
    
    fc_thuc_calc, fc_may_calc, ft_calc = calc_current_fc(r['H'], r['ti'], r['po'], r['ip'], r['volt'], r['vf'], r['isHard'])
    
    d_thuc = fc_thuc_calc - fc_thuc_do
    d_may = fc_may_calc - fc_may_goc
    
    diff_thuc_list.append(abs(d_thuc))
    diff_may_list.append(abs(d_may))
    
    print(f"{r['name']:<10} {r['H']:<4} {ft_thuc_do:<8.2f} {fc_thuc_do:<10.1f} {fc_thuc_calc:<12} {d_thuc:<+8.1f} | {fc_may_goc:<10.1f} {fc_may_calc:<11} {d_may:<+8.1f}")

mae_thuc = sum(diff_thuc_list) / len(diff_thuc_list)
mae_may = sum(diff_may_list) / len(diff_may_list)
print("-" * 90)
print(f"MAE Fc Thực hiện tại: {mae_thuc:.2f} mm²/p | MAE Fc Máy hiện tại: {mae_may:.2f} mm²/p")
