import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

# Đọc các bài trong WS_LIB_BENCHMARK_JOBS[1]
def calc_v5_lib(H, Ton, Po, IP, Volt, VF, hz, isHard, length_mm):
    toff = Ton * (Po + 1)
    duty = Ton / (Ton + toff)
    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.28)
    if Ton > 80: eta_base = min(0.92, eta_base)
    eta_h = max(0.70, 1.0 - max(0, H - 80) * 0.0005) if isHard else max(0.55, 1.0 - max(0, H - 50) * 0.0022)
    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.6
    k_drag = max(0.38, 1.0 - 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke)
    
    if VF >= 55.0:
        k_vf = 1.0 + (VF - 55.0) * 0.0050
    else:
        k_vf = 1.0 + (VF - 55.0) * 0.0100

    eta_eff = eta_base * eta_h * k_drag * k_vf
    p_w = (22 if Volt == 'Low' else 27) * (IP * 2.8) * duty
    v_raw = (60 * 0.0135 * p_w * eta_eff) / 0.23
    ft = min(v_raw / H, hz * 0.060)
    fc_thuc = round(ft * H)
    fc_may = round(ft * 40)
    
    if length_mm and length_mm > 0:
        t_min = length_mm / ft
        hrs = int(t_min // 60)
        mins = int(t_min % 60)
        secs = int(round((t_min * 60) % 60))
        if secs == 60:
            mins += 1; secs = 0
        if hrs > 0:
            t_str = f"{hrs}h{mins:02d}p" if secs == 0 else f"{hrs}h{mins:02d}p{secs:02d}s"
        else:
            t_str = f"{mins}p{secs:02d}s" if secs > 0 else f"{mins}p"
    else:
        t_str = "--"
    return fc_thuc, fc_may, t_str

lib_p1 = [
    { 'H': 12, 'mat': "30HRC", 'isHard': True, 'Ton': 20, 'Toff': 5, 'IP': 3, 'Volt': "High", 'VF': 65, 'hz': 150, 'L': 128 },
    { 'H': 12, 'mat': "HB<200", 'isHard': False, 'Ton': 16, 'Toff': 6, 'IP': 3, 'Volt': "Low", 'VF': 60, 'hz': 150, 'L': 0 },
    { 'H': 30, 'mat': "30HRC", 'isHard': True, 'Ton': 32, 'Toff': 5, 'IP': 4, 'Volt': "High", 'VF': 65, 'hz': 200, 'L': 30 },
    { 'H': 40, 'mat': "30HRC", 'isHard': True, 'Ton': 36, 'Toff': 5, 'IP': 4, 'Volt': "High", 'VF': 65, 'hz': 180, 'L': 30 },
    { 'H': 63, 'mat': "HB<200", 'isHard': False, 'Ton': 44, 'Toff': 7, 'IP': 5, 'Volt': "High", 'VF': 55, 'hz': 150, 'L': 27 },
    { 'H': 63, 'mat': "HB<200", 'isHard': False, 'Ton': 44, 'Toff': 8, 'IP': 4, 'Volt': "High", 'VF': 57, 'hz': 150, 'L': 22.3 },
    { 'H': 68, 'mat': "30HRC", 'isHard': True, 'Ton': 70, 'Toff': 7, 'IP': 3, 'Volt': "Low", 'VF': 50, 'hz': 100, 'L': 0 },
    { 'H': 75, 'mat': "HB<200", 'isHard': False, 'Ton': 55, 'Toff': 7, 'IP': 4, 'Volt': "High", 'VF': 54, 'hz': 187, 'L': 50.3 },
    { 'H': 85, 'mat': "30HRC", 'isHard': True, 'Ton': 70, 'Toff': 8, 'IP': 5, 'Volt': "High", 'VF': 61, 'hz': 150, 'L': 65.6 },
    { 'H': 90, 'mat': "HB<200", 'isHard': False, 'Ton': 80, 'Toff': 7, 'IP': 4, 'Volt': "High", 'VF': 54, 'hz': 150, 'L': 0 },
    { 'H': 95, 'mat': "30HRC", 'isHard': True, 'Ton': 82, 'Toff': 7, 'IP': 4, 'Volt': "High", 'VF': 55, 'hz': 150, 'L': 76 },
    { 'H': 110, 'mat': "HB<200", 'isHard': False, 'Ton': 100, 'Toff': 10, 'IP': 5, 'Volt': "High", 'VF': 65, 'hz': 150, 'L': 0 },
    { 'H': 140, 'mat': "HB<200", 'isHard': False, 'Ton': 120, 'Toff': 8, 'IP': 5, 'Volt': "High", 'VF': 55, 'hz': 50, 'L': 0 },
    { 'H': 140, 'mat': "HB<200", 'isHard': False, 'Ton': 100, 'Toff': 9, 'IP': 6, 'Volt': "High", 'VF': 60, 'hz': 100, 'L': 28.4 },
    { 'H': 160, 'mat': "HB<200", 'isHard': False, 'Ton': 120, 'Toff': 11, 'IP': 6, 'Volt': "High", 'VF': 70, 'hz': 154, 'L': 32.3 },
    { 'H': 165, 'mat': "30HRC", 'isHard': True, 'Ton': 135, 'Toff': 11, 'IP': 6, 'Volt': "High", 'VF': 70, 'hz': 60, 'L': 43.6 },
    { 'H': 200, 'mat': "HB<200", 'isHard': False, 'Ton': 120, 'Toff': 10, 'IP': 6, 'Volt': "High", 'VF': 65, 'hz': 60, 'L': 0 },
    { 'H': 290, 'mat': "30HRC", 'isHard': True, 'Ton': 135, 'Toff': 10, 'IP': 6, 'Volt': "High", 'VF': 75, 'hz': 50, 'L': 0 },
    { 'H': 300, 'mat': "30HRC", 'isHard': True, 'Ton': 120, 'Toff': 9, 'IP': 6, 'Volt': "High", 'VF': 65, 'hz': 50, 'L': 76.1 }
]

print("CẬP NHẬT CHUẨN XÁC THƯ VIỆN BENCHMARK V5:")
for item in lib_p1:
    fc_t, fc_m, t_str = calc_v5_lib(item['H'], item['Ton'], item['Toff'], item['IP'], item['Volt'], item['VF'], item['hz'], item['isHard'], item['L'])
    print(f"H={item['H']:<3} {item['mat']:<7} Ton={item['Ton']:<3} Po={item['Toff']:<2} IP={item['IP']} VF={item['VF']} Hz={item['hz']} => Fc_máy={fc_m} mm²/p | calcTime={t_str}")
