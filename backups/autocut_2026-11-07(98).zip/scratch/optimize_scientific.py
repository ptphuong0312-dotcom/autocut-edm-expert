import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 15 bài cắt có số đo cứng L, H, t thực tế từ xưởng SirPhuong
benchmarks = [
    {"id": "5P-01",  "mat": "SCM440", "H": 12,  "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_real": 19.833},
    {"id": "2P-10",  "mat": "SCM440", "H": 85,  "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6,  "t_real": 48.000},
    {"id": "2P-11",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_real": 77.000},
    {"id": "2P-12",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_real": 77.000},
    {"id": "STT 1",  "mat": "SCM440", "H": 30,  "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_real": 8.667},
    {"id": "STT 2",  "mat": "SCM440", "H": 40,  "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_real": 9.600},
    {"id": "STT 3",  "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_real": 14.333},
    {"id": "STT 9",  "mat": "SCM420", "H": 63,  "Ton": 24,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 43, "Hz": 150, "L": 27.0,  "t_real": 21.000},
    {"id": "STT 12", "mat": "SCM420", "H": 140, "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4,  "t_real": 36.000},
    {"id": "STT 13", "mat": "SCM440", "H": 300, "Ton": 80,  "Po": 9,  "IP": 6, "Volt": "High", "VF": 50, "Hz": 50,  "L": 31.3,  "t_real": 89.000},
    {"id": "STT 14", "mat": "SCM440", "H": 300, "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1,  "t_real": 180.000},
    {"id": "STT 15", "mat": "SCM420", "H": 160, "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3,  "t_real": 59.000},
    {"id": "STT 16", "mat": "SCM420", "H": 75,  "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3,  "t_real": 73.000},
    {"id": "STT 17", "mat": "SCM440", "H": 95,  "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0,  "t_real": 75.000},
    {"id": "STT 18", "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3,  "t_real": 17.667},
]

# Tính ground truth cho từng bài
for b in benchmarks:
    b['ft_real'] = b['L'] / b['t_real']
    b['fc_thuc_real'] = b['ft_real'] * b['H']
    b['fc_may_real'] = b['ft_real'] * 40.0

def evaluate_params(params):
    # params: eta0_hard, eta0_soft, p_ton, h_slope_hard, h_slope_soft, drag_scale, drag_mat_soft, vf_pos, vf_neg
    eta0_hard, eta0_soft, p_ton, h_slope_hard, h_slope_soft, drag_scale, drag_mat_soft, vf_pos, vf_neg = params
    
    mape_t = 0.0
    mae_t = 0.0
    mae_fcm = 0.0
    mae_fcr = 0.0
    
    for b in benchmarks:
        H = b['H']
        Ton = b['Ton']
        Po = b['Po']
        IP = b['IP']
        Volt = b['Volt']
        VF = b['VF']
        Hz = b['Hz']
        isHard = (b['mat'] == 'SCM440')
        
        toff = Ton * (Po + 1)
        duty = Ton / (Ton + toff)
        Uarc = 27.0 if Volt == 'High' else 22.0
        power_watts = Uarc * (2.8 * IP) * duty
        
        # 1. Năng lượng xung đơn không bị trần cứng
        eta_base = (eta0_hard if isHard else eta0_soft) * math.pow(max(1, Ton) / 50.0, p_ton)
        
        # 2. Suy giảm độ sâu rãnh phôi
        if isHard:
            eta_h = max(0.60, 1.0 - max(0, H - 40) * h_slope_hard)
        else:
            eta_h = max(0.50, 1.0 - max(0, H - 40) * h_slope_soft)
            
        # 3. Lực cản mạt xỉ dẻo nghẽn phôi
        h_choke = max(0.0, (H - 63.0) / 100.0)
        po_choke = max(0.0, (8.0 - Po) / 10.0)
        mat_choke = 1.0 if isHard else drag_mat_soft
        drag_loss = drag_scale * math.pow(h_choke, 0.65) * po_choke * mat_choke
        k_drag = max(0.35, 1.0 - drag_loss)
        
        # 4. Phản ứng bám tải VF phi tuyến 2 nhánh
        if VF >= 55.0:
            k_vf = 1.0 + (VF - 55.0) * vf_pos
        else:
            k_vf = 1.0 + (VF - 55.0) * vf_neg
            
        eta_eff = eta_base * eta_h * k_drag * k_vf
        speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23
        
        feedRate_calc = speedArea_raw / H
        ft_max = Hz * 0.060
        feedRate_final = min(feedRate_calc, ft_max)
        
        fc_thuc_calc = feedRate_final * H
        fc_may_calc = feedRate_final * 40.0
        t_calc = b['L'] / feedRate_final
        
        mape_t += abs(t_calc - b['t_real']) / b['t_real']
        mae_t += abs(t_calc - b['t_real'])
        mae_fcm += abs(fc_may_calc - b['fc_may_real'])
        mae_fcr += abs(fc_thuc_calc - b['fc_thuc_real'])
        
    n = len(benchmarks)
    return (mape_t / n) * 100.0, mae_t / n, mae_fcm / n, mae_fcr / n

# Baseline cũ (Vòng 5)
v5_params = (0.85, 0.78, 0.28, 0.0005, 0.0022, 0.60, 2.60, 0.0050, 0.0100)
mape5, mae_t5, mae_fcm5, mae_fcr5 = evaluate_params(v5_params)
print(f"--- BASELINE VÒNG 5 CŨ ---")
print(f"MAPE thời gian t: {mape5:.2f}% | MAE t: {mae_t5:.2f}p | MAE Fc_máy: {mae_fcm5:.2f} mm²/p | MAE Fc_thực: {mae_fcr5:.2f} mm²/p\n")
