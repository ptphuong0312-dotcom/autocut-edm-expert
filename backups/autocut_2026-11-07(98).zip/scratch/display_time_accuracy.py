import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': '2P-02 P1', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': '2P-03 P1', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

def fmt_time(minutes):
    hrs = int(minutes // 60)
    mins = int(minutes % 60)
    secs = int(round((minutes * 60) % 60))
    if secs == 60:
        mins += 1
        secs = 0
    if hrs > 0:
        return f"{hrs}h{mins:02d}p" if secs == 0 else f"{hrs}h{mins:02d}p{secs:02d}s"
    else:
        return f"{mins}p{secs:02d}s" if secs > 0 else f"{mins}p"

C_m = 0.0135
exp_ton = 0.30
k_vf = 0.0060
k_slag = 0.55
h_scale_hard = 0.0006
h_scale_soft = 0.0022

print("=" * 125)
print(f"{'Mẫu Cắt':<10} {'Mat':<7} {'H':<4} {'L(mm)':<6} | {'t thực':<10} {'t tính':<10} {'Sai lệch t':<12} | {'FcThực Đo':<10} {'FcThực Tính':<12} | {'FcMáy Đo':<10} {'FcMáy Tính':<11} {'Δ Máy':<6}")
print("=" * 125)

for r in runs:
    toff = r['ti'] * (r['po'] + 1)
    true_cycle = r['ti'] + toff
    duty = r['ti'] / true_cycle
    
    eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, exp_ton)
    if r['ti'] > 80: eta_base = min(0.92, eta_base)

    if r['isHard']:
        eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * h_scale_hard)
    else:
        eta_h = max(0.55, 1.0 - max(0, r['H'] - 50) * h_scale_soft)

    h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - r['po']) / 10.0)
    mat_choke = 1.0 if r['isHard'] else 2.6
    slag_drag = k_slag * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.40, 1.0 - slag_drag)

    k_vf_factor = 1.0 + (r['vf'] - 55.0) * k_vf
    eta_eff = eta_base * eta_h * k_drag * k_vf_factor

    u_arc = 22 if r['volt'] == 'Low' else 27
    i_peak = r['ip'] * 2.8
    power_watts = u_arc * i_peak * duty

    mrr_vol = 60 * C_m * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B

    feedRate_calc = speedArea_raw / r['H']
    ft_max = r['hz'] * 0.060
    feedRate_final = min(feedRate_calc, ft_max)

    fc_thuc_calc = round(feedRate_final * r['H'])
    fc_may_calc = round(feedRate_final * 40)
    t_calc_min = (r['L'] * r['H']) / (feedRate_final * r['H'])

    fc_thuc_exact = (r['L'] * r['H']) / r['t_min']
    fc_may_exact = (r['L'] / r['t_min']) * 40

    d_t = t_calc_min - r['t_min']
    sign_t = "+" if d_t >= 0 else "-"
    d_t_str = f"{sign_t}{fmt_time(abs(d_t))}"
    d_may = fc_may_calc - fc_may_exact

    print(f"{r['name']:<10} {r['mat']:<7} {r['H']:<4} {r['L']:<6.1f} | {fmt_time(r['t_min']):<10} {fmt_time(t_calc_min):<10} {d_t_str:<12} | {fc_thuc_exact:<10.1f} {fc_thuc_calc:<12} | {fc_may_exact:<10.1f} {fc_may_calc:<11} {d_may:<+6.1f}")
print("=" * 125)
