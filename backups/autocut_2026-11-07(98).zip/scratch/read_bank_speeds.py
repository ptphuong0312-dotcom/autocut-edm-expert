import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('WORKSHOP_DATA_BANK.md', 'r', encoding='utf-8') as f:
    text = f.read()

# Tìm tất cả các đoạn có STT, H, và tốc độ
sections = re.split(r'###\s+(?:BÀI|B\xc0I|STT|ĐỢT|DOT)', text, flags=re.IGNORECASE)
print(f"Total sections: {len(sections)}")

for i, sec in enumerate(sections[1:], 1):
    first_line = sec.strip().splitlines()[0] if sec.strip() else ""
    # Tìm H
    h_m = re.search(r'H\s*=\s*(\d+)', sec)
    h_val = h_m.group(1) if h_m else "?"
    # Tìm tốc độ
    spd_m = re.findall(r'(?:tốc độ|t\u1ed1c \u0111\u1ed9|speed|fc)[^\n:]*:\s*([^\n]+)', sec, re.IGNORECASE)
    time_m = re.findall(r'(?:thời gian|th\u1eddi gian|time)[^\n:]*:\s*([^\n]+)', sec, re.IGNORECASE)
    length_m = re.findall(r'(?:chu vi|chiều dài|chi\u1ec1u d\xe0i|dài cắt|d\xe0i c\u1eaft)[^\n:]*:\s*([^\n]+)', sec, re.IGNORECASE)
    print(f"--- Item {i}: {first_line[:50]} (H={h_val})")
    if spd_m:
        print(f"    Speed: {spd_m}")
    if time_m:
        print(f"    Time: {time_m}")
    if length_m:
        print(f"    Length: {length_m}")
