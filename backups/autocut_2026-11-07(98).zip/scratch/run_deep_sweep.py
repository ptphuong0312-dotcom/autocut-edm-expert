import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 15 bài cắt có số đo cứng L, H, t thực tế từ xưởng SirPhuong
benchmarks = [
    {"id": "5P-01",  "mat": "SCM440", "H": 12,  "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_real": 19.833},
    {"id": "2P-10",  "mat": "SCM440", "H": 85,  "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6,  "t_real": 48.000},
    {"id": "2P-11",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_real": 77.000},
    {"id": "2P-12",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_real": 77.000},
    {"id": "STT 1",  "mat": "SCM440", "H": 30,  "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_real": 8.667},
    {"id": "STT 2",  "mat": "SCM440", "H": 40,  "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_real": 9.600},
    {"id": "STT 3",  "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_real": 14.333},
    {"id": "STT 9",  "mat": "SCM420", "H": 63,  "Ton": 24,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 43, "Hz": 150, "L": 27.0,  "t_real": 21.000},
    {"id": "STT 12", "mat": "SCM420", "H": 140, "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4,  "t_real": 36.000},
    {"id": "STT 13", "mat": "SCM440", "H": 300, "Ton": 80,  "Po": 9,  "IP": 6, "Volt": "High", "VF": 50, "Hz": 50,  "L": 31.3,  "t_real": 89.000},
    {"id": "STT 14", "mat": "SCM440", "H": 300, "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1,  "t_real": 180.000},
    {"id": "STT 15", "mat": "SCM420", "H": 160, "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3,  "t_real": 59.000},
    {"id": "STT 16", "mat": "SCM420", "H": 75,  "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3,  "t_real": 73.000},
    {"id": "STT 17", "mat": "SCM440", "H": 95,  "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0,  "t_real": 75.000},
    {"id": "STT 18", "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3,  "t_real": 17.667},
]

for b in benchmarks:
    b['ft_real'] = b['L'] / b['t_real']
    b['fc_thuc_real'] = b['ft_real'] * b['H']
    b['fc_may_real'] = b['ft_real'] * 40.0

def run_simulation(c_scale, p_ton, p_ip, p_duty, h_loss_hard, h_loss_soft, drag_scale, drag_soft, vf_pos, vf_neg):
    mape_t = 0.0
    mae_t = 0.0
    mae_fcm = 0.0
    mae_fcr = 0.0
    details = []

    for b in benchmarks:
        H = b['H']
        Ton = b['Ton']
        Po = b['Po']
        IP = b['IP']
        Volt = b['Volt']
        VF = b['VF']
        Hz = b['Hz']
        isHard = (b['mat'] == 'SCM440')
        
        toff = Ton * (Po + 1)
        duty = Ton / (Ton + toff)
        Uarc = 27.0 if Volt == 'High' else 22.0
        power_watts = Uarc * (2.8 * IP) * duty
        
        # 1. Năng lượng xung đơn không bị trần cứng (Ton tăng thì năng suất tăng)
        eta_base = c_scale * math.pow(max(1, Ton) / 50.0, p_ton) * math.pow(IP / 4.0, p_ip)
        
        # 2. Suy giảm độ sâu rãnh phôi (SCM440 cứng xả xỉ tốt hơn, SCM420 dẻo nghẽn xỉ hơn)
        if isHard:
            eta_h = max(0.55, 1.0 - max(0, H - 40) * h_loss_hard)
        else:
            eta_h = max(0.40, 1.0 - max(0, H - 40) * h_loss_soft)
            
        # 3. Lực cản mạt xỉ dẻo nghẽn phôi khi H > 63mm và Po < 8
        h_choke = max(0.0, (H - 63.0) / 100.0)
        po_choke = max(0.0, (8.0 - Po) / 10.0)
        mat_choke = 1.0 if isHard else drag_soft
        drag_loss = drag_scale * math.pow(h_choke, 0.65) * po_choke * mat_choke
        k_drag = max(0.35, 1.0 - drag_loss)
        
        # 4. Phản ứng bám tải VF phi tuyến 2 nhánh
        if VF >= 55.0:
            k_vf = 1.0 + (VF - 55.0) * vf_pos
        else:
            k_vf = 1.0 + (VF - 55.0) * vf_neg
            
        # 5. Hệ số chu kỳ đóng ngắt duty
        k_duty = math.pow(duty / (1.0 / 7.0), p_duty)
        
        eta_eff = eta_base * eta_h * k_drag * k_vf * k_duty
        speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23
        
        feedRate_calc = speedArea_raw / H
        ft_max = Hz * 0.060
        feedRate_final = min(feedRate_calc, ft_max)
        
        fc_thuc_calc = feedRate_final * H
        fc_may_calc = feedRate_final * 40.0
        t_calc = b['L'] / feedRate_final
        
        err_t = abs(t_calc - b['t_real'])
        rel_t = err_t / b['t_real']
        mape_t += rel_t
        mae_t += err_t
        mae_fcm += abs(fc_may_calc - b['fc_may_real'])
        mae_fcr += abs(fc_thuc_calc - b['fc_thuc_real'])
        
        details.append({
            "id": b['id'], "H": H, "t_real": b['t_real'], "t_calc": t_calc,
            "err_t": err_t, "rel_t": rel_t * 100,
            "fc_m_real": b['fc_may_real'], "fc_m_calc": fc_may_calc,
            "fc_r_real": b['fc_thuc_real'], "fc_r_calc": fc_thuc_calc
        })

    n = len(benchmarks)
    return (mape_t / n) * 100.0, mae_t / n, mae_fcm / n, mae_fcr / n, details

print("Ready for deep parameter sweep...")
