import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

matches = [m.start() for m in re.finditer(r'let\s+speedAreaH40', text)]
print('Matches for let speedAreaH40:', len(matches))
for pos in matches:
    line_no = text[:pos].count('\n') + 1
    print(f'Line {line_no}: {text[pos:pos+50]}...')

matches_const = [m.start() for m in re.finditer(r'const\s+speedAreaH40', text)]
print('Matches for const speedAreaH40:', len(matches_const))
for pos in matches_const:
    line_no = text[:pos].count('\n') + 1
    print(f'Line {line_no}: {text[pos:pos+50]}...')
