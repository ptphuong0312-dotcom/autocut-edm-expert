import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'id': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-02', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-03', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'id': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'id': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'id': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'id': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'id': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'id': '2P-10', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'id': '2P-12', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': '2P-13', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'id': '5P-01', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

for r in runs:
    r['ft_exact'] = r['L'] / r['t_min']
    r['fc_thuc_exact'] = (r['L'] * r['H']) / r['t_min']
    r['fc_may_exact'] = r['ft_exact'] * 40

# THỬ NGHIỆM CÁC HÀM TRUYỀN VẬT LÝ VÒNG 5
# Đổi mới cơ bản:
# 1. Tách hàm suy giảm độ sâu H thành: Vùng xối thấu (H <= 50mm) vs Vùng đối lưu dây (H > 50mm)
# 2. Tương tác tích chéo giữa (H / 100) và (1 / (Po + 1)) đại diện cho tỷ trọng mạt xỉ ứ đọng
# 3. Phản ứng phi tuyến của VF: VF dưới 55 giảm nhanh hơn so với VF trên 55 tăng
def eval_v5_candidate(c_m, exp_ton, kvf_pos, kvf_neg, k_choke_base, p_decay_hard, p_decay_soft):
    diff_t_pct = []
    diff_fc_may = []
    diff_fc_thuc = []
    
    for r in runs:
        toff = r['ti'] * (r['po'] + 1)
        duty = r['ti'] / (r['ti'] + toff)
        
        # 1. Năng lượng xung hiệu dụng
        eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, exp_ton)
        if r['ti'] > 80: eta_base = min(0.92, eta_base)

        # 2. Suy giảm độ sâu rãnh H (chuyển tiếp êm dịu sigmoid)
        if r['isHard']:
            # Thép cứng tôi SCM440: mạt xỉ giòn vụn, suy giảm rất ít
            eta_h = 1.0 / (1.0 + math.pow(max(0, r['H'] - 40) / 100.0, 1.3) * p_decay_hard)
        else:
            # Thép mềm SCM420: mạt xỉ dẻo bết, suy giảm mạnh hơn khi phôi sâu
            eta_h = 1.0 / (1.0 + math.pow(max(0, r['H'] - 30) / 100.0, 1.4) * p_decay_soft)

        # 3. Hiệu ứng nghẽn xỉ khi Po ngắn trong rãnh sâu
        # Tỷ lệ thể tích xỉ sinh ra / khoảng không gian xả xỉ
        # Po_crit = ngưỡng Po an toàn theo chiều dày H
        po_req = 4.0 + (r['H'] / 25.0) # H=30 -> po_req=5.2; H=75 -> po_req=7.0; H=165 -> po_req=10.6
        po_deficit = max(0.0, (po_req - r['po']) / 5.0)
        mat_choke = 1.0 if r['isHard'] else 2.5
        choke_factor = max(0.40, 1.0 - k_choke_base * po_deficit * mat_choke * (r['H'] / 100.0))

        # 4. Phản ứng phi tuyến của VF
        if r['vf'] >= 55.0:
            k_vf = 1.0 + (r['vf'] - 55.0) * kvf_pos
        else:
            k_vf = 1.0 + (r['vf'] - 55.0) * kvf_neg # Servo lùi sâu hơn khi VF thấp

        eta_eff = eta_base * eta_h * choke_factor * k_vf

        u_arc = 22 if r['volt'] == 'Low' else 27
        i_peak = r['ip'] * 2.8
        power_watts = u_arc * i_peak * duty

        mrr_vol = 60 * c_m * power_watts * eta_eff
        B = 0.23
        speedArea_raw = mrr_vol / B

        feedRate_calc = speedArea_raw / r['H']
        ft_max = r['hz'] * 0.060
        feedRate_final = min(feedRate_calc, ft_max)

        fc_thuc_calc = feedRate_final * r['H']
        fc_may_calc = feedRate_final * 40
        t_calc = r['L'] / feedRate_final

        diff_fc_thuc.append(abs(fc_thuc_calc - r['fc_thuc_exact']))
        diff_fc_may.append(abs(fc_may_calc - r['fc_may_exact']))
        diff_t_pct.append(abs(t_calc - r['t_min']) / r['t_min'] * 100)

    return sum(diff_fc_thuc) / len(diff_fc_thuc), sum(diff_fc_may) / len(diff_fc_may), sum(diff_t_pct) / len(diff_t_pct)

# Tìm kiếm tham số V5 tối ưu
best_v5_score = 999.0
best_v5_params = None

for cm in [0.0135, 0.0140, 0.0145]:
    for exp_t in [0.28, 0.30, 0.32]:
        for kvf_p in [0.005, 0.006, 0.007]:
            for kvf_n in [0.007, 0.009, 0.012]:
                for kchoke in [0.40, 0.50, 0.60]:
                    for dh in [0.10, 0.15, 0.20]:
                        for ds in [0.30, 0.40, 0.50]:
                            m_thuc, m_may, m_t = eval_v5_candidate(cm, exp_t, kvf_p, kvf_n, kchoke, dh, ds)
                            score = m_t + m_may * 0.4
                            if score < best_v5_score:
                                best_v5_score = score
                                best_v5_params = (cm, exp_t, kvf_p, kvf_n, kchoke, dh, ds, m_thuc, m_may, m_t)

cm, exp_t, kvf_p, kvf_n, kchoke, dh, ds, m_thuc, m_may, m_t = best_v5_params
print("KẾT QUẢ TỐI ƯU VÒNG 5 (V5 CANDIDATE):")
print(f"  Cm = {cm}, exp_ton = {exp_t}")
print(f"  kvf_pos = {kvf_p}, kvf_neg = {kvf_n}")
print(f"  k_choke = {kchoke}")
print(f"  decay_hard = {dh}, decay_soft = {ds}")
print(f"--> MAE Fc Thực: {m_thuc:.2f} mm²/p")
print(f"--> MAE Fc Máy:  {m_may:.2f} mm²/p")
print(f"--> MAPE Thời gian: {m_t:.1f}%")
