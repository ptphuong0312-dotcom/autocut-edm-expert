import subprocess
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

edge_exe = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
html_path = os.path.abspath('index.html').replace('\\', '/')
html_url = f'file:///{html_path}'

res = subprocess.run([
    edge_exe,
    '--headless=new',
    '--disable-gpu',
    '--enable-logging=stderr',
    '--v=1',
    '--dump-dom',
    html_url
], capture_output=True, text=True, encoding='utf-8')

print("STDERR:")
for line in res.stderr.splitlines():
    if 'CONSOLE' in line or 'error' in line.lower() or 'exception' in line.lower() or 'app.js' in line:
        print(line)
