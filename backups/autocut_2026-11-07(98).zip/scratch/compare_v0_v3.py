import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'id': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-02', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-03', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'id': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'id': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'id': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'id': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'id': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'id': '2P-10', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'id': '2P-12', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': '2P-13', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'id': '5P-01', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

for r in runs:
    r['ft_exact'] = r['L'] / r['t_min']
    r['fc_thuc_exact'] = (r['L'] * r['H']) / r['t_min']
    r['fc_may_exact'] = r['ft_exact'] * 40

def fmt_time(minutes):
    hrs = int(minutes // 60)
    mins = int(minutes % 60)
    secs = int(round((minutes * 60) % 60))
    if secs == 60:
        mins += 1
        secs = 0
    if hrs > 0:
        return f"{hrs}h{mins:02d}p" if secs == 0 else f"{hrs}h{mins:02d}p{secs:02d}s"
    else:
        return f"{mins}p{secs:02d}s" if secs > 0 else f"{mins}p"

# Mô hình V0 (Gốc)
def m_v0(r):
    toff = r['ti'] * (r['po'] + 1)
    duty = r['ti'] / (r['ti'] + toff)
    eta = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.38)
    if r['ti'] > 80: eta = min(0.92, eta)
    if r['isHard']:
        if r['H'] > 80: eta *= max(0.65, 1.0 - (r['H'] - 80) * 0.0010)
    else:
        if r['H'] > 50: eta *= max(0.55, 1.0 - (r['H'] - 50) * 0.0016)
    p_w = (22 if r['volt'] == 'Low' else 27) * (r['ip'] * 2.8) * duty
    v = (60 * 0.0140 * p_w * eta) / 0.23
    ft = v / r['H']
    return ft * 40, (r['L'] * r['H']) / v

# Mô hình V3 (Toàn diện tối ưu)
def m_v3(r):
    toff = r['ti'] * (r['po'] + 1)
    duty = r['ti'] / (r['ti'] + toff)
    eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.30)
    if r['ti'] > 80: eta_base = min(0.92, eta_base)
    eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * 0.0006) if r['isHard'] else max(0.55, 1.0 - max(0, r['H'] - 50) * 0.0022)
    h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - r['po']) / 10.0)
    mat_choke = 1.0 if r['isHard'] else 2.6
    k_drag = max(0.38, 1.0 - 0.55 * math.pow(h_choke, 0.65) * po_choke * mat_choke)
    k_vf = 1.0 + (r['vf'] - 55.0) * 0.0060
    eta_eff = eta_base * eta_h * k_drag * k_vf
    p_w = (22 if r['volt'] == 'Low' else 27) * (r['ip'] * 2.8) * duty
    v_raw = (60 * 0.0135 * p_w * eta_eff) / 0.23
    ft = min(v_raw / r['H'], r['hz'] * 0.060)
    return ft * 40, r['L'] / ft

print(f"{'Bài cắt':<10} {'H':<4} {'L(mm)':<6} | {'t thực':<10} {'t V0 (Cũ)':<11} {'t V3 (Mới)':<11} | {'FcMáy Đo':<10} {'FcMáy V0':<10} {'FcMáy V3':<10}")
print("-" * 90)

for r in runs:
    fc_m0, t_0 = m_v0(r)
    fc_m3, t_3 = m_v3(r)
    print(f"{r['id']:<10} {r['H']:<4} {r['L']:<6.1f} | {fmt_time(r['t_min']):<10} {fmt_time(t_0):<11} {fmt_time(t_3):<11} | {r['fc_may_exact']:<10.1f} {fc_m0:<10.1f} {fc_m3:<10.1f}")
