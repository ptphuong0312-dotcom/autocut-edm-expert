import sys
sys.stdout.reconfigure(encoding='utf-8')

dataset = [
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "target_fc_may": 280, "read": "275 - 285"},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "target_fc_may": 170, "read": "165 - 175"},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "target_fc_may": 135, "read": "130 - 140"},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "target_fc_may": 80,  "read": "75 - 85"},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "target_fc_may": 55,  "read": "50 - 65"},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "target_fc_may": 55,  "read": "50 - 65"},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "target_fc_may": 60,  "read": "55 - 65"},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "target_fc_may": 55,  "read": "50 - 60"},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "target_fc_may": 40,  "read": "35 - 45"},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "target_fc_may": 35,  "read": "30 - 40"},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "target_fc_may": 35,  "read": "30 - 40"},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "target_fc_may": 23,  "read": "18 - 28"},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "target_fc_may": 25,  "read": "15 - 35"},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "target_fc_may": 16,  "read": "12 - 20"},
]

print(f"{'Bài':<7} | {'H':<3} | {'Fc máy đọc':<12} | {'Ft quy đổi = Fc_máy / 40 (mm/p)':<30} | {'Fc thực quy đổi = Ft * H (mm²/p)':<32}")
print("-" * 88)
for j in dataset:
    fc_may = j['target_fc_may']
    ft = fc_may / 40.0
    fc_thuc = ft * j['H']
    print(f"{j['name']:<7} | {j['H']:<3} | {fc_may:<12} | {ft:<30.3f} | {fc_thuc:<32.1f}")
