import math

# Dữ liệu 14 bài cắt có số đọc máy thực tế từ SirPhuong
dataset = [
    # name, H, mat, Ton, Po, IP, Volt, VF, Hz, L, t_real_min, speed_read_str, target_fc_may
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_real": 19.833, "read": "275 - 285", "target": 280},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_real": 8.667,  "read": "165 - 175", "target": 170},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_real": 9.600,  "read": "130 - 140", "target": 135},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_real": 14.333, "read": "75 - 85",   "target": 80},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3, "t_real": 17.667, "read": "50 - 65",   "target": 55},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3, "t_real": 73.000, "read": "50 - 65",   "target": 55},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6, "t_real": 48.000, "read": "55 - 65",   "target": 60},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "L": None,  "t_real": None,   "read": "50 - 60",   "target": 55},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0,  "t_real": 75.000, "read": "35 - 45",   "target": 40},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "L": None,  "t_real": None,   "read": "30 - 40",   "target": 35},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4, "t_real": 36.000, "read": "30 - 40",   "target": 35},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3, "t_real": 59.000, "read": "18 - 28",   "target": 23},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6, "t_real": 77.000, "read": "15 - 35",   "target": 25},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1, "t_real": 180.00, "read": "12 - 20",   "target": 16},
]

print(f"Total jobs: {len(dataset)}")
