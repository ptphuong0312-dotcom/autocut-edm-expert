import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

matches = [m.start() for m in re.finditer(r'speedArea', text)]
print(f"Total speedArea occurrences: {len(matches)}")
for pos in matches[:10]:
    line_no = text[:pos].count('\n') + 1
    print(f"Line {line_no}: {text[pos-20:pos+80].strip()}")
