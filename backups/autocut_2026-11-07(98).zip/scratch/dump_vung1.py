import subprocess
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

edge_exe = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
html_path = os.path.abspath('index.html').replace('\\', '/')
html_url = f'file:///{html_path}'

res = subprocess.run([
    edge_exe,
    '--headless=new',
    '--disable-gpu',
    '--dump-dom',
    html_url
], capture_output=True, text=True, encoding='utf-8')

dom = res.stdout

idx = dom.find('id="ws-table-body-vung1"')
if idx != -1:
    print('Found ws-table-body-vung1 around:')
    print(dom[idx-50:idx+600])
else:
    print('Not found')

with open('scratch/dom_dump.html', 'w', encoding='utf-8') as f:
    f.write(dom)
print('Saved scratch/dom_dump.html')
