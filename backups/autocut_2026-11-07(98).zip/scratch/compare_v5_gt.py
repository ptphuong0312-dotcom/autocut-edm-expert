import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

benchmark_data = [
    {"id": "5P-01",  "mat": "SCM440", "H": 12,  "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_str": "19p50'", "t_min": 19.833},
    {"id": "2P-10",  "mat": "SCM440", "H": 85,  "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6,  "t_str": "48p",    "t_min": 48.000},
    {"id": "2P-11",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_str": "1h17'",  "t_min": 77.000},
    {"id": "2P-12",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_str": "1h17'",  "t_min": 77.000},
    {"id": "STT 1",  "mat": "SCM440", "H": 30,  "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_str": "8p40'",  "t_min": 8.667},
    {"id": "STT 2",  "mat": "SCM440", "H": 40,  "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_str": "9p36'",  "t_min": 9.600},
    {"id": "STT 3",  "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_str": "14p20'", "t_min": 14.333},
    {"id": "STT 9",  "mat": "SCM420", "H": 63,  "Ton": 24,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 43, "Hz": 150, "L": 27.0,  "t_str": "21p",    "t_min": 21.000},
    {"id": "STT 12", "mat": "SCM420", "H": 140, "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4,  "t_str": "36p",    "t_min": 36.000},
    {"id": "STT 13", "mat": "SCM440", "H": 300, "Ton": 80,  "Po": 9,  "IP": 6, "Volt": "High", "VF": 50, "Hz": 50,  "L": 31.3,  "t_str": "1h29'",  "t_min": 89.000},
    {"id": "STT 14", "mat": "SCM440", "H": 300, "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1,  "t_str": "3h",     "t_min": 180.000},
    {"id": "STT 15", "mat": "SCM420", "H": 160, "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3,  "t_str": "59p",    "t_min": 59.000},
    {"id": "STT 16", "mat": "SCM420", "H": 75,  "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3,  "t_str": "1h13'",  "t_min": 73.000},
    {"id": "STT 17", "mat": "SCM440", "H": 95,  "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0,  "t_str": "1h15'",  "t_min": 75.000},
    {"id": "STT 18", "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3,  "t_str": "17p40'", "t_min": 17.667},
]

def eval_model_v5(b):
    H = b['H']
    Ton = b['Ton']
    Po = b['Po']
    IP = b['IP']
    Volt = b['Volt']
    VF = b['VF']
    Hz = b['Hz']
    isHard = (b['mat'] == 'SCM440')

    toff = Ton * (Po + 1)
    duty = Ton / (Ton + toff)
    Uarc = 27.0 if Volt == 'High' else 22.0
    power_watts = Uarc * (2.8 * IP) * duty

    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.28)
    if Ton > 80: eta_base = min(0.92, eta_base)

    if isHard:
        eta_h = max(0.70, 1.0 - max(0, H - 80) * 0.0005)
    else:
        eta_h = max(0.55, 1.0 - max(0, H - 50) * 0.0022)

    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.60
    drag_loss = 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.38, 1.0 - drag_loss)

    if VF >= 55.0:
        k_vf = 1.0 + (VF - 55.0) * 0.0050
    else:
        k_vf = 1.0 + (VF - 55.0) * 0.0100

    eta_eff = eta_base * eta_h * k_drag * k_vf
    speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23

    feedRate_calc = speedArea_raw / H
    ft_max = Hz * 0.060
    feedRate_final = min(feedRate_calc, ft_max)

    fc_thuc = round(feedRate_final * H)
    fc_may_h40 = round(feedRate_final * 40.0)
    t_calc = b['L'] / feedRate_final

    return fc_thuc, fc_may_h40, t_calc, feedRate_final

print(f"{'Bài':<7} | {'t_thực':<7} | {'t_tính':<7} | {'Sai lệch t':<10} | {'Fc_máy Thực':<12} | {'Fc_máy Tính':<12} | {'Lệch Fc_máy':<12} | {'Fc_thực Thực':<13} | {'Fc_thực Tính':<13}")
print("-" * 105)
for b in benchmark_data:
    fc_thuc_calc, fc_may_calc, t_calc, ft_calc = eval_model_v5(b)
    ft_real = b['L'] / b['t_min']
    fc_thuc_real = ft_real * b['H']
    fc_may_real = ft_real * 40.0

    dt = t_calc - b['t_min']
    dfc_may = fc_may_calc - fc_may_real
    print(f"{b['id']:<7} | {b['t_min']:<7.1f} | {t_calc:<7.1f} | {dt:+<10.2f} | {fc_may_real:<12.1f} | {fc_may_calc:<12} | {dfc_may:+<12.1f} | {fc_thuc_real:<13.1f} | {fc_thuc_calc:<13}")
