import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

dataset = [
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "target": 280, "low": 275, "high": 285},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "target": 170, "low": 165, "high": 175},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "target": 135, "low": 130, "high": 140},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "target": 80,  "low": 75,  "high": 85},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "target": 55,  "low": 50,  "high": 65},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "target": 55,  "low": 50,  "high": 65},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "target": 60,  "low": 55,  "high": 65},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "target": 55,  "low": 50,  "high": 60},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "target": 40,  "low": 35,  "high": 45},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "target": 35,  "low": 30,  "high": 40},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "target": 35,  "low": 30,  "high": 40},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "target": 23,  "low": 18,  "high": 28},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "target": 25,  "low": 15,  "high": 35},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "target": 16,  "low": 12,  "high": 20},
]

# Mô hình tính Fc_thực và Fc_máy:
# Fc_thực = Năng suất bóc tách kim loại thực tế của máy (mm²/p)
# Fc_thực = P_eff * K_scale
# Trong đó P_eff phụ thuộc vào:
# 1. Năng lượng xung đơn: Ep ~ (Ton / 50)^alpha_ton * (IP / 4)^alpha_ip
# 2. Tần số xung / Duty: duty = 1 / (Po + 2)
# 3. Điện áp: Uarc (High = 27V, Low = 22V)
# 4. Ảnh hưởng của độ dày H lên khả năng xối nước xả xỉ: k_H = (40 / H)^gamma_h đối với tốc độ tiến bàn
# -> Fc_máy = Fc_thực * (40 / H)

# Hãy tìm các hệ số để Fc_máy khớp chính xác nhất với dataset
best_mae = 999.0
best_params = None

# Grid search tinh gọn
for alpha_ton in [0.25, 0.30, 0.35, 0.40]:
    for alpha_ip in [0.45, 0.55, 0.65, 0.75]:
        for k_base in [120, 130, 135, 140, 145, 150]:
            for gamma_h in [0.00, 0.05, 0.08, 0.12]:
                for k_mat_soft in [0.90, 0.95, 1.00, 1.05]:
                    total_err = 0.0
                    in_range_count = 0
                    for j in dataset:
                        H = j['H']
                        Ton = j['Ton']
                        Po = j['Po']
                        IP = j['IP']
                        VF = j['VF']
                        isHard = (j['mat'] == 'SCM440')
                        
                        # 1. Năng suất bóc phôi thực tế Fc_thực (mm²/p)
                        # Tỷ lệ với dòng điện xung hiệu dụng và chu kỳ xung
                        duty = 1.0 / (Po + 2.0)
                        ep_factor = math.pow(Ton / 40.0, alpha_ton) * math.pow(IP / 4.0, alpha_ip)
                        duty_factor = duty / (1.0 / 7.0) # Chuẩn hóa quanh Po=5 (duty = 1/7)
                        
                        # Hiệu ứng suy giảm xả xỉ ở rãnh sâu
                        slag_loss = 1.0 - (0.0008 * max(0, H - 40)) if isHard else (1.0 - 0.0012 * max(0, H - 40))
                        slag_loss = max(0.65, slag_loss)
                        
                        # Hiệu ứng bám tải VF
                        vf_factor = 1.0 + (VF - 55.0) * 0.006
                        
                        mat_factor = 1.0 if isHard else k_mat_soft
                        
                        fc_thuc = k_base * ep_factor * math.pow(duty_factor, 0.65) * slag_loss * vf_factor * mat_factor
                        
                        # Suy giảm nhẹ của Fc_thực theo H
                        fc_thuc = fc_thuc * math.pow(40.0 / max(20.0, H), gamma_h)
                        
                        # 2. Quy đổi sang Fc_máy (H40) theo đúng định nghĩa máy AutoCut
                        fc_may = fc_thuc * (40.0 / H)
                        
                        # Chặn trần cơ học ở phôi siêu mỏng (không quá 290 mm²/p)
                        fc_may = min(fc_may, 285.0)
                        
                        err = abs(fc_may - j['target'])
                        total_err += err
                        if j['low'] <= round(fc_may) <= j['high']:
                            in_range_count += 1
                            
                    mae = total_err / len(dataset)
                    if mae < best_mae:
                        best_mae = mae
                        best_params = (alpha_ton, alpha_ip, k_base, gamma_h, k_mat_soft, in_range_count)

print("BEST PARAMS:", best_params, "BEST MAE:", best_mae)
