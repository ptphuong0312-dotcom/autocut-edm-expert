import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('.agents/rules/09-WORKSHOP_RAW_DATA_BANK_AND_REVERSE_INTERPOLATION.md', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('Tốc độ hiển thị trên máy AutoCut')
if idx != -1:
    print(text[idx-200:idx+600])
