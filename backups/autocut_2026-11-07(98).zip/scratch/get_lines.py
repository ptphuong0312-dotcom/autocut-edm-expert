with open('app.js', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(2535, 2545):
    print(f'{i+1}: {repr(lines[i])}')
