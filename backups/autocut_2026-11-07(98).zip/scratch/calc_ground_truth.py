import sys
sys.stdout.reconfigure(encoding='utf-8')

# 15 bài cắt có số đo cứng L, H, t thực tế từ xưởng SirPhuong
benchmark_data = [
    # Nhóm 1: Các bài cắt nhiều Pass có đo kiểm Pass 1
    {"id": "5P-01",  "mat": "SCM440", "H": 12,  "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_str": "19p50'", "t_min": 19.833},
    {"id": "2P-10",  "mat": "SCM440", "H": 85,  "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6,  "t_str": "48p",    "t_min": 48.000},
    {"id": "2P-11",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_str": "1h17'",  "t_min": 77.000},
    {"id": "2P-12",  "mat": "SCM440", "H": 165, "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6,  "t_str": "1h17'",  "t_min": 77.000},

    # Nhóm 2: Các bài 1 Pass chuẩn có thời gian đo chính xác
    {"id": "STT 1",  "mat": "SCM440", "H": 30,  "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_str": "8p40'",  "t_min": 8.667},
    {"id": "STT 2",  "mat": "SCM440", "H": 40,  "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_str": "9p36'",  "t_min": 9.600},
    {"id": "STT 3",  "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_str": "14p20'", "t_min": 14.333},
    {"id": "STT 9",  "mat": "SCM420", "H": 63,  "Ton": 24,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 43, "Hz": 150, "L": 27.0,  "t_str": "21p",    "t_min": 21.000},
    {"id": "STT 12", "mat": "SCM420", "H": 140, "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4,  "t_str": "36p",    "t_min": 36.000},
    {"id": "STT 13", "mat": "SCM440", "H": 300, "Ton": 80,  "Po": 9,  "IP": 6, "Volt": "High", "VF": 50, "Hz": 50,  "L": 31.3,  "t_str": "1h29'",  "t_min": 89.000},
    {"id": "STT 14", "mat": "SCM440", "H": 300, "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1,  "t_str": "3h",     "t_min": 180.000},
    {"id": "STT 15", "mat": "SCM420", "H": 160, "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3,  "t_str": "59p",    "t_min": 59.000},
    {"id": "STT 16", "mat": "SCM420", "H": 75,  "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3,  "t_str": "1h13'",  "t_min": 73.000},
    {"id": "STT 17", "mat": "SCM440", "H": 95,  "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0,  "t_str": "1h15'",  "t_min": 75.000},
    {"id": "STT 18", "mat": "SCM420", "H": 63,  "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3,  "t_str": "17p40'", "t_min": 17.667},
]

print(f"{'Bài':<7} | {'Vật liệu':<8} | {'H (mm)':<6} | {'L (mm)':<7} | {'t thực':<8} | {'Ft_thực (mm/p)':<15} | {'Fc_thực = Ft*H (mm²/p)':<23} | {'Fc_máy = Ft*40 (mm²/p)':<23}")
print("-" * 105)
for b in benchmark_data:
    ft = b["L"] / b["t_min"]
    fc_thuc = ft * b["H"]
    fc_may = ft * 40.0
    print(f"{b['id']:<7} | {b['mat']:<8} | {b['H']:<6} | {b['L']:<7} | {b['t_str']:<8} | {ft:<15.3f} | {fc_thuc:<23.1f} | {fc_may:<23.1f}")
