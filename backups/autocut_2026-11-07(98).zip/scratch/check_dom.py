import subprocess
import os

edge_exe = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
html_path = os.path.abspath('index.html').replace('\\', '/')
html_url = f'file:///{html_path}'

res = subprocess.run([
    edge_exe,
    '--headless=new',
    '--disable-gpu',
    '--dump-dom',
    html_url
], capture_output=True, text=True, encoding='utf-8')

dom = res.stdout
print('id="ws-table-body-vung1" in dom?', 'id="ws-table-body-vung1"' in dom)
print('Pass 1 in dom?', 'Pass 1' in dom)
print('data-field="ti" in dom?', 'data-field="ti"' in dom)
print('ws-dyn-offset-0 in dom?', 'ws-dyn-offset-0' in dom)
print('Length of dom:', len(dom))
