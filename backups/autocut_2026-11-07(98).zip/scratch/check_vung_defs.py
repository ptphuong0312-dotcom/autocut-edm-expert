import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.findall(r'const\s+wsTableBodyVung\d\s*=\s*[^;]+;', text)
print('Definitions:', m)
