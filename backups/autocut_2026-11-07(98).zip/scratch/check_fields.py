import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

print('Has ws-table-body-vung1:', 'ws-table-body-vung1' in text)
print('Has ws-table-body-vung2:', 'ws-table-body-vung2' in text)

matches = re.findall(r'data-field=[\'"][a-zA-Z0-9_-]+[\'"]', text)
print('Unique data-field in app.js:', set(matches))

matches2 = re.findall(r'ws-dyn-[a-zA-Z0-9_-]+', text)
print('Unique ws-dyn in app.js:', set(matches2))

# Kiểm tra hàm render Vùng 1 và Vùng 2
m = re.search(r'function render[a-zA-Z0-9_]*\([^)]*\)\s*\{', text)
for fmatch in re.finditer(r'function (render[a-zA-Z0-9_]*)\(', text):
    print('Function:', fmatch.group(1))
