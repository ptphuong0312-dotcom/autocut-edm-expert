import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('docs/OPTIMIZATION_HISTORY.md', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('### 🚀 ĐỢT 60:')
if idx != -1:
    print(text[idx:idx+800])
