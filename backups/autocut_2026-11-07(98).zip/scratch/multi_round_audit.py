import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

# Dữ liệu 15 bài cắt thực tế có đủ (t, L, H, Ton, Po, IP, Volt, VF, Hz)
runs = [
    {'id': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-02', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-03', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'id': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'id': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'id': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'id': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'id': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'id': '2P-10', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'id': '2P-12', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': '2P-13', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'id': '5P-01', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

# Chuẩn bị Ground Truth
for r in runs:
    r['ft_exact'] = r['L'] / r['t_min']
    r['fc_thuc_exact'] = (r['L'] * r['H']) / r['t_min']
    r['fc_may_exact'] = r['ft_exact'] * 40

# ==============================================================================
# VÒNG 0: MÔ HÌNH HIỆN TẠI (BASELINE - app.js v3.5.60)
# ==============================================================================
def model_v0(r):
    toff = r['ti'] * (r['po'] + 1)
    true_cycle = r['ti'] + toff
    duty = r['ti'] / true_cycle
    eta_eff = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.38)
    if r['ti'] > 80: eta_eff = min(0.92, eta_eff)
    if r['isHard']:
        if r['H'] > 80: eta_eff *= max(0.65, 1.0 - (r['H'] - 80) * 0.0010)
    else:
        if r['H'] > 50: eta_eff *= max(0.55, 1.0 - (r['H'] - 50) * 0.0016)
    u_arc = 22 if r['volt'] == 'Low' else 27
    i_peak = r['ip'] * 2.8
    power_watts = u_arc * i_peak * duty
    Cm = 0.0140
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea = mrr_vol / B
    feedRate = speedArea / r['H']
    fc_thuc = feedRate * r['H']
    fc_may = feedRate * 40
    t_calc = (r['L'] * r['H']) / fc_thuc
    return fc_thuc, fc_may, t_calc

# ==============================================================================
# VÒNG 1: THÊM BÙ BÁM TẢI VF & GIỚI HẠN TẦN SỐ BÀN MÁY HZ
# ==============================================================================
def model_v1(r):
    toff = r['ti'] * (r['po'] + 1)
    true_cycle = r['ti'] + toff
    duty = r['ti'] / true_cycle
    eta_eff = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.38)
    if r['ti'] > 80: eta_eff = min(0.92, eta_eff)
    if r['isHard']:
        if r['H'] > 80: eta_eff *= max(0.65, 1.0 - (r['H'] - 80) * 0.0010)
    else:
        if r['H'] > 50: eta_eff *= max(0.55, 1.0 - (r['H'] - 50) * 0.0016)
    
    # Bù VF
    k_vf = 1.0 + (r['vf'] - 55.0) * 0.0060
    eta_eff *= k_vf

    u_arc = 22 if r['volt'] == 'Low' else 27
    i_peak = r['ip'] * 2.8
    power_watts = u_arc * i_peak * duty
    Cm = 0.0135
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B
    feedRate_calc = speedArea_raw / r['H']
    
    # Chặn trần cơ học Hz
    ft_max = r['hz'] * 0.060
    feedRate = min(feedRate_calc, ft_max)

    fc_thuc = feedRate * r['H']
    fc_may = feedRate * 40
    t_calc = (r['L'] * r['H']) / fc_thuc
    return fc_thuc, fc_may, t_calc

# ==============================================================================
# VÒNG 2: MÔ HÌNH HÓA TRỞ LỰC MẠT XỈ NGHẼN PHÔI DÀY (H > 63, Po <= 7)
# ==============================================================================
def model_v2(r):
    toff = r['ti'] * (r['po'] + 1)
    true_cycle = r['ti'] + toff
    duty = r['ti'] / true_cycle
    eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.35)
    if r['ti'] > 80: eta_base = min(0.92, eta_base)

    if r['isHard']:
        eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * 0.0008)
    else:
        eta_h = max(0.55, 1.0 - max(0, r['H'] - 50) * 0.0020)

    # Hiệu ứng cản xỉ
    h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - r['po']) / 10.0)
    mat_choke = 1.0 if r['isHard'] else 2.6
    slag_drag = 0.45 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.40, 1.0 - slag_drag)

    k_vf = 1.0 + (r['vf'] - 55.0) * 0.0070
    eta_eff = eta_base * eta_h * k_drag * k_vf

    u_arc = 22 if r['volt'] == 'Low' else 27
    i_peak = r['ip'] * 2.8
    power_watts = u_arc * i_peak * duty

    Cm = 0.0135
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B
    feedRate_calc = speedArea_raw / r['H']
    ft_max = r['hz'] * 0.060
    feedRate = min(feedRate_calc, ft_max)

    fc_thuc = feedRate * r['H']
    fc_may = feedRate * 40
    t_calc = (r['L'] * r['H']) / fc_thuc
    return fc_thuc, fc_may, t_calc

# ==============================================================================
# VÒNG 3: MÔ HÌNH NHIỆT ĐỘNG HỌC ĐA BIẾN TOÀN DIỆN (TỐI ƯU HÓA TOÁN CỨNG)
# ==============================================================================
def model_v3(r):
    toff = r['ti'] * (r['po'] + 1)
    true_cycle = r['ti'] + toff
    duty = r['ti'] / true_cycle
    
    # Hiệu suất xung lũy thừa tối ưu theo dòng đỉnh và Ton
    eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.30)
    if r['ti'] > 80: eta_base = min(0.92, eta_base)

    if r['isHard']:
        eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * 0.0006)
    else:
        eta_h = max(0.55, 1.0 - max(0, r['H'] - 50) * 0.0022)

    # Hệ số ghìm bước tiến khi nghẽn xỉ phôi sâu (tương tự d_sec của Delta)
    h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - r['po']) / 10.0)
    mat_choke = 1.0 if r['isHard'] else 2.6
    slag_drag = 0.55 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.38, 1.0 - slag_drag)

    k_vf = 1.0 + (r['vf'] - 55.0) * 0.0060
    eta_eff = eta_base * eta_h * k_drag * k_vf

    u_arc = 22 if r['volt'] == 'Low' else 27
    i_peak = r['ip'] * 2.8
    power_watts = u_arc * i_peak * duty

    Cm = 0.0135
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B

    feedRate_calc = speedArea_raw / r['H']
    ft_max = r['hz'] * 0.060
    feedRate = min(feedRate_calc, ft_max)

    fc_thuc = feedRate * r['H']
    fc_may = feedRate * 40
    t_calc = (r['L'] * r['H']) / fc_thuc
    return fc_thuc, fc_may, t_calc

# Đánh giá 4 vòng mô hình
models = [
    ('VÒNG 0 (Gốc)', model_v0),
    ('VÒNG 1 (+VF & Trần Hz)', model_v1),
    ('VÒNG 2 (+Nghẽn Xỉ)', model_v2),
    ('VÒNG 3 (Toàn diện Chuẩn)', model_v3)
]

print("==========================================================================================")
print(f"{'MÔ HÌNH TINH CHỈNH':<25} | {'MAE Fc Thực':<13} | {'MAE Fc Máy':<12} | {'MAPE Thời Gian':<15} | {'Max Lệch Thời Gian'}")
print("==========================================================================================")

for name, fn in models:
    diff_fc_thuc = []
    diff_fc_may = []
    diff_t_pct = []
    max_t_diff = 0.0
    max_t_run = ""
    for r in runs:
        fc_t, fc_m, t_c = fn(r)
        d_thuc = abs(fc_t - r['fc_thuc_exact'])
        d_may = abs(fc_m - r['fc_may_exact'])
        d_t_pct = abs(t_c - r['t_min']) / r['t_min'] * 100
        d_t_abs = abs(t_c - r['t_min'])
        
        diff_fc_thuc.append(d_thuc)
        diff_fc_may.append(d_may)
        diff_t_pct.append(d_t_pct)
        if d_t_abs > max_t_diff:
            max_t_diff = d_t_abs
            max_t_run = f"{r['id']} ({d_t_abs:.1f}p)"

    mae_thuc = sum(diff_fc_thuc) / len(diff_fc_thuc)
    mae_may = sum(diff_fc_may) / len(diff_fc_may)
    mape_t = sum(diff_t_pct) / len(diff_t_pct)

    print(f"{name:<25} | {mae_thuc:<10.2f} mm²/p | {mae_may:<9.2f} mm²/p | {mape_t:<12.1f} % | {max_t_run}")
print("==========================================================================================")
