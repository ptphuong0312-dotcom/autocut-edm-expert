import sys
import math
sys.stdout.reconfigure(encoding='utf-8')

dataset = [
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "target": 280, "low": 275, "high": 285},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "target": 170, "low": 165, "high": 175},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "target": 135, "low": 130, "high": 140},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "target": 80,  "low": 75,  "high": 85},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "target": 55,  "low": 50,  "high": 65},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "target": 55,  "low": 50,  "high": 65},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "target": 60,  "low": 55,  "high": 65},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "target": 55,  "low": 50,  "high": 60},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "target": 40,  "low": 35,  "high": 45},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "target": 35,  "low": 30,  "high": 40},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "target": 35,  "low": 30,  "high": 40},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "target": 23,  "low": 18,  "high": 28},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "target": 25,  "low": 15,  "high": 35},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "target": 16,  "low": 12,  "high": 20},
]

print(f"{'Bài':<7} | {'H':<3} | {'Ton':<3} | {'Po':<2} | {'IP':<2} | {'Fc_máy Target':<14} | {'Fc_thực = Target*(H/40)':<24}")
for j in dataset:
    fc_thuc = j['target'] * (j['H'] / 40.0)
    print(f"{j['name']:<7} | {j['H']:<3} | {j['Ton']:<3} | {j['Po']:<2} | {j['IP']:<2} | {j['target']:<14} | {fc_thuc:<24.1f}")
