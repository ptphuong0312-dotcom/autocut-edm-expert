import sys
sys.stdout.reconfigure(encoding='utf-8')

# Dữ liệu thực tế SirPhuong cung cấp
data = [
    {"name": "5P-01", "H": 12, "mat": "SCM440", "Ton": 20, "Po": 5, "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "L": 128.0, "t_real": "19p50'", "t_min": 19.833, "speed_read": "275 - 285", "speed_target": 280},
    {"name": "STT 1", "H": 30, "mat": "SCM440", "Ton": 32, "Po": 5, "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "L": 30.0,  "t_real": "8p40'",  "t_min": 8.667,  "speed_read": "165 - 175", "speed_target": 170},
    {"name": "STT 2", "H": 40, "mat": "SCM440", "Ton": 36, "Po": 5, "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "L": 30.0,  "t_real": "9p36'",  "t_min": 9.600,  "speed_read": "130 - 140", "speed_target": 135},
    {"name": "STT 3", "H": 63, "mat": "SCM420", "Ton": 44, "Po": 7, "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "L": 27.0,  "t_real": "14p20'", "t_min": 14.333, "speed_read": "75 - 85",   "speed_target": 80},
    {"name": "STT 18", "H": 63, "mat": "SCM420", "Ton": 44, "Po": 8, "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "L": 22.3, "t_real": "17p40'", "t_min": 17.667, "speed_read": "50 - 65",   "speed_target": 55},
    {"name": "STT 16", "H": 75, "mat": "SCM420", "Ton": 55, "Po": 7, "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "L": 50.3, "t_real": "1h13'",  "t_min": 73.000, "speed_read": "50 - 65",   "speed_target": 55},
    {"name": "2P-10", "H": 85, "mat": "SCM440", "Ton": 70, "Po": 8, "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "L": 65.6, "t_real": "48p",    "t_min": 48.000, "speed_read": "55 - 65",   "speed_target": 60},
    {"name": "STT 21", "H": 90, "mat": "SCM420", "Ton": 80, "Po": 7, "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "L": None, "t_real": "--",     "t_min": None,   "speed_read": "50 - 60",   "speed_target": 55},
    {"name": "STT 17", "H": 95, "mat": "SCM440", "Ton": 82, "Po": 7, "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "L": 76.0, "t_real": "1h15'",  "t_min": 75.000, "speed_read": "35 - 45",   "speed_target": 40},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "L": None, "t_real": "--",    "t_min": None,   "speed_read": "30 - 40",   "speed_target": 35},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9, "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "L": 28.4, "t_real": "36p",    "t_min": 36.000, "speed_read": "30 - 40",   "speed_target": 35},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "L": 32.3, "t_real": "59p",    "t_min": 59.000, "speed_read": "18 - 28",   "speed_target": 23},
    {"name": "2P-12", "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "L": 43.6, "t_real": "1h17'",  "t_min": 77.000, "speed_read": "15 - 35",   "speed_target": 25},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9, "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "L": 76.1, "t_real": "3h",     "t_min": 180.000, "speed_read": "12 - 20", "speed_target": 16},
]

# Hàm tính toán hiện tại trong app.js
import math
def calc_current(j):
    H = j['H']
    Ton = j['Ton']
    Po = j['Po']
    IP = j['IP']
    Volt = j['Volt']
    VF = j['VF']
    Hz = j['Hz']
    isHard = (j['mat'] == 'SCM440')

    toff = Ton * (Po + 1)
    duty = Ton / (Ton + toff)
    Uarc = 27.0 if Volt == 'High' else 22.0
    power_watts = Uarc * (2.8 * IP) * duty

    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.28)
    if Ton > 80: eta_base = min(0.92, eta_base)

    if isHard:
        eta_h = max(0.70, 1.0 - max(0, H - 80) * 0.0005)
    else:
        eta_h = max(0.55, 1.0 - max(0, H - 50) * 0.0022)

    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.60
    drag_loss = 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.38, 1.0 - drag_loss)

    if VF >= 55.0:
        k_vf = 1.0 + (VF - 55.0) * 0.0050
    else:
        k_vf = 1.0 + (VF - 55.0) * 0.0100

    eta_eff = eta_base * eta_h * k_drag * k_vf
    speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23

    feedRate_calc = speedArea_raw / H
    ft_max = Hz * 0.060
    feedRate_final = min(feedRate_calc, ft_max)

    fc_thuc = round(feedRate_final * H)
    fc_may_h40 = round(feedRate_final * 40.0)
    t_calc = (j['L'] / feedRate_final) if j['L'] else None

    return fc_thuc, fc_may_h40, t_calc, feedRate_final

print(f"{'Bài':<7} | {'H':<3} | {'Đọc trên máy':<14} | {'Fc máy Hiện Tại':<16} | {'Lệch Fc máy':<12} | {'Fc thực Hiện Tại':<17} | {'t thực':<7} | {'t tính':<7}")
print("-" * 95)
for j in data:
    fc_thuc, fc_may, t_calc, ft = calc_current(j)
    diff = fc_may - j['speed_target']
    t_calc_str = f"{t_calc:.1f}p" if t_calc else "--"
    t_real_str = f"{j['t_min']:.1f}p" if j['t_min'] else "--"
    print(f"{j['name']:<7} | {j['H']:<3} | {j['speed_read']:<14} | {fc_may:<16} | {diff:+<12} | {fc_thuc:<17} | {t_real_str:<7} | {t_calc_str:<7}")
