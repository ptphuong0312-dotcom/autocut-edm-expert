import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

from run_deep_sweep import benchmarks, run_simulation

# Baseline Vòng 5 cũ
# c_scale, p_ton, p_ip, p_duty, h_loss_hard, h_loss_soft, drag_scale, drag_soft, vf_pos, vf_neg
base_v5 = (0.85, 0.28, 0.0, 0.0, 0.0005, 0.0022, 0.60, 2.60, 0.0050, 0.0100)
mape_v5, mae_t_v5, mae_fcm_v5, mae_fcr_v5, det_v5 = run_simulation(*base_v5)
print(f"=== BASELINE VÒNG 5 (CŨ) ===")
print(f"MAPE thời gian t: {mape_v5:.2f}% | MAE t: {mae_t_v5:.2f}p | MAE Fc_máy: {mae_fcm_v5:.2f} mm²/p | MAE Fc_thực: {mae_fcr_v5:.2f} mm²/p\n")

# Tối ưu hóa vi sai
best_mape = mape_v5
best_params = base_v5

# Quét lưới các hệ số thuần vật lý
for c_scale in [0.75, 0.80, 0.85, 0.90]:
    for p_ton in [0.20, 0.25, 0.30, 0.35]:
        for p_ip in [0.0, 0.15, 0.25]:
            for p_duty in [0.0, 0.15, 0.30]:
                for h_loss_hard in [0.0004, 0.0006, 0.0008, 0.0010]:
                    for h_loss_soft in [0.0015, 0.0020, 0.0025, 0.0030]:
                        for drag_scale in [0.45, 0.60, 0.75]:
                            for drag_soft in [1.5, 2.0, 2.6, 3.2]:
                                for vf_pos in [0.004, 0.006, 0.008]:
                                    for vf_neg in [0.008, 0.010, 0.014]:
                                        params = (c_scale, p_ton, p_ip, p_duty, h_loss_hard, h_loss_soft, drag_scale, drag_soft, vf_pos, vf_neg)
                                        mape, mae_t, mae_fcm, mae_fcr, _ = run_simulation(*params)
                                        if mape < best_mape:
                                            best_mape = mape
                                            best_params = params
                                            print(f"New Best MAPE: {best_mape:.2f}% | MAE t: {mae_t:.2f}p | Params: {best_params}")

print(f"\n=== KẾT QUẢ TỐI ƯU TOÀN CỤC ===")
print(f"Best MAPE: {best_mape:.2f}%")
print(f"Best Params: {best_params}")
