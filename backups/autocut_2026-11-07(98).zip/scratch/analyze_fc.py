import sys
sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'H': 30, 'L': 30, 't_min': 8 + 40/60, 'speed_note': '165 - 175', 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 2', 'mat': 'SCM440', 'H': 40, 'L': 30, 't_min': 9 + 36/60, 'speed_note': '130 - 140', 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 3', 'mat': 'SCM420', 'H': 63, 'L': 27, 't_min': 14 + 20/60, 'speed_note': '75 - 85', 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': 'STT 12', 'mat': 'SCM420', 'H': 140, 'L': 28.4, 't_min': 36, 'speed_note': '30 - 40', 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'name': 'STT 14', 'mat': 'SCM440', 'H': 300, 'L': 76.1, 't_min': 180, 'speed_note': '12 - 20', 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'name': 'STT 15', 'mat': 'SCM420', 'H': 160, 'L': 32.3, 't_min': 59, 'speed_note': '18 - 28', 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': 'STT 16', 'mat': 'SCM420', 'H': 75, 'L': 50.3, 't_min': 73, 'speed_note': '50 - 65', 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'name': 'STT 17', 'mat': 'SCM440', 'H': 95, 'L': 76, 't_min': 75, 'speed_note': '35 - 45', 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'name': 'STT 18', 'mat': 'SCM420', 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'speed_note': '50 - 65', 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'H': 85, 'L': 65.6, 't_min': 48, 'speed_note': '55 - 65', 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'H': 165, 'L': 43.6, 't_min': 77, 'speed_note': '15 - 35', 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'H': 60, 'L': 68, 't_min': 40 + 20/60, 'speed_note': '65 - 75', 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'name': '2P-14 P1', 'mat': 'SCM420', 'H': 75, 'L': 50.3, 't_min': 73, 'speed_note': '50 - 65', 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'H': 12, 'L': 128, 't_min': 19 + 50/60, 'speed_note': '275 - 285', 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

print(f"{'Bài cắt':<10} {'Mat':<7} {'H':<4} {'L (mm)':<7} {'Thời gian':<10} {'Fc (LxH/t)':<12} {'Ghi chú xưởng':<15} {'Ft (mm/p)':<10} {'Fc H40':<8} {'Hz máy':<8}")
print("-" * 95)
for r in runs:
    fc_calc = (r['L'] * r['H']) / r['t_min'] if r['L'] and r['t_min'] else 0
    feed_rate = (r['L'] / r['t_min']) if r['t_min'] else 0
    fc_h40 = feed_rate * 40
    print(f"{r['name']:<10} {r['mat']:<7} {r['H']:<4} {r['L']:<7.1f} {r['t_min']:<10.2f} {fc_calc:<12.1f} {r['speed_note']:<15} {feed_rate:<10.2f} {fc_h40:<8.1f} {r['hz']:<8}")
