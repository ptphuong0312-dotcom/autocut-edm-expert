import sys
sys.stdout.reconfigure(encoding='utf-8')

# Đọc toàn bộ các bài cắt trong WORKSHOP_DATA_BANK.md
with open('WORKSHOP_DATA_BANK.md', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if '| **' in line and any(m in line for m in ['SCM440', 'SCM420']):
        parts = [p.strip() for p in line.split('|')]
        # Tìm các dòng có đủ cột
        if len(parts) >= 12:
            print(f"L{i}: {' | '.join(parts[1:17])}")
