import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': '2P-02 P1', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': '2P-03 P1', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

# Hàm tính toán mô hình vật lý
def evaluate_model(C_m, exp_ton, k_vf, k_slag, h_scale_hard, h_scale_soft):
    diff_fc_thuc = []
    diff_fc_may = []
    diff_time_pct = []
    
    for r in runs:
        toff = r['ti'] * (r['po'] + 1)
        true_cycle = r['ti'] + toff
        duty = r['ti'] / true_cycle
        
        eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, exp_ton)
        if r['ti'] > 80: eta_base = min(0.92, eta_base)

        if r['isHard']:
            eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * h_scale_hard)
        else:
            eta_h = max(0.55, 1.0 - max(0, r['H'] - 50) * h_scale_soft)

        h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
        po_choke = max(0.0, (8.0 - r['po']) / 10.0)
        mat_choke = 1.0 if r['isHard'] else 2.6
        slag_drag = k_slag * math.pow(h_choke, 0.65) * po_choke * mat_choke
        k_drag = max(0.40, 1.0 - slag_drag)

        k_vf_factor = 1.0 + (r['vf'] - 55.0) * k_vf
        eta_eff = eta_base * eta_h * k_drag * k_vf_factor

        u_arc = 22 if r['volt'] == 'Low' else 27
        i_peak = r['ip'] * 2.8
        power_watts = u_arc * i_peak * duty

        mrr_vol = 60 * C_m * power_watts * eta_eff
        B = 0.23
        speedArea_raw = mrr_vol / B

        feedRate_calc = speedArea_raw / r['H']
        ft_max = r['hz'] * 0.060
        feedRate_final = min(feedRate_calc, ft_max)

        fc_thuc_calc = feedRate_final * r['H']
        fc_may_calc = feedRate_final * 40
        t_calc = (r['L'] * r['H']) / fc_thuc_calc

        fc_thuc_exact = (r['L'] * r['H']) / r['t_min']
        fc_may_exact = (r['L'] / r['t_min']) * 40

        diff_fc_thuc.append(abs(fc_thuc_calc - fc_thuc_exact))
        diff_fc_may.append(abs(fc_may_calc - fc_may_exact))
        diff_time_pct.append(abs(t_calc - r['t_min']) / r['t_min'] * 100)

    mae_thuc = sum(diff_fc_thuc) / len(diff_fc_thuc)
    mae_may = sum(diff_fc_may) / len(diff_fc_may)
    mape_time = sum(diff_time_pct) / len(diff_time_pct)
    return mae_thuc, mae_may, mape_time

# Tìm kiếm bộ hệ số tối ưu
best_score = 999.0
best_params = None

for cm in [0.0130, 0.0133, 0.0135, 0.0138]:
    for exp_t in [0.30, 0.32, 0.35]:
        for kvf in [0.006, 0.007, 0.008]:
            for kslag in [0.40, 0.45, 0.50, 0.55]:
                for h_hard in [0.0006, 0.0008, 0.0010]:
                    for h_soft in [0.0018, 0.0020, 0.0022]:
                        mae_thuc, mae_may, mape_t = evaluate_model(cm, exp_t, kvf, kslag, h_hard, h_soft)
                        # Trọng số: ưu tiên khớp thời gian cắt & Fc máy
                        score = mae_may + mape_t * 0.5
                        if score < best_score:
                            best_score = score
                            best_params = (cm, exp_t, kvf, kslag, h_hard, h_soft, mae_thuc, mae_may, mape_t)

cm, exp_t, kvf, kslag, h_hard, h_soft, mae_thuc, mae_may, mape_t = best_params
print(f"BỘ HỆ SỐ TỐI ƯU TOÁN HỌC TRÊN DỮ LIỆU CỨNG (t, L, H):")
print(f"  Cm = {cm}")
print(f"  exp_ton = {exp_t}")
print(f"  k_vf = {kvf}")
print(f"  k_slag = {kslag}")
print(f"  h_scale_hard = {h_hard}")
print(f"  h_scale_soft = {h_soft}")
print(f"--> MAE Fc Thực: {mae_thuc:.2f} mm²/p")
print(f"--> MAE Fc Máy (H40): {mae_may:.2f} mm²/p")
print(f"--> MAPE Sai số Thời gian cắt: {mape_t:.1f}%")
