import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

# Dữ liệu thực nghiệm đầy đủ (13 bài cắt Pass 1 chuẩn có đủ L, H, t_p và ghi chú xưởng)
# Lưu ý: STT 16 và 2P-14 P1 là cùng 1 bài cắt ghi 2 lần, ta lấy 1 bài đại diện để tránh trùng lặp.
runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_p': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 170},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_p': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 135},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_p': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55, 'note_fc': 80},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_p': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60, 'note_fc': 35},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_p': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65, 'note_fc': 16},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_p': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 23},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_p': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54, 'note_fc': 57.5},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_p': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55, 'note_fc': 40},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_p': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57, 'note_fc': 57.5},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_p': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61, 'note_fc': 60},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_p': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 25},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_p': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62, 'note_fc': 70},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_p': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65, 'note_fc': 280},
]

# Hàm tính toán mô hình vật lý nâng cấp có bổ sung:
# 1. Bù điện áp bám tải VF: k_vf_fc = 1.0 + (VF - 55) * 0.008 (mỗi 10 vạch VF tăng/giảm ~8% tốc độ bám tải)
# 2. Suy giảm do nghẽn mạt xỉ phôi dày (đặc biệt SCM420 mềm và Po <= 7): k_slag_fc
# 3. Chặn trần tốc độ theo Hz giới hạn: ft_limit = hz * 0.060
def calc_advanced_fc(H, Ton, Po, IP, Volt, VF, hz, isHard, params):
    C_m, exp_ton, k_vf, k_slag_scale, h_scale_hard, h_scale_soft = params
    
    toff = Ton * (Po + 1)
    true_cycle = Ton + toff
    duty = Ton / true_cycle

    # 1. Hiệu suất nhiệt cơ bản theo Ton
    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, exp_ton)
    if Ton > 80:
        eta_base = min(0.92, eta_base)

    # 2. Hệ số suy giảm thoát xỉ rãnh sâu theo chiều dày H
    if isHard:
        eta_h = max(0.70, 1.0 - max(0, H - 80) * h_scale_hard)
    else:
        eta_h = max(0.55, 1.0 - max(0, H - 50) * h_scale_soft)

    # 3. Hệ số nghẽn xỉ do Po ngắn và phôi dày (tương tự d_sec của lượng cào phôi)
    # Nếu H > 63mm và Po <= 7: mạt xỉ dính bết làm khựng servo
    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.6
    slag_drag = k_slag_scale * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.40, 1.0 - slag_drag)

    # 4. Ảnh hưởng của điện áp bám tải VF
    k_vf_factor = 1.0 + (VF - 55.0) * k_vf

    # 5. Hiệu suất thực tế tổng hợp
    eta_eff = eta_base * eta_h * k_drag * k_vf_factor

    # 6. Công suất phóng điện
    u_arc = 22 if Volt == 'Low' else 27
    i_peak = IP * 2.8
    power_watts = u_arc * i_peak * duty

    # 7. Thể tích kim loại bóc tách trong 1 phút MRR_vol (mm3/p)
    mrr_vol = 60 * C_m * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B

    # 8. Tốc độ tiến bàn máy và Giới hạn trần theo Hz
    feedRate_calc = speedArea_raw / H
    ft_max = hz * 0.060 # Giới hạn phần cứng động cơ bước
    feedRate_final = min(feedRate_calc, ft_max)

    speedArea_final = round(feedRate_final * H)
    speedAreaH40 = round(feedRate_final * 40)

    return speedArea_final, speedAreaH40, round(feedRate_final, 2)

# Đánh giá các bộ tham số
best_params = [0.0135, 0.35, 0.0070, 0.45, 0.0006, 0.0018]

# Thử nghiệm tối ưu hóa lưới (Grid Search)
best_mae_may = 999.0
best_opt = None

for cm in [0.0130, 0.0135, 0.0140]:
    for exp_t in [0.32, 0.35, 0.38]:
        for kvf in [0.005, 0.007, 0.009]:
            for kslag in [0.30, 0.45, 0.60]:
                for h_hard in [0.0005, 0.0008]:
                    for h_soft in [0.0015, 0.0020]:
                        p = [cm, exp_t, kvf, kslag, h_hard, h_soft]
                        diffs = []
                        for r in runs:
                            ft_thuc = r['L'] / r['t_p']
                            fc_may_goc = ft_thuc * 40
                            _, fc_may_calc, _ = calc_advanced_fc(r['H'], r['ti'], r['po'], r['ip'], r['volt'], r['vf'], r['hz'], r['isHard'], p)
                            diffs.append(abs(fc_may_calc - fc_may_goc))
                        mae = sum(diffs) / len(diffs)
                        if mae < best_mae_may:
                            best_mae_may = mae
                            best_opt = p

print(f"Optimal Parameters: {best_opt}")
print(f"Optimal MAE Fc Máy: {best_mae_may:.2f} mm²/p (Cũ: 8.47 mm²/p)")
