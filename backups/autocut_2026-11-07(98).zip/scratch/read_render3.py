import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('// VÙNG 1: Render bảng Đầu Vào')
if idx == -1:
    idx = text.find('wsTableBodyVung1.innerHTML')
if idx != -1:
    print(text[idx-100:idx+2500])
