import math
import sys
from scipy.optimize import minimize

sys.stdout.reconfigure(encoding='utf-8')
from run_deep_sweep import benchmarks, run_simulation

# Hàm mục tiêu: hàm mất mát MAPE thời gian t
def loss_func(p):
    c_scale, p_ton, p_ip, p_duty, h_loss_hard, h_loss_soft, drag_scale, drag_soft, vf_pos, vf_neg = p
    mape, mae_t, mae_fcm, mae_fcr, _ = run_simulation(c_scale, p_ton, p_ip, p_duty, h_loss_hard, h_loss_soft, drag_scale, drag_soft, vf_pos, vf_neg)
    return mape

# Điểm khởi tạo
init_p = [0.85, 0.28, 0.0, 0.0, 0.0005, 0.0022, 0.60, 2.60, 0.0050, 0.0100]
bounds = [
    (0.60, 1.10),   # c_scale
    (0.15, 0.45),   # p_ton
    (0.00, 0.40),   # p_ip
    (0.00, 0.40),   # p_duty
    (0.0002, 0.0020), # h_loss_hard
    (0.0010, 0.0050), # h_loss_soft
    (0.30, 0.90),   # drag_scale
    (1.0, 4.0),     # drag_soft
    (0.002, 0.012), # vf_pos
    (0.005, 0.020)  # vf_neg
]

res = minimize(loss_func, init_p, method='Nelder-Mead', bounds=bounds, options={'maxiter': 1500, 'disp': True})

opt_p = res.x
mape_opt, mae_t_opt, mae_fcm_opt, mae_fcr_opt, det_opt = run_simulation(*opt_p)

print(f"\n=== KẾT QUẢ TỐI ƯU HỘI TỤ (NELDER-MEAD) ===")
print(f"MAPE thời gian t: {mape_opt:.2f}% (Giảm từ 14.31%)")
print(f"MAE thời gian t:  {mae_t_opt:.2f} phút")
print(f"MAE Fc_máy:       {mae_fcm_opt:.2f} mm²/p")
print(f"MAE Fc_thực:      {mae_fcr_opt:.2f} mm²/p")
print(f"Tham số tối ưu:\n  c_scale={opt_p[0]:.4f}\n  p_ton={opt_p[1]:.4f}\n  p_ip={opt_p[2]:.4f}\n  p_duty={opt_p[3]:.4f}\n  h_loss_hard={opt_p[4]:.6f}\n  h_loss_soft={opt_p[5]:.6f}\n  drag_scale={opt_p[6]:.4f}\n  drag_soft={opt_p[7]:.4f}\n  vf_pos={opt_p[8]:.5f}\n  vf_neg={opt_p[9]:.5f}")

print(f"\n{'Bài':<7} | {'H':<3} | {'t thực':<7} | {'t tính':<7} | {'Sai số':<8} | {'% Lệch':<7} | {'Fc_m thực':<10} | {'Fc_m tính':<10} | {'Fc_r thực':<10} | {'Fc_r tính':<10}")
print("-" * 105)
for d in det_opt:
    print(f"{d['id']:<7} | {d['H']:<3} | {d['t_real']:<7.1f} | {d['t_calc']:<7.1f} | {d['t_calc']-d['t_real']:+<8.2f} | {d['rel_t']:<7.1f}% | {d['fc_m_real']:<10.1f} | {d['fc_m_calc']:<10.1f} | {d['fc_r_real']:<10.1f} | {d['fc_r_calc']:<10.1f}")
