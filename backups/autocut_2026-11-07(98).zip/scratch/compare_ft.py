import sys
sys.stdout.reconfigure(encoding='utf-8')

jobs = [
    {"name": "5P-01", "H": 12, "L": 128.0, "t": 19 + 50/60, "recorded": "275 - 285"},
    {"name": "STT 1", "H": 30, "L": 30.0, "t": 8 + 40/60, "recorded": "165 - 175"},
    {"name": "STT 2", "H": 40, "L": 30.0, "t": 9 + 36/60, "recorded": "130 - 140"},
    {"name": "STT 3", "H": 63, "L": 27.0, "t": 14 + 20/60, "recorded": "75 - 85"},
    {"name": "STT 18", "H": 63, "L": 22.3, "t": 17 + 40/60, "recorded": "50 - 65"},
    {"name": "STT 16", "H": 75, "L": 50.3, "t": 73.0, "recorded": "50 - 65"},
    {"name": "2P-10", "H": 85, "L": 65.6, "t": 48.0, "recorded": "55 - 65"},
    {"name": "STT 17", "H": 95, "L": 76.0, "t": 75.0, "recorded": "35 - 45"},
    {"name": "STT 12", "H": 140, "L": 28.4, "t": 36.0, "recorded": "30 - 40"},
    {"name": "STT 15", "H": 160, "L": 32.3, "t": 59.0, "recorded": "18 - 28"},
    {"name": "2P-12", "H": 165, "L": 43.6, "t": 77.0, "recorded": "15 - 35"},
    {"name": "STT 14", "H": 300, "L": 76.1, "t": 180.0, "recorded": "12 - 20"},
]

print(f"{'Bài':<8} | {'H':<4} | {'Ft = L/t (mm/p)':<16} | {'Ft * H (mm²/p)':<15} | {'Ft * 40 (mm²/p)':<16} | {'Số ghi trên máy':<16}")
print("-" * 85)
for j in jobs:
    ft = j["L"] / j["t"]
    f_real = ft * j["H"]
    f_h40 = ft * 40.0
    print(f"{j['name']:<8} | {j['H']:<4} | {ft:<16.3f} | {f_real:<15.1f} | {f_h40:<16.1f} | {j['recorded']:<16}")
