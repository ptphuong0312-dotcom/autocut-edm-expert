import re

with open('app.js', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. CẬP NHẬT TRONG generateWorkshopRows (Pass 1)
old_gen_block = """                let eta_eff = (isHard ? 0.85 : 0.78) * Math.pow(Math.max(1, Ton) / 50, 0.38);
                if (Ton > 80) eta_eff = Math.min(0.92, eta_eff);
                
                // Suy giảm hiệu suất do thoát xỉ rãnh sâu
                if (isHard) {
                    if (H > 80) eta_eff *= Math.max(0.65, 1.0 - (H - 80) * 0.0010);
                } else {
                    // Thép mềm dẻo SCM420 (HB < 200) phoi bết dính suy giảm từ H > 50mm
                    if (H > 50) eta_eff *= Math.max(0.55, 1.0 - (H - 50) * 0.0016);
                }
                
                // Đã loại bỏ hệ số ghìm tiến nhân tạo: SCM420 H>=70 cắt thực tế 50-65 mm2/p
                
                const u_arc = Volt === 'Low' ? 22 : 27;
                const i_peak = IP * 2.8;
                const power_watts = u_arc * i_peak * duty;
                
                let Cm = 0.0140; // Thép chuẩn xưởng SCM420/440 (Hiệu chuẩn theo Toff = Pon * (Poff + 1))
                const mrr_vol = 60 * Cm * power_watts * eta_eff;
                const B = 0.23;
                let speedArea = Math.round(mrr_vol / B);
                let feedRate = (speedArea / H).toFixed(2);"""

new_gen_block = """                // HỆ PHƯƠNG TRÌNH TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC FC THỰC & FC MÁY (VÒNG 5 REFINED)
                let eta_base = (isHard ? 0.85 : 0.78) * Math.pow(Math.max(1, Ton) / 50.0, 0.28);
                if (Ton > 80) eta_base = Math.min(0.92, eta_base);

                let eta_h;
                if (isHard) {
                    eta_h = Math.max(0.70, 1.0 - Math.max(0, H - 80) * 0.0005);
                } else {
                    eta_h = Math.max(0.55, 1.0 - Math.max(0, H - 50) * 0.0022);
                }

                const h_choke = Math.max(0.0, (H - 63.0) / 100.0);
                const po_choke = Math.max(0.0, (8.0 - Po) / 10.0);
                const mat_choke = isHard ? 1.0 : 2.60;
                const slag_drag = 0.60 * Math.pow(h_choke, 0.65) * po_choke * mat_choke;
                const k_drag = Math.max(0.38, 1.0 - slag_drag);

                let k_vf;
                if (VF >= 55.0) {
                    k_vf = 1.0 + (VF - 55.0) * 0.0050;
                } else {
                    k_vf = 1.0 + (VF - 55.0) * 0.0100;
                }

                const eta_eff = eta_base * eta_h * k_drag * k_vf;

                const u_arc = Volt === 'Low' ? 22 : 27;
                const i_peak = IP * 2.8;
                const power_watts = u_arc * i_peak * duty;

                const Cm = 0.0135; // Hằng số bóc phôi xưởng chuẩn hóa Vòng 5
                const B = 0.23;
                const mrr_vol = 60 * Cm * power_watts * eta_eff;
                const speedArea_raw = mrr_vol / B;

                const feedRate_calc = speedArea_raw / H;
                const ft_max = multiPassHzList[0] * 0.060;
                const feedRate_final = Math.min(feedRate_calc, ft_max);

                let speedArea = Math.round(feedRate_final * H);
                let speedAreaH40 = Math.round(feedRate_final * 40);
                let feedRate = feedRate_final.toFixed(2);"""

if old_gen_block in code:
    code = code.replace(old_gen_block, new_gen_block)
    print("[OK] Replaced generateWorkshopRows Fc block successfully!")
else:
    print("[ERROR] old_gen_block not found in app.js!")

# 2. CẬP NHẬT TRONG computeRowDynamics
old_dyn_block = """                        const isHard = (state.wsMaterial === 'SCM440');
                        let eta_eff = (isHard ? 0.85 : 0.78) * Math.pow(Math.max(1, tiVal) / 50, 0.38);
                        if (tiVal > 80) eta_eff = Math.min(0.92, eta_eff);
                        if (isHard) {
                            if (state.thickness > 80) eta_eff *= Math.max(0.65, 1.0 - (state.thickness - 80) * 0.0010);
                        } else {
                            if (state.thickness > 50) eta_eff *= Math.max(0.55, 1.0 - (state.thickness - 50) * 0.0016);
                        }
                        const u_arc = voltVal === 'Low' ? 22 : 27;
                        const i_peak = ipVal * 2.8;
                        const duty = tiVal / (tiVal * (poVal + 2));
                        const power_watts = u_arc * i_peak * duty;
                        const Cm = 0.0140;
                        const B = 0.23;
                        speedArea = Math.round((60 * Cm * power_watts * eta_eff) / B);
                        const feedRate = (speedArea / state.thickness).toFixed(2);
                        speedAreaH40 = Math.round(parseFloat(feedRate) * 40);"""

new_dyn_block = """                        const isHard = (state.wsMaterial === 'SCM440');
                        const toffVal = tiVal * (poVal + 1);
                        const dutyVal = tiVal / (tiVal + toffVal);

                        let eta_base = (isHard ? 0.85 : 0.78) * Math.pow(Math.max(1, tiVal) / 50.0, 0.28);
                        if (tiVal > 80) eta_base = Math.min(0.92, eta_base);

                        let eta_h;
                        if (isHard) {
                            eta_h = Math.max(0.70, 1.0 - Math.max(0, state.thickness - 80) * 0.0005);
                        } else {
                            eta_h = Math.max(0.55, 1.0 - Math.max(0, state.thickness - 50) * 0.0022);
                        }

                        const h_choke = Math.max(0.0, (state.thickness - 63.0) / 100.0);
                        const po_choke = Math.max(0.0, (8.0 - poVal) / 10.0);
                        const mat_choke = isHard ? 1.0 : 2.60;
                        const slag_drag = 0.60 * Math.pow(h_choke, 0.65) * po_choke * mat_choke;
                        const k_drag = Math.max(0.38, 1.0 - slag_drag);

                        let k_vf;
                        if (vfVal >= 55.0) {
                            k_vf = 1.0 + (vfVal - 55.0) * 0.0050;
                        } else {
                            k_vf = 1.0 + (vfVal - 55.0) * 0.0100;
                        }

                        const eta_eff = eta_base * eta_h * k_drag * k_vf;
                        const u_arc = voltVal === 'Low' ? 22 : 27;
                        const i_peak = ipVal * 2.8;
                        const power_watts = u_arc * i_peak * dutyVal;

                        const Cm = 0.0135;
                        const B = 0.23;
                        const speedArea_raw = (60 * Cm * power_watts * eta_eff) / B;
                        const feedRate_calc = speedArea_raw / state.thickness;
                        const ft_max = (hz || 150) * 0.060;
                        const feedRate_final = Math.min(feedRate_calc, ft_max);

                        speedArea = Math.round(feedRate_final * state.thickness);
                        speedAreaH40 = Math.round(feedRate_final * 40);"""

if old_dyn_block in code:
    code = code.replace(old_dyn_block, new_dyn_block)
    print("[OK] Replaced computeRowDynamics Fc block successfully!")
else:
    print("[ERROR] old_dyn_block not found in app.js!")

with open('app.js', 'w', encoding='utf-8') as f:
    f.write(code)

print("Saved app.js successfully!")
