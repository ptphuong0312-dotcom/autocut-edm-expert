import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('docs/OPTIMIZATION_HISTORY.md', 'r', encoding='utf-8') as f:
    text = f.read()

for i in [58, 59, 60, 61]:
    print(f'Has Đợt {i}?:', f'ĐỢT {i}' in text)
