with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

target = '                let speedAreaH40 = Math.round(parseFloat(feedRate) * 40);\n'
if target not in text:
    target = '                let speedAreaH40 = Math.round(parseFloat(feedRate) * 40);\r\n'

if target in text:
    text = text.replace(target, '')
    with open('app.js', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Successfully removed duplicate let speedAreaH40 line!")
else:
    print("Target not found!")
