import os
import zipfile
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')

backup_dir = 'backups'
os.makedirs(backup_dir, exist_ok=True)

import glob
existing = glob.glob(os.path.join(backup_dir, f'autocut_*.zip'))
max_n = 0
for f in existing:
    fname = os.path.basename(f)
    if 'autocut_' in fname and fname.endswith(').zip'):
        try:
            n = int(fname.split('(')[1].split(')')[0])
            if n > max_n:
                max_n = n
        except ValueError:
            pass

next_n = max_n + 1 if max_n > 0 else 98
target_zip = os.path.join(backup_dir, f'autocut_2026-11-07({next_n}).zip')

print(f"Creating backup: {target_zip}")

exclude_dirs = {'backups', '.git', 'node_modules', '__pycache__', '.venv', '.vercel'}
exclude_exts = {'.zip'}

file_count = 0
with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in exclude_exts:
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, '.')
            zipf.write(full_path, rel_path)
            file_count += 1

print(f"Backup created successfully! Packed {file_count} files into {target_zip}")
