import math
import sys
import random

sys.stdout.reconfigure(encoding='utf-8')
from run_deep_sweep import benchmarks, run_simulation

# Thuật toán Pattern Search / Coordinate Descent thuần Python
def optimize_pure():
    best_p = [0.85, 0.28, 0.0, 0.0, 0.0005, 0.0022, 0.60, 2.60, 0.0050, 0.0100]
    best_score, mae_t, mae_fcm, mae_fcr, _ = run_simulation(*best_p)
    print(f"Initial MAPE: {best_score:.2f}% | MAE t: {mae_t:.2f}p")

    step_sizes = [0.05, 0.03, 0.03, 0.03, 0.0001, 0.0003, 0.05, 0.20, 0.0010, 0.0010]
    bounds = [
        (0.60, 1.10),   # c_scale
        (0.15, 0.45),   # p_ton
        (0.00, 0.40),   # p_ip
        (0.00, 0.40),   # p_duty
        (0.0002, 0.0020), # h_loss_hard
        (0.0010, 0.0050), # h_loss_soft
        (0.30, 0.90),   # drag_scale
        (1.0, 4.0),     # drag_soft
        (0.002, 0.012), # vf_pos
        (0.005, 0.020)  # vf_neg
    ]

    for iteration in range(12):
        improved = False
        for i in range(len(best_p)):
            for direction in [-1, 1]:
                cand_p = list(best_p)
                cand_p[i] = max(bounds[i][0], min(bounds[i][1], cand_p[i] + direction * step_sizes[i]))
                score, m_t, m_fcm, m_fcr, _ = run_simulation(*cand_p)
                if score < best_score:
                    best_score = score
                    best_p = cand_p
                    improved = True
                    # Thử bước đôi nếu cải thiện
                    while True:
                        cand_p2 = list(best_p)
                        cand_p2[i] = max(bounds[i][0], min(bounds[i][1], cand_p2[i] + direction * step_sizes[i]))
                        score2, _, _, _, _ = run_simulation(*cand_p2)
                        if score2 < best_score:
                            best_score = score2
                            best_p = cand_p2
                        else:
                            break
        # Thu hẹp bước nhảy
        step_sizes = [s * 0.75 for s in step_sizes]
        print(f"Iteration {iteration+1}: Best MAPE = {best_score:.2f}%")

    mape_final, mae_t_final, mae_fcm_final, mae_fcr_final, details = run_simulation(*best_p)
    return best_p, mape_final, mae_t_final, mae_fcm_final, mae_fcr_final, details

opt_p, mape_opt, mae_t_opt, mae_fcm_opt, mae_fcr_opt, det_opt = optimize_pure()

print(f"\n=== KẾT QUẢ TỐI ƯU HỘI TỤ (COORDINATE SEARCH) ===")
print(f"MAPE thời gian t: {mape_opt:.2f}% (Giảm kỷ lục từ 14.31% -> {mape_opt:.2f}%)")
print(f"MAE thời gian t:  {mae_t_opt:.2f} phút")
print(f"MAE Fc_máy:       {mae_fcm_opt:.2f} mm²/p")
print(f"MAE Fc_thực:      {mae_fcr_opt:.2f} mm²/p")

print(f"\n{'Bài':<7} | {'H':<3} | {'t thực':<7} | {'t tính':<7} | {'Sai số':<8} | {'% Lệch':<7} | {'Fc_m thực':<10} | {'Fc_m tính':<10} | {'Fc_r thực':<10} | {'Fc_r tính':<10}")
print("-" * 105)
for d in det_opt:
    print(f"{d['id']:<7} | {d['H']:<3} | {d['t_real']:<7.1f} | {d['t_calc']:<7.1f} | {d['t_calc']-d['t_real']:+<8.2f} | {d['rel_t']:<7.1f}% | {d['fc_m_real']:<10.1f} | {d['fc_m_calc']:<10.1f} | {d['fc_r_real']:<10.1f} | {d['fc_r_calc']:<10.1f}")

print("\nBộ tham số tối ưu xuất sắc:")
names = ["c_scale", "p_ton", "p_ip", "p_duty", "h_loss_hard", "h_loss_soft", "drag_scale", "drag_soft", "vf_pos", "vf_neg"]
for n, val in zip(names, opt_p):
    print(f"  {n}: {val}")
