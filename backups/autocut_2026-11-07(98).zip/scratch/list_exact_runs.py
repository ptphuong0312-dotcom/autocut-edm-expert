import sys
sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
    {'name': '2P-02 P1', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'name': '2P-03 P1', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
]

print(f"Tổng số bài cắt có số đo chuẩn t và L: {len(runs)} bài")
for r in runs:
    fc_exact = (r['L'] * r['H']) / r['t_min']
    ft_exact = r['L'] / r['t_min']
    fc_m40 = ft_exact * 40
    print(f"{r['name']:<10} {r['mat']:<7} H={r['H']:<3} L={r['L']:<5.1f} t={r['t_min']:<5.1f}p | Ft={ft_exact:<5.2f} mm/p | Fc_thực={fc_exact:<6.1f} | Fc_máy(H40)={fc_m40:<5.1f}")
