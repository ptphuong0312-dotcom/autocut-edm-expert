import sys
sys.stdout.reconfigure(encoding='utf-8')

# Mô phỏng computeRowDynamics trong app.js
def test_dyn_pon(H, mat, base_cfg, test_pons):
    isHard = (mat == 'SCM440')
    po = base_cfg['Po']
    ip = base_cfg['IP']
    volt = base_cfg['Volt']
    vf = base_cfg['VF']
    hz = base_cfg['Hz']

    print(f"--- Test H={H}mm, {mat}, Po={po}, IP={ip}, VF={vf}, Hz={hz} ---")
    for pon in test_pons:
        toff = pon * (po + 1)
        duty = pon / (pon + toff)  # = 1 / (po + 2)
        uarc = 27.0 if volt == 'High' else 22.0
        power_watts = uarc * (2.8 * ip) * duty

        import math
        eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, pon) / 50.0, 0.28)
        if pon > 80: eta_base = min(0.92, eta_base)

        if isHard:
            eta_h = max(0.70, 1.0 - max(0, H - 80) * 0.0005)
        else:
            eta_h = max(0.55, 1.0 - max(0, H - 50) * 0.0022)

        h_choke = max(0.0, (H - 63.0) / 100.0)
        po_choke = max(0.0, (8.0 - po) / 10.0)
        mat_choke = 1.0 if isHard else 2.60
        drag_loss = 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke
        k_drag = max(0.38, 1.0 - drag_loss)

        if vf >= 55.0:
            k_vf = 1.0 + (vf - 55.0) * 0.0050
        else:
            k_vf = 1.0 + (vf - 55.0) * 0.0100

        eta_eff = eta_base * eta_h * k_drag * k_vf
        speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23
        feedRate_calc = speedArea_raw / H
        ft_max = hz * 0.060
        feedRate_final = min(feedRate_calc, ft_max)

        fc_thuc = round(feedRate_final * H)
        fc_may = round(feedRate_final * 40.0)
        print(f"   Pon={pon:<3} | duty={duty:.3f} | Power={power_watts:.1f}W | eta_eff={eta_eff:.3f} | Ft={feedRate_final:.2f} mm/p | Fc thực={fc_thuc:<3} mm²/p | Fc máy={fc_may:<3} mm²/p")

test_dyn_pon(40, 'SCM440', {'Po': 5, 'IP': 4, 'Volt': 'High', 'VF': 65, 'Hz': 180}, [15, 25, 36, 50, 70, 100])
test_dyn_pon(140, 'SCM420', {'Po': 9, 'IP': 6, 'Volt': 'High', 'VF': 60, 'Hz': 100}, [40, 60, 80, 100, 120, 150])
