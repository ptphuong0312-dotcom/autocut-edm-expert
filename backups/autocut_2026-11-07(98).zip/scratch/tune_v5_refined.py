import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'id': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-02', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-03', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'id': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'id': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'id': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'id': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'id': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'id': '2P-10', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'id': '2P-12', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': '2P-13', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'id': '5P-01', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

for r in runs:
    r['ft_exact'] = r['L'] / r['t_min']
    r['fc_thuc_exact'] = (r['L'] * r['H']) / r['t_min']
    r['fc_may_exact'] = r['ft_exact'] * 40

# THỬ NGHIỆM VÒNG 5 (V5_REFINED):
# Tinh chỉnh Vật liệu Cm riêng biệt: SCM440 vs SCM420
# Tinh chỉnh VF hai nhánh: VF >= 55 vs VF < 55
def eval_v5_refined(cm_hard, cm_soft, exp_ton, kvf_pos, kvf_neg, k_slag, h_scale_hard, h_scale_soft):
    diff_t_pct = []
    diff_fc_may = []
    diff_fc_thuc = []
    
    for r in runs:
        toff = r['ti'] * (r['po'] + 1)
        duty = r['ti'] / (r['ti'] + toff)
        
        eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, exp_ton)
        if r['ti'] > 80: eta_base = min(0.92, eta_base)

        if r['isHard']:
            eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * h_scale_hard)
        else:
            eta_h = max(0.55, 1.0 - max(0, r['H'] - 50) * h_scale_soft)

        h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
        po_choke = max(0.0, (8.0 - r['po']) / 10.0)
        mat_choke = 1.0 if r['isHard'] else 2.6
        slag_drag = k_slag * math.pow(h_choke, 0.65) * po_choke * mat_choke
        k_drag = max(0.38, 1.0 - slag_drag)

        if r['vf'] >= 55.0:
            k_vf = 1.0 + (r['vf'] - 55.0) * kvf_pos
        else:
            k_vf = 1.0 + (r['vf'] - 55.0) * kvf_neg

        eta_eff = eta_base * eta_h * k_drag * k_vf

        u_arc = 22 if r['volt'] == 'Low' else 27
        i_peak = r['ip'] * 2.8
        power_watts = u_arc * i_peak * duty

        Cm = cm_hard if r['isHard'] else cm_soft
        mrr_vol = 60 * Cm * power_watts * eta_eff
        B = 0.23
        speedArea_raw = mrr_vol / B

        feedRate_calc = speedArea_raw / r['H']
        ft_max = r['hz'] * 0.060
        feedRate_final = min(feedRate_calc, ft_max)

        fc_thuc_calc = feedRate_final * r['H']
        fc_may_calc = feedRate_final * 40
        t_calc = r['L'] / feedRate_final

        diff_fc_thuc.append(abs(fc_thuc_calc - r['fc_thuc_exact']))
        diff_fc_may.append(abs(fc_may_calc - r['fc_may_exact']))
        diff_t_pct.append(abs(t_calc - r['t_min']) / r['t_min'] * 100)

    return sum(diff_fc_thuc) / len(diff_fc_thuc), sum(diff_fc_may) / len(diff_fc_may), sum(diff_t_pct) / len(diff_t_pct)

# Quét lưới mịn
best_score = 999.0
best_p = None

for cm_h in [0.0135, 0.0138, 0.0140]:
    for cm_s in [0.0130, 0.0133, 0.0135]:
        for exp_t in [0.28, 0.30, 0.32]:
            for kvf_p in [0.005, 0.006, 0.007]:
                for kvf_n in [0.006, 0.008, 0.010]:
                    for k_s in [0.50, 0.55, 0.60]:
                        for h_h in [0.0005, 0.0006, 0.0007]:
                            for h_s in [0.0020, 0.0022, 0.0025]:
                                m_thuc, m_may, m_t = eval_v5_refined(cm_h, cm_s, exp_t, kvf_p, kvf_n, k_s, h_h, h_s)
                                score = m_t * 0.7 + m_may * 0.3
                                if score < best_score:
                                    best_score = score
                                    best_p = (cm_h, cm_s, exp_t, kvf_p, kvf_n, k_s, h_h, h_s, m_thuc, m_may, m_t)

cm_h, cm_s, exp_t, kvf_p, kvf_n, k_s, h_h, h_s, m_thuc, m_may, m_t = best_p
print("KẾT QUẢ TỐI ƯU VÒNG 5 (V5 REFINED):")
print(f"  Cm_hard = {cm_h}, Cm_soft = {cm_s}")
print(f"  exp_ton = {exp_t}")
print(f"  kvf_pos = {kvf_p}, kvf_neg = {kvf_n}")
print(f"  k_slag = {k_s}")
print(f"  h_scale_hard = {h_h}, h_scale_soft = {h_s}")
print(f"--> MAE Fc Thực: {m_thuc:.2f} mm²/p (V3: 9.50)")
print(f"--> MAE Fc Máy:  {m_may:.2f} mm²/p (V3: 6.12)")
print(f"--> MAPE Thời gian: {m_t:.1f}% (V3: 9.2%)")
