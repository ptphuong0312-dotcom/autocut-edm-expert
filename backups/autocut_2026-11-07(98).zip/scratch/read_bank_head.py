import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('WORKSHOP_DATA_BANK.md', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i in range(min(120, len(lines))):
    print(lines[i], end='')
