import os
import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

rules_dir = '.agents/rules'
for f in sorted(os.listdir(rules_dir)):
    if f.endswith('.md'):
        path = os.path.join(rules_dir, f)
        with open(path, 'r', encoding='utf-8') as rf:
            content = rf.read()
        matches = re.findall(r'.{0,50}(?:Fc|tốc độ cắt|speedArea|H40|Fc thực|Fc máy).{0,50}', content, re.IGNORECASE)
        if matches:
            print(f"=== {f} ({len(matches)} matches) ===")
            for m in matches[:5]:
                print("  ", m.strip())
