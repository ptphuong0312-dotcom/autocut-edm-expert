import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Kiểm tra vị trí generateWorkshopRows
idx1 = text.find('let eta_base = (isHard ? 0.85 : 0.78)')
print(f"Position 1 (generateWorkshopRows): {idx1}")
if idx1 != -1:
    print("Code around pos 1:")
    print(text[idx1-100:idx1+700])

# Kiểm tra vị trí computeRowDynamics
idx2 = text.find('let eta_base = (isHard ? 0.85 : 0.78)', idx1 + 100)
print(f"\nPosition 2 (computeRowDynamics): {idx2}")
if idx2 != -1:
    print("Code around pos 2:")
    print(text[idx2-100:idx2+700])
