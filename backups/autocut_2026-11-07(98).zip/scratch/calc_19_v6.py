import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 19 bài trong WS_LIB_BENCHMARK_JOBS[1]
jobs19 = [
    # H=12 (Quy đổi từ Pass 1 bài cắt 5P-01 có đo kiểm vách P1)
    {"H": 12, "mat": "SCM440", "fromMulti": True, "Ton": 20, "Toff": 5, "IP": 3, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 150, "offset": "0,101", "actOff": "0,101", "calcOff": "0,0988", "L": 128.0, "actT": "19p50'", "actA": "4A", "calcA": "3.6A", "actSpd": "275-285 mm²/p"},
    # H=12 (SCM420, STT 22 - Cắt chày 1 Pass Volt Low)
    {"H": 12, "mat": "SCM420", "fromMulti": False, "Ton": 16, "Toff": 6, "IP": 3, "Wire": 1, "Volt": "Low", "VF": 60, "Hz": 150, "offset": "0,095", "actOff": "0,095", "calcOff": "0,0963", "L": None, "actT": "--", "actA": "2,5A - 2,7A", "calcA": "2.5A", "actSpd": "--"},
    # H=30 (SCM440, STT 1 - Chuẩn gốc 1 Pass)
    {"H": 30, "mat": "SCM440", "fromMulti": False, "Ton": 32, "Toff": 5, "IP": 4, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 200, "offset": "0,098", "actOff": "0,098", "calcOff": "0,1003", "L": 30.0, "actT": "8p40'", "actA": "4,45A - 4,5A", "calcA": "4.7A", "actSpd": "165-175 mm²/p"},
    # H=40 (SCM440, STT 2 - Chuẩn gốc 1 Pass)
    {"H": 40, "mat": "SCM440", "fromMulti": False, "Ton": 36, "Toff": 5, "IP": 4, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 180, "offset": "0,098", "actOff": "0,098", "calcOff": "0,1003", "L": 30.0, "actT": "9p36'", "actA": "4,35A - 4,4A", "calcA": "4.6A", "actSpd": "130-140 mm²/p"},
    # H=63 (SCM420, STT 3 - Cắt chày 1 Pass)
    {"H": 63, "mat": "SCM420", "fromMulti": False, "Ton": 44, "Toff": 7, "IP": 5, "Wire": 1, "Volt": "High", "VF": 55, "Hz": 150, "offset": "0,095", "actOff": "0,095", "calcOff": "0,0997", "L": 27.0, "actT": "14p20'", "actA": "4,1A - 4,2A", "calcA": "4.2A", "actSpd": "75-85 mm²/p"},
    # H=63 (SCM420, STT 18 - Cắt chày 1 Pass)
    {"H": 63, "mat": "SCM420", "fromMulti": False, "Ton": 44, "Toff": 8, "IP": 4, "Wire": 1, "Volt": "High", "VF": 57, "Hz": 150, "offset": "0,098", "actOff": "0,098", "calcOff": "0,0987", "L": 22.3, "actT": "17p40'", "actA": "3,3A - 3,4A", "calcA": "2.9A", "actSpd": "50-65 mm²/p"},
    # H=68 (SCM440, STT 6 - Cắt chày Volt Low)
    {"H": 68, "mat": "SCM440", "fromMulti": False, "Ton": 70, "Toff": 7, "IP": 3, "Wire": 1, "Volt": "Low", "VF": 50, "Hz": 100, "offset": "0,097", "actOff": "0,097", "calcOff": "0,0981", "L": None, "actT": "--", "actA": "2,4A - 2,6A", "calcA": "2.0A", "actSpd": "--"},
    # H=75 (SCM420, STT 16 - Cắt cối 1 Pass)
    {"H": 75, "mat": "SCM420", "fromMulti": False, "Ton": 55, "Toff": 7, "IP": 4, "Wire": 1, "Volt": "High", "VF": 54, "Hz": 187, "offset": "0,112", "actOff": "0,112", "calcOff": "0,1094", "L": 50.3, "actT": "1h13'", "actA": "3,4A - 3,5A", "calcA": "3.3A", "actSpd": "50-65 mm²/p"},
    # H=85 (Quy đổi từ Pass 1 bài cắt 2P-10 có đo kiểm vách P1)
    {"H": 85, "mat": "SCM440", "fromMulti": True, "Ton": 70, "Toff": 8, "IP": 5, "Wire": 1, "Volt": "High", "VF": 61, "Hz": 150, "offset": "0,1025", "actOff": "0,1025", "calcOff": "0,1034", "L": 65.6, "actT": "48p", "actA": "3,6A - 3,7A", "calcA": "3.6A", "actSpd": "55-65 mm²/p"},
    # H=90 (SCM420, STT 21 - Cắt cối 1 Pass)
    {"H": 90, "mat": "SCM420", "fromMulti": False, "Ton": 80, "Toff": 7, "IP": 4, "Wire": 1, "Volt": "High", "VF": 54, "Hz": 150, "offset": "0,118", "actOff": "0,118", "calcOff": "0,1185", "L": None, "actT": "--", "actA": "3,5A - 3,6A", "calcA": "3.3A", "actSpd": "50-60 mm²/p"},
    # H=95 (SCM440, STT 17 - Cắt cối 1 Pass)
    {"H": 95, "mat": "SCM440", "fromMulti": False, "Ton": 82, "Toff": 7, "IP": 4, "Wire": 1, "Volt": "High", "VF": 55, "Hz": 150, "offset": "0,1135", "actOff": "0,1135", "calcOff": "0,1087", "L": 76.0, "actT": "1h15'", "actA": "3,6A - 3,7A", "calcA": "3.3A", "actSpd": "35-45 mm²/p"},
    # H=110 (SCM420, STT 19 - Cắt chày 1 Pass)
    {"H": 110, "mat": "SCM420", "fromMulti": False, "Ton": 100, "Toff": 10, "IP": 5, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 150, "offset": "0,105", "actOff": "0,105", "calcOff": "0,1068", "L": None, "actT": "--", "actA": "2,7A - 2,8A", "calcA": "2.8A", "actSpd": "30-40 mm²/p"},
    # H=140 (SCM420, STT 7 - Cắt chày 1 Pass)
    {"H": 140, "mat": "SCM420", "fromMulti": False, "Ton": 120, "Toff": 8, "IP": 5, "Wire": 1, "Volt": "High", "VF": 55, "Hz": 50, "offset": "0,095", "actOff": "0,095", "calcOff": "0,0987", "L": None, "actT": "--", "actA": "3,5A - 3,8A", "calcA": "3.6A", "actSpd": "--"},
    # H=140 (SCM420, STT 12 - Cắt chày 1 Pass)
    {"H": 140, "mat": "SCM420", "fromMulti": False, "Ton": 100, "Toff": 9, "IP": 6, "Wire": 1, "Volt": "High", "VF": 60, "Hz": 100, "offset": "0,102", "actOff": "0,102", "calcOff": "0,1052", "L": 28.4, "actT": "36p", "actA": "3,7A - 3,8A", "calcA": "3.8A", "actSpd": "30-40 mm²/p"},
    # H=160 (SCM420, STT 15 - Cắt cối 1 Pass)
    {"H": 160, "mat": "SCM420", "fromMulti": False, "Ton": 120, "Toff": 11, "IP": 6, "Wire": 1, "Volt": "High", "VF": 70, "Hz": 154, "offset": "0,120", "actOff": "0,120", "calcOff": "0,1143", "L": 32.3, "actT": "59p", "actA": "2,8A - 3A", "calcA": "2.9A", "actSpd": "18-28 mm²/p"},
    # H=165 (Quy đổi từ Pass 1 bài cắt 2P-12 có đo kiểm vách P1)
    {"H": 165, "mat": "SCM440", "fromMulti": True, "Ton": 135, "Toff": 11, "IP": 6, "Wire": 1, "Volt": "High", "VF": 70, "Hz": 60, "offset": "0,1125", "actOff": "0,1125", "calcOff": "0,1068", "L": 43.6, "actT": "1h17'", "actA": "2,8A - 3,0A", "calcA": "2.9A", "actSpd": "15-35 mm²/p"},
    # H=200 (SCM420, STT 23 - Cắt cối 1 Pass phôi siêu dày)
    {"H": 200, "mat": "SCM420", "fromMulti": False, "Ton": 120, "Toff": 10, "IP": 6, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 60, "offset": "0,108", "actOff": "0,108", "calcOff": "0,1102", "L": None, "actT": "--", "actA": "--", "calcA": "3.5A", "actSpd": "--"},
    # H=290 (SCM440, STT 20 - Cắt cối 1 Pass phôi siêu dày)
    {"H": 290, "mat": "SCM440", "fromMulti": False, "Ton": 135, "Toff": 10, "IP": 6, "Wire": 1, "Volt": "High", "VF": 75, "Hz": 50, "offset": "0,110", "actOff": "0,110", "calcOff": "0,1156", "L": None, "actT": "--", "actA": "--", "calcA": "3.4A", "actSpd": "--"},
    # H=300 (SCM440, STT 14 - Cắt cối 1 Pass mốc biên)
    {"H": 300, "mat": "SCM440", "fromMulti": False, "Ton": 120, "Toff": 9, "IP": 6, "Wire": 1, "Volt": "High", "VF": 65, "Hz": 50, "offset": "0,115", "actOff": "0,115", "calcOff": "0,1150", "L": 76.1, "actT": "3h", "actA": "3,7A - 3,9A", "calcA": "3.7A", "actSpd": "12-20 mm²/p"},
]

def format_time(minutes):
    if minutes is None:
        return "--"
    total_sec = round(minutes * 60)
    h = total_sec // 3600
    m = (total_sec % 3600) // 60
    s = total_sec % 60
    if h > 0:
        if s > 0:
            return f"{h}h{m:02d}p{s:02d}'" if m > 0 else f"{h}h{s:02d}'"
        else:
            return f"{h}h{m}p" if m > 0 else f"{h}h"
    else:
        return f"{m}p{s:02d}'" if s > 0 else f"{m}p"

def calc_v6_job(j):
    H = j['H']
    Ton = j['Ton']
    Po = j['Toff']
    IP = j['IP']
    Volt = j['Volt']
    VF = j['VF']
    Hz = j['Hz']
    isHard = (j['mat'] == 'SCM440')
    
    toff = Ton * (Po + 1)
    duty = Ton / (Ton + toff)
    Uarc = 27.0 if Volt == 'High' else 22.0
    power_watts = Uarc * (2.8 * IP) * duty
    
    c_scale = 0.80
    eta_base = c_scale * math.pow(max(1, Ton) / 50.0, 0.15) * math.pow(IP / 4.0, 0.16)
    
    if isHard:
        eta_h = max(0.55, 1.0 - max(0, H - 40) * 0.000687)
    else:
        eta_h = max(0.40, 1.0 - max(0, H - 40) * 0.001975)
        
    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 4.0
    drag_loss = 0.90 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.35, 1.0 - drag_loss)
    
    if VF >= 55.0:
        k_vf = 1.0 + (VF - 55.0) * 0.0020
    else:
        k_vf = 1.0 + (VF - 55.0) * 0.0050
        
    k_duty = math.pow(duty / (1.0 / 7.0), 0.0205)
    eta_eff = eta_base * eta_h * k_drag * k_vf * k_duty
    speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23
    
    feedRate_calc = speedArea_raw / H
    ft_max = Hz * 0.060
    feedRate_final = min(feedRate_calc, ft_max)
    
    fc_máy = round(feedRate_final * 40.0)
    t_min = (j['L'] / feedRate_final) if j['L'] else None
    t_calc_str = format_time(t_min)
    
    return fc_máy, t_calc_str

print("CALCULATED 19 JOBS:")
for j in jobs19:
    fcm, t_str = calc_v6_job(j)
    print(f"H={j['H']} ({j['mat']}): calcTime = {t_str}, calcSpeedH40 = {fcm} mm²/p")
