import math
import sys
sys.stdout.reconfigure(encoding='utf-8')

dataset = [
    {"name": "5P-01",  "H": 12,  "mat": "SCM440", "Ton": 20,  "Po": 5,  "IP": 3, "Volt": "High", "VF": 65, "Hz": 150, "target": 280, "low": 275, "high": 285, "read": "275 - 285"},
    {"name": "STT 1",  "H": 30,  "mat": "SCM440", "Ton": 32,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 200, "target": 170, "low": 165, "high": 175, "read": "165 - 175"},
    {"name": "STT 2",  "H": 40,  "mat": "SCM440", "Ton": 36,  "Po": 5,  "IP": 4, "Volt": "High", "VF": 65, "Hz": 180, "target": 135, "low": 130, "high": 140, "read": "130 - 140"},
    {"name": "STT 3",  "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 7,  "IP": 5, "Volt": "High", "VF": 55, "Hz": 150, "target": 80,  "low": 75,  "high": 85,  "read": "75 - 85"},
    {"name": "STT 18", "H": 63,  "mat": "SCM420", "Ton": 44,  "Po": 8,  "IP": 4, "Volt": "High", "VF": 57, "Hz": 150, "target": 55,  "low": 50,  "high": 65,  "read": "50 - 65"},
    {"name": "STT 16", "H": 75,  "mat": "SCM420", "Ton": 55,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 187, "target": 55,  "low": 50,  "high": 65,  "read": "50 - 65"},
    {"name": "2P-10",  "H": 85,  "mat": "SCM440", "Ton": 70,  "Po": 8,  "IP": 5, "Volt": "High", "VF": 61, "Hz": 150, "target": 60,  "low": 55,  "high": 65,  "read": "55 - 65"},
    {"name": "STT 21", "H": 90,  "mat": "SCM420", "Ton": 80,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 54, "Hz": 150, "target": 55,  "low": 50,  "high": 60,  "read": "50 - 60"},
    {"name": "STT 17", "H": 95,  "mat": "SCM440", "Ton": 82,  "Po": 7,  "IP": 4, "Volt": "High", "VF": 55, "Hz": 150, "target": 40,  "low": 35,  "high": 45,  "read": "35 - 45"},
    {"name": "STT 19", "H": 110, "mat": "SCM420", "Ton": 100, "Po": 10, "IP": 5, "Volt": "High", "VF": 65, "Hz": 150, "target": 35,  "low": 30,  "high": 40,  "read": "30 - 40"},
    {"name": "STT 12", "H": 140, "mat": "SCM420", "Ton": 100, "Po": 9,  "IP": 6, "Volt": "High", "VF": 60, "Hz": 100, "target": 35,  "low": 30,  "high": 40,  "read": "30 - 40"},
    {"name": "STT 15", "H": 160, "mat": "SCM420", "Ton": 120, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 154, "target": 23,  "low": 18,  "high": 28,  "read": "18 - 28"},
    {"name": "2P-12",  "H": 165, "mat": "SCM440", "Ton": 135, "Po": 11, "IP": 6, "Volt": "High", "VF": 70, "Hz": 60,  "target": 25,  "low": 15,  "high": 35,  "read": "15 - 35"},
    {"name": "STT 14", "H": 300, "mat": "SCM440", "Ton": 120, "Po": 9,  "IP": 6, "Volt": "High", "VF": 65, "Hz": 50,  "target": 16,  "low": 12,  "high": 20,  "read": "12 - 20"},
]

best_score = -1
best_mae = 999
best_comb = None

for a_ton in [0.22, 0.25, 0.28, 0.30]:
    for a_ip in [0.50, 0.55, 0.60]:
        for k_b in [124, 126, 128, 130, 132, 134]:
            for g_h in [0.06, 0.08, 0.10, 0.12]:
                for k_soft in [0.92, 0.95, 0.98, 1.00]:
                    for p_exp in [0.60, 0.65, 0.70]:
                        in_cnt = 0
                        t_err = 0
                        for j in dataset:
                            H = j['H']
                            Ton = j['Ton']
                            Po = j['Po']
                            IP = j['IP']
                            VF = j['VF']
                            isHard = (j['mat'] == 'SCM440')
                            
                            duty = 1.0 / (Po + 2.0)
                            ep_factor = math.pow(Ton / 40.0, a_ton) * math.pow(IP / 4.0, a_ip)
                            duty_factor = duty / (1.0 / 7.0)
                            
                            slag_loss = 1.0 - (0.0008 * max(0, H - 40)) if isHard else (1.0 - 0.0012 * max(0, H - 40))
                            slag_loss = max(0.65, slag_loss)
                            
                            vf_factor = 1.0 + (VF - 55.0) * 0.006
                            mat_factor = 1.0 if isHard else k_soft
                            
                            fc_thuc = k_b * ep_factor * math.pow(duty_factor, p_exp) * slag_loss * vf_factor * mat_factor
                            fc_thuc = fc_thuc * math.pow(40.0 / max(20.0, H), g_h)
                            
                            fc_may = fc_thuc * (40.0 / H)
                            fc_may = min(fc_may, 280.0)
                            
                            r_may = round(fc_may)
                            if j['low'] <= r_may <= j['high']:
                                in_cnt += 1
                            t_err += abs(fc_may - j['target'])
                            
                        mae = t_err / len(dataset)
                        if in_cnt > best_score or (in_cnt == best_score and mae < best_mae):
                            best_score = in_cnt
                            best_mae = mae
                            best_comb = (a_ton, a_ip, k_b, g_h, k_soft, p_exp)

print(f"BEST IN RANGE: {best_score}/14 | MAE: {best_mae:.2f} | PARAMS: {best_comb}")
