import sys
sys.stdout.reconfigure(encoding='utf-8')

# Mô phỏng chính xác hàm generateWorkshopRows trong app.js
def simulate_app_fc(H, mat='SCM440', strat_level=4):
    isHard = (mat == 'SCM440')
    
    # 1. Chế độ điện theo H trong generateWorkshopRows
    if H <= 25:
        Ton = 28; Po = 5; IP = 4; Volt = "High"; VF = 62 if isHard else 60; Hz = 180
    elif H <= 35:
        Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65 if isHard else 62; Hz = 200
    elif H <= 50:
        Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65 if isHard else 62; Hz = 180
    elif H <= 70:
        Ton = 45; Po = 6; IP = 5; Volt = "High"; VF = 60 if isHard else 58; Hz = 150
    elif H <= 90:
        Ton = 70; Po = 7; IP = 5; Volt = "High"; VF = 62 if isHard else 58; Hz = 150
    elif H <= 110:
        Ton = 85; Po = 8; IP = 5; Volt = "High"; VF = 64 if isHard else 60; Hz = 140
    elif H <= 135:
        Ton = 100; Po = 9; IP = 6; Volt = "High"; VF = 66 if isHard else 62; Hz = 120
    elif H <= 170:
        Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 70 if isHard else 65; Hz = 80
    elif H <= 220:
        Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70 if isHard else 65; Hz = 60
    else:
        Ton = 135; Po = 12; IP = 6; Volt = "High"; VF = 72 if isHard else 68; Hz = 50

    # Tính toán
    toff = Ton * (Po + 1)
    duty = Ton / (Ton + toff)
    Uarc = 27.0 if Volt == 'High' else 22.0
    power_watts = Uarc * (2.8 * IP) * duty

    import math
    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.28)
    if Ton > 80: eta_base = min(0.92, eta_base)

    if isHard:
        eta_h = max(0.70, 1.0 - max(0, H - 80) * 0.0005)
    else:
        eta_h = max(0.55, 1.0 - max(0, H - 50) * 0.0022)

    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.60
    drag_loss = 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.38, 1.0 - drag_loss)

    if VF >= 55.0:
        k_vf = 1.0 + (VF - 55.0) * 0.0050
    else:
        k_vf = 1.0 + (VF - 55.0) * 0.0100

    eta_eff = eta_base * eta_h * k_drag * k_vf
    speedArea_raw = 60.0 * 0.0135 * power_watts * eta_eff / 0.23

    feedRate_calc = speedArea_raw / H
    ft_max = Hz * 0.060
    feedRate_final = min(feedRate_calc, ft_max)

    fc_thuc = round(feedRate_final * H)
    fc_may_h40 = round(feedRate_final * 40.0)

    return {
        "H": H, "Ton": Ton, "Po": Po, "IP": IP, "VF": VF, "Hz": Hz,
        "Ft": feedRate_final, "Fc_thuc": fc_thuc, "Fc_may": fc_may_h40,
        "is_clamped": (feedRate_calc >= ft_max)
    }

print("=== BẢNG KHẢO SÁT MÔ HÌNH TRÊN WEB APP CHO THÉP SCM440 ===")
print(f"{'H (mm)':<8} | {'Ton/Po/IP/VF/Hz':<20} | {'Ft (mm/p)':<12} | {'Fc thực (mm²/p)':<18} | {'Fc máy H40 (mm²/p)':<20} | {'Chặn Hz?':<10}")
print("-" * 95)
for h in [10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200, 250, 300]:
    r = simulate_app_fc(h, 'SCM440')
    cfg = f"{r['Ton']}/{r['Po']}/{r['IP']}/{r['VF']}/{r['Hz']}Hz"
    print(f"{r['H']:<8} | {cfg:<20} | {r['Ft']:<12.3f} | {r['Fc_thuc']:<18} | {r['Fc_may']:<20} | {str(r['is_clamped']):<10}")

print("\n=== BẢNG KHẢO SÁT MÔ HÌNH TRÊN WEB APP CHO THÉP SCM420 ===")
print(f"{'H (mm)':<8} | {'Ton/Po/IP/VF/Hz':<20} | {'Ft (mm/p)':<12} | {'Fc thực (mm²/p)':<18} | {'Fc máy H40 (mm²/p)':<20} | {'Chặn Hz?':<10}")
print("-" * 95)
for h in [10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200, 250, 300]:
    r = simulate_app_fc(h, 'SCM420')
    cfg = f"{r['Ton']}/{r['Po']}/{r['IP']}/{r['VF']}/{r['Hz']}Hz"
    print(f"{r['H']:<8} | {cfg:<20} | {r['Ft']:<12.3f} | {r['Fc_thuc']:<18} | {r['Fc_may']:<20} | {str(r['is_clamped']):<10}")
