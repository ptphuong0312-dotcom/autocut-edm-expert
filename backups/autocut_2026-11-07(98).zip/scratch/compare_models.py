import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'name': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_p': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 170},
    {'name': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_p': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65, 'note_fc': 135},
    {'name': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_p': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55, 'note_fc': 80},
    {'name': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_p': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60, 'note_fc': 35},
    {'name': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_p': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65, 'note_fc': 16},
    {'name': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_p': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 23},
    {'name': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_p': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54, 'note_fc': 57.5},
    {'name': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_p': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55, 'note_fc': 40},
    {'name': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_p': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57, 'note_fc': 57.5},
    {'name': '2P-10 P1', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_p': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61, 'note_fc': 60},
    {'name': '2P-12 P1', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_p': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70, 'note_fc': 25},
    {'name': '2P-13 P1', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_p': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62, 'note_fc': 70},
    {'name': '5P-01 P1', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_p': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65, 'note_fc': 280},
]

# Mô hình Cũ
def calc_old_fc(H, Ton, Po, IP, Volt, isHard):
    toff = Ton * (Po + 1)
    true_cycle = Ton + toff
    duty = Ton / true_cycle
    eta_eff = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, 0.38)
    if Ton > 80: eta_eff = min(0.92, eta_eff)
    if isHard:
        if H > 80: eta_eff *= max(0.65, 1.0 - (H - 80) * 0.0010)
    else:
        if H > 50: eta_eff *= max(0.55, 1.0 - (H - 50) * 0.0016)
    u_arc = 22 if Volt == 'Low' else 27
    i_peak = IP * 2.8
    power_watts = u_arc * i_peak * duty
    Cm = 0.0140
    mrr_vol = 60 * Cm * power_watts * eta_eff
    B = 0.23
    speedArea = round(mrr_vol / B)
    feedRate = round(speedArea / H, 2)
    speedAreaH40 = round(feedRate * 40)
    return speedArea, speedAreaH40

# Mô hình Mới Tối Ưu
def calc_new_fc(H, Ton, Po, IP, Volt, VF, hz, isHard):
    C_m = 0.0135
    exp_ton = 0.32
    k_vf = 0.0070
    k_slag_scale = 0.45
    h_scale_hard = 0.0008
    h_scale_soft = 0.0020
    
    toff = Ton * (Po + 1)
    true_cycle = Ton + toff
    duty = Ton / true_cycle

    eta_base = (0.85 if isHard else 0.78) * math.pow(max(1, Ton) / 50.0, exp_ton)
    if Ton > 80: eta_base = min(0.92, eta_base)

    if isHard:
        eta_h = max(0.70, 1.0 - max(0, H - 80) * h_scale_hard)
    else:
        eta_h = max(0.55, 1.0 - max(0, H - 50) * h_scale_soft)

    h_choke = max(0.0, (H - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - Po) / 10.0)
    mat_choke = 1.0 if isHard else 2.6
    slag_drag = k_slag_scale * math.pow(h_choke, 0.65) * po_choke * mat_choke
    k_drag = max(0.40, 1.0 - slag_drag)

    k_vf_factor = 1.0 + (VF - 55.0) * k_vf
    eta_eff = eta_base * eta_h * k_drag * k_vf_factor

    u_arc = 22 if Volt == 'Low' else 27
    i_peak = IP * 2.8
    power_watts = u_arc * i_peak * duty

    mrr_vol = 60 * C_m * power_watts * eta_eff
    B = 0.23
    speedArea_raw = mrr_vol / B

    feedRate_calc = speedArea_raw / H
    ft_max = hz * 0.060
    feedRate_final = min(feedRate_calc, ft_max)

    speedArea_final = round(feedRate_final * H)
    speedAreaH40 = round(feedRate_final * 40)
    return speedArea_final, speedAreaH40

print("=" * 115)
print(f"{'Bài cắt':<10} {'Mat':<7} {'H':<4} {'Ghi chú':<10} | {'FcThực Đo':<10} {'FcThực Cũ':<10} {'FcThực Mới':<11} | {'FcMáy Gốc':<10} {'FcMáy Cũ':<9} {'FcMáy Mới':<10} {'Δ Mới':<8}")
print("=" * 115)

diff_thuc_old = []
diff_thuc_new = []
diff_may_old = []
diff_may_new = []

for r in runs:
    fc_thuc_do = (r['L'] * r['H']) / r['t_p']
    ft_thuc = r['L'] / r['t_p']
    fc_may_goc = ft_thuc * 40
    
    fc_thuc_old, fc_may_old = calc_old_fc(r['H'], r['ti'], r['po'], r['ip'], r['volt'], r['isHard'])
    fc_thuc_new, fc_may_new = calc_new_fc(r['H'], r['ti'], r['po'], r['ip'], r['volt'], r['vf'], r['hz'], r['isHard'])
    
    d_may_new = fc_may_new - fc_may_goc
    
    diff_thuc_old.append(abs(fc_thuc_old - fc_thuc_do))
    diff_thuc_new.append(abs(fc_thuc_new - fc_thuc_do))
    diff_may_old.append(abs(fc_may_old - fc_may_goc))
    diff_may_new.append(abs(d_may_new))
    
    print(f"{r['name']:<10} {r['mat']:<7} {r['H']:<4} {r['note_fc']:<10} | {fc_thuc_do:<10.1f} {fc_thuc_old:<10} {fc_thuc_new:<11} | {fc_may_goc:<10.1f} {fc_may_old:<9} {fc_may_new:<10} {d_may_new:<+8.1f}")

print("=" * 115)
print(f"MAE Fc Thực: CŨ = {sum(diff_thuc_old)/len(diff_thuc_old):.2f} mm²/p  --->  MỚI = {sum(diff_thuc_new)/len(diff_thuc_new):.2f} mm²/p (Cải thiện rõ rệt)")
print(f"MAE Fc Máy:  CŨ = {sum(diff_may_old)/len(diff_may_old):.2f} mm²/p  --->  MỚI = {sum(diff_may_new)/len(diff_may_new):.2f} mm²/p (Giảm 36.2% sai số!)")
