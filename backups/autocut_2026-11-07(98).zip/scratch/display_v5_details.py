import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

runs = [
    {'id': 'STT 1', 'mat': 'SCM440', 'isHard': True, 'H': 30, 'L': 30.0, 't_min': 8 + 40/60, 'hz': 200, 'ti': 32, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 2', 'mat': 'SCM440', 'isHard': True, 'H': 40, 'L': 30.0, 't_min': 9 + 36/60, 'hz': 180, 'ti': 36, 'po': 5, 'ip': 4, 'volt': 'High', 'vf': 65},
    {'id': 'STT 3', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 27.0, 't_min': 14 + 20/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-02', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 30.0, 't_min': 16 + 26/60, 'hz': 150, 'ti': 44, 'po': 7, 'ip': 5, 'volt': 'High', 'vf': 55},
    {'id': '2P-03', 'mat': 'SCM420', 'isHard': False, 'H': 30, 'L': 644.0, 't_min': 188.0, 'hz': 200, 'ti': 28, 'po': 6, 'ip': 4, 'volt': 'High', 'vf': 60},
    {'id': 'STT 12', 'mat': 'SCM420', 'isHard': False, 'H': 140, 'L': 28.4, 't_min': 36.0, 'hz': 100, 'ti': 100, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 60},
    {'id': 'STT 14', 'mat': 'SCM440', 'isHard': True, 'H': 300, 'L': 76.1, 't_min': 180.0, 'hz': 50, 'ti': 120, 'po': 9, 'ip': 6, 'volt': 'High', 'vf': 65},
    {'id': 'STT 15', 'mat': 'SCM420', 'isHard': False, 'H': 160, 'L': 32.3, 't_min': 59.0, 'hz': 154, 'ti': 120, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': 'STT 16', 'mat': 'SCM420', 'isHard': False, 'H': 75, 'L': 50.3, 't_min': 73.0, 'hz': 187, 'ti': 55, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 54},
    {'id': 'STT 17', 'mat': 'SCM440', 'isHard': True, 'H': 95, 'L': 76.0, 't_min': 75.0, 'hz': 150, 'ti': 82, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 55},
    {'id': 'STT 18', 'mat': 'SCM420', 'isHard': False, 'H': 63, 'L': 22.3, 't_min': 17 + 40/60, 'hz': 150, 'ti': 44, 'po': 8, 'ip': 4, 'volt': 'High', 'vf': 57},
    {'id': '2P-10', 'mat': 'SCM440', 'isHard': True, 'H': 85, 'L': 65.6, 't_min': 48.0, 'hz': 150, 'ti': 70, 'po': 8, 'ip': 5, 'volt': 'High', 'vf': 61},
    {'id': '2P-12', 'mat': 'SCM440', 'isHard': True, 'H': 165, 'L': 43.6, 't_min': 77.0, 'hz': 60, 'ti': 135, 'po': 11, 'ip': 6, 'volt': 'High', 'vf': 70},
    {'id': '2P-13', 'mat': 'SCM440', 'isHard': True, 'H': 60, 'L': 68.0, 't_min': 40 + 20/60, 'hz': 150, 'ti': 50, 'po': 7, 'ip': 4, 'volt': 'High', 'vf': 62},
    {'id': '5P-01', 'mat': 'SCM440', 'isHard': True, 'H': 12, 'L': 128.0, 't_min': 19 + 50/60, 'hz': 150, 'ti': 20, 'po': 5, 'ip': 3, 'volt': 'High', 'vf': 65},
]

def fmt_time(minutes):
    hrs = int(minutes // 60)
    mins = int(minutes % 60)
    secs = int(round((minutes * 60) % 60))
    if secs == 60:
        mins += 1
        secs = 0
    if hrs > 0:
        return f"{hrs}h{mins:02d}p" if secs == 0 else f"{hrs}h{mins:02d}p{secs:02d}s"
    else:
        return f"{mins}p{secs:02d}s" if secs > 0 else f"{mins}p"

# Mô hình V5 Refined
def m_v5(r):
    toff = r['ti'] * (r['po'] + 1)
    duty = r['ti'] / (r['ti'] + toff)
    eta_base = (0.85 if r['isHard'] else 0.78) * math.pow(max(1, r['ti']) / 50.0, 0.28)
    if r['ti'] > 80: eta_base = min(0.92, eta_base)
    eta_h = max(0.70, 1.0 - max(0, r['H'] - 80) * 0.0005) if r['isHard'] else max(0.55, 1.0 - max(0, r['H'] - 50) * 0.0022)
    h_choke = max(0.0, (r['H'] - 63.0) / 100.0)
    po_choke = max(0.0, (8.0 - r['po']) / 10.0)
    mat_choke = 1.0 if r['isHard'] else 2.6
    k_drag = max(0.38, 1.0 - 0.60 * math.pow(h_choke, 0.65) * po_choke * mat_choke)
    
    if r['vf'] >= 55.0:
        k_vf = 1.0 + (r['vf'] - 55.0) * 0.0050
    else:
        k_vf = 1.0 + (r['vf'] - 55.0) * 0.0100

    eta_eff = eta_base * eta_h * k_drag * k_vf
    p_w = (22 if r['volt'] == 'Low' else 27) * (r['ip'] * 2.8) * duty
    v_raw = (60 * 0.0135 * p_w * eta_eff) / 0.23
    ft = min(v_raw / r['H'], r['hz'] * 0.060)
    fc_thuc = round(ft * r['H'])
    fc_may = round(ft * 40)
    t_c = r['L'] / ft
    return fc_thuc, fc_may, t_c

print("=" * 125)
print(f"{'Bài cắt':<10} {'Mat':<7} {'H':<4} {'L(mm)':<6} | {'t thực':<10} {'t V5(Mới)':<11} {'Sai lệch t':<12} | {'FcThực Đo':<10} {'FcThực V5':<11} | {'FcMáy Đo':<10} {'FcMáy V5':<10} {'Δ Máy':<6}")
print("=" * 125)

for r in runs:
    fc_t5, fc_m5, t_5 = m_v5(r)
    fc_t_exact = (r['L'] * r['H']) / r['t_min']
    fc_m_exact = (r['L'] / r['t_min']) * 40
    d_t = t_5 - r['t_min']
    sign_t = "+" if d_t >= 0 else "-"
    d_t_str = f"{sign_t}{fmt_time(abs(d_t))}"
    d_m = fc_m5 - fc_m_exact
    print(f"{r['id']:<10} {r['mat']:<7} {r['H']:<4} {r['L']:<6.1f} | {fmt_time(r['t_min']):<10} {fmt_time(t_5):<11} {d_t_str:<12} | {fc_t_exact:<10.1f} {fc_t5:<11} | {fc_m_exact:<10.1f} {fc_m5:<10} {d_m:<+6.1f}")
print("=" * 125)
