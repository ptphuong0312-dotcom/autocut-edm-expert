import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('docs/PROJECT_HISTORY.md', 'r', encoding='utf-8') as f:
    text = f.read()

matches = re.findall(r'.{0,60}(?:Fc|Fc thực|Fc máy|speedArea|H40).{0,60}', text, re.IGNORECASE)
print(f"Total matches: {len(matches)}")
for m in matches[:20]:
    print(m.strip())
