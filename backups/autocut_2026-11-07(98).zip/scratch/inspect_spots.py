import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Spot 1
s1 = text.find('// HỆ PHƯƠNG TRÌNH TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC FC THỰC & FC MÁY (VÒNG 5 REFINED)')
e1 = text.find('row.hz = multiPassHzList[0];', s1)
print("=== SPOT 1 ===")
print(text[s1:e1])

# Spot 2
s2 = text.find('let eta_base = (isHard ? 0.85 : 0.78)', e1)
e2 = text.find('speedArea = Math.round(feedRate_final * state.thickness);', s2)
print("=== SPOT 2 ===")
print(text[s2-50:e2+100])
