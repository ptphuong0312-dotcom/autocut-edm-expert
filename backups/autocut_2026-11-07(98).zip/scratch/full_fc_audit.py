import sys
import math

sys.stdout.reconfigure(encoding='utf-8')

# Dữ liệu 14 bài cắt có thông số thời gian cắt / tốc độ thực tế từ WORKSHOP_DATA_BANK.md
data = [
    {
        'id': 'STT 1', 'pass': '1 Pass', 'mat': 'SCM440', 'isHard': True,
        'H': 30, 'L': 30.0, 't_p': 8 + 40/60, 'hz': 200,
        'Ton': 32, 'Po': 5, 'IP': 4, 'Volt': 'High', 'VF': 65,
        'note_fc_range': '165 - 175', 'note_fc_mid': 170.0
    },
    {
        'id': 'STT 2', 'pass': '1 Pass', 'mat': 'SCM440', 'isHard': True,
        'H': 40, 'L': 30.0, 't_p': 9 + 36/60, 'hz': 180,
        'Ton': 36, 'Po': 5, 'IP': 4, 'Volt': 'High', 'VF': 65,
        'note_fc_range': '130 - 140', 'note_fc_mid': 135.0
    },
    {
        'id': 'STT 3', 'pass': '1 Pass', 'mat': 'SCM420', 'isHard': False,
        'H': 63, 'L': 27.0, 't_p': 14 + 20/60, 'hz': 150,
        'Ton': 44, 'Po': 7, 'IP': 5, 'Volt': 'High', 'VF': 55,
        'note_fc_range': '75 - 85', 'note_fc_mid': 80.0
    },
    {
        'id': 'STT 12', 'pass': '1 Pass', 'mat': 'SCM420', 'isHard': False,
        'H': 140, 'L': 28.4, 't_p': 36.0, 'hz': 100,
        'Ton': 100, 'Po': 9, 'IP': 6, 'Volt': 'High', 'VF': 60,
        'note_fc_range': '30 - 40', 'note_fc_mid': 35.0
    },
    {
        'id': 'STT 14', 'pass': '1 Pass', 'mat': 'SCM440', 'isHard': True,
        'H': 300, 'L': 76.1, 't_p': 180.0, 'hz': 50,
        'Ton': 120, 'Po': 9, 'IP': 6, 'Volt': 'High', 'VF': 65,
        'note_fc_range': '12 - 20', 'note_fc_mid': 16.0
    },
    {
        'id': 'STT 15', 'pass': '1 Pass', 'mat': 'SCM420', 'isHard': False,
        'H': 160, 'L': 32.3, 't_p': 59.0, 'hz': 154,
        'Ton': 120, 'Po': 11, 'IP': 6, 'Volt': 'High', 'VF': 70,
        'note_fc_range': '18 - 28', 'note_fc_mid': 23.0
    },
    {
        'id': 'STT 16', 'pass': '1 Pass', 'mat': 'SCM420', 'isHard': False,
        'H': 75, 'L': 50.3, 't_p': 73.0, 'hz': 187,
        'Ton': 55, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 54,
        'note_fc_range': '50 - 65', 'note_fc_mid': 57.5
    },
    {
        'id': 'STT 17', 'pass': '1 Pass', 'mat': 'SCM440', 'isHard': True,
        'H': 95, 'L': 76.0, 't_p': 75.0, 'hz': 150,
        'Ton': 82, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 55,
        'note_fc_range': '35 - 45', 'note_fc_mid': 40.0
    },
    {
        'id': 'STT 18', 'pass': '1 Pass', 'mat': 'SCM420', 'isHard': False,
        'H': 63, 'L': 22.3, 't_p': 17 + 40/60, 'hz': 150,
        'Ton': 44, 'Po': 8, 'IP': 4, 'Volt': 'High', 'VF': 57,
        'note_fc_range': '50 - 65', 'note_fc_mid': 57.5
    },
    {
        'id': '2P-10 P1', 'pass': 'P1', 'mat': 'SCM440', 'isHard': True,
        'H': 85, 'L': 65.6, 't_p': 48.0, 'hz': 150,
        'Ton': 70, 'Po': 8, 'IP': 5, 'Volt': 'High', 'VF': 61,
        'note_fc_range': '55 - 65', 'note_fc_mid': 60.0
    },
    {
        'id': '2P-12 P1', 'pass': 'P1', 'mat': 'SCM440', 'isHard': True,
        'H': 165, 'L': 43.6, 't_p': 77.0, 'hz': 60,
        'Ton': 135, 'Po': 11, 'IP': 6, 'Volt': 'High', 'VF': 70,
        'note_fc_range': '15 - 35', 'note_fc_mid': 25.0
    },
    {
        'id': '2P-13 P1', 'pass': 'P1', 'mat': 'SCM440', 'isHard': True,
        'H': 60, 'L': 68.0, 't_p': 40 + 20/60, 'hz': 150,
        'Ton': 50, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 62,
        'note_fc_range': '65 - 75', 'note_fc_mid': 70.0
    },
    {
        'id': '5P-01 P1', 'pass': 'P1', 'mat': 'SCM440', 'isHard': True,
        'H': 12, 'L': 128.0, 't_p': 19 + 50/60, 'hz': 150,
        'Ton': 20, 'Po': 5, 'IP': 3, 'Volt': 'High', 'VF': 65,
        'note_fc_range': '275 - 285', 'note_fc_mid': 280.0
    },
    # Pass 2 của multi-pass có ghi nhận thời gian
    {
        'id': '2P-12 P2', 'pass': 'P2', 'mat': 'SCM440', 'isHard': True,
        'H': 165, 'L': 43.6, 't_p': 9.0, 'hz': 80,
        'Ton': 40, 'Po': 7, 'IP': 3, 'Volt': 'High', 'VF': 36,
        'note_fc_range': '190', 'note_fc_mid': 190.0
    },
    {
        'id': '2P-13 P2', 'pass': 'P2', 'mat': 'SCM440', 'isHard': True,
        'H': 60, 'L': 68.0, 't_p': 12.0, 'hz': 100,
        'Ton': 16, 'Po': 6, 'IP': 2, 'Volt': 'High', 'VF': 40,
        'note_fc_range': '240', 'note_fc_mid': 240.0
    },
    {
        'id': '2P-14 P2', 'pass': 'P2', 'mat': 'SCM420', 'isHard': False,
        'H': 75, 'L': 50.3, 't_p': 8 + 40/60, 'hz': 100,
        'Ton': 18, 'Po': 7, 'IP': 3, 'Volt': 'High', 'VF': 32,
        'note_fc_range': '240', 'note_fc_mid': 240.0
    },
    {
        'id': '5P-01 P2', 'pass': 'P2', 'mat': 'SCM440', 'isHard': True,
        'H': 12, 'L': 128.0, 't_p': 16.0, 'hz': 140,
        'Ton': 14, 'Po': 5, 'IP': 2, 'Volt': 'Low', 'VF': 42,
        'note_fc_range': '232 - 340', 'note_fc_mid': 286.0
    }
]

print("=== BẢNG TỔNG HỢP TOÀN BỘ SỐ LIỆU ĐO CẮT THỰC NGHIỆM TẠI XƯỞNG ===")
for d in data:
    ft_thuc = d['L'] / d['t_p']
    fc_thuc = (d['L'] * d['H']) / d['t_p']
    fc_may_h40 = ft_thuc * 40
    print(f"{d['id']:<10} {d['pass']:<6} H={d['H']:<3} L={d['L']:<5.1f} t={d['t_p']:<5.1f}p | Ft_thực={ft_thuc:<5.2f} mm/p | Fc_thực={fc_thuc:<6.1f} mm²/p | Fc_máy(H40)={fc_may_h40:<5.1f} | Ghi chú xưởng={d['note_fc_range']:<12}")
