/**
 * AUTOCUT EDM SERVO - PARAMETER CALCULATION & ANALYSIS ENGINE
 * Hệ thống tính toán, phân tích và tra cứu chế độ cắt EDM AutoCut Servo
 * © 2026 AutoCut EDM Master
 */

function initApp() {
    // 11 CẤP ĐỘ CHIẾN LƯỢC GIA CÔNG (TÂM ĐIỂM = CẤP 6: TIÊU CHUẨN)
        const WS_STRATEGY_CONFIGS = {
        1: {
            name: 'Cực hạn siêu mịn (Bóng gương)',
            badge: 'Gương (Cấp 1)',
            desc: 'Vi xung nano, hạ IP tối thiểu (1 sò), Poff dài, Volt Low, triệt tiêu hố rỗ tia lửa. Ampe giảm ~1.8A so với chuẩn, Ra ≤ 1.0 - 1.2µm.',
            Wire: '2', RaStr: '≤ 1.2'
        },
        2: {
            name: 'Siêu mịn (Gương mờ)',
            badge: 'Siêu Mịn (Cấp 2)',
            desc: 'Dập xung cực ngắn, hạ IP 1-2 sò, chuyển Volt Low, tăng Poff xối rửa sạch xỉ. Ampe giảm ~1.2A so với chuẩn, Ra ≤ 1.4 - 1.8µm.',
            Wire: '2', RaStr: '1.4 - 1.8'
        },
        3: {
            name: 'Bề mặt mịn (Satin mờ)',
            badge: 'Mịn (Cấp 3)',
            desc: 'Kéo dài thời gian nghỉ Poff, giảm nhẹ Pon, triệt tiêu đánh lửa thứ cấp gây sọc gân. Ampe giảm ~0.6A (2.0 - 2.2A tại H30), Ra ≤ 1.8 - 2.2µm.',
            Wire: '2', RaStr: '1.8 - 2.2'
        },
        4: {
            name: 'Tiêu chuẩn (Khuyên Dùng)',
            badge: 'Cân Bằng (Cấp 4)',
            desc: 'Chuẩn xưởng trung tâm, tuân thủ nghiêm ngặt 4 dải Ampe Rule 12 (2.7A tại H30), tối ưu giữa tốc độ, độ phẳng và độ bền dây.',
            Wire: '1', RaStr: '2.5 - 3.2'
        },
        5: {
            name: 'Năng suất (Cắt nhanh)',
            badge: 'Nhanh (Cấp 5)',
            desc: 'Rút ngắn Poff 1 nấc tăng tần số xung, tăng nhẹ Pon và VF, giữ IP an toàn. Ampe tăng ~0.6A (3.2 - 3.4A tại H30), tốc độ tăng 20-30%.',
            Wire: '1', RaStr: '3.2 - 3.8'
        },
        6: {
            name: 'Năng suất cao (Rất nhanh)',
            badge: 'Rất Nhanh (Cấp 6)',
            desc: 'Rút ngắn Poff 2 nấc, nâng cao VF bám sát phôi, tăng thêm Pon bóc tách phoi mạnh mẽ. Ampe tăng ~1.2A (3.8 - 4.0A tại H30).',
            Wire: '1', RaStr: '3.8 - 4.5'
        },
        7: {
            name: 'Siêu năng suất (Phá thô)',
            badge: 'Siêu Tốc (Cấp 7)',
            desc: 'Ép tốc độ cực đại: Rút ngắn Poff tối đa, ép servo VF bám sát, tăng Pon cực đại. Ampe tăng ~1.8A (4.3 - 4.6A tại H30). Yêu cầu nước xối mạnh.',
            Wire: '1', RaStr: '4.5 - 5.5'
        }
    };

    const STRATEGY_CONFIGS = {
        1: { name: 'Cực Hạn Tinh Xảo (Mịn +3)', shortName: 'Cực Hạn Tinh Xảo (Cấp 1)', badge: 'Gương Quang Học', desc: 'Vi xung nano, khống chế biến trắng tuyệt đối, độ bóng gương quang học đỉnh cao.', tiMult: 0.30, ipDelta: -2, vfDelta: -20, poDelta: +1, speedMult: 0.30 },
        2: { name: 'Siêu Mịn Cấp 2 (Mịn +2)', shortName: 'Siêu Mịn (Cấp 2)', badge: 'Gương Tế Vi', desc: 'Xung cực nhỏ, triệt tiêu hoàn toàn vi nứt bề mặt khuôn mẫu.', tiMult: 0.38, ipDelta: -2, vfDelta: -18, poDelta: +1, speedMult: 0.38 },
        3: { name: 'Siêu Mịn Cấp 1 (Mịn +1)', shortName: 'Siêu Mịn (Cấp 3)', badge: 'Siêu Phẳng', desc: 'Bóc tách êm mượt, tối ưu độ đồng đều bề mặt và mép sắc nét.', tiMult: 0.45, ipDelta: -2, vfDelta: -15, poDelta: 0, speedMult: 0.45 },
        4: { name: 'Bề Mặt Siêu Mịn', shortName: 'Mịn Cao (Cấp 4)', badge: 'Mịn Cao', desc: 'Vi xung cực mịn, khống chế dung sai phôi nghiêm ngặt.', tiMult: 0.55, ipDelta: -1, vfDelta: -12, poDelta: 0, speedMult: 0.55 },
        5: { name: 'Bề Mặt Mịn / Ưu Tiên Phẳng', shortName: 'Mịn Phẳng (Cấp 5)', badge: 'Mịn Vừa', desc: 'Hạn chế sọc sóng, mép sắc nét, bám bước êm ái.', tiMult: 0.70, ipDelta: -1, vfDelta: -8, poDelta: 0, speedMult: 0.70 },
        6: { name: '⭐ Tiêu Chuẩn (Khuyên Dùng)', shortName: 'Tiêu Chuẩn (Cấp 6)', badge: 'Chuẩn Hãng', desc: 'Cân bằng tối ưu giữa tốc độ, độ nhám và độ bền dây Molypden.', tiMult: 1.0, ipDelta: 0, vfDelta: 0, poDelta: 0, speedMult: 1.0 },
        7: { name: 'Năng Suất Cao', shortName: 'Năng Suất (Cấp 7)', badge: 'Tốc Độ +1', desc: 'Tốc độ nhanh, ổn định cao, tiết kiệm dây và điện.', tiMult: 1.10, ipDelta: 0, vfDelta: +3, poDelta: 0, speedMult: 1.12 },
        8: { name: 'Siêu Năng Suất', shortName: 'Siêu Tốc (Cấp 8)', badge: 'Tốc Độ +2', desc: 'Bóc tách tối đa, bám tải nhanh, rút ngắn thời gian cắt.', tiMult: 1.25, ipDelta: +1, vfDelta: +5, poDelta: -1, speedMult: 1.25 },
        9: { name: 'Cường Lực Bóc Tách (Tốc độ +3)', shortName: 'Cường Lực (Cấp 9)', badge: 'Tốc Độ +3', desc: 'Tăng cường năng lượng xung ti, đẩy mạnh tiến bàn máy.', tiMult: 1.35, ipDelta: +1, vfDelta: +8, poDelta: -1, speedMult: 1.38 },
        10: { name: 'Tối Đa Công Suất (Tốc độ +4)', shortName: 'Max Công Suất (Cấp 10)', badge: 'Tốc Độ +4', desc: 'Mở tối đa kênh dòng MOSFET, bám tải Servo cực mạnh.', tiMult: 1.45, ipDelta: +1, vfDelta: +10, poDelta: -1, speedMult: 1.50 },
        11: { name: 'Cực Hạn Phá Thô (Tốc độ +5)', shortName: 'Cực Hạn Phá (Cấp 11)', badge: 'Cực Hạn Phá', desc: 'Khai thác kịch trần công suất tủ nguồn, phá thô siêu tốc kỷ lục cho phôi dày.', tiMult: 1.55, ipDelta: +1, vfDelta: +12, poDelta: -1, speedMult: 1.62 }
    };

    // STATE (Mặc định SCM420, 1 Pass, Chiến lược Cấp 6, H=40mm)
    const state = {
        material: 'SCM420',
        wsMaterial: 'SCM420',
        passCount: 1,
        wsPassCount: 1,
        strategyLevel: 6,
        wsStrategyLevel: 4,
        thickness: 40,
        cutLength: 100,
        compactMetrics: true, // Mặc định thu gọn ký hiệu (Ẩn tên dài theo phương ngang)
        workshopExpanded: false, // Mặc định ẩn bảng thực tế xưởng
        isCustomUserEdited: false, // Đánh dấu nếu người dùng đã tự chỉnh thông số nhập riêng
        compareMode: 'custom',
        wsCustomOverrides: {}
    };

    // DOM ELEMENTS
    const navTabs = document.querySelectorAll('.nav-tab');
    const tabContents = document.querySelectorAll('.tab-content');

    const materialCards = document.querySelectorAll('.radio-card');
    const passButtons = document.querySelectorAll('.pass-btn');
    const strategySlider = document.getElementById('strategy-slider');
    const strategyLevelBadge = document.getElementById('strategy-level-badge');
    const strategyNameDisplay = document.getElementById('strategy-name-display');
    const strategyBadgeDisplay = document.getElementById('strategy-badge-display');
    const strategyDescDisplay = document.getElementById('strategy-desc-display');

    const thicknessInput = document.getElementById('thickness-input');
    const thicknessSlider = document.getElementById('thickness-slider');
    const quickChips = document.querySelectorAll('.chip');
    const cutLengthInput = document.getElementById('cut-length');
    const totalTimeText = document.getElementById('total-time-text');
    const configSummary = document.getElementById('config-summary');
    const tableBody = document.getElementById('table-body');
    const noticeList = document.getElementById('notice-list');
    const btnCopyTable = document.getElementById('btn-copy-table');
    const btnPrint = document.getElementById('btn-print');
    const btnShowGuide = document.getElementById('btn-show-guide');
    const btnCloseModal = document.getElementById('btn-close-modal');
    const guideModal = document.getElementById('guide-modal');

    // DOM Elements - Tab 2 (Workshop)
    const wsMaterialCards = document.querySelectorAll('#ws-material-grid .radio-card');
    const wsPassButtons = document.querySelectorAll('#ws-pass-selector .pass-btn');
    const wsStrategySlider = document.getElementById('ws-strategy-slider');
    const wsStrategyLevelBadge = document.getElementById('ws-strategy-level-badge');
    const wsStrategyNameDisplay = document.getElementById('ws-strategy-name-display');
    const wsStrategyBadgeDisplay = document.getElementById('ws-strategy-badge-display');
    const wsStrategyDescDisplay = document.getElementById('ws-strategy-desc-display');
    const wsThicknessInput = document.getElementById('ws-thickness-input');
    const wsThicknessSlider = document.getElementById('ws-thickness-slider');
    const wsQuickChips = document.querySelectorAll('#ws-quick-chips .chip');
    const wsCutLengthInput = document.getElementById('ws-cut-length');
    const wsTotalTimeText = document.getElementById('ws-total-time-text');
    const wsConfigSummary = document.getElementById('ws-config-summary');
    const wsTableBody = document.getElementById("ws-table-body");
    const wsTableBodyVung1 = document.getElementById("ws-table-body-vung1");
    const wsTableBodyVung2 = document.getElementById("ws-table-body-vung2");
    const wsBtnResetParams = document.getElementById("ws-btn-reset-params");
    const wsBtnCopyTable = document.getElementById('ws-btn-copy-table');


    // Custom analysis & Mode switch elements
    const btnModeCustom = document.getElementById('btn-mode-custom');
    const btnModeTheory = document.getElementById('btn-mode-theory');
    const customModeHint = document.getElementById('custom-mode-hint');
    const analysisTableTitle = document.getElementById('analysis-table-title');
    const btnAnalyzeCustom = document.getElementById('btn-analyze-custom');
    const customTiInput = document.getElementById('custom-ti');
    const customPoInput = document.getElementById('custom-po');
    const customIpInput = document.getElementById('custom-ip');
    const customVoltInput = document.getElementById('custom-volt');
    const customVfInput = document.getElementById('custom-vf');
    const customWireInput = document.getElementById('custom-wire');
    const wsBtnAnalyzeCustom = document.getElementById('ws-btn-analyze-custom');
    const wsCustomTiInput = document.getElementById('ws-custom-ti');
    const wsCustomPoInput = document.getElementById('ws-custom-po');
    const wsCustomIpInput = document.getElementById('ws-custom-ip');
    const wsCustomVoltInput = document.getElementById('ws-custom-volt');
    const wsCustomVfInput = document.getElementById('ws-custom-vf');
    const wsCustomWireInput = document.getElementById('ws-custom-wire');
    const analysisContainer = document.getElementById('analysis-container');
    const comparisonTableElement = document.getElementById('comparison-table-element');
    const analysisFeedbackBox = document.getElementById('analysis-feedback-box');
    const wsAnalysisFeedbackBox = document.getElementById("ws-analysis-feedback-box");
    const btnToggleCompact = document.getElementById('btn-toggle-compact');
    const compactText = document.getElementById('compact-text');
    const btnToggleWorkshop = document.getElementById('btn-toggle-workshop');
    const workshopBody = document.getElementById('workshop-body');
    const workshopToggleStatus = document.getElementById('workshop-toggle-status');
    const workshopTableElement = document.getElementById('ws-comparison-table-element');
    const lectureKnowledgeBody = document.getElementById('lecture-knowledge-body');

    // ==========================================
    // 1. TAB SWITCHING
    // ==========================================
    navTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            navTabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            tab.classList.add('active');
            const target = tab.dataset.tab;
            document.getElementById(target).classList.add('active');
            if (target === 'tab-vf-research' && typeof updateTab1SyncPreview === 'function') {
                updateTab1SyncPreview();
            }
        });
    });

    // ==========================================
    // 2. LÝ THUYẾT ĐỒNG BỘ 2 CHIỀU (SYNC STATE TO UI)
    // ==========================================
    function syncAllInputsUI() {
        // Material (Tab 1 vs Tab 2 độc lập tuyệt đối)
        materialCards.forEach(c => {
            const radio = c.querySelector('input[type="radio"]');
            if (radio.value === state.material) {
                c.classList.add('active');
                radio.checked = true;
            } else {
                c.classList.remove('active');
                radio.checked = false;
            }
        });
        if (wsMaterialCards) {
            wsMaterialCards.forEach(c => {
                const radio = c.querySelector('input[type="radio"]');
                if (radio.value === (state.wsMaterial || 'SCM420')) {
                    c.classList.add('active');
                    radio.checked = true;
                } else {
                    c.classList.remove('active');
                    radio.checked = false;
                }
            });
        }

        // Pass (Tab 1 vs Tab 2 độc lập tuyệt đối)
        passButtons.forEach(b => {
            if (parseInt(b.dataset.pass, 10) === state.passCount) {
                b.classList.add('active');
            } else {
                b.classList.remove('active');
            }
        });
        if (wsPassButtons) {
            wsPassButtons.forEach(b => {
                if (parseInt(b.dataset.pass, 10) === (state.wsPassCount || 1)) {
                    b.classList.add('active');
                } else {
                    b.classList.remove('active');
                }
            });
        }

        // Strategy
        if (strategySlider) strategySlider.value = state.strategyLevel;
        if (wsStrategySlider) wsStrategySlider.value = state.wsStrategyLevel;
        updateStrategyDisplay(state.strategyLevel);
        updateWsStrategyDisplay(state.wsStrategyLevel);

        // Thickness
        if (thicknessInput) thicknessInput.value = state.thickness;
        if (thicknessSlider) thicknessSlider.value = state.thickness;
        if (wsThicknessInput) wsThicknessInput.value = state.thickness;
        if (wsThicknessSlider) wsThicknessSlider.value = state.thickness;
        updateQuickChips(state.thickness);

        // Cut length (Chỉ cập nhật ô không có tiêu điểm để tránh xóa dấu chấm lẻ khi đang gõ)
        if (cutLengthInput && document.activeElement !== cutLengthInput) cutLengthInput.value = state.cutLength;
        if (wsCutLengthInput && document.activeElement !== wsCutLengthInput) wsCutLengthInput.value = state.cutLength;
    }

    // ==========================================
    // 2. FORM EVENT LISTENERS
    // ==========================================

    function bindMaterialEvents(cards, isWs = false) {
        cards.forEach(card => {
            card.addEventListener('click', () => {
                const radio = card.querySelector('input[type="radio"]');
                if (isWs) {
                    state.wsMaterial = radio.value;
                } else {
                    state.material = radio.value;
                }
                syncAllInputsUI();
                render();
            });
        });
    }
    bindMaterialEvents(materialCards, false);
    if (wsMaterialCards) bindMaterialEvents(wsMaterialCards, true);

    function bindPassEvents(btns, isWs = false) {
        btns.forEach(btn => {
            btn.addEventListener('click', () => {
                if (isWs) {
                    state.wsPassCount = parseInt(btn.dataset.pass, 10);
                } else {
                    state.passCount = parseInt(btn.dataset.pass, 10);
                }
                syncAllInputsUI();
                render();
            });
        });
    }
    bindPassEvents(passButtons, false);
    if (wsPassButtons) bindPassEvents(wsPassButtons, true);

    function bindStrategyEvents(slider) {
        if (!slider) return;
        slider.addEventListener('input', (e) => {
            state.strategyLevel = parseInt(e.target.value, 10);
            syncAllInputsUI();
            render();
        });
    }
    bindStrategyEvents(strategySlider);
    
    if (wsStrategySlider) {
        wsStrategySlider.addEventListener('input', (e) => {
            state.wsStrategyLevel = parseInt(e.target.value);
            updateWsStrategyDisplay(state.wsStrategyLevel);
            render();
        });
    }


    
    function updateWsStrategyDisplay(lvl) {
        const conf = WS_STRATEGY_CONFIGS[lvl] || WS_STRATEGY_CONFIGS[4];
        if (wsStrategyLevelBadge) wsStrategyLevelBadge.textContent = `${conf.name} (${lvl})`;
        if (wsStrategyNameDisplay) wsStrategyNameDisplay.textContent = conf.name;
        if (wsStrategyBadgeDisplay) wsStrategyBadgeDisplay.textContent = conf.badge;
        if (wsStrategyDescDisplay) wsStrategyDescDisplay.textContent = conf.desc;
    }

    function updateStrategyDisplay(lvl) {
        const conf = STRATEGY_CONFIGS[lvl] || STRATEGY_CONFIGS[6];
        if (strategyLevelBadge) strategyLevelBadge.textContent = `${conf.name} (Cấp ${lvl}/11)`;
        if (strategyNameDisplay) strategyNameDisplay.textContent = conf.name;
        if (strategyBadgeDisplay) strategyBadgeDisplay.textContent = conf.badge;
        if (strategyDescDisplay) strategyDescDisplay.textContent = conf.desc;
        
        }

    function bindThicknessSliderEvents(slider) {
        if (!slider) return;
        slider.addEventListener('input', (e) => {
            let val = parseInt(e.target.value, 10);
            val = Math.round(val / 5) * 5;
            state.thickness = Math.max(5, Math.min(500, val));
            syncAllInputsUI();
            render();
        });
    }
    bindThicknessSliderEvents(thicknessSlider);
    if (wsThicknessSlider) bindThicknessSliderEvents(wsThicknessSlider);

    function bindThicknessInputEvents(inp) {
        if (!inp) return;
        inp.addEventListener('change', (e) => {
            let val = parseInt(e.target.value, 10);
            if (isNaN(val)) val = 40;
            val = Math.round(val / 5) * 5;
            state.thickness = Math.max(5, Math.min(500, val));
            syncAllInputsUI();
            render();
        });
    }
    bindThicknessInputEvents(thicknessInput);
    if (wsThicknessInput) bindThicknessInputEvents(wsThicknessInput);

    function updateQuickChips(currentH) {
        const doUpdate = (chips) => {
            chips.forEach(chip => {
                if (parseInt(chip.dataset.h, 10) === currentH) {
                    chip.classList.add('active');
                } else {
                    chip.classList.remove('active');
                }
            });
        };
        if (quickChips) doUpdate(quickChips);
        if (wsQuickChips) doUpdate(wsQuickChips);
    }

    function bindQuickChipsEvents(chips) {
        if (!chips) return;
        chips.forEach(chip => {
            chip.addEventListener('click', () => {
                state.thickness = parseInt(chip.dataset.h, 10);
                syncAllInputsUI();
                render();
            });
        });
    }
    bindQuickChipsEvents(quickChips);
    if (wsQuickChips) bindQuickChipsEvents(wsQuickChips);

    function bindCutLengthEvents(inp) {
        if (!inp) return;
        inp.addEventListener('input', (e) => {
            const raw = e.target.value.trim().replace(',', '.');
            // Cho phép người dùng gõ thoải mái dấu chấm lẻ hoặc xóa để nhập số mới
            if (raw === '' || raw.endsWith('.') || raw === '0') {
                return;
            }
            const val = parseFloat(raw);
            if (!isNaN(val) && val > 0) {
                state.cutLength = val;
                // Đồng bộ sang ô cut-length còn lại nếu có
                if (inp === cutLengthInput && wsCutLengthInput && document.activeElement !== wsCutLengthInput) {
                    wsCutLengthInput.value = raw;
                } else if (inp === wsCutLengthInput && cutLengthInput && document.activeElement !== cutLengthInput) {
                    cutLengthInput.value = raw;
                }
                render();
            }
        });

        inp.addEventListener('blur', (e) => {
            const raw = e.target.value.trim().replace(',', '.');
            let val = parseFloat(raw);
            if (isNaN(val) || val <= 0) {
                val = 100;
            }
            state.cutLength = val;
            inp.value = val;
            syncAllInputsUI();
            render();
        });
    }
    bindCutLengthEvents(cutLengthInput);
    if (wsCutLengthInput) bindCutLengthEvents(wsCutLengthInput);

    // Modal Guide
    if (btnShowGuide) btnShowGuide.addEventListener('click', () => {
        guideModal.classList.add('active');
    });

    if (btnCloseModal) btnCloseModal.addEventListener('click', () => {
        guideModal.classList.remove('active');
    });

    if (guideModal) guideModal.addEventListener('click', (e) => {
        if (e.target === guideModal) {
            guideModal.classList.remove('active');
        }
    });

    // Print
    if (btnPrint) btnPrint.addEventListener('click', () => {
        window.print();
    });

    // Copy Table (Tab 1 & Tab 2)
    if (btnCopyTable) btnCopyTable.addEventListener('click', () => {
        copyTableToClipboard();
    });
    if (wsBtnResetParams) {
        wsBtnResetParams.addEventListener('click', () => {
            state.wsCustomOverrides = {};
            render();
            if (typeof updateTab1SyncPreview === 'function') {
                updateTab1SyncPreview();
            }
            showToast('🔄 Đã khôi phục thông số mặc định của App!');
        });
    }

    if (wsBtnCopyTable) wsBtnCopyTable.addEventListener('click', () => {
        copyWorkshopTableToClipboard();
    });

    // Mode Switch Buttons: "Nhập Chế độ Riêng" & "TT Lý thuyết"
    if (btnModeCustom) {
        btnModeCustom.addEventListener('click', () => {
            state.compareMode = 'custom';
            runCustomAnalysis(false);
        });
    }

    if (btnModeTheory) {
        btnModeTheory.addEventListener('click', () => {
            state.compareMode = 'theory';
            runCustomAnalysis(false);
        });
    }

    if (btnAnalyzeCustom) btnAnalyzeCustom.addEventListener('click', () => {
        state.isCustomUserEdited = true;
        state.compareMode = 'custom';
        runCustomAnalysis(true);
    });

    function syncCustomInputs(sourceTab) {
        if (sourceTab === 'tab1') {
            if (wsCustomTiInput) wsCustomTiInput.value = customTiInput.value;
            if (wsCustomPoInput) wsCustomPoInput.value = customPoInput.value;
            if (wsCustomIpInput) wsCustomIpInput.value = customIpInput.value;
            if (wsCustomVoltInput) wsCustomVoltInput.value = customVoltInput.value;
            if (wsCustomVfInput) wsCustomVfInput.value = customVfInput.value;
            if (wsCustomWireInput) wsCustomWireInput.value = customWireInput.value;
        } else {
            if (customTiInput) customTiInput.value = wsCustomTiInput.value;
            if (customPoInput) customPoInput.value = wsCustomPoInput.value;
            if (customIpInput) customIpInput.value = wsCustomIpInput.value;
            if (customVoltInput) customVoltInput.value = wsCustomVoltInput.value;
            if (customVfInput) customVfInput.value = wsCustomVfInput.value;
            if (customWireInput) customWireInput.value = wsCustomWireInput.value;
        }
    }

    [customTiInput, customPoInput, customIpInput, customVoltInput, customVfInput, customWireInput].forEach(inp => {
        if (inp) {
            const handler = () => {
                syncCustomInputs('tab1');
                state.isCustomUserEdited = true;
                state.compareMode = 'custom';
                runCustomAnalysis(false);
            };
            inp.addEventListener('input', handler);
            inp.addEventListener('change', handler);
        }
    });

    [wsCustomTiInput, wsCustomPoInput, wsCustomIpInput, wsCustomVoltInput, wsCustomVfInput, wsCustomWireInput].forEach(inp => {
        if (inp) {
            const handler = () => {
                syncCustomInputs('tab2');
                state.isCustomUserEdited = true;
                state.compareMode = 'custom';
                runCustomAnalysis(false);
            };
            inp.addEventListener('input', handler);
            inp.addEventListener('change', handler);
        }
    });

    if (wsBtnAnalyzeCustom) {
        wsBtnAnalyzeCustom.addEventListener('click', () => {
            state.isCustomUserEdited = true;
            state.compareMode = 'custom';
            runCustomAnalysis(true);
        });
    }

    // Toggle Chế độ Ẩn/Hiện Ký hiệu viết tắt theo phương ngang
    if (btnToggleCompact) {
        btnToggleCompact.addEventListener('click', () => {
            state.compactMetrics = !state.compactMetrics;
            if (state.compactMetrics) {
                compactText.innerHTML = 'KÃ½ hiá»‡u viáº¿t táº¯t: <strong>Báº¬T</strong>';
                comparisonTableElement.classList.add('compact-mode');
            } else {
                compactText.innerHTML = 'KÃ½ hiá»‡u viáº¿t táº¯t: <strong>Táº®T (Hiá»‡n Ä‘á»§)</strong>';
                comparisonTableElement.classList.remove('compact-mode');
            }
            runCustomAnalysis(false);
        });
    }
    if (btnToggleWorkshop && workshopBody) {
        btnToggleWorkshop.addEventListener('click', () => {
            state.workshopExpanded = !state.workshopExpanded;
            workshopBody.style.display = state.workshopExpanded ? 'block' : 'none';
            if (workshopToggleStatus) {
                workshopToggleStatus.textContent = state.workshopExpanded ? 'Hiện ▲' : 'Ẩn ▼';
            }
        });
    }

    // ==========================================
    // 3. CALCULATION ENGINE (PHYSICS & RULES)
    // ==========================================

    function calculateEDM(state) {
        const { material, passCount, strategyLevel, thickness, cutLength } = state;
        const H = thickness;
        const isHard = material === 'SCM440'; // Thép tôi cứng SCM440
        const isCopper = material === 'COPPER'; // Đồng đỏ / Đồng thau
        const isAlu = material === 'ALUMINUM'; // Nhôm 6061 / 7075
        const rows = [];
        const strat = STRATEGY_CONFIGS[strategyLevel] || STRATEGY_CONFIGS[6];

        // ----------------------------------------------------
        // PASS VARIABLES DECLARATION
        // ----------------------------------------------------
        let ti_1, Po_1, IP_1, Volt_1, VF_1, Wire_1, Offset_1, SpeedArea_1, Ra_1;
        let ti_2, Po_2, IP_2, Volt_2, VF_2, Wire_2, remain_2;
        let ti_3, Po_3, IP_3, Volt_3, VF_3, Wire_3, remain_3;
        let ti_4, Po_4, IP_4, Volt_4, VF_4, Wire_4, remain_4;
        let ti_5, Po_5, IP_5, Volt_5, VF_5, Wire_5, remain_5;
        let ti_6, Po_6, IP_6, Volt_6, VF_6, Wire_6, remain_6;

        // ----------------------------------------------------
        // PASS 1: ROUGH CUT (CẮT PHÁ THÔ)
        // ----------------------------------------------------

        // Base Ton (ti) calculation
        if (isAlu) {
            // Nhôm nóng chảy 660°C -> xung ti ngắn tránh bốc mạt nhôm dính dây
            if (H <= 15) ti_1 = 18;
            else if (H <= 30) ti_1 = 22;
            else if (H <= 60) ti_1 = 26;
            else if (H <= 100) ti_1 = 32;
            else if (H <= 160) ti_1 = 38;
            else if (H <= 250) ti_1 = 44;
            else if (H <= 350) ti_1 = 50;
            else ti_1 = 56;
        } else if (isCopper) {
            // Đồng tản nhiệt rất nhanh -> xung ti tập trung
            if (H <= 15) ti_1 = 26;
            else if (H <= 30) ti_1 = 30;
            else if (H <= 60) ti_1 = 36;
            else if (H <= 100) ti_1 = 44;
            else if (H <= 160) ti_1 = 52;
            else if (H <= 250) ti_1 = 60;
            else if (H <= 350) ti_1 = 64;
            else ti_1 = 68;
        } else {
            // Thép SCM420 / SCM440
            if (H <= 15) ti_1 = isHard ? 28 : 24;
            else if (H <= 30) ti_1 = isHard ? 32 : 28;
            else if (H <= 60) ti_1 = isHard ? 36 : 32;
            else if (H <= 100) ti_1 = isHard ? 48 : 44;
            else if (H <= 160) ti_1 = isHard ? 56 : 52;
            else if (H <= 250) ti_1 = isHard ? 64 : 60;
            else if (H <= 350) ti_1 = isHard ? 68 : 64;
            else ti_1 = isHard ? 72 : 68;
        }

        // Base Toff (Po) calculation
        if (isAlu) {
            // Nhôm cần Toff lớn để xả xỉ nhôm chống ngắn mạch
            if (H <= 15) Po_1 = 6;
            else if (H <= 40) Po_1 = 7;
            else if (H <= 70) Po_1 = 8;
            else if (H <= 120) Po_1 = 9;
            else if (H <= 200) Po_1 = 10;
            else Po_1 = 12;
        } else if (isCopper) {
            if (H <= 15) Po_1 = 4;
            else if (H <= 40) Po_1 = 5;
            else if (H <= 70) Po_1 = 6;
            else if (H <= 120) Po_1 = 7;
            else if (H <= 200) Po_1 = 8;
            else Po_1 = 10;
        } else {
            if (H <= 15) Po_1 = isHard ? 4 : 5;
            else if (H <= 40) Po_1 = isHard ? 5 : 6;
            else if (H <= 70) Po_1 = isHard ? 6 : 7;
            else if (H <= 120) Po_1 = isHard ? 6 : 7;
            else if (H <= 200) Po_1 = isHard ? 7 : 8;
            else if (H <= 350) Po_1 = isHard ? 9 : 10;
            else Po_1 = isHard ? 11 : 13;
        }

        // Base IP calculation
        if (H <= 15) IP_1 = 3;
        else if (H <= 50) IP_1 = 4;
        else if (H <= 100) IP_1 = 5;
        else IP_1 = 6;

        // Base VF calculation (Thuận lý công nghệ: phôi mỏng xối thoáng VF vừa phải 50-52; phôi dày rãnh sâu tăng VF 65-75 chống đâm sầm đứt dây)
        if (isAlu) {
            if (H <= 30) VF_1 = 52;
            else if (H <= 70) VF_1 = 58;
            else if (H <= 120) VF_1 = 64;
            else if (H <= 180) VF_1 = 68;
            else if (H <= 300) VF_1 = 72;
            else VF_1 = 75;
        } else if (isCopper) {
            if (H <= 30) VF_1 = 48;
            else if (H <= 70) VF_1 = 54;
            else if (H <= 120) VF_1 = 60;
            else if (H <= 180) VF_1 = 65;
            else if (H <= 300) VF_1 = 70;
            else VF_1 = 72;
        } else {
            if (H <= 30) VF_1 = isHard ? 52 : 50;
            else if (H <= 70) VF_1 = isHard ? 56 : 54;
            else if (H <= 120) VF_1 = isHard ? 62 : 60;
            else if (H <= 180) VF_1 = isHard ? 68 : 65;
            else if (H <= 300) VF_1 = isHard ? 72 : 70;
            else VF_1 = isHard ? 75 : 72;
        }

        Volt_1 = 'High';
        Wire_1 = 1;

        // Base Offset (R_wire = 0.090 + Spark Gap)
        if (isAlu) {
            if (H <= 20) Offset_1 = 0.116;
            else if (H <= 60) Offset_1 = 0.118;
            else if (H <= 100) Offset_1 = 0.122;
            else if (H <= 200) Offset_1 = 0.125;
            else Offset_1 = 0.128;
        } else if (isCopper) {
            if (H <= 20) Offset_1 = 0.112;
            else if (H <= 60) Offset_1 = 0.115;
            else if (H <= 100) Offset_1 = 0.118;
            else if (H <= 200) Offset_1 = 0.120;
            else Offset_1 = 0.124;
        } else {
            if (H <= 20) Offset_1 = 0.112;
            else if (H <= 60) Offset_1 = 0.115;
            else if (H <= 100) Offset_1 = 0.118;
            else if (H <= 200) Offset_1 = 0.120;
            else if (H <= 350) Offset_1 = 0.122;
            else Offset_1 = 0.125;
        }

        // Base Speed area (mm2/min)
        if (isAlu) {
            SpeedArea_1 = 165;
            if (H <= 20) SpeedArea_1 = 145;
            if (H > 100 && H <= 250) SpeedArea_1 = 150;
            if (H > 250) SpeedArea_1 = 125;
            Ra_1 = '3.2 - 3.8';
        } else if (isCopper) {
            SpeedArea_1 = 125;
            if (H <= 20) SpeedArea_1 = 110;
            if (H > 100 && H <= 250) SpeedArea_1 = 105;
            if (H > 250) SpeedArea_1 = 90;
            Ra_1 = '2.6 - 3.0';
        } else {
            SpeedArea_1 = isHard ? 130 : 115;
            if (H <= 20) SpeedArea_1 = isHard ? 115 : 100;
            if (H > 100 && H <= 250) SpeedArea_1 = isHard ? 110 : 95;
            if (H > 250) SpeedArea_1 = isHard ? 95 : 80;
            Ra_1 = isHard ? '2.8 - 3.2' : '3.0 - 3.4';
        }

        // Tinh chỉnh theo Chiến lược 11 Cấp độ
        let strategySpeedMult = strat.speedMult;
        if (strategyLevel !== 6) {
            const minTi1 = passCount > 1 ? 10 : 6;
            const maxTiAllowed = H > 160 ? 120 : (H > 100 ? 100 : 80);
            ti_1 = Math.max(minTi1, Math.min(maxTiAllowed, Math.round(ti_1 * strat.tiMult)));
            IP_1 = Math.max(passCount > 1 ? 2 : 1, Math.min(6, IP_1 + strat.ipDelta));
            VF_1 = Math.max(20, Math.min(90, VF_1 + strat.vfDelta));
            Po_1 = Math.max(2, Math.min(16, Po_1 + strat.poDelta));
            SpeedArea_1 = Math.round(SpeedArea_1 * strat.speedMult);

            if (strategyLevel <= 3 && H <= 40) {
                Volt_1 = 'Low';
                Offset_1 -= 0.005;
                Ra_1 = isAlu ? '1.4 - 1.8' : (isCopper ? '1.0 - 1.3' : (isHard ? '1.0 - 1.4' : '1.2 - 1.6'));
            } else if (strategyLevel <= 5) {
                Offset_1 -= 0.002;
                Ra_1 = isAlu ? '2.0 - 2.4' : (isCopper ? '1.5 - 1.9' : (isHard ? '1.6 - 2.0' : '1.8 - 2.2'));
            } else if (strategyLevel >= 9) {
                Offset_1 += 0.004;
                Ra_1 = isAlu ? '4.5 - 5.5' : (isCopper ? '3.8 - 4.5' : (isHard ? '4.0 - 4.8' : '4.2 - 5.2'));
            } else if (strategyLevel >= 7) {
                Offset_1 += 0.002;
                Ra_1 = isAlu ? '3.6 - 4.2' : (isCopper ? '3.0 - 3.5' : (isHard ? '3.2 - 3.8' : '3.4 - 4.0'));
            }
        }

        // Tốc độ tiến bàn cơ bản cho Pass 1: F1 = S1 / H
        const feedRate_1 = (SpeedArea_1 / H);

        rows.push({
            passName: 'P1',
            badgeClass: 'pass-badge-1',
            ti: ti_1,
            Po: Po_1,
            IP: IP_1,
            Voltage: Volt_1,
            VF: VF_1,
            Wire: Wire_1,
            offsetText: `${Offset_1.toFixed(3)}mm`,
            speedArea: Math.round(SpeedArea_1),
            feedRate: feedRate_1.toFixed(2),
            Ra: Ra_1,
            tolerance: H <= 50 ? '±0.015mm' : (H <= 150 ? '±0.020mm' : '±0.025mm'),
            rawOffset: Offset_1
        });

        // ----------------------------------------------------
        // PASS 2: SEMI-FINISH 1 / SỬA CÔN & SÓNG
        // ----------------------------------------------------
        if (passCount >= 2) {
            ti_2 = H <= 60 ? 16 : (H <= 150 ? 20 : 24);
            Po_2 = isHard ? 4 : 5;
            if (H > 100) Po_2 += 1;
            IP_2 = H <= 60 ? 2 : 3;
            Volt_2 = H <= 60 ? 'Low' : 'High';
            VF_2 = isHard ? 45 : 40;
            Wire_2 = 2;
            remain_2 = H <= 20 ? 0.018 : (H <= 60 ? 0.022 : (H <= 120 ? 0.024 : 0.026));
            
            // Đồng bộ bậc thang Pass 2 theo Chiến lược (Đảm bảo P2 luôn nhỏ hơn P1)
            if (strategyLevel !== 6) {
                if (strategyLevel <= 5) {
                    const ti2Scale = 0.45 + 0.55 * strat.tiMult;
                    ti_2 = Math.max(4, Math.min(ti_1 - 2, Math.round(ti_2 * ti2Scale)));
                    IP_2 = Math.min(IP_1, Math.max(1, strategyLevel <= 3 ? 1 : 2));
                    VF_2 = Math.max(25, VF_2 - (6 - strategyLevel) * 2);
                    remain_2 = Math.max(0.012, remain_2 - 0.002);
                } else {
                    ti_2 = Math.min(ti_1 - 4, Math.round(ti_2 * (0.8 + 0.2 * strat.tiMult)));
                }
            }
            // Khóa bảo vệ nghiêm ngặt: ti_2 < ti_1 và IP_2 <= IP_1
            if (ti_2 >= ti_1) ti_2 = Math.max(4, ti_1 - 2);
            if (IP_2 > IP_1) IP_2 = IP_1;

            const feedRate_2 = feedRate_1 * 1.85 * strategySpeedMult;
            const speedArea_2 = Math.round(feedRate_2 * H);

            rows.push({
                passName: 'P2',
                badgeClass: 'pass-badge-2',
                ti: ti_2,
                Po: Po_2,
                IP: IP_2,
                Voltage: Volt_2,
                VF: VF_2,
                Wire: Wire_2,
                offsetText: `${remain_2.toFixed(3)}mm`,
                speedArea: speedArea_2,
                feedRate: feedRate_2.toFixed(2),
                Ra: isHard ? '1.8 - 2.0' : '2.0 - 2.2',
                tolerance: H <= 50 ? '±0.008mm' : (H <= 150 ? '±0.010mm' : '±0.012mm')
            });
        }

        // ----------------------------------------------------
        // PASS 3: FINISH 1 / CẮT TINH HẠ NHÁM
        // ----------------------------------------------------
        if (passCount >= 3) {
            ti_3 = H <= 60 ? 6 : (H <= 150 ? 8 : 10);
            Po_3 = isHard ? 8 : 10; if (H > 100) Po_3 += 2;
            IP_3 = H <= 60 ? 1 : 2;
            Volt_3 = 'Low';
            VF_3 = isHard ? 35 : 30;
            Wire_3 = 3;
            remain_3 = H <= 20 ? 0.008 : (H <= 60 ? 0.010 : 0.012);
            
            // Đồng bộ bậc thang Pass 3 theo Chiến lược (Đảm bảo P3 luôn nhỏ hơn P2)
            if (strategyLevel <= 5) {
                ti_3 = Math.max(2, Math.min(ti_2 - 2, Math.round(ti_3 * (0.5 + 0.5 * strat.tiMult))));
                IP_3 = 1;
                VF_3 = Math.max(20, VF_3 - (6 - strategyLevel) * 2);
                remain_3 = Math.max(0.005, remain_3 - 0.001);
            }
            // Khóa bảo vệ nghiêm ngặt: ti_3 < ti_2 và IP_3 <= IP_2
            if (ti_3 >= ti_2) ti_3 = Math.max(2, ti_2 - 2);
            if (IP_3 > IP_2) IP_3 = IP_2;

            const feedRate_3 = feedRate_1 * 2.30 * strategySpeedMult;
            const speedArea_3 = Math.round(feedRate_3 * H);

            rows.push({
                passName: 'P3',
                badgeClass: 'pass-badge-3',
                ti: ti_3,
                Po: Po_3,
                IP: IP_3,
                Voltage: Volt_3,
                VF: VF_3,
                Wire: Wire_3,
                offsetText: `${remain_3.toFixed(3)}mm`,
                speedArea: speedArea_3,
                feedRate: feedRate_3.toFixed(2),
                Ra: isHard ? '1.0 - 1.2' : '1.2 - 1.4',
                tolerance: H <= 50 ? '±0.005mm' : (H <= 150 ? '±0.006mm' : '±0.008mm')
            });
        }

        // ----------------------------------------------------
        // PASS 4: SUPER FINISH / XÓA BIẾN TRẮNG
        // ----------------------------------------------------
        if (passCount >= 4) {
            ti_4 = H <= 60 ? 2 : (H <= 150 ? 3 : 4);
            Po_4 = isHard ? 12 : 15;
            IP_4 = 1;
            Volt_4 = 'Low';
            VF_4 = isHard ? 25 : 22;
            Wire_4 = 3;
            remain_4 = H <= 20 ? 0.004 : (H <= 60 ? 0.005 : 0.006);
            
            // Khóa bảo vệ nghiêm ngặt: ti_4 < ti_3
            if (ti_4 >= ti_3) ti_4 = Math.max(1, ti_3 - 1);
            if (IP_4 > IP_3) IP_4 = IP_3;

            const feedRate_4 = feedRate_1 * 2.50 * strategySpeedMult;
            const speedArea_4 = Math.round(feedRate_4 * H);

            rows.push({
                passName: 'P4',
                badgeClass: 'pass-badge-4',
                ti: ti_4,
                Po: Po_4,
                IP: IP_4,
                Voltage: Volt_4,
                VF: VF_4,
                Wire: Wire_4,
                offsetText: `${remain_4.toFixed(3)}mm`,
                speedArea: speedArea_4,
                feedRate: feedRate_4.toFixed(2),
                Ra: isHard ? '0.7 - 0.9' : '0.9 - 1.1',
                tolerance: '±0.004mm'
            });
        }

        // ----------------------------------------------------
        // PASS 5: MIRROR POLISH 1 / ĐÁNH BÓNG
        // ----------------------------------------------------
        if (passCount >= 5) {
            ti_5 = H <= 80 ? 1 : 2;
            Po_5 = isHard ? 15 : 20;
            IP_5 = 1;
            Volt_5 = 'Low';
            VF_5 = isHard ? 20 : 18;
            Wire_5 = 3;
            remain_5 = H <= 60 ? 0.002 : 0.003;
            
            // Khóa bảo vệ nghiêm ngặt: ti_5 < ti_4
            if (ti_5 >= ti_4) ti_5 = Math.max(1, ti_4 - 1);
            if (IP_5 > IP_4) IP_5 = IP_4;

            const feedRate_5 = feedRate_1 * 2.65 * strategySpeedMult;
            const speedArea_5 = Math.round(feedRate_5 * H);

            rows.push({
                passName: 'P5',
                badgeClass: 'pass-badge-5',
                ti: ti_5,
                Po: Po_5,
                IP: IP_5,
                Voltage: Volt_5,
                VF: VF_5,
                Wire: Wire_5,
                offsetText: `${remain_5.toFixed(3)}mm`,
                speedArea: speedArea_5,
                feedRate: feedRate_5.toFixed(2),
                Ra: isHard ? '≤ 0.60' : '≤ 0.70',
                tolerance: '±0.003mm'
            });
        }

        // ----------------------------------------------------
        // PASS 6: ULTRA MIRROR FINISH / BÓNG GƯƠNG TẾ VI
        // ----------------------------------------------------
        if (passCount >= 6) {
            ti_6 = 1;
            Po_6 = isHard ? 20 : 25;
            IP_6 = 1;
            Volt_6 = 'Low';
            VF_6 = 15;
            Wire_6 = 3;
            remain_6 = 0.001;
            
            // Khóa bảo vệ nghiêm ngặt: ti_6 <= ti_5
            if (ti_6 > ti_5) ti_6 = ti_5;
            if (IP_6 > IP_5) IP_6 = IP_5;

            const feedRate_6 = feedRate_1 * 2.70 * strategySpeedMult;
            const speedArea_6 = Math.round(feedRate_6 * H);

            rows.push({
                passName: 'P6',
                badgeClass: 'pass-badge-6',
                ti: ti_6,
                Po: Po_6,
                IP: IP_6,
                Voltage: Volt_6,
                VF: VF_6,
                Wire: Wire_6,
                offsetText: `${remain_6.toFixed(3)}mm`,
                speedArea: speedArea_6,
                feedRate: feedRate_6.toFixed(2),
                Ra: isHard ? '≤ 0.45' : '≤ 0.55',
                tolerance: '±0.002mm'
            });
        }

        // Calculate Total Time
        let totalMinutes = 0;
        rows.forEach(r => {
            const feed = parseFloat(r.feedRate);
            if (feed > 0) {
                totalMinutes += cutLength / feed;
            }
        });

        // Expert Operation Notices
        const notices = [];
        if (isAlu) {
            notices.push("Nhôm (Al 6061/7075): Tốc độ cắt cực nhanh do nhiệt độ nóng chảy thấp (660°C). Bắt buộc tăng Toff để xả xỉ chống bám dính dây và đoản mạch.");
        } else if (isHard) {
            notices.push("Thép đã tôi cứng SCM440 (28-32 HRC): Bề mặt bóc xỉ rất đều, độ bóng cao. Tăng nhẹ VF và giảm nhẹ Toff để tăng năng suất.");
        } else {
            notices.push("Thép mềm SCM420 dễ dính phôi: Đã tự động tăng hệ số nghỉ xung Toff và giảm bớt VF để triệt tiêu nguy cơ ngắn mạch / đứt dây.");
        }

        if (H >= 350) {
            notices.push(`Phôi siêu dày H=${H}mm: Ton được khống chế trần an toàn ở 68μs và Po=${rows[0].Po} để bảo vệ dây Molypden chống đứt và ngăn phình rãnh cắt dạng thùng rượu. Nếu cần bóc tách cực đại (Ton 80-100μs), chuyển sang Cấp 10-11 kèm dây mới 100% và nước 1:8.`);
        } else if (H > 150) {
            notices.push(`Phôi dày lớn H=${H}mm: Cần mở van nước áp lực cao, kiểm tra tiếp điện và định kỳ hạ tốc độ dây khi cắt tinh.`);
        } else if (H <= 20) {
            notices.push(`Phôi mỏng H=${H}mm: Tránh dùng Ton quá lớn để ngăn ngừa phồng biên dạng mép cắt.`);
        }

        if (strategyLevel >= 9) {
            notices.push("⚠️ Đang kích hoạt chế độ Cường lực / Tối đa công suất: Chú ý lực căng dây và lưu lượng nước làm mát để phòng ngừa đứt dây.");
        } else if (strategyLevel <= 3) {
            notices.push("✨ Đang kích hoạt chế độ Siêu mịn / Bóng gương: Năng lượng cực nhỏ, yêu cầu dây sạch và độ căng chuẩn tuyệt đối.");
        }

        return { rows, totalMinutes, notices };
    }

    // =========================================================================
    // 4. HỆ THỐNG THƯ VIỆN THỰC NGHIỆM & TÍNH TOÁN HIỆU CHỈNH XƯỞNG ĐỘC LẬP
    // =========================================================================
    /**
     * NGUYÊN TẮC CỐT LÕI (NGUYÊN TẮC TRONG NGUYÊN TẮC):
     * 1. Tách biệt 100% không gian biến, cấu hình và hàm tính toán với hệ thống chuẩn Hãng.
     * 2. Áp dụng 100% các phương trình vật lý nhiệt điện học gốc (T, f, eta, We, Ptb, Fc, Ft, t, delta, Offset)
     *    kết hợp với bộ hệ số hiệu chuẩn thực nghiệm xưởng (k_ampe, Cm_xưởng, KerfB_xưởng)
     *    để tính toán tự động khớp chính xác với số liệu thực đo tại xưởng.
     * 3. Cơ sở dữ liệu thư viện thực nghiệm WORKSHOP_EMPIRICAL_LIBRARY lưu trữ các bộ dữ liệu đo thực tế.
     */

    const WORKSHOP_EMPIRICAL_LIBRARY = [
        {
                "id": "STT 1",
                "name": "SCM440 (28-32HRC) | H=30mm | 1 Lần",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 30,
                "cutLength": "30mm",
                "passCount": 1,
                "params": {
                        "ti": 32,
                        "Po": 5,
                        "IP": 4,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 65,
                        "maxSpeed": "200Hz"
                },
                "measured": {
                        "totalTimeStr": "8p40'",
                        "ammeterA": "4,45A - 4,5A",
                        "measuredSpeed": "165 - 175",
                        "enteredOffset": 0.115,
                        "standardOffset": 0.098,
                        "sparkGap": "0.008",
                        "tolerance": "Chày to hơn lập trình 0.034mm"
                },
                "notes": "Nhập test 0.115mm -> Cắt lấy chày: To hơn lập trình 0.034mm (bù mỗi bên 0.017mm). OFFSET CHUẨN HIỆU CHỈNH = 0.115 - 0.017 = 0.098mm (Khe hở δ = 0.008mm)."
        },
        {
                "id": "STT 2",
                "name": "SCM440 (28-32HRC) | H=40mm | 1 Lần",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 40,
                "cutLength": "30mm",
                "passCount": 1,
                "params": {
                        "ti": 36,
                        "Po": 5,
                        "IP": 4,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 65,
                        "maxSpeed": "180Hz"
                },
                "measured": {
                        "totalTimeStr": "9p36'",
                        "ammeterA": "4,35A - 4,4A",
                        "measuredSpeed": "130 - 140",
                        "enteredOffset": 0.115,
                        "standardOffset": 0.098,
                        "sparkGap": "0.008",
                        "tolerance": "Chày to hơn lập trình 0.034mm"
                },
                "notes": "Nhập test 0.115mm -> Cắt lấy chày: To hơn lập trình 0.034mm (bù mỗi bên 0.017mm). OFFSET CHUẨN HIỆU CHỈNH = 0.115 - 0.017 = 0.098mm (Khe hở δ = 0.008mm)."
        },
        {
                "id": "STT 3",
                "name": "SCM420 (HB<200) | H=63mm | 1 Lần",
                "materialName": "SCM420 (HB<200)",
                "thickness": 63,
                "cutLength": "27mm",
                "passCount": 1,
                "params": {
                        "ti": 44,
                        "Po": 7,
                        "IP": 5,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 55,
                        "maxSpeed": "150Hz"
                },
                "measured": {
                        "totalTimeStr": "14p20'",
                        "ammeterA": "4,1A - 4,2A",
                        "measuredSpeed": "75 - 85",
                        "enteredOffset": 0.118,
                        "standardOffset": 0.095,
                        "sparkGap": "0.005",
                        "tolerance": "Chày to hơn lập trình 0.046mm"
                },
                "notes": "Nhập test 0.118mm -> Cắt lấy chày: To hơn lập trình 0.046mm (bù mỗi bên 0.023mm). OFFSET CHUẨN HIỆU CHỈNH = 0.118 - 0.023 = 0.095mm (Khe hở δ = 0.005mm)."
        },
        {
                "id": "STT 5",
                "name": "SCM420 (HB<200) | H=45mm | 1 Lần (Chuẩn Vàng)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 45,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 50,
                        "Po": 7,
                        "IP": 3,
                        "wire": 1,
                        "Voltage": "Low",
                        "VF": 50,
                        "maxSpeed": "150Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "enteredOffset": 0.105,
                        "standardOffset": 0.105,
                        "sparkGap": "0.015",
                        "tolerance": "Chuẩn tuyệt đối"
                },
                "notes": "Nhập test 0.105mm -> Cắt lấy chày: Kích thước offset chuẩn luôn! OFFSET CHUẨN = 0.105mm (Khe hở δ = 0.015mm)."
        },
        {
                "id": "STT 6",
                "name": "SCM440 (28-32HRC) | H=68mm | 1 Lần (Chuẩn Vàng)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 68,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 70,
                        "Po": 7,
                        "IP": 3,
                        "wire": 1,
                        "Voltage": "Low",
                        "VF": 50,
                        "maxSpeed": "100Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "enteredOffset": 0.097,
                        "standardOffset": 0.097,
                        "sparkGap": "0.007",
                        "tolerance": "Chuẩn tuyệt đối"
                },
                "notes": "Nhập test 0.097mm -> Cắt lấy chày: Kích thước offset chuẩn luôn! OFFSET CHUẨN = 0.097mm (Khe hở δ = 0.007mm)."
        },
        {
                "id": "STT 7",
                "name": "SCM420 (HB<200) | H=140mm | 1 Lần (Chuẩn Vàng)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 140,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 120,
                        "Po": 8,
                        "IP": 5,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 55,
                        "maxSpeed": "50Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "enteredOffset": 0.095,
                        "standardOffset": 0.095,
                        "sparkGap": "0.005",
                        "tolerance": "Chuẩn tuyệt đối"
                },
                "notes": "Nhập test 0.095mm -> Cắt lấy chày: Kích thước offset chuẩn luôn! OFFSET CHUẨN = 0.095mm (Khe hở δ = 0.005mm)."
        },
        {
                "id": "STT 8",
                "name": "SCM420 (HB<200) | H=160mm | 1 Lần (Chuẩn Vàng)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 160,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 120,
                        "Po": 8,
                        "IP": 5,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 55,
                        "maxSpeed": "50Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "enteredOffset": 0.11,
                        "standardOffset": 0.11,
                        "sparkGap": "0.020",
                        "tolerance": "Chuẩn tuyệt đối"
                },
                "notes": "Nhập test 0.110mm -> Cắt lấy chày: Kích thước offset chuẩn luôn! OFFSET CHUẨN = 0.110mm (Khe hở δ = 0.020mm)."
        },
        {
                "id": "STT 10",
                "name": "SCM420 (HB<200) | H=140mm | 1 Lần (Thử 1)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 140,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 52,
                        "Po": 8,
                        "IP": 6,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 50,
                        "maxSpeed": "100Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "speedNote": "không cắt được",
                        "enteredOffset": 0.12,
                        "standardOffset": null,
                        "sparkGap": null,
                        "tolerance": "Không cắt được"
                },
                "notes": "Không cắt được: Ton=52 quá nhỏ không duy trì được hồ quang ổn định cho H=140mm."
        },
        {
                "id": "STT 11",
                "name": "SCM420 (HB<200) | H=140mm | 1 Lần (Thử 2)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 140,
                "cutLength": "",
                "passCount": 1,
                "params": {
                        "ti": 80,
                        "Po": 8,
                        "IP": 6,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 50,
                        "maxSpeed": "100Hz"
                },
                "measured": {
                        "totalTimeStr": "",
                        "ammeterA": "",
                        "measuredSpeed": null,
                        "speedNote": "không cắt được",
                        "enteredOffset": 0.12,
                        "standardOffset": null,
                        "sparkGap": null,
                        "tolerance": "Không cắt được"
                },
                "notes": "Không cắt được: Ton=80 vẫn chưa đủ bù suy hao năng lượng trên khoảng cách 140mm."
        },
        {
                "id": "STT 12",
                "name": "SCM420 (HB<200) | H=140mm | 1 Lần (Thử 3)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 140,
                "cutLength": "28,4mm",
                "passCount": 1,
                "params": {
                        "ti": 100,
                        "Po": 9,
                        "IP": 6,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 60,
                        "maxSpeed": "100Hz"
                },
                "measured": {
                        "totalTimeStr": "36p",
                        "ammeterA": "3,7A - 3,8A",
                        "measuredSpeed": "30 - 40",
                        "enteredOffset": 0.12,
                        "standardOffset": 0.102,
                        "sparkGap": "0.012",
                        "tolerance": "Chày to hơn lập trình 0.036mm"
                },
                "notes": "Nhập test 0.120mm -> Chày to hơn 0.036mm. OFFSET CHUẨN HIỆU CHỈNH = 0.120 - 0.018 = 0.102mm (Khe hở δ = 0.012mm)."
        },
        {
                "id": "STT 14",
                "name": "SCM440 (28-32HRC) | H=300mm | Giai đoạn 2",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 300,
                "cutLength": "76,1mm",
                "passCount": 1,
                "params": {
                        "ti": 120,
                        "Po": 9,
                        "IP": 6,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 65,
                        "maxSpeed": "50Hz"
                },
                "measured": {
                        "totalTimeStr": "3h",
                        "ammeterA": "3,7A - 3,9A",
                        "measuredSpeed": "12 - 20",
                        "enteredOffset": 0.12,
                        "standardOffset": 0.115,
                        "sparkGap": "0.025",
                        "tolerance": "Cối lớn hơn lập trình 0.010mm"
                },
                "notes": "GĐ 2: Cắt cối lỗ lớn hơn lập trình 0.010mm. OFFSET CHUẨN HIỆU CHỈNH = 0.120 - 0.005 = 0.115mm (Khe hở δ = 0.025mm)."
        },
        {
                "id": "STT 15",
                "name": "SCM420 (HB<200) | H=160mm | 1 Lần",
                "materialName": "SCM420 (HB<200)",
                "thickness": 160,
                "cutLength": "32,3mm",
                "passCount": 1,
                "params": {
                        "ti": 120,
                        "Po": 11,
                        "IP": 6,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 70,
                        "maxSpeed": "154Hz"
                },
                "measured": {
                        "totalTimeStr": "59p",
                        "ammeterA": "2,8A - 3A",
                        "measuredSpeed": "18 - 28",
                        "enteredOffset": 0.107,
                        "standardOffset": 0.120,
                        "sparkGap": "0.030",
                        "tolerance": "Cối to hơn lập trình 0.026mm"
                },
                "notes": "Nhập test 0.107mm -> Cắt lấy cối: To hơn lập trình 0.026mm (bù mỗi bên +0.013mm). OFFSET CHUẨN HIỆU CHỈNH = 0.107 + 0.013 = 0.120mm (Khe hở δ = 0.030mm). Thời gian thực 59p khớp 100% thời gian tính toán 59p."
        },
        {
                "id": "STT 16",
                "name": "SCM420 (HB<200) | H=75mm | 1 Lần",
                "materialName": "SCM420 (HB<200)",
                "thickness": 75,
                "cutLength": "50,3mm",
                "passCount": 1,
                "params": {
                        "ti": 55,
                        "Po": 7,
                        "IP": 4,
                        "wire": 1,
                        "Voltage": "High",
                        "VF": 54,
                        "maxSpeed": "187Hz"
                },
                "measured": {
                        "totalTimeStr": "1h13p",
                        "ammeterA": "3,4A - 3,5A",
                        "measuredSpeed": "50 - 65",
                        "enteredOffset": 0.092,
                        "standardOffset": 0.112,
                        "sparkGap": "0.022",
                        "tolerance": "Cối to hơn lập trình 0.040mm"
                },
                "notes": "Nhập test 0.092mm -> Cắt lấy cối: To hơn lập trình 0.040mm (bù mỗi bên +0.020mm). OFFSET CHUẨN HIỆU CHỈNH = 0.092 + 0.020 = 0.112mm (Khe hở δ = 0.022mm). Ampe 3.4-3.5A và tốc độ 50-65 mm²/p khớp chuẩn dải lý thuyết."
        },
                {
                  "id": "STT 17",
                  "name": "SCM440 (28-32HRC) | H=95mm | 1 Lần",
                  "materialName": "SCM440 (28-32HRC)",
                  "thickness": 95,
                  "cutLength": "76mm",
                  "passCount": 1,
                  "params": {
                            "ti": 82,
                            "Po": 7,
                            "IP": 4,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 55,
                            "maxSpeed": "150Hz"
                  },
                  "measured": {
                            "totalTimeStr": "1h15p",
                            "ammeterA": "3,6A - 3,7A",
                            "measuredSpeed": "35 - 45",
                            "enteredOffset": 0.091,
                            "standardOffset": 0.1135,
                            "sparkGap": "0.0235",
                            "tolerance": "Cối lớn hơn lập trình 0.045mm"
                  },
                  "notes": "Nhập test 0.091mm -> Cắt lấy cối: Lớn hơn lập trình 0.045mm (bù mỗi bên +0.0225mm). OFFSET CHUẨN HIỆU CHỈNH = 0.091 + 0.0225 = 0.1135mm (Khe hở δ = 0.0235mm). Ampe 3.6-3.7A và tốc độ 35-45 mm²/p khớp chuẩn dải lý thuyết."
        },
        {
                  "id": "STT 18",
                  "name": "SCM420 (HB<200) | H=63mm | 1 Lần",
                  "materialName": "SCM420 (HB<200)",
                  "thickness": 63,
                  "cutLength": "22,3mm",
                  "passCount": 1,
                  "params": {
                            "ti": 44,
                            "Po": 8,
                            "IP": 4,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 57,
                            "maxSpeed": "150Hz"
                  },
                  "measured": {
                            "totalTimeStr": "17p40'",
                            "ammeterA": "3,3A - 3,4A",
                            "measuredSpeed": "50 - 65",
                            "enteredOffset": 0.093,
                            "standardOffset": 0.098,
                            "sparkGap": "0.008",
                            "tolerance": "Chày nhỏ hơn lập trình 0.010mm"
                  },
                  "notes": "Nhập test 0.093mm -> Cắt lấy chày: Nhỏ hơn lập trình 0.010mm (bù mỗi bên +0.005mm). OFFSET CHUẨN HIỆU CHỈNH = 0.093 + 0.005 = 0.098mm (Khe hở δ = 0.008mm). Thời gian thực 17p40s khớp 99.9% thời gian tính toán 17.6p."
        },
        {
                  "id": "STT 19",
                  "name": "SCM420 (HB<200) | H=110mm | 1 Lần",
                  "materialName": "SCM420 (HB<200)",
                  "thickness": 110,
                  "cutLength": "--",
                  "passCount": 1,
                  "params": {
                            "ti": 100,
                            "Po": 10,
                            "IP": 5,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 65,
                            "maxSpeed": "150Hz"
                  },
                  "measured": {
                            "totalTimeStr": "--",
                            "ammeterA": "2,7A - 2,8A",
                            "measuredSpeed": "30 - 40",
                            "enteredOffset": 0.105,
                            "standardOffset": 0.105,
                            "sparkGap": "0.015",
                            "tolerance": "Chày chuẩn luôn"
                  },
                  "notes": "Nhập test 0.105mm -> Cắt lấy chày: Kích thước chuẩn luôn 100% không lệch. OFFSET CHUẨN = 0.105mm (Khe hở δ = 0.015mm). Ampe 2.7-2.8A ở Po=10 cho hồ quang êm dịu, thoát xỉ rãnh sâu 110mm."
        },
        {
                  "id": "STT 20",
                  "name": "SCM440 (28-32HRC) | H=290mm | 1 Lần",
                  "materialName": "SCM440 (28-32HRC)",
                  "thickness": 290,
                  "cutLength": "--",
                  "passCount": 1,
                  "params": {
                            "ti": 135,
                            "Po": 10,
                            "IP": 6,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 75,
                            "maxSpeed": "50Hz"
                  },
                  "measured": {
                            "totalTimeStr": "--",
                            "ammeterA": "--",
                            "measuredSpeed": "--",
                            "enteredOffset": 0.110,
                            "standardOffset": 0.110,
                            "sparkGap": "0.020",
                            "tolerance": "Cắt lấy cối: Kích thước chuẩn luôn"
                  },
                  "notes": "Nhập test 0.110mm -> Cắt lấy cối: Kích thước chuẩn luôn 100%. OFFSET CHUẨN = 0.110mm (Khe hở δ = 0.020mm). Chế độ điện phá thô phôi siêu dày H=290mm, Ton=135, Po=10, IP=6, VF=75, giới hạn 50Hz."
        },
        {
                  "id": "STT 21",
                  "name": "SCM420 (HB<200) | H=90mm | 1 Lần",
                  "materialName": "SCM420 (HB<200)",
                  "thickness": 90,
                  "cutLength": "--",
                  "passCount": 1,
                  "params": {
                            "ti": 80,
                            "Po": 7,
                            "IP": 4,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 54,
                            "maxSpeed": "150Hz"
                  },
                  "measured": {
                            "totalTimeStr": "--",
                            "ammeterA": "3,5A - 3,6A",
                            "measuredSpeed": "50 - 60 mm²/p",
                            "enteredOffset": 0.118,
                            "standardOffset": 0.118,
                            "sparkGap": "0.028",
                            "tolerance": "Cắt lấy cối: Kích thước chuẩn luôn"
                  },
                  "notes": "Nhập test 0.118mm -> Cắt lấy cối: Kích thước chuẩn luôn 100%. OFFSET CHUẨN = 0.118mm (Khe hở δ = 0.028mm). Chế độ điện H=90mm, Ton=80, Po=7, IP=4, VF=54, giới hạn 150Hz, Ampe=3.5-3.6A, Fc=50-60mm²/p."
        },
        {
                  "id": "STT 22",
                  "name": "SCM420 (HB<200) | H=12mm | 1 Lần",
                  "materialName": "SCM420 (HB<200)",
                  "thickness": 12,
                  "cutLength": "--",
                  "passCount": 1,
                  "params": {
                            "ti": 16,
                            "Po": 6,
                            "IP": 3,
                            "wire": 1,
                            "Voltage": "Low",
                            "VF": 60,
                            "maxSpeed": "150Hz"
                  },
                  "measured": {
                            "totalTimeStr": "--",
                            "ammeterA": "2,5A - 2,7A",
                            "measuredSpeed": "--",
                            "enteredOffset": 0.095,
                            "standardOffset": 0.095,
                            "sparkGap": "0.005",
                            "tolerance": "Cắt lấy chày: Kích thước chuẩn luôn"
                  },
                  "notes": "Nhập test 0.095mm -> Cắt lấy chày: Kích thước chuẩn luôn 100%. OFFSET CHUẨN = 0.095mm (Khe hở δ = 0.005mm). Chế độ điện H=12mm SCM420, Ton=16, Po=6, IP=3, Volt=Low, VF=60, giới hạn 150Hz, Ampe=2.5-2.7A."
        },
        {
                  "id": "STT 23",
                  "name": "SCM420 (HB<200) | H=200mm | 1 Lần",
                  "materialName": "SCM420 (HB<200)",
                  "thickness": 200,
                  "cutLength": "--",
                  "passCount": 1,
                  "params": {
                            "ti": 120,
                            "Po": 10,
                            "IP": 6,
                            "wire": 1,
                            "Voltage": "High",
                            "VF": 65,
                            "maxSpeed": "60Hz"
                  },
                  "measured": {
                            "totalTimeStr": "--",
                            "ammeterA": "--",
                            "measuredSpeed": "--",
                            "enteredOffset": 0.108,
                            "standardOffset": 0.108,
                            "sparkGap": "0.018",
                            "tolerance": "Cắt lấy cối: Kích thước chuẩn luôn"
                  },
                  "notes": "Nhập test 0.108mm -> Cắt lấy cối: Kích thước chuẩn luôn 100%. OFFSET CHUẨN = 0.108mm (Khe hở δ = 0.018mm). Chế độ điện H=200mm SCM420, Ton=120, Po=10, IP=6, Volt=High, VF=65, giới hạn 60Hz."
        },
{
                "id": "2P-02",
                "name": "SCM420 | H=63mm | 2 Lần (Cấp 6)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 63,
                "cutLength": "30mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 44,
                                "Po": 7,
                                "IP": 5,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 55,
                                "maxSpeed": "150Hz",
                                "offset": 0.118,
                                "time": "16p26'",
                                "ampe": "4,2A",
                                "speed": "75-85 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 20,
                                "Po": 5,
                                "IP": 3,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 40,
                                "maxSpeed": "100Hz",
                                "offset": 0.024,
                                "time": "5p20'",
                                "ampe": "0,1-0,2A",
                                "speed": "240 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "21p46'",
                        "ammeterA": "4.2A (P1) | 0.1-0.2A (P2)",
                        "measuredSpeed": "75-85 (P1) | 240 (P2)",
                        "enteredOffsetP1": 0.118,
                        "enteredOffsetP2": 0.024,
                        "recommendedOffsetP1": 0.093,
                        "recommendedOffsetP2": 0.024,
                        "actualDimension": "Chày to hơn lập trình 0.050mm"
                },
                "notes": "Nhập test P1=0.118, P2=0.024 -> Chày to hơn 0.050mm. Offset chuẩn hiệu chỉnh: P1=0.093mm, P2=0.024mm."
        },
        {
                "id": "2P-03",
                "name": "SCM420 | H=30mm | 2 Lần (Cắt Cối)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 30,
                "cutLength": "644mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 28,
                                "Po": 6,
                                "IP": 4,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 60,
                                "maxSpeed": "200Hz",
                                "offset": 0.115,
                                "time": "3h08p",
                                "ampe": "4,1A",
                                "speed": "140-150 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 16,
                                "Po": 5,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 40,
                                "maxSpeed": "150Hz",
                                "offset": 0.022,
                                "time": "1h12p",
                                "ampe": "0,1-0,2A",
                                "speed": "360 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "4h20p",
                        "ammeterA": "4.1A (P1) | 0.1-0.2A (P2)",
                        "measuredSpeed": "140-150 (P1) | 360 (P2)",
                        "enteredOffsetP1": 0.115,
                        "enteredOffsetP2": 0.022,
                        "recommendedOffsetP1": 0.1075,
                        "recommendedOffsetP2": 0.022,
                        "actualDimension": "Cối nhỏ hơn lập trình 0.015mm"
                },
                "notes": "Cắt cối L=644mm. Nhập test P1=0.115, P2=0.022 -> Cối nhỏ hơn 0.015mm. Offset chuẩn hiệu chỉnh: P1=0.1075mm, P2=0.022mm."
        },
        {
                "id": "2P-04",
                "name": "SCM440 | H=12mm | 2 Lần (Đã Chuẩn)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 12,
                "cutLength": "--",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 20,
                                "Po": 7,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 50,
                                "maxSpeed": "150Hz",
                                "offset": 0.098,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 12,
                                "Po": 7,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 20,
                                "maxSpeed": "130Hz",
                                "offset": 0.04,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        }
                ],
                "measured": {
                        "totalTimeStr": "--",
                        "ammeterA": "--",
                        "measuredSpeed": "--",
                        "enteredOffsetP1": 0.098,
                        "enteredOffsetP2": 0.04,
                        "recommendedOffsetP1": 0.098,
                        "recommendedOffsetP2": 0.04,
                        "actualDimension": "Kích thước đã chuẩn 100%"
                },
                "notes": "H=12mm Thép SCM440. P1(Ton=20, IP=2, Low, VF=50, O1=0.098) + P2(Ton=12, IP=2, Low, VF=20, O2=0.040) -> Kích thước đã chuẩn."
        },
        {
                "id": "2P-05",
                "name": "SCM440 | H=32mm | 2 Lần (Đã Chuẩn)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 32,
                "cutLength": "--",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 30,
                                "Po": 7,
                                "IP": 3,
                                "wire": 1,
                                "voltage": "Low",
                                "vf": 50,
                                "maxSpeed": "200Hz",
                                "offset": 0.091,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 5,
                                "Po": 15,
                                "IP": 1,
                                "wire": 1,
                                "voltage": "Low",
                                "vf": 10,
                                "maxSpeed": "130Hz",
                                "offset": 0.03,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        }
                ],
                "measured": {
                        "totalTimeStr": "--",
                        "ammeterA": "--",
                        "measuredSpeed": "--",
                        "enteredOffsetP1": 0.091,
                        "enteredOffsetP2": 0.03,
                        "recommendedOffsetP1": 0.091,
                        "recommendedOffsetP2": 0.03,
                        "actualDimension": "Kích thước đã chuẩn 100%"
                },
                "notes": "H=32mm Thép SCM440. P1(Ton=30, IP=3, Low, VF=50, O1=0.091) + P2(Ton=5, IP=1, Low, VF=10, O2=0.030) -> Kích thước đã chuẩn."
        },
        {
                "id": "2P-06",
                "name": "SCM440 | H=62mm | 2 Lần (Đã Chuẩn)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 62,
                "cutLength": "--",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 70,
                                "Po": 7,
                                "IP": 4,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 50,
                                "maxSpeed": "150Hz",
                                "offset": 0.092,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 15,
                                "Po": 7,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 20,
                                "maxSpeed": "100Hz",
                                "offset": 0.03,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        }
                ],
                "measured": {
                        "totalTimeStr": "--",
                        "ammeterA": "--",
                        "measuredSpeed": "--",
                        "enteredOffsetP1": 0.092,
                        "enteredOffsetP2": 0.03,
                        "recommendedOffsetP1": 0.092,
                        "recommendedOffsetP2": 0.03,
                        "actualDimension": "Kích thước đã chuẩn 100%"
                },
                "notes": "H=62mm Thép SCM440. P1(Ton=70, IP=4, High, VF=50, O1=0.092) + P2(Ton=15, IP=2, Low, VF=20, O2=0.030) -> Kích thước đã chuẩn."
        },
        {
                "id": "2P-09",
                "name": "SCM420 | H=140mm | 2 Lần (Đã Chuẩn)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 140,
                "cutLength": "--",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 120,
                                "Po": 8,
                                "IP": 5,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 55,
                                "maxSpeed": "60Hz",
                                "offset": 0.098,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 25,
                                "Po": 7,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 25,
                                "maxSpeed": "100Hz",
                                "offset": 0.03,
                                "time": "--",
                                "ampe": "--",
                                "speed": "--"
                        }
                ],
                "measured": {
                        "totalTimeStr": "--",
                        "ammeterA": "--",
                        "measuredSpeed": "--",
                        "enteredOffsetP1": 0.098,
                        "enteredOffsetP2": 0.03,
                        "recommendedOffsetP1": 0.098,
                        "recommendedOffsetP2": 0.03,
                        "actualDimension": "Kích thước đã chuẩn 100%"
                },
                "notes": "H=140mm Phôi dày SCM420. P1(Ton=120, IP=5, High, VF=55, O1=0.098) + P2(Ton=25, IP=2, Low, VF=25, O2=0.030) -> Kích thước đã chuẩn."
        }
,
        {
                "id": "2P-10",
                "name": "SCM440 | H=85mm | 2 Lần (Kiểm chứng Web App Tab 2)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 85,
                "cutLength": "65,6mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 70,
                                "Po": 8,
                                "IP": 5,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 61,
                                "maxSpeed": "150Hz",
                                "offset": 0.095,
                                "time": "48p",
                                "ampe": "3,6A - 3,7A",
                                "speed": "55 - 65 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 20,
                                "Po": 6,
                                "IP": 3,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 36,
                                "maxSpeed": "100Hz",
                                "offset": 0.03,
                                "time": "10p24'",
                                "ampe": "0,5A - 1,0A",
                                "speed": "240 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "58p24' (P1: 48p, P2: 10p24')",
                        "ammeterA": "3.6 - 3.7A (P1) | 0.5 - 1.0A (P2)",
                        "measuredSpeed": "55 - 65 mm²/p (P1) | 240 mm²/p (P2)",
                        "enteredOffsetP1": 0.095,
                        "enteredOffsetP2": 0.03,
                        "recommendedOffsetP1": 0.1025,
                        "recommendedOffsetP2": 0.03,
                        "actualDimension": "Sau P1: 19.94-19.95mm | Sau P2: to hơn 0.015mm (20.015mm)"
                },
                "notes": "H=85mm SCM440 cắt 2 Pass theo chuẩn Web App Tab 2. Sau Pass 1 đo đạt 19.94-19.95mm (chừa đúng 0.0275mm lượng dư mỗi bên). Sau Pass 2 đạt 20.015mm (to hơn 0.015mm do Pass 2 ăn 0.035mm/bên). Offset P1 chuẩn hiệu chỉnh: 0.1025mm, Offset P2: 0.030mm."
        }
,
        {
                "id": "2P-11",
                "name": "SCM440 | H=165mm | 2 Lần (Hiệu chuẩn VF=70)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 165,
                "cutLength": "43,6mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 135,
                                "Po": 11,
                                "IP": 6,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 70,
                                "maxSpeed": "60Hz",
                                "offset": 0.110,
                                "time": "1h17'",
                                "ampe": "2,8A - 3,0A",
                                "speed": "15 - 35 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 24,
                                "Po": 6,
                                "IP": 3,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 36,
                                "maxSpeed": "80Hz",
                                "offset": 0.030,
                                "time": "9p",
                                "ampe": "1,0A - 1,5A",
                                "speed": "190 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "1h26' (P1: 1h17', P2: 9p)",
                        "ammeterA": "2.8 - 3.0A (P1) | 1.0 - 1.5A (P2)",
                        "measuredSpeed": "15 - 35 mm²/p (P1) | 190 mm²/p (P2)",
                        "enteredOffsetP1": 0.110,
                        "enteredOffsetP2": 0.030,
                        "recommendedOffsetP1": 0.0875,
                        "recommendedOffsetP2": 0.020,
                        "actualDimension": "Sau P1: 23.95-23.96mm | Sau P2: 23.95-23.96mm (nhỏ hơn lập trình 0.045mm)"
                },
                "delta1Solid": 0.0275,
                        "equivalent1PassOffset": 0.1175,
                        "notes": "H=165mm SCM440 phôi siêu dày. LƯỢNG CÀO THÉP ĐẶC PASS 1: δ1 = 0.050 - 0.0225 = 0.0275mm (Bào mòn cực mạnh 27.5 micron). Quy đổi Offset 1-Pass chuẩn tương đương: O_1P = 0.090 + 0.0275 = 0.1175mm (dùng tinh chỉnh công thức 1-Pass). Phát hiện bước ngoặt: VF=70 tăng độ nhạy dò dây giúp máy đi chậm rãi, chống đâm sầm vào phôi. P2 hụt tầm vươn do O2 đặt lùi quá xa. Hiệu chỉnh 2 Pass chuẩn: P1=0.0875mm, P2=0.020mm."
        }
,
        {
                "id": "2P-12",
                "name": "SCM440 | H=165mm | 2 Lần (Mẫu 2: O1=0.100, O2=0.015)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 165,
                "cutLength": "43,6mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 135,
                                "Po": 11,
                                "IP": 6,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 70,
                                "maxSpeed": "60Hz",
                                "offset": 0.100,
                                "time": "1h17'",
                                "ampe": "2,8A - 3,0A",
                                "speed": "15 - 35 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 40,
                                "Po": 7,
                                "IP": 3,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 36,
                                "maxSpeed": "80Hz",
                                "offset": 0.015,
                                "time": "9p",
                                "ampe": "0,5A (3/4 đường) | 1,0A-1,5A (1/4 đường)",
                                "speed": "190 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "1h26' (P1: 1h17', P2: 9p)",
                        "ammeterA": "2.8-3.0A (P1) | 0.5A ~ 1.0-1.5A (P2)",
                        "measuredSpeed": "15-35 mm²/p (P1) | 190 mm²/p (P2)",
                        "enteredOffsetP1": 0.100,
                        "enteredOffsetP2": 0.015,
                        "recommendedOffsetP1": 0.1075,
                        "recommendedOffsetP2": 0.015,
                        "delta1Solid": 0.0225,
                        "equivalent1PassOffset": 0.1125,
                        "actualDimension": "Sau P1: 23.99-24.00mm | Sau P2: 24.01-24.02mm (to hơn lập trình 0.015mm)"
                },
                "notes": "H=165mm SCM440 mẫu 2. P1 cào thép đặc δ1=0.0225mm (gần khớp 24.00mm). P2 tăng Ton=40 và ép O2=0.015mm giúp tia lửa cắn sâu vào vách, cối to hơn 0.015mm. Đúc kết vàng về kim Ampe P2: 3/4 đường kim chỉ 0.5A (đỉnh núi lửa thấp), 1/4 đường vọt lên 1-1.5A (đỉnh núi lửa cao còn nhiều lượng dư). Offset 2 Pass chuẩn: P1=0.1075mm, P2=0.015mm."
        }
,
        {
                "id": "2P-13",
                "name": "SCM440 | H=60mm | 2 Lần (Kiểm chứng Thực tế Xưởng)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 60,
                "cutLength": "68mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 50,
                                "Po": 7,
                                "IP": 4,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 62,
                                "maxSpeed": "150Hz",
                                "offset": 0.094,
                                "time": "40p20'",
                                "ampe": "3,5A - 3,6A",
                                "speed": "65 - 75 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 16,
                                "Po": 6,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 40,
                                "maxSpeed": "100Hz",
                                "offset": 0.022,
                                "time": "12p",
                                "ampe": "0,5A - 0,6A",
                                "speed": "240 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "52p20' (P1: 40p20', P2: 12p)",
                        "ammeterA": "3.5 - 3.6A (P1) | 0.5 - 0.6A (P2)",
                        "measuredSpeed": "65 - 75 mm²/p (P1) | 240 mm²/p (P2)",
                        "enteredOffsetP1": 0.094,
                        "enteredOffsetP2": 0.022,
                        "recommendedOffsetP1": 0.099,
                        "recommendedOffsetP2": 0.022,
                        "actualDimension": "Cắt lấy cối: kích thước lớn hơn lập trình 0.010mm (lỗ cối rộng hơn 5μm/bên)"
                },
                "notes": "H=60mm SCM440 cắt 2 Pass kiểm chứng xưởng. Kích thước chày lớn hơn lập trình 0.010mm (chỉ lệch 5μm/bên). Offset P1 chuẩn: 0.099mm, Offset P2 chuẩn: 0.022mm. Khớp tuyệt đối với công thức lý thuyết: O1_calc = 0.0943mm (thực tế nhập 0.094), O2_calc = 0.022mm (thực tế nhập 0.022). Ampe P1 ăn 3.5-3.6A, P2 ăn 0.5-0.6A."
        },
        {
                "id": "2P-14",
                "name": "SCM420 | H=75mm | 2 Lần (Đối Chứng Khép Kín 95%)",
                "materialName": "SCM420 (HB<200)",
                "thickness": 75,
                "cutLength": "50,3mm",
                "passCount": 2,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 55,
                                "Po": 7,
                                "IP": 4,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 54,
                                "maxSpeed": "187Hz",
                                "offset": 0.092,
                                "time": "1h13p",
                                "ampe": "3,4A - 3,5A",
                                "speed": "50 - 65 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 18,
                                "Po": 7,
                                "IP": 3,
                                "wire": 2,
                                "voltage": "High",
                                "vf": 32,
                                "maxSpeed": "100Hz",
                                "offset": 0.023,
                                "time": "8p40'",
                                "ampe": "0,5A - 1,0A",
                                "speed": "240 mm²/p"
                        }
                ],
                "measured": {
                        "totalTimeStr": "1h21p40' (P1: 1h13p, P2: 8p40')",
                        "ammeterA": "3.4 - 3.5A (P1) | 0.5 - 1.0A (P2)",
                        "measuredSpeed": "50 - 65 mm²/p (P1) | 240 mm²/p (P2)",
                        "enteredOffsetP1": 0.092,
                        "enteredOffsetP2": 0.023,
                        "recommendedOffsetP1": 0.0945,
                        "recommendedOffsetP2": 0.0255,
                        "delta1Solid": 0.0225,
                        "equivalent1PassOffset": 0.1125,
                        "actualDimension": "Sau P1: 31.935mm (chừa 2.5μm/bên) | Sau P2: 31.945mm (to hơn 0.005mm)"
                },
                "notes": "H=75mm SCM420 cắt 2 Pass đối chứng khép kín 95% thông số Web App Tab 2. Sau Pass 1 đo 31.935mm (Path1=0.115mm, cối chừa đúng 2.5μm/bên). Bào mòn thép đặc P1: δ1=0.0225mm, quy đổi Offset 1P tương đương: 0.1125mm (khớp STT 16: δ=0.022mm). Pass 2 bóc tách 5.0μm/bên, phạt đỉnh núi lửa Rz1 với ampe êm 0.5-1.0A trong 8p40'. Thành phẩm lệch chỉ +2.5μm/bên. Offset 2 Pass chuẩn: P1=0.0945mm (hoặc giữ P1=0.092mm), P2=0.0255mm."
        },
        {
                "id": "5P-01",
                "name": "SCM440 | H=12mm | 5 Lần (Cắt Chày Kiểm Chứng Thực Tế)",
                "materialName": "SCM440 (28-32HRC)",
                "thickness": 12,
                "cutLength": "128mm",
                "passCount": 5,
                "multiPassDetails": [
                        {
                                "pass": "Pass 1",
                                "ti": 20,
                                "Po": 5,
                                "IP": 3,
                                "wire": 1,
                                "voltage": "High",
                                "vf": 65,
                                "maxSpeed": "150Hz",
                                "offset": 0.108,
                                "time": "19p50'",
                                "ampe": "4A",
                                "speed": "275-285 mm²/p"
                        },
                        {
                                "pass": "Pass 2",
                                "ti": 14,
                                "Po": 5,
                                "IP": 2,
                                "wire": 2,
                                "voltage": "Low",
                                "vf": 42,
                                "maxSpeed": "140Hz",
                                "offset": 0.018,
                                "time": "16p",
                                "ampe": "0,3A - 0,5A",
                                "speed": "232-340 mm²/p"
                        },
                        {
                                "pass": "Pass 3",
                                "ti": 6,
                                "Po": 8,
                                "IP": 1,
                                "wire": 3,
                                "voltage": "Low",
                                "vf": 35,
                                "maxSpeed": "120Hz",
                                "offset": 0.009,
                                "time": "--",
                                "ampe": "< 0,2A",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 4",
                                "ti": 2,
                                "Po": 12,
                                "IP": 1,
                                "wire": 3,
                                "voltage": "Low",
                                "vf": 25,
                                "maxSpeed": "100Hz",
                                "offset": 0.004,
                                "time": "--",
                                "ampe": "< 0,1A",
                                "speed": "--"
                        },
                        {
                                "pass": "Pass 5",
                                "ti": 1,
                                "Po": 16,
                                "IP": 1,
                                "wire": 3,
                                "voltage": "Low",
                                "vf": 20,
                                "maxSpeed": "80Hz",
                                "offset": 0.002,
                                "time": "--",
                                "ampe": "~ 0,05A",
                                "speed": "--"
                        }
                ],
                "measured": {
                        "totalTimeStr": "1h45p (Tổng 5 Pass)",
                        "ammeterA": "4A (P1) | 0.3-0.5A (P2) | <0.2A (P3) | <0.1A (P4) | ~0.05A (P5)",
                        "measuredSpeed": "275-285 (P1) | 232-340 (P2)",
                        "enteredOffsetP1": 0.108,
                        "enteredOffsetP2": 0.018,
                        "recommendedOffsetP1": 0.093,
                        "recommendedOffsetP2": 0.018,
                        "delta1Solid": 0.011,
                        "equivalent1PassOffset": 0.101,
                        "actualDimension": "Sau P1: 54.08mm (chừa 0.040mm/bên) | Sau P2: 54.045mm (gọt 0.0175mm/bên) | Sau P5: 54.030mm (to hơn lập trình 0.030mm)"
                },
                "notes": "H=12mm SCM440 cắt 5 Pass chày chu vi 128mm, tổng thời gian 1h45p. P1(Ton=20,Po=5,IP=3,High,VF=65) cào thép đặc δ1=0.011mm (Offset 1 Pass tương đương 0.101mm). P2(Ton=14,Po=5,IP=2,Low,VF=42) gọt đỉnh núi lửa 17.5μm/bên, Ampe 0.3-0.5A. P3-P5 gọt siêu mịn 7.5μm/bên. Kết thúc đo 54.030mm (chày to hơn lập trình 0.030mm -> dư 0.015mm/bên). Offset P1 chuẩn hiệu chỉnh: 0.093mm."
        }
    ];

    const WORKSHOP_CALIBRATION_MODEL = {
        kAmpe: 2.2857,               // Hệ số dòng Ampe thực tế xưởng (~4.0A với IP=5, Po=7)
        calibratedCm: 0.0111,        // Hệ số năng suất bóc tách phôi thực tế (mm3/J)
        calibratedKerfB: 0.276,      // Bề rộng rãnh cắt thực tế xưởng (mm)
        calibratedSparkGap: 0.048,   // Khe hở tia lửa thực tế xưởng (mm)
        speedCalibrationFactor: 1.0, // Hệ số tinh chỉnh tốc độ
        actualAmmeterReading: '≈ 4.0 A (Khớp kim đo thực tế xưởng)'
    };

    
    // HỆ THỐNG LAI TẠO DỮ LIỆU & NHÂN QUẢ BÙ DAO (RULE 06, 07, 08)
    // =========================================================================
    // HÀM TÍNH TOÁN DÒNG ĐIỆN AMPE KẾ MODEL VÒNG 5 (CHUẨN HÓA THỰC NGHIỆM XƯỞNG)
    // =========================================================================
    function calcTheoreticalAmpe(IP, Po, H, Volt) {
        const duty = 1.0 / (Po + 2.0);
        const u_arc = (Volt === 'Low' || Volt === 'L') ? 22.0 : 27.0;
        const eta_po = 1.0 - 0.33 * ((Po - 5.0) / 10.0);
        const eta_h = 1.0 - 0.08 * (H / (H + 20.0));
        const k_scale = 8.55;
        const ampe = IP * duty * k_scale * eta_po * (u_arc / 27.0) * eta_h;
        return Math.max(0.2, ampe);
    }

    function generateWorkshopRows(state) {
        const H = state.thickness;
        const passes = state.wsPassCount || 1;
        const strat = WS_STRATEGY_CONFIGS[state.wsStrategyLevel] || WS_STRATEGY_CONFIGS[4];
        const isHard = (state.wsMaterial || state.material) === 'SCM440';
        const wsRows = [];

        // 1.5. HE THONG CONG THUC TOAN - VAT LY NHIET DONG HOC EDM TOAN NANG (RULE 10 - VONG 5 CAN BANG TOAN CAU)
        // Hieu chuan tinh chinh tu toan bo Ngan hang Du lieu Thuc nghiem Xuong (Toi uu hoa SCM420 & SCM440)
        const C0 = 0.00200;          // Hang so mang cach dien ion hoa ban dau (+2.00 um)
        const K_ELEC = 0.00070;      // Nang luong xung don toi uu (mm/sqrt(us*A))
        const K_VF = 0.00210;        // He so bu tre buoc tien VF (+2.10 um / 10 vach VF so voi chuan 55)
        const K_VIBR = 0.00350;      // He so mo rong kerf do rung uon co hoc day Moly
        const K_H_CONF = 0.00650;    // He so gioi han ap luc thuy tinh ranh sau phoi cao (mm)
        const K_SPD = 0.00550;       // He so bu giam toc phoi sau (Speed < 150Hz khi H >= 110mm)
        const K_SEC_BASE = 0.160;    // He so danh lua thu cap theo mat xi deo tich tu (mm)
        const K_RZ = 0.00120;        // He so chieu sau ho ro nhap nho pha tho Pass 1
        const H_THRESH = 63.0;       // Nguong thau voi phun kep (H <= 63mm xoi sach phoi, H > 63mm moi sinh nghen phoi)
        const PO_THRESH = 8.0;       // Nguong chu ky nghi Po xa phoi (Po <= 7 sinh nghen mat xi)
        const S_EXP = 0.65;          // Luy thua suy giam do sau ranh nen mat xi
        const slag_mat = isHard ? 1.0 : 0.80;
        const DELTA_LOW = 0.0045;   // Hang so mang dien moi Volt Low (+4.5 um)
        const K_SLAG = K_SEC_BASE;  // Alias tuong thich kiem dinh he so nen mat xi

        // 1. Hệ thống Quy luật Vật lý Biến đổi Mượt mà & 4 Dải Ampe Tiêu Chuẩn (Rule 12)
        // Áp dụng cho Thép xưởng: SCM440 (28-32 HRC) vs SCM420 (HB < 200)
        let baseTon, basePo, baseIP, baseVF, baseGap, baseVolt;
        baseVolt = H <= 15 ? 'Low' : 'High';

        if (H <= 170) {
            // PHÂN VÙNG 1 (H <= 170mm): CÔNG THỨC TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC EDM TOÀN NĂNG (RULE 10)
            if (isHard) {
                if (H <= 15) baseTon = Math.round(16 + (H - 5) * (20 - 16) / (15 - 5));
                else if (H <= 30) baseTon = Math.round(20 + (H - 15) * (32 - 20) / (30 - 15));
                else if (H <= 60) baseTon = Math.round(32 + (H - 30) * (50 - 32) / (60 - 30));
                else if (H <= 100) baseTon = Math.round(50 + (H - 60) * (82 - 50) / (100 - 60));
                else if (H <= 140) baseTon = Math.round(82 + (H - 100) * (120 - 82) / (140 - 100));
                else if (H <= 165) baseTon = Math.round(120 + (H - 140) * (135 - 120) / (165 - 140));
                else baseTon = 135;
            } else {
                if (H <= 15) baseTon = Math.round(14 + (H - 5) * (18 - 14) / (15 - 5));
                else if (H <= 30) baseTon = Math.round(18 + (H - 15) * (28 - 18) / (30 - 15));
                else if (H <= 60) baseTon = Math.round(28 + (H - 30) * (44 - 28) / (60 - 30));
                else if (H <= 100) baseTon = Math.round(44 + (H - 60) * (72 - 44) / (100 - 60));
                else if (H <= 140) baseTon = Math.round(72 + (H - 100) * (110 - 72) / (140 - 100));
                else baseTon = 120;
            }

            const isMultiPass = (passes >= 3);
            if (!isMultiPass) {
                // === QUY TRÌNH 1 PASS & 2 PASS (CHẾ ĐỘ TIÊU CHUẨN) ===
                // H5-30: Ampe 2.0 - 2.5A
                // H30-60: Ampe 2.5 - 3.0A
                // H60-100: Ampe 3.0 - 3.5A
                // H100-160: Ampe 3.0 - 3.5A
                if (H <= 15) {
                    baseIP = 3; basePo = 6; // Ampe ~ 2.2A (Volt Low)
                } else if (H <= 30) {
                    baseIP = 3; basePo = 7; // Ampe ~ 2.4A (Volt High)
                } else if (H <= 60) {
                    baseIP = 4; basePo = 8; // Ampe ~ 2.8A (Volt High)
                } else if (H <= 100) {
                    baseIP = 4; basePo = 7; // Ampe ~ 3.2A (Volt High)
                } else {
                    // Phân phối Toff từ H100 đến H170 mượt mà từ 8 đến 11, Ampe luôn 3.0 - 3.5A
                    if (H <= 120) {
                        baseIP = 5; basePo = 8;  // Ampe ~ 3.5A
                    } else if (H <= 140) {
                        baseIP = 5; basePo = 9;  // Ampe ~ 3.2A
                    } else if (H <= 155) {
                        baseIP = 6; basePo = 10; // Ampe ~ 3.5A
                    } else {
                        baseIP = 6; basePo = 11; // Ampe ~ 3.2A
                    }
                }
            } else {
                // === QUY TRÌNH 3 PASS ĐẾN 5 PASS (CHẾ ĐỘ TIÊU CHUẨN) ===
                // H5-30: Ampe 3.0 - 3.5A
                // H30-100: Ampe 3.5 - 4.0A
                // H100-160: Ampe 3.0 - 3.5A
                if (H <= 15) {
                    baseIP = 4; basePo = 5; // Ampe ~ 3.5A (Volt Low)
                } else if (H <= 30) {
                    baseIP = 4; basePo = 7; // Ampe ~ 3.2A (Volt High)
                } else if (H <= 60) {
                    baseIP = 4; basePo = 6; // Ampe ~ 3.7A (Volt High)
                } else if (H <= 100) {
                    baseIP = 5; basePo = H <= 80 ? 7 : 8; // Ampe ~ 4.0A (H<=80) hoặc 3.6A (H>80)
                } else {
                    // Phân phối Toff từ H100 đến H170 mượt mà từ 8 đến 11, Ampe an toàn 3.0 - 3.5A
                    if (H <= 120) {
                        baseIP = 5; basePo = 8;  // Ampe ~ 3.5A
                    } else if (H <= 140) {
                        baseIP = 5; basePo = 9;  // Ampe ~ 3.2A
                    } else if (H <= 155) {
                        baseIP = 6; basePo = 10; // Ampe ~ 3.5A
                    } else {
                        baseIP = 6; basePo = 11; // Ampe ~ 3.2A
                    }
                }
            }

            // Duong cong VF thuan chieu vat ly: phoi mong H<=20mm VF trung binh (50-52), tang dan em diu len 70 tai H=170mm
            const vf_start = isHard ? 52 : 50;
            if (H <= 20) baseVF = vf_start;
            else baseVF = Math.round(vf_start + (H - 20) * (70 - vf_start) / (170 - 20));

            // Tinh toan gioi han tan so p1_hz de ap dung he so giam toc phoi sau d_spd
            let p1_hz;
            if (H <= 40) p1_hz = 200;
            else if (H <= 170) p1_hz = Math.round(200 - (H - 40) * (200 - 150) / (170 - 40));
            else p1_hz = Math.round(150 - (Math.min(300, H) - 170) * (150 - 50) / (300 - 170));

            const u_ratio_base = baseVolt === 'High' ? 1.0 : 0.815;
            const d_elec_base = K_ELEC * Math.sqrt(baseTon * baseIP) * u_ratio_base;
            const d_vf_base = K_VF * ((baseVF - 55.0) / 10.0);
            const d_vibr_base = K_VIBR * Math.pow(H / 100.0, 2) * (baseIP / 5.0);
            const d_h_conf_base = - K_H_CONF * (H / 100.0);
            const d_spd_base = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;
            const h_starve_base = Math.max(0.0, (H - H_THRESH) / 100.0);
            const po_shortage_base = Math.max(0.0, (PO_THRESH - basePo) / 10.0);
            const mat_boost_base = isHard ? 1.0 : 2.60;
            const d_sec_base = K_SEC_BASE * Math.pow(h_starve_base, S_EXP) * po_shortage_base * mat_boost_base;
            baseGap = C0 + d_elec_base + d_vf_base + d_vibr_base + d_h_conf_base + d_spd_base + d_sec_base;

        } else {
            // PHÂN VÙNG 2 (H > 170mm): PHƯƠNG PHÁP THỐNG KÊ HỘI TỤ THỰC NGHIỆM XƯỞNG
            baseTon = isHard ? 135 : 120;
            baseIP = 6;
            basePo = Math.round(11 + (H - 170) * (12 - 11) / (300 - 170));
            baseVF = Math.min(75, Math.round(70 + (H - 170) * (75 - 70) / (300 - 170)));
            baseGap = 0.0187 + (H - 170) * (0.0250 - 0.0187) / (300 - 170);
        }

        // Apply Tab 2 7-level Strategy strictly adhering to Regular Ammeter Stepping (ΔI = 0.5 - 0.7A)
        let Ton, Po, IP, Volt, VF;
        const lvl = state.wsStrategyLevel || 4;

        if (lvl === 4) {
            Ton = baseTon; Po = basePo; IP = baseIP; Volt = baseVolt; VF = baseVF;
        } else if (lvl === 3) {
            Ton = Math.max(8, baseTon - 6); Po = basePo + 2; IP = baseIP; Volt = baseVolt; VF = Math.max(25, baseVF - 5);
        } else if (lvl === 2) {
            Ton = Math.max(8, baseTon - 12); IP = Math.max(1, baseIP - 1); Po = basePo + 1; Volt = H <= 40 ? 'Low' : baseVolt; VF = Math.max(25, baseVF - 10);
        } else if (lvl === 1) {
            Ton = Math.max(6, baseTon - 18); IP = Math.max(1, baseIP - 2); Po = basePo + 3; Volt = 'Low'; VF = Math.max(20, baseVF - 15);
        } else if (lvl === 5) {
            Ton = baseTon + 6; Po = Math.max(3, basePo - 1); IP = baseIP; Volt = baseVolt; VF = Math.min(85, baseVF + 5);
        } else if (lvl === 6) {
            Ton = baseTon + 14; Po = Math.max(3, basePo - 2); IP = baseIP; Volt = 'High'; VF = Math.min(88, baseVF + 10);
        } else {
            Ton = baseTon + 22;
            if (H <= 60 && baseIP <= 4) {
                IP = baseIP + 1; Po = Math.max(3, basePo - 1);
            } else {
                IP = baseIP; Po = Math.max(3, basePo - 3);
            }
            Volt = 'High'; VF = Math.min(90, baseVF + 15);
        }

        // TÍNH TOÁN LƯỢNG CÀO PHÔI THỰC TẾ PASS 1 (GAP1 / DELTA1)
        let gap;
        if (H <= 170) {
            const u_ratio_actual = Volt === 'High' ? 1.0 : 0.815;
            const d_elec_actual = K_ELEC * Math.sqrt(Ton * IP) * u_ratio_actual;
            const d_vf_actual = K_VF * ((VF - 55.0) / 10.0);
            const d_vibr_actual = K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);
            const d_h_conf_actual = - K_H_CONF * (H / 100.0);
            const d_spd_actual = (H >= 110 && p1_hz < 150) ? - K_SPD * ((150.0 - p1_hz) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;
            const h_starve_actual = Math.max(0.0, (H - H_THRESH) / 100.0);
            const po_shortage_actual = Math.max(0.0, (PO_THRESH - Po) / 10.0);
            const mat_boost_actual = isHard ? 1.0 : 2.60;
            const d_sec_actual = K_SEC_BASE * Math.pow(h_starve_actual, S_EXP) * po_shortage_actual * mat_boost_actual;
            gap = C0 + d_elec_actual + d_vf_actual + d_vibr_actual + d_h_conf_actual + d_spd_actual + d_sec_actual;
        } else {
            const stratGapMods = {1: -0.009, 2: -0.006, 3: -0.003, 4: 0.0, 5: +0.003, 6: +0.006, 7: +0.010};
            gap = baseGap + (stratGapMods[lvl] || 0.0);
        }

        // Dynamic Calculation of Pass 2 Electrical Params & Physical Offset (Rule 03, 04, 10)
        let p2_ton;
        if (isHard) {
            if (H <= 20) p2_ton = 12;
            else if (H <= 60) p2_ton = 16;
            else if (H <= 120) p2_ton = 20;
            else if (H <= 140) p2_ton = 24;
            else if (H <= 165) p2_ton = Math.round(24 + (H - 140) * (40 - 24) / (165 - 140));
            else p2_ton = 40;
        } else {
            if (H <= 20) p2_ton = 10;
            else if (H <= 60) p2_ton = 14;
            else if (H <= 120) p2_ton = 18;
            else if (H <= 140) p2_ton = 22;
            else p2_ton = 36;
        }

        let p2_po = isHard ? (H <= 40 ? 5 : (H <= 120 ? 6 : 7)) : (H <= 40 ? 6 : 7);
        let p2_ip = H <= 60 ? 2 : 3;
        let p2_volt = H <= 40 ? 'Low' : 'High';
        let p2_vf = isHard ? (H <= 60 ? 40 : 36) : (H <= 60 ? 36 : 32);


        if (state.wsStrategyLevel === 1) { p2_ton = Math.max(2, p2_ton - 2); p2_ip = Math.max(1, p2_ip - 1); }
        else if (state.wsStrategyLevel === 5) { p2_ton += 4; }

        // BÙ DAO PASS 2 (O2 - REMAIN / LƯỢNG CHỪA PHÔI):
        // Tuân thủ triệt để Quy tắc Núi Lửa (Rule 14 & Rule 16): O2 = Rz1 + delta2
        // Khi Ton/IP của Pass 1 biến thiên, Rz1 tự động biến thiên và kéo theo O2 tính toán lại động học
        let calculated_O2;
        if (H <= 170) {
            const u_ratio_actual = Volt === 'High' ? 1.0 : (22.0 / 27.0);
            const Rz_p1 = K_RZ * Math.sqrt(Ton * IP) * u_ratio_actual;
            const u_ratio_p2 = p2_volt === 'High' ? 1.0 : 0.815;
            const d_elec_p2 = K_ELEC * Math.sqrt(p2_ton * p2_ip) * u_ratio_p2;
            const d_h_conf_p2 = - K_H_CONF * (H / 100.0) * 0.5;
            const delta_2_calc = C0 + d_elec_p2 + d_h_conf_p2;

            // Giới hạn trần lượng chừa Pass 2 để triệt tiêu hoàn toàn nguy cơ trượt gió (hụt tia lửa) ở phôi dày (Bài học STT 2P-11 vs 2P-12)
            // Dải H <= 60mm: trần an toàn 0.025mm. Từ H=60 đến 165mm thu hẹp êm dịu về đúng 0.015mm
            const maxCeilingO2 = H <= 60 ? 0.025 : Math.max(0.015, 0.025 - (H - 60) * (0.025 - 0.015) / (165 - 60));
            calculated_O2 = Math.max(0.015, Math.min(Rz_p1 + Math.max(0.005, Math.min(0.015, delta_2_calc)), maxCeilingO2));
        } else {
            calculated_O2 = 0.015;
        }

        // TÍNH TOÁN DÃY GIỚI HẠN TẦN SỐ (HZ) THEO NGUYÊN TẮC CÔNG NGHỆ XƯỞNG
        // 1. Pass 1 (Cắt phá): 150 - 200 Hz (H <= 170) để luôn lớn hơn tốc độ cắt, không kìm hãm công suất phóng điện
        // p1_hz da duoc tinh toan o tren
        if (H <= 40) {
            p1_hz = 200;
        } else if (H <= 170) {
            p1_hz = Math.round(200 - (H - 40) * (200 - 150) / (170 - 40));
        } else {
            p1_hz = Math.round(150 - (Math.min(300, H) - 170) * (150 - 50) / (300 - 170));
        }

        // 2. Pass tinh cuối cùng:
        // H <= 170: 80 - 100 Hz (H=5 -> 100, H=170 -> 80)
        // H > 170: 60 - 80 Hz (H=170 -> 80, H=300 -> 60)
        let final_hz;
        if (H <= 170) {
            let raw_final = 100 - (Math.max(5, H) - 5) * (100 - 80) / (170 - 5);
            final_hz = Math.round(raw_final / 5.0) * 5;
        } else {
            let raw_final = 80 - (Math.min(300, H) - 170) * (80 - 60) / (300 - 170);
            final_hz = Math.round(raw_final / 5.0) * 5;
        }

        // 3. Bước nhảy delta_hz ngược từ pass cuối cùng về trước:
        // 5 Pass: từng 15 Hz (Ví dụ H20: 100 -> 115 -> 130 -> 145)
        // 4 Pass: từng 20 Hz (Ví dụ H20: 100 -> 120 -> 140)
        // 3 Pass: từng 25 Hz (Ví dụ H20: 100 -> 125)
        // 2 Pass: Pass 2 = final_hz (Ví dụ H20: 100, H85: 90, H165: 80)
        const stepDeltaMap = { 5: 15, 4: 20, 3: 25, 2: 0 };
        const stepDelta = stepDeltaMap[passes] || 0;

        const multiPassHzList = new Array(passes);
        multiPassHzList[0] = p1_hz;
        if (passes > 1) {
            multiPassHzList[passes - 1] = final_hz;
            for (let p = passes - 2; p >= 1; p--) {
                const stepsFromFinal = (passes - 1) - p;
                multiPassHzList[p] = final_hz + stepsFromFinal * stepDelta;
            }
        }

        // GENERATE ROWS FOR MULTI-PASS (1 TO 5 PASSES)
        for (let i = 0; i < passes; i++) {
            let row = { passName: `Pass ${i + 1}`, badgeClass: i === 0 ? 'badge-primary' : 'badge-secondary' };
            if (i === 0) {
                let O1 = 0.090 + gap;
                let toff = Ton * (Po + 1);
                let true_cycle = Ton + toff;
                let duty = Ton / true_cycle;
                
                // HỆ PHƯƠNG TRÌNH TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC FC THỰC & FC MÁY (VÒNG 6 TỐI ƯU HỘI TỤ 7.8%)
                const c_scale = 0.80;
                const eta_base = c_scale * Math.pow(Math.max(1, Ton) / 50.0, 0.15) * Math.pow(IP / 4.0, 0.16);

                let eta_h;
                if (isHard) {
                    eta_h = Math.max(0.55, 1.0 - Math.max(0, H - 40) * 0.000687);
                } else {
                    eta_h = Math.max(0.40, 1.0 - Math.max(0, H - 40) * 0.001975);
                }

                const h_choke = Math.max(0.0, (H - 63.0) / 100.0);
                const po_choke = Math.max(0.0, (8.0 - Po) / 10.0);
                const mat_choke = isHard ? 1.0 : 4.0;
                const slag_drag = 0.90 * Math.pow(h_choke, 0.65) * po_choke * mat_choke;
                const k_drag = Math.max(0.35, 1.0 - slag_drag);

                let k_vf;
                if (VF >= 55.0) {
                    k_vf = 1.0 + (VF - 55.0) * 0.0020;
                } else {
                    k_vf = 1.0 + (VF - 55.0) * 0.0050;
                }

                const k_duty = Math.pow(duty / (1.0 / 7.0), 0.0205);
                const eta_eff = eta_base * eta_h * k_drag * k_vf * k_duty;

                const u_arc = Volt === 'Low' ? 22 : 27;
                const i_peak = IP * 2.8;
                const power_watts = u_arc * i_peak * duty;

                const Cm = 0.0135; // Hằng số bóc phôi xưởng chuẩn hóa Vòng 6
                const B = 0.23;
                const mrr_vol = 60 * Cm * power_watts * eta_eff;
                const speedArea_raw = mrr_vol / B;

                const feedRate_calc = speedArea_raw / H;
                const ft_max = multiPassHzList[0] * 0.060;
                const feedRate_final = Math.min(feedRate_calc, ft_max);

                let speedArea = Math.round(feedRate_final * H);
                let speedAreaH40 = Math.round(feedRate_final * 40);
                let feedRate = feedRate_final.toFixed(2);

                row.hz = multiPassHzList[0];

                let calculatedAmpe = calcTheoreticalAmpe(IP, Po, H, Volt);
                row.ampe = calculatedAmpe.toFixed(1);
                row.ti = Ton;
                row.Po = Po;
                row.IP = IP;
                row.Voltage = Volt;
                row.VF = VF;
                row.Wire = strat.Wire || '1';
                row.offsetText = O1.toFixed(3);
                row.speedArea = speedArea;
                row.speedAreaH40 = speedAreaH40;
                row.feedRate = feedRate;
                row.Ra = passes === 1 ? (strat.RaStr || '~ 2.8') : (isHard ? '1.8 - 2.2' : '2.0 - 2.5');
                
                row._gap = gap;
                row._duty = duty;
                row._power_watts = power_watts;
                row._eta_eff = eta_eff;

            } else if (i === 1) {
                // PASS 2: BÁN TINH 1 (SỬA CÔN & PHẠT CHÓP ĐỈNH NÚI LỬA)
                row.ti = p2_ton;
                row.Po = p2_po;
                row.IP = p2_ip;
                row.Voltage = p2_volt;
                row.VF = p2_vf;
                row.Wire = '2';
                row.offsetText = calculated_O2.toFixed(3);
                
                // Chuẩn hóa Tần số giới hạn và Hiển thị theo Máy Xưởng (Rule 02: Fc máy = Hz * 2.4)
                let p2_hz = multiPassHzList[1];
                let p2SpeedAreaH40 = Math.round(p2_hz * 2.4);
                let p2FeedRate = (p2_hz * 0.060).toFixed(2);
                let p2SpeedArea = Math.round(parseFloat(p2FeedRate) * H);

                row.speedArea = p2SpeedArea;
                row.speedAreaH40 = p2SpeedAreaH40;
                row.feedRate = p2FeedRate;
                row.Ra = passes === 2 ? (isHard ? '1.4 - 1.8' : '1.6 - 2.0') : '~ 1.8 - 2.0';
                row.hz = p2_hz;

                if (p2_volt === 'Low') {
                    row.ampe = '< 0.2';
                } else if (H > 140) {
                    row.ampe = '0.5 - 1.5';
                } else {
                    row.ampe = '0.5 - 1.0';
                }

            } else if (i === 2) {
                // PASS 3: CẮT TINH 1 / BÁN TINH 2 (SAN PHẲNG VI SÓNG)
                let p3_ton = H <= 40 ? 6 : (H <= 120 ? 8 : 10);
                let p3_po = isHard ? (H <= 60 ? 8 : 10) : (H <= 60 ? 10 : 12);
                let p3_ip = H <= 80 ? 1 : 2;
                let p3_vf = isHard ? 35 : 30;
                let p3_O = H <= 20 ? 0.009 : (H <= 80 ? 0.010 : 0.012);
                
                let p3_hz = multiPassHzList[2];
                let p3SpeedAreaH40 = Math.round(p3_hz * 2.4);
                let p3FeedRate = (p3_hz * 0.060).toFixed(2);
                let p3SpeedArea = Math.round(parseFloat(p3FeedRate) * H);

                row.ti = p3_ton;
                row.Po = p3_po;
                row.IP = p3_ip;
                row.Voltage = 'Low';
                row.VF = p3_vf;
                row.Wire = '3';
                row.offsetText = p3_O.toFixed(3);
                row.speedArea = p3SpeedArea;
                row.speedAreaH40 = p3SpeedAreaH40;
                row.feedRate = p3FeedRate;
                row.Ra = passes === 3 ? (isHard ? '1.0 - 1.2' : '1.2 - 1.4') : '~ 1.0 - 1.2';
                row.hz = p3_hz;
                row.ampe = '< 0.2';

            } else if (i === 3) {
                // PASS 4: SIÊU TINH (SUPER FINISH - XÓA BIẾN TRẮNG)
                let p4_ton = H <= 60 ? 2 : 3;
                let p4_po = isHard ? 12 : 15;
                let p4_vf = isHard ? 25 : 22;
                let p4_O = H <= 40 ? 0.004 : 0.005;

                let p4_hz = multiPassHzList[3];
                let p4SpeedAreaH40 = Math.round(p4_hz * 2.4);
                let p4FeedRate = (p4_hz * 0.060).toFixed(2);
                let p4SpeedArea = Math.round(parseFloat(p4FeedRate) * H);

                row.ti = p4_ton;
                row.Po = p4_po;
                row.IP = 1;
                row.Voltage = 'Low';
                row.VF = p4_vf;
                row.Wire = '3';
                row.offsetText = p4_O.toFixed(3);
                row.speedArea = p4SpeedArea;
                row.speedAreaH40 = p4SpeedAreaH40;
                row.feedRate = p4FeedRate;
                row.Ra = passes === 4 ? (isHard ? '0.6 - 0.8' : '0.8 - 1.0') : '~ 0.6 - 0.8';
                row.hz = p4_hz;
                row.ampe = '< 0.1';

            } else if (i === 4) {
                // PASS 5: ĐÁNH BÓNG GƯƠNG (MIRROR POLISH)
                let p5_ton = H <= 80 ? 1 : 2;
                let p5_po = isHard ? 16 : 20;
                let p5_vf = isHard ? 20 : 18;
                let p5_O = H <= 60 ? 0.002 : 0.003;

                let p5_hz = multiPassHzList[4];
                let p5SpeedAreaH40 = Math.round(p5_hz * 2.4);
                let p5FeedRate = (p5_hz * 0.060).toFixed(2);
                let p5SpeedArea = Math.round(parseFloat(p5FeedRate) * H);

                row.ti = p5_ton;
                row.Po = p5_po;
                row.IP = 1;
                row.Voltage = 'Low';
                row.VF = p5_vf;
                row.Wire = '3';
                row.offsetText = p5_O.toFixed(3);
                row.speedArea = p5SpeedArea;
                row.speedAreaH40 = p5SpeedAreaH40;
                row.feedRate = p5FeedRate;
                row.Ra = isHard ? '≤ 0.4 - 0.6' : '≤ 0.5 - 0.7';
                row.hz = p5_hz;
                row.ampe = '~ 0.05';
            }
            wsRows.push(row);
        }
        return wsRows;
    }

    function calculateWorkshopEDM(state) {
        // Delegate logic perfectly to the Pass 1 generation to ensure zero mismatches
        const wsRows = generateWorkshopRows(state);
        const p1 = wsRows[0];
        
        const L = state.cutLength || 100;
        const H = state.thickness;

        const ti_w = p1.ti;
        const Po_w = p1.Po;
        const IP_w = p1.IP;
        const Volt_w = p1.Voltage;
        const VF_w = p1.VF;
        const Wire_w = 1;
        const gap_w = p1._gap;

        // 2. Tính toán các đặc trưng điện động lực học (Toff = Pon * (Poff + 1))
        const toff_w = ti_w * (Po_w + 1);
        const cycle_w = ti_w + toff_w;
        const cycle_ms_w = (cycle_w / 1000).toFixed(3);
        const freq_hz_w = Math.round(1000000 / cycle_w);
        const freq_khz_w = (freq_hz_w / 1000).toFixed(2);
        const duty_factor_w = (p1._duty * 100).toFixed(1);

        const u_arc_w = Volt_w === 'Low' ? 22 : 27;
        const i_peak_w = IP_w * 2.8;
        const we_mj_w = ((u_arc_w * i_peak_w * ti_w) / 1000).toFixed(2);
        const we_score_w = ti_w * IP_w;
        const power_watts_w = p1._power_watts.toFixed(2);

        // 3. Dòng Ampe xưởng (Matches Factory exactly)
        const i_tb_high = p1.ampe;
        const i_tb_std = (i_peak_w * p1._duty * 0.75).toFixed(1);

        // 4. Năng suất bóc phôi Fc, Tốc độ tiến bàn Ft
        const feedRate_w = p1.feedRate;
        const speedArea_w = p1.speedArea;
        
        let Cm = 0.012; // Thép xưởng SCM420/440
        const B = 0.23;
        const mrr_vol_w = (60 * Cm * p1._power_watts * p1._eta_eff).toFixed(2);
        
        let total_ws_time_min = 0;
        wsRows.forEach(r => {
            const f = parseFloat(r.feedRate);
            if (f > 0) {
                total_ws_time_min += L / f;
            }
        });

        // 5. Độ nhám bề mặt Ra & Bù dao Offset
        const lastRow = wsRows[wsRows.length - 1];
        const Ra_w = lastRow.Ra;
        const offset_w = p1.offsetText;
        const kerfB_w = (0.180 + 2 * gap_w).toFixed(3);

        return {
            ti: ti_w,
            Po: Po_w,
            toff: toff_w,
            IP: IP_w,
            Voltage: Volt_w,
            VF: VF_w,
            Wire: Wire_w,
            cycle: cycle_w,
            cycle_ms: cycle_ms_w,
            freq_hz: freq_hz_w,
            freq_khz: freq_khz_w,
            duty_factor: duty_factor_w,
            u_arc: u_arc_w,
            i_peak: i_peak_w,
            we_mj: we_mj_w,
            we_score: we_score_w,
            power_watts: power_watts_w,
            i_tb_std,
            i_tb_high,
            speedArea: speedArea_w,
            feedRate: feedRate_w,
            time_min: total_ws_time_min,
            Ra: Ra_w,
            sparkGap: gap_w.toFixed(4),
            offset: offset_w,
            kerfB: kerfB_w
        };
    }

    function computeTheoryKinematics({ ti, Po, IP, Voltage, VF, Wire, H, material, cutLength = 100 }) {
        const isHard = material === 'SCM440';
        const isCopper = material === 'COPPER';
        const isAlu = material === 'ALUMINUM';

        // 1. Chu kỳ & Thời gian nghỉ (Chuẩn máy AutoCut: Toff = Pon * (Poff + 1))
        const toff = ti * (Po + 1); // μs
        const cycle = ti + toff; // μs
        const cycle_ms = (cycle / 1000).toFixed(3); // ms
        const freq_hz = Math.round(1000000 / cycle);
        const freq_khz = (freq_hz / 1000).toFixed(2);
        const duty_factor = (ti / cycle) * 100; // η (%)

        // 2. Điện áp & Dòng điện (Mục I tailieu.txt)
        const u_arc = Voltage === 'Low' ? 22 : 27; // V
        const i_peak = IP * 2.8; // A
        const we_mj = (u_arc * i_peak * ti) / 1000; // mJ
        const we_score = ti * IP;

        // 3. Công suất phóng điện trung bình Ptb (Watts = J/s)
        // Ptb = U_arc * I_peak * η = U_arc * (IP * 2.8) * [1 / (Po + 2)]
        const power_watts = u_arc * i_peak * (duty_factor / 100);
        const power_score = Math.round(freq_hz * we_score);

        // 4. Dòng điện chỉ thị Ampe kế (Itb thực tế)
        const i_tb_std = (i_peak * (duty_factor / 100) * 0.75).toFixed(1);
        const i_tb_high = (i_peak * (duty_factor / 100) * 1.85).toFixed(1);

        // 5. NĂNG SUẤT BÓC PHÔI THEO TAILIEU.TXT (Dòng 207-258):
        // Fc = (60 * Cm * Ptb * η_eff) / B
        let Cm = 0.012; // Thép SCM420/SCM440: 0.012 mm3/J (Theo phép nhân chuẩn dòng 247 tailieu.txt)
        if (isCopper) Cm = 0.015; // Đồng: 0.015 mm3/J
        if (isAlu) Cm = 0.028; // Nhôm: 0.028 mm3/J

        // Bề rộng rãnh cắt thực tế B = Phi_dây + 2 * g = 0.18 + 2 * 0.025 = 0.23 mm (Dòng 223 & 343 tailieu.txt)
        const B = 0.23;

        // Hiệu suất nhiệt hữu dụng η_eff (Dòng 226 tailieu.txt: 0.70 - 0.85)
        // Khớp chính xác 100% các ví dụ TH1 (Ton=32 -> 105 mm2/p), TH2 (Ton=40 -> 115 mm2/p), TH3 (Ton=50 -> 125 mm2/p)
        let eta_eff = 0.85 * Math.pow(Math.max(1, ti) / 50, 0.40);
        if (ti > 80) eta_eff = Math.min(0.95, eta_eff);
        if (H > 100) eta_eff *= Math.max(0.72, 1.0 - (H - 100) * 0.0012);

        // Thể tích kim loại bóc tách trong 1 phút MRR_vol (mm3/p) (Dòng 247 tailieu.txt)
        const mrr_vol = 60 * Cm * power_watts * eta_eff;

        // Năng suất cắt diện tích Fc (mm2/p) (Dòng 252 tailieu.txt)
        const speedArea = Math.round(mrr_vol / B);

        // Tốc độ tiến bàn Ft = Fc / H (mm/p) (Dòng 257 tailieu.txt)
        const feedRate = (speedArea / H).toFixed(2);
        const time_min = cutLength / parseFloat(feedRate);

        // 6. Độ nhám bề mặt Ra
        let ra_center;
        if (isHard) ra_center = 1.0 + 0.0125 * we_score;
        else if (isCopper) ra_center = 1.0 + 0.0115 * we_score;
        else if (isAlu) ra_center = 1.4 + 0.0145 * we_score;
        else ra_center = 1.2 + 0.0135 * we_score;

        const ra_low = Math.max(0.6, (ra_center - 0.3)).toFixed(1);
        const ra_high = (ra_center + 0.3).toFixed(1);
        const Ra = `${ra_low} - ${ra_high}`;

        const sparkGap_num = 0.015 + 0.00035 * ti * (IP / 3) + (Voltage === 'High' ? 0.004 : 0.001);
        const sparkGap = sparkGap_num.toFixed(3);

        return {
            ti, Po, toff, IP, Voltage, VF, Wire,
            cycle, cycle_ms,
            freq_hz, freq_khz,
            duty_factor: duty_factor.toFixed(1),
            u_arc, i_peak,
            we_mj: we_mj.toFixed(2),
            we_score,
            power_watts: power_watts.toFixed(1),
            power_score,
            i_tb_std,
            i_tb_high,
            speedArea,
            feedRate,
            time_min,
            Ra,
            sparkGap,
            mrr_vol: mrr_vol.toFixed(2),
            B: B.toFixed(3),
            Cm,
            eta_eff: eta_eff.toFixed(2)
        };
    }

    // 5b. Mô hình tính toán Vật lý Động học EDM Thống nhất cho mọi chế độ (Chuẩn Hãng, Tự Nhập, Workshop)
    function computePulseKinematics({ ti, Po, IP, Voltage, VF, Wire, H, material, cutLength = 100 }) {
        const isHard = material === 'SCM440';
        const isCopper = material === 'COPPER';
        const isAlu = material === 'ALUMINUM';

        // 1. Chu kỳ xung T và Thời gian nghỉ Toff (Chuẩn máy AutoCut: Toff = Pon * (Poff + 1))
        const toff = ti * (Po + 1); // μs
        const cycle = ti + toff; // μs
        const cycle_ms = (cycle / 1000).toFixed(3); // ms
        const freq_hz = Math.round(1000000 / cycle);
        const freq_khz = (freq_hz / 1000).toFixed(2);
        const duty_factor = (ti / cycle) * 100;

        // 2. Điện áp hồ quang, Dòng đỉnh, Năng lượng tia We
        const u_arc = Voltage === 'Low' ? 22 : 27;
        const i_peak = IP * 2.8; // Amperes
        const we_mj = (u_arc * i_peak * ti) / 1000; // mJ
        const we_score = ti * IP;

        // 3. Công suất phát trung bình Ptb
        const power_watts = (freq_hz * we_mj) / 1000; // Watts
        const power_score = Math.round(freq_hz * we_score);

        // 4. Dòng điện chỉ thị Ampe kế (Itb thực tế) - Tính toán động học chính xác 100%
        // Tủ tiêu chuẩn: Itb_std = I_peak * duty * 0.75
        // Tủ công suất cao / Xưởng: Itb_high = I_peak * duty * 1.85 (Khớp thực tế ~3.8-4.3A khi cắt thô)
        const i_tb_std = (i_peak * (duty_factor / 100) * 0.75).toFixed(1);
        const i_tb_high = (i_peak * (duty_factor / 100) * 1.85).toFixed(1);

        // 5. Baseline Năng suất bóc phôi Fc (mm2/p) và Tốc độ tiến bàn Ft (mm/p)
        let standardFc_baseline = 115;
        if (isAlu) standardFc_baseline = 155;
        else if (isCopper) standardFc_baseline = 95;
        else if (isHard) standardFc_baseline = 125;

        // Hiệu suất theo chiều dày phôi H
        let heightEfficiency = 1.0;
        if (H > 100) {
            heightEfficiency = Math.max(0.70, 1.0 - (H - 100) * 0.0012);
        } else if (H < 25) {
            heightEfficiency = Math.max(0.75, 0.85 + H * 0.006);
        }

        // Điểm chuẩn Cấp 6 cơ sở
        let base_ti = 32;
        if (isAlu) base_ti = 26;
        else if (isCopper) base_ti = 36;
        const base_Po = 6;
        const base_IP = 4;
        const base_VF = isAlu || isHard ? 65 : 60;
        const base_cycle = base_ti * (1 + base_Po);
        const base_freq = 1000000 / base_cycle;
        const base_we = (27 * (base_IP * 2.8) * base_ti) / 1000;
        const base_power = (base_freq * base_we) / 1000;

        const power_ratio = power_watts / base_power;
        const we_ratio = we_mj / base_we;
        const vf_factor = 1 + (VF - base_VF) / 250;

        let speedArea = Math.round(standardFc_baseline * heightEfficiency * power_ratio * Math.pow(we_ratio, 0.12) * vf_factor);
        if (ti > 70 && H < 60) speedArea = Math.round(speedArea * 0.88);
        if (Po < 4 && H > 80) speedArea = Math.round(speedArea * 0.85);

        const feedRate = (speedArea / H).toFixed(2);
        const time_min = cutLength / parseFloat(feedRate);

        // 6. Độ nhám bề mặt Ra (Hàm toán học liên tục theo we_score)
        let ra_center;
        if (isHard) ra_center = 1.0 + 0.0125 * we_score;
        else if (isCopper) ra_center = 1.0 + 0.0115 * we_score;
        else if (isAlu) ra_center = 1.4 + 0.0145 * we_score;
        else ra_center = 1.2 + 0.0135 * we_score; // SCM420

        const ra_low = Math.max(0.6, (ra_center - 0.3)).toFixed(1);
        const ra_high = (ra_center + 0.3).toFixed(1);
        const Ra = `${ra_low} - ${ra_high}`;

        // 7. Khe hở tia lửa sparkGap (δ)
        const sparkGap = (0.015 + 0.00035 * ti * (IP / 3) + (Voltage === 'High' ? 0.004 : 0.001)).toFixed(3);

        return {
            ti, Po, toff, IP, Voltage, VF, Wire,
            cycle, cycle_ms,
            freq_hz, freq_khz,
            duty_factor: duty_factor.toFixed(1),
            u_arc, i_peak,
            we_mj: we_mj.toFixed(2),
            we_score,
            power_watts: power_watts.toFixed(1),
            power_score,
            i_tb_std,
            i_tb_high,
            speedArea,
            feedRate,
            time_min,
            Ra,
            sparkGap
        };
    }

    // Tự động điền Chế độ "Bề Mặt Mịn / Ưu Tiên Phẳng (Cấp 5/11)" làm mặc định cho ô nhập riêng
    function populateSmoothCustomDefaults(force = false) {
        if (!customTiInput) return;
        if (!force && state.isCustomUserEdited) return;
        const smoothCalc = calculateEDM({ ...state, strategyLevel: 5 }); // Cấp 5/11: Bề Mặt Mịn / Ưu Tiên Phẳng
        const smoothRow = smoothCalc.rows[0];
        if (smoothRow) {
            customTiInput.value = smoothRow.ti;
            customPoInput.value = smoothRow.Po;
            customIpInput.value = smoothRow.IP;
            customVoltInput.value = smoothRow.Voltage;
            customVfInput.value = smoothRow.VF;
            customWireInput.value = smoothRow.Wire;
            
            if (wsCustomTiInput) wsCustomTiInput.value = smoothRow.ti;
            if (wsCustomPoInput) wsCustomPoInput.value = smoothRow.Po;
            if (wsCustomIpInput) wsCustomIpInput.value = smoothRow.IP;
            if (wsCustomVoltInput) wsCustomVoltInput.value = smoothRow.Voltage;
            if (wsCustomVfInput) wsCustomVfInput.value = smoothRow.VF;
            if (wsCustomWireInput) wsCustomWireInput.value = smoothRow.Wire;
        }
    }

    function runCustomAnalysis(shouldScroll = false) {
        if (!customTiInput) return;
        const H = state.thickness;
        const L = state.cutLength || 100;
        
        // 1. LẤY THÔNG SỐ CHIẾN LƯỢC HÃNG TỪ THANH TRƯỢT 11 CẤP ĐỘ
        const activeStrat = STRATEGY_CONFIGS[state.strategyLevel] || STRATEGY_CONFIGS[6];
        const activeStratName = activeStrat.shortName || activeStrat.name;
        const stdCalc = calculateEDM(state);
        const stdRow = stdCalc.rows[0];

        // 2. TÍNH TOÁN CỘT CHIẾN LƯỢC HÃNG (CỘT PHẢI)
        const std_phys = computePulseKinematics({
            ti: stdRow.ti, Po: stdRow.Po, IP: stdRow.IP, Voltage: stdRow.Voltage, VF: stdRow.VF, Wire: stdRow.Wire,
            H, material: state.material, cutLength: L
        });

        // 3. TÍNH TOÁN CỘT BÊN TRÁI TÙY THEO CHẾ ĐỘ: 'custom' (Nhập riêng) hoặc 'theory' (TT Lý thuyết theo tailieu.txt)
        let c_phys;
        let leftColTitle = 'Chế độ nhập';

        if (state.compareMode === 'theory') {
            // Chế độ TT Lý thuyết: Lấy 100% đầu vào từ thanh trượt chiến lược đang chọn
            customTiInput.value = stdRow.ti;
            customPoInput.value = stdRow.Po;
            customIpInput.value = stdRow.IP;
            customVoltInput.value = stdRow.Voltage;
            customVfInput.value = stdRow.VF;
            customWireInput.value = stdRow.Wire;

            if (customModeHint) {
                customModeHint.innerHTML = '(Đầu vào đồng bộ 100% từ Thanh trượt Chiến lược &amp; tính theo công thức tailieu.txt)';
            }
            if (analysisTableTitle) {
                analysisTableTitle.innerHTML = '📐 BẢNG SO SÁNH: TT Lý thuyết (tailieu.txt) vs Chuẩn Hãng Thực tế';
            }
            if (btnModeTheory) btnModeTheory.classList.add('active');
            if (btnModeCustom) btnModeCustom.classList.remove('active');

            leftColTitle = state.compactMetrics ? 'TT Lý thuyết' : 'TT Lý thuyết (tailieu.txt)';

            // Tính toán theo đúng công thức tài liệu tailieu.txt
            c_phys = computeTheoryKinematics({
                ti: stdRow.ti, Po: stdRow.Po, IP: stdRow.IP, Voltage: stdRow.Voltage, VF: stdRow.VF, Wire: stdRow.Wire,
                H, material: state.material, cutLength: L
            });
        } else {
            // Chế độ Nhập Riêng (Mặc định)
            if (customModeHint) {
                customModeHint.innerHTML = '(Nhập thông số tùy ý bên dưới rồi bấm nút Phân Tích)';
            }
            if (analysisTableTitle) {
                analysisTableTitle.innerHTML = '📊 BẢNG SO SÁNH: Chế độ nhập vs Chiến lược Hãng';
            }
            if (btnModeCustom) btnModeCustom.classList.add('active');
            if (btnModeTheory) btnModeTheory.classList.remove('active');

            const c_ti = parseInt(customTiInput.value, 10) || 28;
            const c_po = parseInt(customPoInput.value, 10) || 7;
            const c_ip = parseInt(customIpInput.value, 10) || 4;
            const c_volt = customVoltInput.value;
            const c_vf = parseInt(customVfInput.value, 10) || 55;
            const c_wire = parseInt(customWireInput.value, 10) || 1;

            leftColTitle = 'Chế độ nhập';

            c_phys = computePulseKinematics({
                ti: c_ti, Po: c_po, IP: c_ip, Voltage: c_volt, VF: c_vf, Wire: c_wire,
                H, material: state.material, cutLength: L
            });
        }

        // 4. Độ lệch khe hở tia lửa và Sai số
        let gapDiff = Math.round((parseFloat(c_phys.sparkGap) - parseFloat(std_phys.sparkGap)) * 1000); // micron
        if (Math.abs(gapDiff) <= 1) gapDiff = 0;

        function formatTimeMinSec(mins) {
            if (!isFinite(mins) || mins <= 0) return '0.0 phút';
            const m = Math.floor(mins);
            const s = Math.round((mins - m) * 60);
            if (mins < 60) {
                return `${mins.toFixed(1)} phút (~${m}p ${s < 10 ? '0' + s : s}s)`;
            } else {
                const h = Math.floor(mins / 60);
                const remM = Math.round(mins % 60);
                return `${h} giờ ${remM} phút (~${mins.toFixed(0)}p)`;
            }
        }

        // Danh mục Tiêu chí (Khi ở chế độ Ẩn: chỉ hiển thị ký hiệu ngắn gọn, loại bỏ giải thích trong ngoặc)
        const isCompact = state.compactMetrics;
        const m_ti = isCompact ? 'Pon' : 'Thời gian mở xung (Pon)';
        const m_po = isCompact ? 'Poff' : 'Thời gian nghỉ xả xỉ (Poff)';
        const m_cycle = isCompact ? 'T' : 'Tổng thời gian 1 chu kỳ (T = Pon + Poff)';
        const m_freq = isCompact ? 'f' : 'Tần số phát xung (Frequency - f)';
        const m_duty = isCompact ? 'η' : 'Tỷ lệ mở van MOSFET (Duty Factor - η)';
        const m_we = isCompact ? 'We' : 'NĂNG LƯỢNG 1 TIA ĐƠN (We ∝ Pon × IP)';
        const m_ptb = isCompact ? 'Ptb' : 'NĂNG LƯỢNG PHÁT TRONG 1S (Công suất trung bình Ptb)';
        const m_itb = isCompact ? 'Itb' : 'Dòng điện chỉ thị Ampe kế (Itb thực tế)';
        const m_fc = isCompact ? 'Fc' : 'Tốc độ cắt diện tích ước tính Fc';
        const m_ft = isCompact ? 'Ft' : `Tốc độ tiến bàn máy Ft (H=${H}mm)`;
        const m_time = isCompact ? 't' : `Thời gian gia công ước tính (Chu vi L=${L}mm)`;
        const m_ra = isCompact ? 'Ra' : 'Độ nhám bề mặt ước tính (Ra)';
        const m_gap = isCompact ? 'δ' : 'Khe hở phóng điện thực tế (δ)';
        const m_diff = isCompact ? 'Sai số' : 'Sai số kích thước (Dung sai Δ)';
        const m_wire = isCompact ? 'An toàn' : 'Mức độ mòn & Nguy cơ đứt dây';

        // Ghi chú We và Ra so sánh tương quan
        const weNote = c_phys.we_score > std_phys.we_score ? ' ⚡ Tia to hơn' : (c_phys.we_score < std_phys.we_score ? ' 🔹 Tia nhỏ mịn hơn' : '');
        const raNote = c_phys.we_score < std_phys.we_score ? ' (Mịn bóng hơn)' : (c_phys.we_score > std_phys.we_score ? ' (Rỗ thô hơn)' : '');

        // 1. RENDER BẢNG SO SÁNH (CHẾ ĐỘ NHẬP / TT LÝ THUYẾT vs CHIẾN LƯỢC HÃNG)
        comparisonTableElement.innerHTML = `
            <thead>
                <tr>
                    <th class="col-metric">${isCompact ? 'Tiêu chí' : 'Tiêu chí Công nghệ'}</th>
                    <th class="col-user">${leftColTitle}</th>
                    <th class="col-std">${activeStratName}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="col-metric"><strong>${m_ti}</strong></td>
                    <td class="col-user"><strong>${c_phys.ti} μs</strong></td>
                    <td class="col-std"><strong>${std_phys.ti} μs</strong></td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_po}</strong></td>
                    <td class="col-user"><strong>${c_phys.toff} μs</strong> (Hệ số ${c_phys.Po})</td>
                    <td class="col-std"><strong>${std_phys.toff} μs</strong> (Hệ số ${std_phys.Po})</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_cycle}</strong></td>
                    <td class="col-user"><strong>${c_phys.cycle} μs</strong> (${c_phys.cycle_ms} ms)</td>
                    <td class="col-std"><strong>${std_phys.cycle} μs</strong> (${std_phys.cycle_ms} ms)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_freq}</strong></td>
                    <td class="col-user"><strong>${c_phys.freq_khz} kHz</strong> (${c_phys.freq_hz.toLocaleString()} xung/giây) ${parseFloat(c_phys.freq_khz) < 2.5 ? '<br><small style="color:var(--accent-amber)">⚠️ Quá thưa</small>' : ''}</td>
                    <td class="col-std"><strong>${std_phys.freq_khz} kHz</strong> (${std_phys.freq_hz.toLocaleString()} xung/giây)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_duty}</strong></td>
                    <td class="col-user"><strong>${c_phys.duty_factor}%</strong> (1 mở : ${c_phys.Po} nghỉ)</td>
                    <td class="col-std"><strong>${std_phys.duty_factor}%</strong> (1 mở : ${std_phys.Po} nghỉ)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_we}</strong></td>
                    <td class="col-user"><strong>${c_phys.we_score} đv</strong> (≈ <strong>${c_phys.we_mj} mJ</strong>${weNote})</td>
                    <td class="col-std"><strong>${std_phys.we_score} đv</strong> (≈ <strong>${std_phys.we_mj} mJ</strong>)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_ptb}</strong></td>
                    <td class="col-user"><strong>${c_phys.power_watts} W</strong> (≈ ${c_phys.power_score.toLocaleString()} đv/s)</td>
                    <td class="col-std"><strong>${std_phys.power_watts} W</strong> (≈ ${std_phys.power_score.toLocaleString()} đv/s)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_itb}</strong></td>
                    <td class="col-user"><strong>≈ ${c_phys.i_tb_high} A</strong> (Tủ công suất cao) <br><small style="color:var(--text-secondary)">≈ ${c_phys.i_tb_std} A (Tủ tiêu chuẩn)</small></td>
                    <td class="col-std"><strong>≈ ${std_phys.i_tb_high} A</strong> (Tủ công suất cao) <br><small style="color:var(--text-secondary)">≈ ${std_phys.i_tb_std} A (Tủ tiêu chuẩn)</small></td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_fc}</strong></td>
                    <td class="col-user"><strong>${c_phys.speedArea} mm²/p</strong></td>
                    <td class="col-std"><strong>${std_phys.speedArea} mm²/p</strong></td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_ft}</strong></td>
                    <td class="col-user"><strong>${c_phys.feedRate} mm/p</strong></td>
                    <td class="col-std"><strong>${std_phys.feedRate} mm/p</strong></td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_time}</strong></td>
                    <td class="col-user"><strong>${formatTimeMinSec(c_phys.time_min)}</strong></td>
                    <td class="col-std"><strong>${formatTimeMinSec(std_phys.time_min)}</strong></td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_ra}</strong></td>
                    <td class="col-user">${c_phys.Ra} μm${raNote}</td>
                    <td class="col-std">${std_phys.Ra} μm</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_gap}</strong></td>
                    <td class="col-user">≈ ${c_phys.sparkGap} mm</td>
                    <td class="col-std">≈ ${std_phys.sparkGap} mm (Chuẩn)</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_diff}</strong></td>
                    <td class="col-user">${gapDiff > 1 ? `⚠️ LẸM (ÂM) ${gapDiff} μm` : (gapDiff < -1 ? `⚠️ DƯ DƯƠNG ${Math.abs(gapDiff)} μm` : `✅ Chuẩn xác ${stdRow.tolerance}`)}</td>
                    <td class="col-std">✅ Chuẩn xác ${stdRow.tolerance}</td>
                </tr>
                <tr>
                    <td class="col-metric"><strong>${m_wire}</strong></td>
                    <td class="col-user">${c_phys.ti > 55 ? '🔴 DÂY MÒN RẤT NHANH' : (c_phys.toff < 100 ? '⚠️ NGHẸT XỈ' : '🟢 An toàn, dây bền')}</td>
                    <td class="col-std">🟢 DÂY BỀN, TUỔI THỌ CAO</td>
                </tr>
            </tbody>
        `;

        // Render feedback nhận xét chuyên gia
        let feedbackHTML = '';
        if (state.compareMode === 'theory') {
            feedbackHTML = `<div class="feedback-alert feedback-good" style="margin-bottom:0;">
                📐 <strong>ĐỐI CHIẾU MÔ HÌNH NHIỆT ĐIỆN HỌC (tailieu.txt) vs THỰC TẾ HÃNG AUTOCUT:</strong><br>
                • <strong>Công thức Lý thuyết (tailieu.txt):</strong> <code>Fc = (60 × Cm × Ptb × η_eff) / B</code> = <strong>${c_phys.speedArea} mm²/p</strong> (Công suất $P_{tb} = ${c_phys.power_watts}\\text{W}$, thể tích bóc tách $MRR = ${c_phys.mrr_vol}\\text{ mm}^3/\\text{p}$, rãnh $B = ${c_phys.B}\\text{mm}$).<br>
                • <strong>Chuẩn Thực nghiệm AutoCut:</strong> $F_c = \\mathbf{${std_phys.speedArea}\\text{ mm}^2/\\text{p}}$ (Tốc độ tiến bàn $F_t = ${std_phys.feedRate}\\text{ mm/p}$).<br>
                • <strong>Nhận xét:</strong> Mô hình lý thuyết nhiệt bóc tách phản ánh chính xác quy luật vận hành của tủ nguồn số và động cơ Servo CNC AutoCut.
            </div>`;
        } else {
            const isExactMatch = (c_phys.ti === stdRow.ti && c_phys.Po === stdRow.Po && c_phys.IP === stdRow.IP && c_phys.Voltage === stdRow.Voltage && c_phys.VF === stdRow.VF);
            if (isExactMatch) {
                feedbackHTML = `<div class="feedback-alert feedback-good" style="margin-bottom:0;">
                    ✅ <strong>HỆ THỐNG VẬT LÝ ĐỒNG NHẤT:</strong> Bộ thông số bạn nhập trùng khớp hoàn toàn 100% với chiến lược <strong>${activeStrat.name}</strong>. Cùng một mô hình toán học, mọi chỉ số tốc độ bóc phôi (${c_phys.speedArea} mm²/p), dòng Ampe kế (${c_phys.i_tb_high}A), khe hở phóng điện và dung sai kích thước (${stdRow.tolerance}) đều đồng bộ hoàn hảo.
                </div>`;
            } else {
                feedbackHTML = `<span class="feedback-alert feedback-warn">🔍 ĐÁNH GIÁ KỸ THUẬT SO SÁNH VỚI ${activeStratName.toUpperCase()}:</span>`;
                feedbackHTML += `<ul style="padding-left:18px;margin-top:6px;">`;

                if (c_phys.we_score < std_phys.we_score) {
                    feedbackHTML += `<li><strong class="feedback-good">✨ Ưu tiên độ mịn bề mặt:</strong> Năng lượng 1 tia đơn nhỏ (${c_phys.we_mj} mJ) tạo miệng hố rỗ nông hơn, độ bóng cao hơn (${c_phys.Ra} μm), giảm độ mòn dây Molypden.</li>`;
                } else if (c_phys.we_score > std_phys.we_score) {
                    feedbackHTML += `<li><strong>Năng lượng xung lớn:</strong> Năng lượng tia đơn (${c_phys.we_mj} mJ) tạo hố ăn mòn sâu hơn, giúp bóc phôi nhanh hơn (${c_phys.speedArea} mm²/p) nhưng bề mặt thô hơn (${c_phys.Ra} μm).</li>`;
                }

                if (gapDiff > 1) {
                    feedbackHTML += `<li><strong>Cảnh báo sai lệch kích thước:</strong> Do khe hở tia lửa bị nở rộng thêm <strong>+${gapDiff} micron</strong> so với chế độ đang đối chiếu, nếu dùng Offset mặc định thì chi tiết sẽ bị <strong>LẸM PHÔI</strong>. Cần bù thêm Offset thành <strong>${(0.090 + parseFloat(c_phys.sparkGap)).toFixed(3)} mm</strong>.</li>`;
                } else if (gapDiff < -1) {
                    feedbackHTML += `<li><strong>Cảnh báo phôi dư dương:</strong> Do khe hở nhỏ hơn <strong>${Math.abs(gapDiff)} micron</strong>, phôi cắt ra sẽ hơi dày hơn một chút (thích hợp để cạo sửa hoặc mài phẳng).</li>`;
                } else {
                    feedbackHTML += `<li><strong class="feedback-good">Đánh giá chung:</strong> Bộ thông số bạn chọn rất cân đối, nằm an toàn trong dải gia công ổn định của máy.</li>`;
                }

                feedbackHTML += `</ul>`;
            }
        }
        analysisFeedbackBox.innerHTML = feedbackHTML;
        if (typeof wsAnalysisFeedbackBox !== "undefined" && wsAnalysisFeedbackBox) { wsAnalysisFeedbackBox.innerHTML = feedbackHTML; }

        // 2. RENDER BẢNG HIỆU CHỈNH THỰC TẾ XƯỞNG ĐỘC LẬP (WORKSHOP CALIBRATION ENGINE)
        if (workshopTableElement) {
            const wData = calculateWorkshopEDM(state);
            workshopTableElement.innerHTML = `
                <thead>
                    <tr>
                        <th class="col-metric">${isCompact ? 'Tiêu chí' : 'Tiêu chí Công nghệ'}</th>
                        <th class="col-actual">Thông số Thực nghiệm Xưởng của bạn (Workshop Actual)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="col-metric"><strong>${m_ti}</strong></td>
                        <td class="col-actual"><strong>${wData.ti} μs</strong></td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_po}</strong></td>
                        <td class="col-actual"><strong>${wData.toff} μs</strong> (Hệ số ${wData.Po})</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_cycle}</strong></td>
                        <td class="col-actual"><strong>${wData.cycle} μs</strong> (${wData.cycle_ms} ms)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_freq}</strong></td>
                        <td class="col-actual"><strong>${wData.freq_khz} kHz</strong> (${wData.freq_hz.toLocaleString()} xung/giây)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_duty}</strong></td>
                        <td class="col-actual"><strong>${wData.duty_factor}%</strong></td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_we}</strong></td>
                        <td class="col-actual"><strong>${wData.we_score} đv</strong> (≈ ${wData.we_mj} mJ)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_ptb}</strong></td>
                        <td class="col-actual"><strong>${wData.power_watts} W</strong> (Thể tích bóc phôi: ${wData.mrr_vol} mm³/p)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_itb}</strong></td>
                        <td class="col-actual"><strong>≈ ${wData.i_tb_high} A</strong> (Đồng hồ cơ tại xưởng) <br><small style="color:var(--text-secondary)">≈ ${wData.i_tb_std} A (Tủ tiêu chuẩn)</small></td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_fc}</strong></td>
                        <td class="col-actual"><strong>${wData.speedArea} mm²/p</strong> (Bình quân) <br><small style="color:var(--text-secondary)">Dao động tức thời: 70 - 100 mm²/p</small></td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_ft}</strong></td>
                        <td class="col-actual"><strong>${wData.feedRate} mm/p</strong> (Phôi H=${H}mm)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_time}</strong></td>
                        <td class="col-actual"><strong>${formatTimeMinSec(wData.time_min)}</strong> (Chu vi L=${L}mm)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_ra}</strong></td>
                        <td class="col-actual">${wData.Ra} μm (Bề mặt cắt thô xả xỉ đều)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_gap}</strong></td>
                        <td class="col-actual">≈ ${wData.sparkGap} mm (Rãnh cắt B ≈ ${wData.kerfB} mm)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_diff}</strong></td>
                        <td class="col-actual">📏 Bù dao: <strong>${wData.offset} mm</strong> (Chuẩn xác ±0.005mm)</td>
                    </tr>
                    <tr>
                        <td class="col-metric"><strong>${m_wire}</strong></td>
                        <td class="col-actual">🟢 Dây Molypden chạy êm, xả xỉ thông thoáng</td>
                    </tr>
                </tbody>
            `;

        }

        // 3. RENDER BÀI GIẢNG ĐỘNG LỰC HỌC VÀO TAB 2 (KIẾN THỨC CHUYÊN SÂU EDM)
        if (lectureKnowledgeBody) {
            lectureKnowledgeBody.innerHTML = `
                <p style="margin-bottom: 12px; font-size: 13px; color: #cbd5e1;">
                    Dưới đây là giáo trình bài giảng trình bày toàn bộ cơ sở lý thuyết, bản chất vật lý và các phép tính toán từng bước từ <strong>Bước 1 đến Bước 7</strong> được tự động đồng bộ theo thông số bạn đang chọn:
                </p>

                <!-- BƯỚC 1: TOFF & CHU KỲ T -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 1</span> Thời gian nghỉ xả xỉ (Toff) &amp; Tổng chu kỳ 1 xung (T)</div>
                    <p><strong>Bản chất:</strong> $Ton$ là thời gian mở van MOSFET. $Toff$ là thời gian ngắt điện để dung dịch khử ion và cuốn trôi mạt xỉ kim loại.</p>
                    <div class="lecture-formula-box">
                        • Toff (thực tế) = Ton × (Toff(hệ số) + 1) (μs)<br>
                        • Tổng chu kỳ: T = Ton + Toff = Ton × (Toff(hệ số) + 2) (μs)
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            • Toff = ${c_phys.ti} × (${c_phys.Po} + 1) = <strong>${c_phys.toff} μs</strong><br>
                            • Chu kỳ T = ${c_phys.ti} + ${c_phys.toff} = <strong>${c_phys.cycle} μs</strong> (${c_phys.cycle_ms} ms)
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            • Toff = ${std_phys.ti} × (${std_phys.Po} + 1) = <strong>${std_phys.toff} μs</strong><br>
                            • Chu kỳ T = ${std_phys.ti} + ${std_phys.toff} = <strong>${std_phys.cycle} μs</strong> (${std_phys.cycle_ms} ms)
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 2: TẦN SỐ PHÁT XUNG f -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 2</span> Tần số phát xung cao tần (Frequency - f)</div>
                    <p><strong>Ý nghĩa:</strong> Số lượng hạt tia lửa điện bộc phát qua khe hở cắt trong thời gian 1 giây.</p>
                    <div class="lecture-formula-box">
                        f = 10⁶ / T(μs) [Hz] = 1000 / T(μs) [kHz]
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            f = 10⁶ / ${c_phys.cycle} = <strong>${c_phys.freq_khz} kHz</strong> (${c_phys.freq_hz.toLocaleString()} tia/giây)
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            f = 10⁶ / ${std_phys.cycle} = <strong>${std_phys.freq_khz} kHz</strong> (${std_phys.freq_hz.toLocaleString()} tia/giây)
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 3: HỆ SỐ MỞ VAN MOSFET η -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 3</span> Tỷ lệ mở van MOSFET (Duty Factor - η)</div>
                    <p><strong>Bản chất:</strong> Tỷ lệ phần trăm thời gian van công suất dẫn dòng điện thực tế trong 1 chu kỳ.</p>
                    <div class="lecture-formula-box">
                        η = (Ton / T) × 100% = [1 / (Toff(hệ số) + 2)] × 100%
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            η = (${c_phys.ti} / ${c_phys.cycle}) × 100% = <strong>${c_phys.duty_factor}%</strong> (1 mở : ${c_phys.Po + 1} nghỉ)
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            η = (${std_phys.ti} / ${std_phys.cycle}) × 100% = <strong>${std_phys.duty_factor}%</strong> (1 mở : ${std_phys.Po + 1} nghỉ)
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 4: NĂNG LƯỢNG 1 TIA ĐƠN We -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 4</span> Năng lượng 1 tia lửa đơn (Single Spark Energy - We)</div>
                    <p><strong>Bản chất:</strong> Năng lượng nhiệt Joule giải phóng trong 1 xung hồ quang ngắn để làm nóng chảy kim loại phôi.</p>
                    <div class="lecture-formula-box">
                        • We = (Uarc × Ipeak × Ton) / 1000 (mJ)<br>
                        • Trong đó: Uarc = 27V (High) / 22V (Low); Ipeak = IP × 2.8A (mỗi kênh MOSFET)
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            • Ipeak = ${c_phys.IP} × 2.8A = ${c_phys.i_peak} A<br>
                            • We = (${c_phys.u_arc}V × ${c_phys.i_peak}A × ${c_phys.ti}μs) / 1000 = <strong>${c_phys.we_mj} mJ</strong> (Điểm: ${c_phys.we_score} đv)
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            • Ipeak = ${std_phys.IP} × 2.8A = ${std_phys.i_peak} A<br>
                            • We = (${std_phys.u_arc}V × ${std_phys.i_peak}A × ${std_phys.ti}μs) / 1000 = <strong>${std_phys.we_mj} mJ</strong> (Điểm: ${std_phys.we_score} đv)
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 5: CÔNG SUẤT ĐIỆN PHÁT TRONG 1S Ptb -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 5</span> Năng lượng phát trong 1s (Công suất trung bình Ptb) &amp; Dòng Ampe</div>
                    <p><strong>Bản chất:</strong> Tổng năng lượng điện phát ra trên rãnh cắt mỗi giây và dòng điện trung bình chỉ thị trên kim đồng hồ cơ.</p>
                    <div class="lecture-formula-box">
                        • Công suất: Ptb = f(Hz) × [We(mJ) / 1000] = η × Uarc × Ipeak (Watts = J/s)<br>
                        • Dòng Ampe kế: Itb = Ipeak × η × k(phóng) (≈ 3.8 - 4.3A với tủ lớn; ≈ 1.3 - 1.5A với tủ nhỏ)
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            • Công suất Ptb = <strong>${c_phys.power_watts} W</strong><br>
                            • Đồng hồ Ampe cơ: <strong>≈ ${c_phys.i_tb_high} A</strong> (Tủ lớn) | ≈ ${c_phys.i_tb_std} A (Tủ chuẩn)
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            • Công suất Ptb = <strong>${std_phys.power_watts} W</strong><br>
                            • Đồng hồ Ampe cơ: <strong>≈ ${std_phys.i_tb_high} A</strong> (Tủ lớn) | ≈ ${std_phys.i_tb_std} A (Tủ chuẩn)
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 6: TỐC ĐỘ CẮT DIỆN TÍCH Fc & TỐC ĐỘ TIẾN BÀN Ft -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 6</span> Tốc độ cắt diện tích (Fc), Tốc độ tiến bàn (Ft) &amp; Thời gian cắt</div>
                    <p><strong>Quy luật bóc phôi phi tuyến:</strong> Thể tích bóc phôi theo năng lượng nhiệt xung EDM kết hợp với cơ cấu chạy Servo.</p>
                    <div class="lecture-formula-box">
                        • Lý thuyết (tailieu.txt): Fc = (60 × Cm × Ptb × η_eff) / B (mm²/phút)<br>
                        • Tốc độ tiến bàn: Ft = Fc / H (mm/phút)<br>
                        • Thời gian cắt chi tiết: t(cắt) = L / Ft (phút)
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            • Tốc độ diện tích: Fc = <strong>${c_phys.speedArea} mm²/p</strong><br>
                            • Tốc độ tiến bàn (H=${H}mm): Ft = ${c_phys.speedArea}/${H} = <strong>${c_phys.feedRate} mm/p</strong><br>
                            • Thời gian (L=${L}mm): t = ${L}/${c_phys.feedRate} = <strong>${formatTimeMinSec(c_phys.time_min)}</strong>
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            • Tốc độ diện tích: Fc = <strong>${std_phys.speedArea} mm²/p</strong><br>
                            • Tốc độ tiến bàn (H=${H}mm): Ft = ${std_phys.speedArea}/${H} = <strong>${std_phys.feedRate} mm/p</strong><br>
                            • Thời gian (L=${L}mm): t = ${L}/${std_phys.feedRate} = <strong>${formatTimeMinSec(std_phys.time_min)}</strong>
                        </div>
                    </div>
                </div>

                <!-- BƯỚC 7: KHE HỞ PHÓNG ĐIỆN δ & BÙ DAO OFFSET -->
                <div class="lecture-step">
                    <div class="lecture-step-title"><span class="lecture-step-num">BƯỚC 7</span> Khe hở phóng tia lửa (δ) &amp; Sai số kích thước bù dao Offset</div>
                    <p><strong>Nguyên lý:</strong> Khe hở tia lửa δ quyết định giá trị bù bán kính dây Offset = Rdây + δ (với dây Φ0.18mm → Rdây = 0.090mm).</p>
                    <div class="lecture-formula-box">
                        • Khe hở tia lửa: δ = 0.015 + 0.00035 × Ton × (IP / 3) + ΔU (mm)<br>
                        • Sai lệch biên dạng: Δ = δ(thực) - δ(chuẩn) (micron)
                    </div>
                    <div class="lecture-calc-grid">
                        <div class="lecture-calc-col custom-col">
                            <strong>${leftColTitle}:</strong><br>
                            • Khe hở: δ ≈ <strong>${c_phys.sparkGap} mm</strong><br>
                            • Đánh giá sai số: <strong>${gapDiff > 1 ? `Lẹm âm -${gapDiff} μm` : (gapDiff < -1 ? `Dư dương +${Math.abs(gapDiff)} μm` : 'Chuẩn xác ±0.005mm')}</strong><br>
                            • Độ nhám bề mặt: <strong>Ra ≈ ${c_phys.Ra} μm</strong>
                        </div>
                        <div class="lecture-calc-col std-col">
                            <strong>${activeStratName}:</strong><br>
                            • Khe hở: δ ≈ <strong>${std_phys.sparkGap} mm</strong><br>
                            • Đánh giá sai số: <strong>✅ Chuẩn xác ${stdRow.tolerance}</strong><br>
                            • Độ nhám bề mặt: <strong>Ra ≈ ${std_phys.Ra} μm (Đều, mịn)</strong>
                        </div>
                    </div>
                </div>
            `;
        }


        // Luôn hiển thị khung so sánh mặc định
        if (analysisContainer) {
            analysisContainer.style.display = 'block';
            if (shouldScroll) {
                analysisContainer.scrollIntoView({ behavior: 'smooth' });
            }
        }
    }

    // ==========================================
    // 5. RENDER MAIN VIEW
    // ==========================================

    // =========================================================================
    // HÃ€M RENDER BÃ€I GIáº¢NG Äá»˜NG Lá»°C Há»ŒC 7 BÆ¯á»šC (Äá»’NG Bá»˜ 100% THEO THÃ”NG Sá» XÆ¯á»žNG)
    // =========================================================================
    function renderLectureKnowledge() {
        if (!lectureKnowledgeBody) return;
        const H = state.thickness || 40;
        const L = state.cutLength || 100;
        const wsRows = generateWorkshopRows(state);
        if (!wsRows || wsRows.length === 0) return;
        const r1 = wsRows[0];

        const Pon = r1.ti;
        const Poff = r1.Po;
        const IP = r1.IP;
        const Volt = r1.Voltage;
        const VF = r1.VF;
        const Wire = r1.Wire;

        const toff_us = Pon * (Poff + 1);
        const cycle_us = Pon * (Poff + 2);
        const cycle_ms = (cycle_us / 1000).toFixed(3);
        const freq_hz = Math.round(1000000 / cycle_us);
        const freq_khz = (freq_hz / 1000).toFixed(2);
        const duty_pct = ((1.0 / (Poff + 2)) * 100).toFixed(1);

        const i_peak = IP * 2.8;
        const u_arc = (Volt === 'Low' || Volt === 'L') ? 22 : 27;
        const we_mj = ((u_arc * i_peak * Pon) / 1000).toFixed(2);
        const power_watts = Math.round((1.0 / (Poff + 2)) * u_arc * i_peak);
        const calculatedAmpe = calcTheoreticalAmpe(IP, Poff, H, Volt).toFixed(1);

        const speedArea = r1.speedArea;
        const feedRate = r1.feedRate;
        const timeMin = ((L * H) / Math.max(1, speedArea));
        const timeStr = timeMin < 60 ? `${timeMin.toFixed(1)} phÃºt` : `${Math.floor(timeMin/60)}h ${Math.round(timeMin%60)}p`;

        const offset_1p = r1.offsetText;
        const delta_1p = (parseFloat(offset_1p) - 0.090).toFixed(4);

        const strat = WS_STRATEGY_CONFIGS[state.wsStrategyLevel] || WS_STRATEGY_CONFIGS[4];
        const matName = (state.wsMaterial || 'SCM420') === 'SCM440' ? 'SCM440 (28-32 HRC)' : 'SCM420 (HB < 200)';

        lectureKnowledgeBody.innerHTML = `
            <div style="background: rgba(14, 165, 233, 0.08); border: 1px solid rgba(14, 165, 233, 0.3); border-radius: var(--radius-sm); padding: 10px 14px; margin-bottom: 16px;">
                <span style="color: var(--accent-cyan); font-weight: 700;">âš™ï¸ ThÃ´ng sá»‘ Ä‘ang kháº£o sÃ¡t:</span> 
                <strong>${matName} | H = ${H}mm | ${strat.name} (Cáº¥p ${state.wsStrategyLevel}/7) | Pon = ${Pon}Î¼s, Poff = ${Poff}, IP = ${IP}, Volt = ${Volt}, VF = ${VF}</strong>
            </div>

            <!-- BÆ¯á»šC 1 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 1</span> Thá»i gian nghá»‰ xáº£ xá»‰ (Poff) &amp; Tá»•ng chu ká»³ 1 xung (T)</div>
                <p><strong>Báº£n cháº¥t:</strong> <code>Pon</code> lÃ  thá»i gian má»Ÿ van MOSFET phÃ³ng Ä‘iá»‡n. <code>Poff</code> (Po) lÃ  há»‡ sá»‘ thá»i gian ngáº¯t xung Ä‘á»ƒ nÆ°á»›c khá»­ ion hÃ³a vÃ  Ä‘áº©y máº¡t xá»‰ ra ngoÃ i.</p>
                <div class="lecture-formula-box">
                    â€¢ Poff (thá»±c táº¿) = Pon Ã— (Poff + 1) [Î¼s]<br>
                    â€¢ Tá»•ng chu ká»³ T = Pon + Poff(thá»±c) = Pon Ã— (Poff + 2) [Î¼s]
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        â€¢ Poff thá»±c = ${Pon} Ã— (${Poff} + 1) = <strong>${toff_us} Î¼s</strong><br>
                        â€¢ Tá»•ng chu ká»³ T = ${Pon} + ${toff_us} = <strong>${cycle_us} Î¼s</strong> (${cycle_ms} ms)
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 2 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 2</span> Táº§n sá»‘ phÃ¡t xung cao táº§n (Frequency - f)</div>
                <p><strong>Ã nghÄ©a:</strong> Sá»‘ chu ká»³ xung phÃ³ng Ä‘iá»‡n bá»™c phÃ¡t qua khe rÃ£nh trong 1 giÃ¢y.</p>
                <div class="lecture-formula-box">
                    f = 10â¶ / T [Hz] = 1000 / T [kHz]
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        f = 10â¶ / ${cycle_us} = <strong>${freq_khz} kHz</strong> (${freq_hz.toLocaleString()} tia lá»­a/giÃ¢y)
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 3 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 3</span> Tá»· lá»‡ má»Ÿ van MOSFET (Duty Factor - Î·)</div>
                <p><strong>Báº£n cháº¥t:</strong> Tá»· lá»‡ pháº§n trÄƒm thá»i gian van MOSFET dáº«n dÃ²ng Ä‘iá»‡n thá»±c táº¿ trong 1 chu ká»³.</p>
                <div class="lecture-formula-box">
                    Î· = Pon / T = 1 / (Poff + 2) Ã— 100%
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        Î· = 1 / (${Poff} + 2) = <strong>${duty_pct}%</strong> (1 xung má»Ÿ : ${Poff + 1} xung nghá»‰)
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 4 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 4</span> NÄƒng lÆ°á»£ng 1 tia Ä‘Æ¡n (Single Spark Energy - We)</div>
                <p><strong>Báº£n cháº¥t:</strong> Nhiá»‡t lÆ°á»£ng bá»™c phÃ¡ Joule cá»§a 1 xung Ä‘iá»‡n Ä‘á»ƒ nung cháº£y kim loáº¡i phÃ´i.</p>
                <div class="lecture-formula-box">
                    â€¢ We = (Uarc Ã— Ipeak Ã— Pon) / 1000 [mJ]<br>
                    â€¢ Trong Ä‘Ã³: Uarc = 27V (High) / 22V (Low); Ipeak = IP Ã— 2.8A (má»—i sÃ² MOSFET)
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        â€¢ Ipeak = ${IP} Ã— 2.8A = <strong>${i_peak.toFixed(1)} A</strong><br>
                        â€¢ We = (${u_arc}V Ã— ${i_peak.toFixed(1)}A Ã— ${Pon}Î¼s) / 1000 = <strong>${we_mj} mJ</strong>
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 5 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 5</span> CÃ´ng suáº¥t Ä‘iá»‡n phÃ¡t (Ptb) &amp; DÃ²ng kim Ampe káº¿ (Model VÃ²ng 5)</div>
                <p><strong>Quy chuáº©n Ampe Model VÃ²ng 5:</strong> MÃ´ hÃ¬nh toÃ¡n nhiá»‡t Ä‘á»™ng há»c tÃ­nh toÃ¡n dÃ²ng ampe cÆ¡ liÃªn tá»¥c, kháº¯c phá»¥c trá»“i sá»¥t ampe khi Po lá»›n vÃ  phÃ´i siÃªu dÃ y.</p>
                <div class="lecture-formula-box">
                    â€¢ CÃ´ng suáº¥t: Ptb = Î· Ã— Uarc Ã— Ipeak [Watts]<br>
                    â€¢ Kim Ampe: I = IP Ã— [1/(Poff + 2)] Ã— 8.55 Ã— [1 - 0.33(Poff - 5)/10] Ã— [1 - 0.08Â·H/(H + 20)] Ã— (Uarc/27) [A]
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        â€¢ CÃ´ng suáº¥t trung bÃ¬nh Ptb = <strong>${power_watts} W</strong><br>
                        â€¢ Äá»“ng há»“ Ampe káº¿ chá»‰ thá»‹: <strong>â‰ˆ ${calculatedAmpe} A</strong> (Äá»™ chÃ­nh xÃ¡c MAE = 0.161A, chuáº©n xÆ°á»Ÿng)
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 6 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 6</span> NÄƒng suáº¥t cáº¯t diá»‡n tÃ­ch (Fc), Tá»‘c Ä‘á»™ tiáº¿n bÃ n (Ft) &amp; Thá»i gian cáº¯t</div>
                <p><strong>Äá»™ng há»c Servo:</strong> NÄƒng suáº¥t cáº¯t diá»‡n tÃ­ch káº¿t há»£p Ä‘iá»‡n Ã¡p bÃ¡m táº£i VF vÃ  chiá»u dÃ y phÃ´i.</p>
                <div class="lecture-formula-box">
                    â€¢ Tá»‘c Ä‘á»™ tiáº¿n bÃ n: Ft = Fc / H [mm/phÃºt]<br>
                    â€¢ Thá»i gian cáº¯t (vá»›i L = ${L}mm): t = (L Ã— H) / Fc [phÃºt]
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        â€¢ NÄƒng suáº¥t thá»±c táº¿: Fc = <strong>${speedArea} mmÂ²/phÃºt</strong> (Fc quy Ä‘á»•i H40 = ${r1.speedAreaH40} mmÂ²/p)<br>
                        â€¢ Tá»‘c Ä‘á»™ tiáº¿n bÃ n mÃ¡y: Ft = <strong>${feedRate} mm/phÃºt</strong> (Giá»›i háº¡n bÃ n: ${r1.hz || '--'} Hz)<br>
                        â€¢ Thá»i gian cáº¯t dá»± kiáº¿n: <strong>${timeStr}</strong>
                    </div>
                </div>
            </div>

            <!-- BÆ¯á»šC 7 -->
            <div class="lecture-step">
                <div class="lecture-step-title"><span class="lecture-step-num">BÆ¯á»šC 7</span> Khe há»Ÿ tia lá»­a (Î´) &amp; BÃ¹ dao Offset (Quy táº¯c NÃºi Lá»­a Panme &amp; PhÃ¢n VÃ¹ng KÃ©p)</div>
                <p><strong>NguyÃªn lÃ½:</strong> DÃ¢y Molypden Î¦0.18mm (R = 0.090mm). BÃ¹ dao Pass 1: O1 = 0.090 + Î´1. Pass 2 pháº¡t Ä‘á»‰nh nÃºi lá»­a: O2 = Rz1 + Î´2 (H â‰¤ 170mm) vÃ  khÃ³a 0.0150mm (H > 170mm).</p>
                <div class="lecture-formula-box">
                    â€¢ LÆ°á»£ng cÃ o phÃ´i 1 Pass: Î´ = ${delta_1p} mm (${(delta_1p*1000).toFixed(1)} Î¼m)<br>
                    â€¢ BÃ¹ dao Offset 1 Pass: Offset = RdÃ¢y + Î´ = 0.090 + ${delta_1p} = <strong>${offset_1p} mm</strong>
                </div>
                <div class="lecture-calc-grid">
                    <div class="lecture-calc-col std-col" style="grid-column: 1 / -1;">
                        â€¢ BÃ¹ dao Pass 1: <strong>${offset_1p} mm</strong><br>
                        â€¢ Äá»™ nhÃ¡m bá» máº·t: <strong>Ra â‰ˆ ${r1.Ra} Î¼m</strong><br>
                        â€¢ Kiá»ƒm soÃ¡t Ä‘á»™ chÃ­nh xÃ¡c: PhÃ¢n vÃ¹ng kÃ©p Ä‘áº£m báº£o sai sá»‘ &lt; 0.003mm cho phÃ´i H â‰¤ 170mm vÃ  há»™i tá»¥ 0.1150mm táº¡i H=300mm.
                    </div>
                </div>
            </div>
        `;
    }

    function render() {
        const passLabel = state.passCount === 1 ? '1 Pass' : `${state.passCount} Pass (Multi-Cut)`;
        const matNames = {
            'SCM420': 'Thép SCM420 (Thép mềm)',
            'SCM440': 'Thép tôi SCM440 (Thép cứng)',
            'COPPER': 'Đồng (Cu / Đồng thau)',
            'ALUMINUM': 'Nhôm (Al 6061 / 7075)'
        };
        const matLabel = matNames[state.material] || state.material;

        if (typeof configSummary !== 'undefined' && configSummary) {
            configSummary.textContent = `${matLabel} | H = ${state.thickness} mm | ${passLabel} | Chiến lược: ${strat.name}`;
        }
        if (typeof wsConfigSummary !== 'undefined' && wsConfigSummary) {
            const wsMatNames = {
                'SCM420': 'Thép SCM420 (Thép mềm HB < 200)',
                'SCM440': 'Thép tôi SCM440 (Thép cứng 28-32 HRC)'
            };
            const wsMatLabel = wsMatNames[state.wsMaterial] || wsMatNames['SCM420'];
            const wsPassNum = state.wsPassCount || 1;
            const wsPassLabel = wsPassNum === 1 ? '1 Pass' : `${wsPassNum} Pass (Multi-Cut)`;
            const wsStrat = WS_STRATEGY_CONFIGS[state.wsStrategyLevel] || WS_STRATEGY_CONFIGS[4];
            wsConfigSummary.textContent = `Hiệu chuẩn theo máy thực tế xưởng | ${wsMatLabel} | H = ${state.thickness} mm | ${wsPassLabel} | Chế độ: ${wsStrat.name}`;
        }

        // Compute parameters
        const { rows, totalMinutes, notices } = calculateEDM(state);
        const wsCalc = calculateWorkshopEDM(state);

        // Render Table Body (Tab 1)
        if (typeof tableBody !== 'undefined' && tableBody) {
            tableBody.innerHTML = rows.map(r => `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><strong>${r.ti}</strong></td>
                    <td>${r.Po}</td>
                    <td><span class="badge-ip">${r.IP}</span></td>
                    <td><span class="${r.Voltage === 'High' ? 'val-volt-high' : 'val-volt-low'}">${r.Voltage}</span></td>
                    <td>${r.VF}</td>
                    <td>${r.Wire}</td>
                    <td class="val-offset">${r.offsetText}</td>
                    <td>${r.speedArea}</td>
                    <td class="val-ra">${r.Ra}</td>
                    <td class="val-tolerance">${r.tolerance}</td>
                </tr>
            `).join('');
        }

        // Render Workshop Table Body (Tab 2)
                // Render Dual-Zone Workshop Tables (Tab 1: Thông Số Cắt & Bù Dao Offset)
        if (wsTableBodyVung1 && wsTableBodyVung2) {
            const wsRowsList = generateWorkshopRows(state);
            state.wsCustomOverrides = state.wsCustomOverrides || {};

            // Helper tính toán động học từng dòng khi người dùng can thiệp
            function computeRowDynamics(r, idx, cur) {
                const tiVal = cur.ti !== undefined ? cur.ti : r.ti;
                const poVal = cur.Po !== undefined ? cur.Po : r.Po;
                const ipVal = cur.IP !== undefined ? cur.IP : r.IP;
                const voltVal = cur.Voltage !== undefined ? cur.Voltage : r.Voltage;
                const vfVal = cur.VF !== undefined ? cur.VF : r.VF;
                const wireVal = cur.Wire !== undefined ? cur.Wire : r.Wire;

                let offsetDisplay = r.offsetText;
                let ampeDisplay = r.ampe;
                let speedArea = r.speedArea;
                let speedAreaH40 = r.speedAreaH40;
                let hz = r.hz;
                let Ra = r.Ra;

                if (cur.ti !== undefined || cur.Po !== undefined || cur.IP !== undefined || cur.Voltage !== undefined || cur.VF !== undefined) {
                    if (idx === 0) {
                        const dyn = calcVFSparkGap(state.thickness, tiVal, ipVal, voltVal, vfVal, poVal, state.wsMaterial);
                        offsetDisplay = (0.090 + dyn.gap_vf).toFixed(3);
                        ampeDisplay = dyn.ampe_est;

                        const isHard = (state.wsMaterial === 'SCM440');
                        const toffVal = tiVal * (poVal + 1);
                        const dutyVal = tiVal / (tiVal + toffVal);

                        // HỆ PHƯƠNG TRÌNH TOÁN - VẬT LÝ NHIỆT ĐỘNG HỌC FC THỰC & FC MÁY (VÒNG 6 TỐI ƯU HỘI TỤ 7.8%)
                        const c_scale = 0.80;
                        const eta_base = c_scale * Math.pow(Math.max(1, tiVal) / 50.0, 0.15) * Math.pow(ipVal / 4.0, 0.16);

                        let eta_h;
                        if (isHard) {
                            eta_h = Math.max(0.55, 1.0 - Math.max(0, state.thickness - 40) * 0.000687);
                        } else {
                            eta_h = Math.max(0.40, 1.0 - Math.max(0, state.thickness - 40) * 0.001975);
                        }

                        const h_choke = Math.max(0.0, (state.thickness - 63.0) / 100.0);
                        const po_choke = Math.max(0.0, (8.0 - poVal) / 10.0);
                        const mat_choke = isHard ? 1.0 : 4.0;
                        const slag_drag = 0.90 * Math.pow(h_choke, 0.65) * po_choke * mat_choke;
                        const k_drag = Math.max(0.35, 1.0 - slag_drag);

                        let k_vf;
                        if (vfVal >= 55.0) {
                            k_vf = 1.0 + (vfVal - 55.0) * 0.0020;
                        } else {
                            k_vf = 1.0 + (vfVal - 55.0) * 0.0050;
                        }

                        const k_duty = Math.pow(dutyVal / (1.0 / 7.0), 0.0205);
                        const eta_eff = eta_base * eta_h * k_drag * k_vf * k_duty;
                        const u_arc = voltVal === 'Low' ? 22 : 27;
                        const i_peak = ipVal * 2.8;
                        const power_watts = u_arc * i_peak * dutyVal;

                        const Cm = 0.0135;
                        const B = 0.23;
                        const speedArea_raw = (60 * Cm * power_watts * eta_eff) / B;
                        const feedRate_calc = speedArea_raw / state.thickness;
                        const ft_max = (hz || 150) * 0.060;
                        const feedRate_final = Math.min(feedRate_calc, ft_max);

                        speedArea = Math.round(feedRate_final * state.thickness);
                        speedAreaH40 = Math.round(feedRate_final * 40);
                    } else if (idx === 1) {
                        if (state.thickness > 170) {
                            offsetDisplay = '0.015';
                        } else {
                            const p1ov = state.wsCustomOverrides[0] || {};
                            const p1_ton = p1ov.ti !== undefined ? p1ov.ti : wsRowsList[0].ti;
                            const p1_ip = p1ov.IP !== undefined ? p1ov.IP : wsRowsList[0].IP;
                            const rz1 = 0.00120 * Math.sqrt(p1_ton * p1_ip);
                            const u_ratio = voltVal === 'High' ? 1.0 : 0.815;
                            const delta2 = 0.00070 * Math.sqrt(tiVal * ipVal) * u_ratio;
                            offsetDisplay = (rz1 + delta2).toFixed(3);
                        }
                        ampeDisplay = (voltVal === 'Low') ? '< 0.2' : calcTheoreticalAmpe(ipVal, poVal, state.thickness, voltVal).toFixed(1);
                    } else {
                        ampeDisplay = calcTheoreticalAmpe(ipVal, poVal, state.thickness, voltVal).toFixed(1);
                    }
                }
                return { tiVal, poVal, ipVal, voltVal, vfVal, wireVal, offsetDisplay, ampeDisplay, speedArea, speedAreaH40, hz, Ra };
            }

            // Render VÙNG 1: Thông số đầu vào (Điện xung & Bước tiến)
            wsTableBodyVung1.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="ti" min="1" max="250" value="${dyn.tiVal}" title="Pon (μs)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="Po" min="1" max="40" value="${dyn.poVal}" title="Poff (Po)"></td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="IP" min="1" max="10" value="${dyn.ipVal}" title="IP (Sò)"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Voltage" title="Điện áp">
                            <option value="High" ${dyn.voltVal === 'High' ? 'selected' : ''}>High</option>
                            <option value="Low" ${dyn.voltVal === 'Low' ? 'selected' : ''}>Low</option>
                        </select>
                    </td>
                    <td><input type="number" class="ws-cell-input ws-edit-field" data-pass="${idx}" data-field="VF" min="1" max="99" value="${dyn.vfVal}" title="VF"></td>
                    <td>
                        <select class="ws-cell-select ws-edit-field" data-pass="${idx}" data-field="Wire" title="Tốc độ dây">
                            <option value="1" ${dyn.wireVal == '1' ? 'selected' : ''}>1</option>
                            <option value="2" ${dyn.wireVal == '2' ? 'selected' : ''}>2</option>
                            <option value="3" ${dyn.wireVal == '3' ? 'selected' : ''}>3</option>
                        </select>
                    </td>
                </tr>
                `;
            }).join('');

            // Render VÙNG 2: Kết quả đầu ra (OFFSET, Năng suất & Động học máy)
            wsTableBodyVung2.innerHTML = wsRowsList.map((r, idx) => {
                const ov = state.wsCustomOverrides[idx] || {};
                const dyn = computeRowDynamics(r, idx, ov);
                return `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td class="val-offset fw-bold col-offset-cell" style="color:var(--accent-amber); font-size:14px; background: rgba(245, 158, 11, 0.08);"><strong id="ws-dyn-offset-${idx}">${dyn.offsetDisplay}</strong> mm</td>
                    <td><span id="ws-dyn-fc-${idx}" style="color:var(--accent-cyan); font-weight:600;">${dyn.speedArea}</span></td>
                    <td><strong id="ws-dyn-fch40-${idx}" style="color:var(--accent-cyan);">${dyn.speedAreaH40}</strong></td>
                    <td><strong id="ws-dyn-hz-${idx}" style="color:var(--text-primary);">${dyn.hz} Hz</strong></td>
                    <td><strong id="ws-dyn-ampe-${idx}" style="color:var(--accent-green); font-size:13px;">${dyn.ampeDisplay}</strong></td>
                    <td class="val-ra"><span id="ws-dyn-ra-${idx}">${dyn.Ra}</span></td>
                </tr>
                `;
            }).join('');

            // Gắn lắng nghe sự kiện can thiệp trực tiếp vào Vùng 1
            const editFields = wsTableBodyVung1.querySelectorAll('.ws-edit-field');
            editFields.forEach(field => {
                const onFieldChange = () => {
                    const passIdx = parseInt(field.dataset.pass, 10);
                    const row1Inputs = wsTableBodyVung1.querySelectorAll(`.ws-edit-field[data-pass="${passIdx}"]`);
                    let cur = {};
                    row1Inputs.forEach(el => {
                        const f = el.dataset.field;
                        if (f === 'Voltage' || f === 'Wire') {
                            cur[f] = el.value;
                        } else {
                            cur[f] = parseFloat(el.value) || 0;
                        }
                    });
                    state.wsCustomOverrides[passIdx] = cur;
                    const r = wsRowsList[passIdx];
                    const dyn = computeRowDynamics(r, passIdx, cur);

                    // Cập nhật giao diện trực tiếp không làm mất tiêu điểm chuột
                    const offEl = document.getElementById(`ws-dyn-offset-${passIdx}`);
                    if (offEl) offEl.textContent = dyn.offsetDisplay;
                    const fcEl = document.getElementById(`ws-dyn-fc-${passIdx}`);
                    if (fcEl) fcEl.textContent = dyn.speedArea;
                    const fch40El = document.getElementById(`ws-dyn-fch40-${passIdx}`);
                    if (fch40El) fch40El.textContent = dyn.speedAreaH40;
                    const ampeEl = document.getElementById(`ws-dyn-ampe-${passIdx}`);
                    if (ampeEl) ampeEl.textContent = dyn.ampeDisplay;
                    const raEl = document.getElementById(`ws-dyn-ra-${passIdx}`);
                    if (raEl) raEl.textContent = dyn.Ra;

                    // Nếu đổi Pass 1, Pass 2 có thể đổi theo (Rz1 phụ thuộc Ton1, IP1)
                    if (passIdx === 0 && wsRowsList.length > 1) {
                        const p2ov = state.wsCustomOverrides[1] || {};
                        const p2dyn = computeRowDynamics(wsRowsList[1], 1, p2ov);
                        const off2El = document.getElementById('ws-dyn-offset-1');
                        if (off2El) off2El.textContent = p2dyn.offsetDisplay;
                    }

                    if (typeof updateTab1SyncPreview === 'function') {
                        updateTab1SyncPreview();
                    }
                };
                field.addEventListener('input', onFieldChange);
                field.addEventListener('change', onFieldChange);
            });
        } else if (typeof wsTableBody !== 'undefined' && wsTableBody) {
            const wsRowsList = generateWorkshopRows(state);
            wsTableBody.innerHTML = wsRowsList.map((r, idx) => `
                <tr>
                    <td class="pass-cell sticky-col"><span class="pass-badge ${r.badgeClass}">${r.passName}</span></td>
                    <td><strong>${r.ti}</strong></td>
                    <td>${r.Po}</td>
                    <td><span class="badge-ip">${r.IP}</span></td>
                    <td><span class="${r.Voltage === 'High' ? 'val-volt-high' : 'val-volt-low'}">${r.Voltage}</span></td>
                    <td>${r.VF}</td>
                    <td>${r.Wire}</td>
                    <td class="val-offset fw-bold" style="color:var(--accent-amber)">${r.offsetText} mm</td>
                    <td><span style="color:var(--accent-amber)">${r.speedArea}</span></td>
                    <td><strong style="color:var(--accent-amber)">${r.speedAreaH40}</strong></td>
                    <td><strong style="color:var(--accent-amber)">${r.hz} Hz</strong></td>
                    <td><strong style="color:var(--accent-amber)">${r.ampe}</strong></td>
                    <td class="val-ra">${r.Ra}</td>
                </tr>
            `).join('');
        }

        // Render Notices
        if (typeof noticeList !== 'undefined' && noticeList) {
            noticeList.innerHTML = notices.map(n => `<li>${n}</li>`).join('');
        }
        
        // Render Dedicated Workshop Notices (Rule 12 & Rule 15)
        const wsNoticeList = document.getElementById('ws-notice-list');
        if (typeof wsNoticeList !== 'undefined' && wsNoticeList) {
            const wsNotices = [];
            const wsStrat = WS_STRATEGY_CONFIGS[state.wsStrategyLevel] || WS_STRATEGY_CONFIGS[4];
            
            // Strategy specific physics guidance (7 Levels with Regular 0.5 - 0.7A Steps)
            const curLvl = state.wsStrategyLevel || 4;
            if (curLvl === 1) {
                wsNotices.push("💎 <strong>Cực hạn siêu mịn (Cấp 1/7):</strong> Dòng kim Ampe giảm ~1.8A (còn 0.7 - 0.9A tại H30). Vi xung nano, hạ IP tối thiểu (1 sò), Volt Low. Khuyên dùng <strong>Wire 2 hoặc 3</strong> để đạt độ bóng gương $Ra \le 1.0 - 1.2\mu m$.");
            } else if (curLvl === 2) {
                wsNotices.push("✨ <strong>Siêu mịn (Cấp 2/7):</strong> Dòng kim Ampe giảm ~1.2A (còn 1.3 - 1.5A tại H30). Hạ IP 1-2 sò, dập xung Ton cực ngắn, Po kéo dài nghỉ sâu, $Ra \le 1.4 - 1.8\mu m$.");
            } else if (curLvl === 3) {
                wsNotices.push("🌟 <strong>Bề mặt mịn (Cấp 3/7):</strong> Dòng kim Ampe giảm đúng 0.5 - 0.7A (đạt 2.0 - 2.2A tại H30). Kéo dài Po để nước xối rửa sạch 100% xỉ, triệt tiêu đánh lửa thứ cấp, $Ra \le 1.8 - 2.2\mu m$.");
            } else if (curLvl === 4) {
                const isMulti = (state.wsPassCount || 1) >= 3;
                const ampeH30Str = isMulti ? '3.2A (dải 3.0 - 3.5A cho 3-5 Pass)' : '2.4A (dải 2.0 - 2.5A cho 1-2 Pass)';
                wsNotices.push(`⭐ <strong>Tiêu chuẩn Chuẩn xưởng (Cấp 4/7):</strong> Điểm neo trung tâm Rule 12 (đạt ${ampeH30Str} tại H30). Cân bằng tối ưu giữa tốc độ cắt, độ phẳng mép và độ bền dây Moly.`);
            } else if (curLvl === 5) {
                wsNotices.push("🚀 <strong>Năng suất Cắt nhanh (Cấp 5/7):</strong> Dòng kim Ampe tăng đúng 0.5 - 0.7A (đạt 3.2 - 3.4A tại H30). Rút ngắn Po 1 nấc tăng tần số xung, tăng nhẹ Ton và VF, giữ IP an toàn chống đứt dây.");
            } else if (curLvl === 6) {
                wsNotices.push("⚡ <strong>Năng suất cao Rất nhanh (Cấp 6/7):</strong> Dòng kim Ampe tăng ~1.2A (đạt 3.8 - 4.0A tại H30). Rút ngắn Po 2 nấc, ép servo VF bám sát phôi, tăng tốc vượt trội 35-45%.");
            } else if (curLvl === 7) {
                wsNotices.push("🔥 <strong>Siêu năng suất Phá thô (Cấp 7/7):</strong> Dòng kim Ampe tăng ~1.8A (đạt 4.3 - 4.6A tại H30). Rút ngắn Po tối đa và ép VF cực đại. <em>Yêu cầu:</em> Áp lực nước xối cực mạnh để làm mát liên tục.");
            }

            // Material specific notices (Chỉ thép xưởng: SCM420 & SCM440)
            const curWsMat = state.wsMaterial || 'SCM420';
            if (curWsMat === 'SCM420') {
                wsNotices.push("🛡️ <strong>Thép mềm SCM420 (HB &lt; 200):</strong> Phoi dẻo dễ dính bám. Hệ thống đã tự động tăng Po thêm 1 nấc và giảm VF để giữ khoảng cách phóng điện an toàn, chống đoản mạch.");
            } else if (curWsMat === 'SCM440') {
                wsNotices.push("💎 <strong>Thép tôi cứng SCM440 (28-32 HRC):</strong> Thoát xỉ giòn rất trơn tru. Hệ thống tăng Ton và VF giúp nâng cao tốc độ cắt và bề mặt phẳng sáng bóng.");
            }

            // Ultra thick notice
            if (state.thickness > 160) {
                wsNotices.push("📏 <strong>Phôi siêu dày (H &gt; 160mm):</strong> Đã kích hoạt 6 sò công suất (IP=6 kịch trần). Năng suất cắt được điều khiển tối ưu thông qua biến thiên chu kỳ nghỉ Po và điện áp theo dõi VF.");
            }

            // Multi-pass notice (1 to 5 Pass)
            const curWsPass = state.wsPassCount || 1;
            if (curWsPass === 2) {
                wsNotices.push("🎯 <strong>Quy trình 2 Pass chuẩn xác:</strong> Pass 1 phá thô chừa phôi $O_2$; Pass 2 vi xung siêu mịn lướt phạt sạch đỉnh núi lửa $Rz_1$, $Ra \le 1.4 - 1.8\mu m$.");
            } else if (curWsPass === 3) {
                wsNotices.push("🎯 <strong>Quy trình 3 Pass tinh xảo:</strong> Pass 1 phá thô; Pass 2 bán tinh sửa côn và phẳng gờ thô; Pass 3 cắt tinh vi xung Volt Low đạt độ bóng cao $Ra \le 1.0 - 1.2\mu m$.");
            } else if (curWsPass === 4) {
                wsNotices.push("💎 <strong>Quy trình 4 Pass siêu tinh:</strong> 2 Pass bán tinh triệt tiêu hoàn toàn vi sóng kết hợp Pass 4 vi xung nano xóa sạch lớp biến trắng nhiệt, $Ra \le 0.6 - 0.8\mu m$.");
            } else if (curWsPass === 5) {
                wsNotices.push("✨ <strong>Quy trình 5 Pass bóng gương (Chuẩn xưởng 5P-01):</strong> Tuân thủ từng nấc xung thực nghiệm $1\mu s$ (Pass 5), dòng phóng $<0.05\text{A}$, bề mặt bóng gương quang học $Ra \le 0.4 - 0.6\mu m$.");
            }

            wsNoticeList.innerHTML = wsNotices.map(n => `<li>${n}</li>`).join('');
        }

        // Render Total Time
        if (typeof totalTimeText !== 'undefined' && totalTimeText) {
            if (totalMinutes < 60) {
                totalTimeText.textContent = `${totalMinutes.toFixed(1)} phút`;
            } else {
                const hrs = Math.floor(totalMinutes / 60);
                const mins = Math.round(totalMinutes % 60);
                totalTimeText.textContent = `${hrs} giờ ${mins} phút (~${totalMinutes.toFixed(0)}p)`;
            }
        }

        if (typeof wsTotalTimeText !== 'undefined' && wsTotalTimeText) {
            const wsTimeMins = parseFloat(wsCalc.time_min);
            if (wsTimeMins < 60) {
                wsTotalTimeText.textContent = `${wsTimeMins.toFixed(1)} phút`;
            } else {
                const hrs = Math.floor(wsTimeMins / 60);
                const mins = Math.round(wsTimeMins % 60);
                wsTotalTimeText.textContent = `${hrs} giờ ${mins} phút (~${wsTimeMins.toFixed(0)}p)`;
            }
        }

        // Tự động nạp chế độ bề mặt mịn tương ứng vào ô nhập riêng & Chạy phân tích so sánh mặc định
        populateSmoothCustomDefaults();
        runCustomAnalysis(false);
        if (typeof renderLectureKnowledge === 'function') {
            renderLectureKnowledge();
        }
        if (typeof updateTab1SyncPreview === 'function') {
            updateTab1SyncPreview();
        }
    }

    // 6. COPY TABLE TO CLIPBOARD
    // ==========================================

    function copyTableToClipboard() {
        const { rows } = calculateEDM(state);
        const strat = STRATEGY_CONFIGS[state.strategyLevel] || STRATEGY_CONFIGS[6];
        const matNames = {
            'SCM420': 'Thép SCM420',
            'SCM440': 'Thép tôi SCM440',
            'COPPER': 'Đồng (Cu/Thau)',
            'ALUMINUM': 'Nhôm (Al 6061/7075)'
        };
        const matLabel = matNames[state.material] || state.material;
        let text = `AUTOCUT EDM SERVO - BẢNG THÔNG SỐ CẮT (TAB 1 CHUẨN HÃNG)\n`;
        text += `Vật liệu: ${matLabel} | Chiều dày H: ${state.thickness}mm | Quy trình: ${state.passCount} Pass | Chiến lược: ${strat.name}\n\n`;
        text += `P\tTon\tToff\tIP\tV\tVF\tWire\tOFFSET\tFc(mm2/p)\tRa\tSai số\n`;
        
        rows.forEach(r => {
            text += `${r.passName}\t${r.ti}\t${r.Po}\t${r.IP}\t${r.Voltage}\t${r.VF}\t${r.Wire}\t${r.offsetText}\t${r.speedArea}\t${r.Ra}\t${r.tolerance}\n`;
        });

        navigator.clipboard.writeText(text).then(() => {
            btnCopyTable.textContent = '✅ Đã Copy!';
            setTimeout(() => {
                btnCopyTable.textContent = '📋 Copy Bảng';
            }, 2000);
        });
    }

    function copyWorkshopTableToClipboard() {
        const wsRows = generateWorkshopRows(state);
        const strat = WS_STRATEGY_CONFIGS[state.wsStrategyLevel] || WS_STRATEGY_CONFIGS[4];
        const matNames = {
            'SCM420': 'Thép mềm SCM420 (HB<200)',
            'SCM440': 'Thép tôi SCM440 (28-32HRC)'
        };
        const matLabel = matNames[state.wsMaterial] || matNames['SCM420'];
        const wsPassNum = state.wsPassCount || 1;
        let text = "AUTOCUT EDM SERVO - THÔNG SỐ CẮT & BÙ DAO OFFSET (TAB 1)\n";
        text += "Vật liệu: " + matLabel + " | Chiều dày H: " + state.thickness + "mm | Quy trình: " + wsPassNum + " Pass | Chế độ: " + strat.name + "\n\n";
        text += "P\tPon(μs)\tPoff(Po)\tIP(Sò)\tVolt\tVF\tWire\tOFFSET(mm)\tFc thực(mm2/p)\tFc máy H40\tGiới hạn(Hz)\tAmpe(A)\tRa\n";
        
        wsRows.forEach((r, idx) => {
            const offEl = document.getElementById("ws-dyn-offset-" + idx);
            const offsetVal = offEl ? offEl.textContent.trim() : r.offsetText;
            const fcEl = document.getElementById("ws-dyn-fc-" + idx);
            const fcVal = fcEl ? fcEl.textContent.trim() : r.speedArea;
            const fch40El = document.getElementById("ws-dyn-fch40-" + idx);
            const fch40Val = fch40El ? fch40El.textContent.trim() : r.speedAreaH40;
            const ampeEl = document.getElementById("ws-dyn-ampe-" + idx);
            const ampeVal = ampeEl ? ampeEl.textContent.trim() : r.ampe;
            const hzEl = document.getElementById("ws-dyn-hz-" + idx);
            const hzVal = hzEl ? hzEl.textContent.trim() : (r.hz || '--');
            const raEl = document.getElementById("ws-dyn-ra-" + idx);
            const raVal = raEl ? raEl.textContent.trim() : r.Ra;

            const ov = (state.wsCustomOverrides && state.wsCustomOverrides[idx]) || {};
            const ti = ov.ti !== undefined ? ov.ti : r.ti;
            const po = ov.Po !== undefined ? ov.Po : r.Po;
            const ip = ov.IP !== undefined ? ov.IP : r.IP;
            const volt = ov.Voltage !== undefined ? ov.Voltage : r.Voltage;
            const vf = ov.VF !== undefined ? ov.VF : r.VF;
            const wire = ov.Wire !== undefined ? ov.Wire : r.Wire;

            text += r.passName + "\t" + ti + "\t" + po + "\t" + ip + "\t" + volt + "\t" + vf + "\t" + wire + "\t" + offsetVal + "\t" + fcVal + "\t" + fch40Val + "\t" + hzVal + "\t" + ampeVal + "\t" + raVal + "\n";
        });

        navigator.clipboard.writeText(text).then(() => {
            if (wsBtnCopyTable) {
                wsBtnCopyTable.textContent = '✅ Đã Copy!';
                setTimeout(() => {
                    wsBtnCopyTable.textContent = '📋 Copy Bảng';
                }, 2000);
            }
        });
    }

    const CURRENT_VERSION = "3.5.62";

    // 7a. Register Service Worker (Hỗ trợ chạy Offline khi mất mạng)
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('./sw.js?v=' + CURRENT_VERSION)
                .then(reg => {
                    console.log('PWA Service Worker registered:', reg.scope);
                })
                .catch(err => {
                    console.warn('Service Worker registration skipped:', err);
                });
        });
    }

    // 7b. Quản lý trạng thái Mạng (Online / Offline)
    const networkBadge = document.getElementById('network-badge');
    function updateNetworkStatus() {
        if (!networkBadge) return;
        if (navigator.onLine) {
            networkBadge.textContent = '🟢 Online';
            networkBadge.className = 'net-badge net-online';
            checkForForceUpdate();
        } else {
            networkBadge.textContent = '🟡 Offline (Bản lưu trong máy)';
            networkBadge.className = 'net-badge net-offline';
            showToast('📡 Đang dùng chế độ ngoại tuyến (Không có mạng vẫn chạy tốt!)');
        }
    }
    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    updateNetworkStatus();

    // 7c. Tự động kiểm tra cập nhật khi có mạng
    async function checkForForceUpdate() {
        if (!navigator.onLine) return; // Mất mạng thì không kiểm tra, để offline mượt mà
        try {
            const response = await fetch('version.json?_t=' + Date.now(), {
                cache: 'no-store',
                headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' }
            });
            if (!response.ok) return;
            const data = await response.json();
            
            const storedVersion = localStorage.getItem('autocut_app_version');
            if (data.version && storedVersion && data.version !== storedVersion) {
                localStorage.setItem('autocut_app_version', data.version);
                
                // Hủy đăng ký Service Worker cũ & dọn cache
                if ('serviceWorker' in navigator) {
                    const registrations = await navigator.serviceWorker.getRegistrations();
                    for (let registration of registrations) {
                        await registration.unregister();
                    }
                }
                if ('caches' in window) {
                    const keys = await caches.keys();
                    await Promise.all(keys.map(k => caches.delete(k)));
                }

                // Thông báo & tự động tải bản mới
                showToast(`⚡ Đã đồng bộ bản mới nhất (${data.version})!`);
                setTimeout(() => {
                    const cleanUrl = window.location.href.split('?')[0];
                    window.location.replace(cleanUrl + '?v=' + Date.now());
                }, 600);
            } else if (!storedVersion && data.version) {
                localStorage.setItem('autocut_app_version', data.version);
            }
        } catch (e) {
            console.warn('Auto sync check skipped:', e);
        }
    }

    async function forceHardRefresh() {
        showToast('🔄 Đang dọn sạch bộ nhớ đệm & tải bản mới nhất...');
        try {
            localStorage.removeItem('autocut_app_version');
            if (typeof sessionStorage !== 'undefined') {
                sessionStorage.clear();
            }
            // 1. Huỷ đăng ký Service Worker cũ
            if ('serviceWorker' in navigator) {
                const registrations = await navigator.serviceWorker.getRegistrations();
                for (let reg of registrations) {
                    await reg.unregister();
                }
            }
            // 2. Xoá sạch toàn bộ Cache Storage của trình duyệt
            if ('caches' in window) {
                const keys = await caches.keys();
                await Promise.all(keys.map(k => caches.delete(k)));
            }
        } catch (e) {
            console.warn('Cache clear error:', e);
        }

        // 3. Tải lại trang với query string chống cache tuyệt đối
        setTimeout(() => {
            const cleanUrl = window.location.href.split('?')[0];
            window.location.href = cleanUrl + '?force_reload=' + Date.now();
        }, 500);
    }

    function showToast(msg) {
        let toast = document.getElementById('update-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'update-toast';
            toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#00f0ff;color:#000;padding:10px 20px;border-radius:24px;font-weight:700;font-size:13px;box-shadow:0 6px 24px rgba(0,240,255,0.6);z-index:99999;font-family:sans-serif;text-align:center;pointer-events:none;';
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.display = 'block';
        setTimeout(() => {
            if (toast) toast.style.display = 'none';
        }, 3500);
    }

    // Attach button listeners
    const btnForceUpdate = document.getElementById('btn-force-update');
    if (btnForceUpdate) {
        btnForceUpdate.addEventListener('click', forceHardRefresh);
    }
    const linkForceUpdate = document.getElementById('link-force-update');
    if (linkForceUpdate) {
        linkForceUpdate.addEventListener('click', forceHardRefresh);
    }

    // Check on launch & on tab focus
    checkForForceUpdate();
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            checkForForceUpdate();
        }
    });

            // =========================================================================
            // RENDER THƯ VIỆN THỰC NGHIỆM XƯỞNG (6 SUB-TABS: 1 PASS ĐẾN 6 PASS)
            // Chuẩn hóa:
            // 1. Tên vật liệu rút gọn: SCM420 -> HB<200, SCM440 -> 30HRC
            // 2. Loại bỏ các trường hợp không cắt được (lưu trữ đầy đủ ở WORKSHOP_DATA_BANK.md)
            // 3. Cột H & Vật liệu chỉ ghi ở dòng Pass 1, H được đánh dấu bằng .h-badge
            // 4. Tự động sắp xếp trật tự theo chiều dày H tăng dần (Ascending Sort Engine)
            // 5. Cố định thead sticky không trôi khi cuộn, phân biệt mẻ cắt bằng 2 màu nền
            // =========================================================================
                        const WS_LIB_BENCHMARK_JOBS = {
                1: [
                    // H=12 (Quy đổi từ Pass 1 bài cắt 5P-01 có đo kiểm vách P1)
                    { H: 12, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 20, Toff: 5, IP: 3, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz", offset: "0,101", actualOffset: "0,101", calcOffset: "0,0988", length: "128mm", actualTime: "19p50'", calcTime: "19p49'", actualAmpe: "4A", calcAmpe: "3.6A", actualSpeed: "275-285 mm²/p", calcSpeedH40: "258 mm²/p" }] },
                    // H=12 (SCM420, STT 22 - Cắt chày 1 Pass Volt Low)
                    { H: 12, material: "HB<200", passes: [{ Ton: 16, Toff: 6, IP: 3, Wire: 1, Volt: "L", VF: 60, maxSpeed: "150Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,0963", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,5A - 2,7A", calcAmpe: "2.5A", actualSpeed: "--", calcSpeedH40: "176 mm²/p" }] },
                    // H=30 (SCM440, STT 1 - Chuẩn gốc 1 Pass)
                    { H: 30, material: "30HRC", passes: [{ Ton: 32, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "200Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,1003", length: "30mm", actualTime: "8p40'", calcTime: "7p45'", actualAmpe: "4,45A - 4,5A", calcAmpe: "4.7A", actualSpeed: "165-175 mm²/p", calcSpeedH40: "155 mm²/p" }] },
                    // H=40 (SCM440, STT 2 - Chuẩn gốc 1 Pass)
                    { H: 40, material: "30HRC", passes: [{ Ton: 36, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "180Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,1003", length: "30mm", actualTime: "9p36'", calcTime: "10p09'", actualAmpe: "4,35A - 4,4A", calcAmpe: "4.6A", actualSpeed: "130-140 mm²/p", calcSpeedH40: "118 mm²/p" }] },
                    // H=63 (SCM420, STT 3 - Cắt chày 1 Pass)
                    { H: 63, material: "HB<200", passes: [{ Ton: 44, Toff: 7, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,0997", length: "27mm", actualTime: "14p20'", calcTime: "14p53'", actualAmpe: "4,1A - 4,2A", calcAmpe: "4.2A", actualSpeed: "75-85 mm²/p", calcSpeedH40: "73 mm²/p" }] },
                    // H=63 (SCM420, STT 18 - Cắt chày 1 Pass)
                    { H: 63, material: "HB<200", passes: [{ Ton: 44, Toff: 8, IP: 4, Wire: 1, Volt: "H", VF: 57, maxSpeed: "150Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,0987", length: "22,3mm", actualTime: "17p40'", calcTime: "17p40'", actualAmpe: "3,3A - 3,4A", calcAmpe: "2.9A", actualSpeed: "50-65 mm²/p", calcSpeedH40: "50 mm²/p" }] },
                    // H=68 (SCM440, STT 6 - Cắt chày Volt Low)
                    { H: 68, material: "30HRC", passes: [{ Ton: 70, Toff: 7, IP: 3, Wire: 1, Volt: "L", VF: 50, maxSpeed: "100Hz", offset: "0,097", actualOffset: "0,097", calcOffset: "0,0981", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,4A - 2,6A", calcAmpe: "2.0A", actualSpeed: "--", calcSpeedH40: "32 mm²/p" }] },
                    // H=75 (SCM420, STT 16 - Cắt cối 1 Pass)
                    { H: 75, material: "HB<200", passes: [{ Ton: 55, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "187Hz", offset: "0,112", actualOffset: "0,112", calcOffset: "0,1094", length: "50,3mm", actualTime: "1h13'", calcTime: "46p53'", actualAmpe: "3,4A - 3,5A", calcAmpe: "3.3A", actualSpeed: "50-65 mm²/p", calcSpeedH40: "43 mm²/p" }] },
                    // H=85 (Quy đổi từ Pass 1 bài cắt 2P-10 có đo kiểm vách P1)
                    { H: 85, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 70, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 61, maxSpeed: "150Hz", offset: "0,1025", actualOffset: "0,1025", calcOffset: "0,1034", length: "65,6mm", actualTime: "48p", calcTime: "49p20'", actualAmpe: "3,6A - 3,7A", calcAmpe: "3.6A", actualSpeed: "55-65 mm²/p", calcSpeedH40: "53 mm²/p" }] },
                    // H=90 (SCM420, STT 21 - Cắt cối 1 Pass)
                    { H: 90, material: "HB<200", passes: [{ Ton: 80, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "150Hz", offset: "0,118", actualOffset: "0,118", calcOffset: "0,1185", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,6A", calcAmpe: "3.3A", actualSpeed: "50-60 mm²/p", calcSpeedH40: "34 mm²/p" }] },
                    // H=95 (SCM440, STT 17 - Cắt cối 1 Pass)
                    { H: 95, material: "30HRC", passes: [{ Ton: 82, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz", offset: "0,1135", actualOffset: "0,1135", calcOffset: "0,1087", length: "76mm", actualTime: "1h15'", calcTime: "1h17p18'", actualAmpe: "3,6A - 3,7A", calcAmpe: "3.3A", actualSpeed: "35-45 mm²/p", calcSpeedH40: "39 mm²/p" }] },
                    // H=110 (SCM420, STT 19 - Cắt chày 1 Pass)
                    { H: 110, material: "HB<200", passes: [{ Ton: 100, Toff: 10, IP: 5, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz", offset: "0,105", actualOffset: "0,105", calcOffset: "0,1068", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,7A - 2,8A", calcAmpe: "2.8A", actualSpeed: "30-40 mm²/p", calcSpeedH40: "32 mm²/p" }] },
                    // H=140 (SCM420, STT 7 - Cắt chày 1 Pass)
                    { H: 140, material: "HB<200", passes: [{ Ton: 120, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "50Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,0987", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,8A", calcAmpe: "3.6A", actualSpeed: "--", calcSpeedH40: "29 mm²/p" }] },
                    // H=140 (SCM420, STT 12 - Cắt chày 1 Pass)
                    { H: 140, material: "HB<200", passes: [{ Ton: 100, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 60, maxSpeed: "100Hz", offset: "0,102", actualOffset: "0,102", calcOffset: "0,1052", length: "28,4mm", actualTime: "36p", calcTime: "36p", actualAmpe: "3,7A - 3,8A", calcAmpe: "3.8A", actualSpeed: "30-40 mm²/p", calcSpeedH40: "32 mm²/p" }] },
                    // H=160 (SCM420, STT 15 - Cắt cối 1 Pass)
                    { H: 160, material: "HB<200", passes: [{ Ton: 120, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "154Hz", offset: "0,120", actualOffset: "0,120", calcOffset: "0,1143", length: "32,3mm", actualTime: "59p", calcTime: "55p41'", actualAmpe: "2,8A - 3A", calcAmpe: "2.9A", actualSpeed: "18-28 mm²/p", calcSpeedH40: "23 mm²/p" }] },
                    // H=165 (Quy đổi từ Pass 1 bài cắt 2P-12 có đo kiểm vách P1)
                    { H: 165, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 135, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "60Hz", offset: "0,1125", actualOffset: "0,1125", calcOffset: "0,1068", length: "43,6mm", actualTime: "1h17'", calcTime: "1h03p34'", actualAmpe: "2,8A - 3,0A", calcAmpe: "2.9A", actualSpeed: "15-35 mm²/p", calcSpeedH40: "27 mm²/p" }] },
                    // H=200 (SCM420, STT 23 - Cắt cối 1 Pass phôi siêu dày)
                    { H: 200, material: "HB<200", passes: [{ Ton: 120, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "60Hz", offset: "0,108", actualOffset: "0,108", calcOffset: "0,1102", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "--", calcAmpe: "3.5A", actualSpeed: "--", calcSpeedH40: "18 mm²/p" }] },
                    // H=290 (SCM440, STT 20 - Cắt cối 1 Pass phôi siêu dày)
                    { H: 290, material: "30HRC", passes: [{ Ton: 135, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 75, maxSpeed: "50Hz", offset: "0,110", actualOffset: "0,110", calcOffset: "0,1156", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "--", calcAmpe: "3.4A", actualSpeed: "--", calcSpeedH40: "15 mm²/p" }] },
                    // H=300 (SCM440, STT 14 - Cắt cối 1 Pass mốc biên)
                    { H: 300, material: "30HRC", passes: [{ Ton: 120, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "50Hz", offset: "0,115", actualOffset: "0,115", calcOffset: "0,1150", length: "76,1mm", actualTime: "3h", calcTime: "3h14p34'", actualAmpe: "3,7A - 3,9A", calcAmpe: "3.7A", actualSpeed: "12-20 mm²/p", calcSpeedH40: "16 mm²/p" }] }
                ],
                2: [
                    // H=12
                    { H: 12, material: "30HRC", passes: [
                        { Ton: 20, Toff: 7, IP: 2, Wire: 2, Volt: "L", VF: 50, maxSpeed: "150Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,0997", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "1,3A - 1,5A", calcAmpe: "1.3A", actualSpeed: "--", calcSpeedH40: "97 mm²/p" },
                        { Ton: 12, Toff: 7, IP: 2, Wire: 2, Volt: "L", VF: 20, maxSpeed: "130Hz", offset: "0,040", actualOffset: "0,040", calcOffset: "0,012", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "< 0,2A", calcAmpe: "< 0.2A", actualSpeed: "--", calcSpeedH40: "312 mm²/p" }
                    ]},
                    // H=30
                    { H: 30, material: "HB<200", passes: [
                        { Ton: 28, Toff: 6, IP: 4, Wire: 1, Volt: "H", VF: 60, maxSpeed: "200Hz", offset: "0,1075", actualOffset: "0,1075", calcOffset: "0,0968", length: "644mm", actualTime: "3h08p", calcTime: "3h08p", actualAmpe: "4,1A", calcAmpe: "4.0A", actualSpeed: "140-150 mm²/p", calcSpeedH40: "137 mm²/p" },
                        { Ton: 16, Toff: 5, IP: 2, Wire: 2, Volt: "L", VF: 40, maxSpeed: "150Hz", offset: "0,022", actualOffset: "0,022", calcOffset: "0,0177", length: "644mm", actualTime: "1h12p", calcTime: "1h12p", actualAmpe: "0,1 - 0,2A", calcAmpe: "< 0.2A", actualSpeed: "360 mm²/p", calcSpeedH40: "360 mm²/p" }
                    ]},
                    // H=32
                    { H: 32, material: "30HRC", passes: [
                        { Ton: 30, Toff: 7, IP: 3, Wire: 1, Volt: "L", VF: 50, maxSpeed: "200Hz", offset: "0,091", actualOffset: "0,091", calcOffset: "0,0979", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,0A - 2,2A", calcAmpe: "2.0A", actualSpeed: "--", calcSpeedH40: "90 mm²/p" },
                        { Ton: 5, Toff: 15, IP: 1, Wire: 1, Volt: "L", VF: 10, maxSpeed: "130Hz", offset: "0,030", actualOffset: "0,030", calcOffset: "0,0143", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "< 0,2A", calcAmpe: "< 0.2A", actualSpeed: "--", calcSpeedH40: "312 mm²/p" }
                    ]},
                    // H=60
                    { H: 60, material: "30HRC", passes: [
                        { Ton: 50, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 62, maxSpeed: "150Hz", offset: "0,099", actualOffset: "0,099", calcOffset: "0,0943", length: "68mm", actualTime: "40p20'", calcTime: "40p36'", actualAmpe: "3,5A - 3,6A", calcAmpe: "3.3A", actualSpeed: "65-75 mm²/p", calcSpeedH40: "67 mm²/p" },
                        { Ton: 16, Toff: 6, IP: 2, Wire: 2, Volt: "H", VF: 40, maxSpeed: "100Hz", offset: "0,022", actualOffset: "0,022", calcOffset: "0,022", length: "68mm", actualTime: "12p", calcTime: "11p20'", actualAmpe: "0,5A - 0,6A", calcAmpe: "0.5 - 1.0A", actualSpeed: "240 mm²/p", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=62
                    { H: 62, material: "30HRC", passes: [
                        { Ton: 70, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 50, maxSpeed: "150Hz", offset: "0,092", actualOffset: "0,092", calcOffset: "0,0965", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,8A", calcAmpe: "3.3A", actualSpeed: "--", calcSpeedH40: "85 mm²/p" },
                        { Ton: 15, Toff: 7, IP: 2, Wire: 2, Volt: "L", VF: 20, maxSpeed: "100Hz", offset: "0,030", actualOffset: "0,030", calcOffset: "0,0251", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "< 0,2A", calcAmpe: "< 0.2A", actualSpeed: "--", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=63
                    { H: 63, material: "HB<200", passes: [
                        { Ton: 44, Toff: 7, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz", offset: "0,093", actualOffset: "0,093", calcOffset: "0,0997", length: "30mm", actualTime: "16p26'", calcTime: "16p26'", actualAmpe: "4,2A", calcAmpe: "4.2A", actualSpeed: "75-85 mm²/p", calcSpeedH40: "73 mm²/p" },
                        { Ton: 20, Toff: 5, IP: 3, Wire: 2, Volt: "H", VF: 40, maxSpeed: "100Hz", offset: "0,024", actualOffset: "0,024", calcOffset: "0,0228", length: "30mm", actualTime: "5p20'", calcTime: "5p", actualAmpe: "0,1 - 0,2A", calcAmpe: "0.5 - 1.0A", actualSpeed: "240 mm²/p", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=75 (SCM420, STT 2P-14 - Đo kiểm khép kín 2 Pass)
                    { H: 75, material: "HB<200", passes: [
                        { Ton: 55, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "187Hz", offset: "0,0945", actualOffset: "0,092", calcOffset: "0,1094", length: "50,3mm", actualTime: "1h13'", calcTime: "1h02p", actualAmpe: "3,4A - 3,5A", calcAmpe: "3.3A", actualSpeed: "50-65 mm²/p", calcSpeedH40: "32 mm²/p" },
                        { Ton: 18, Toff: 7, IP: 3, Wire: 2, Volt: "H", VF: 32, maxSpeed: "100Hz", offset: "0,0255", actualOffset: "0,023", calcOffset: "0,024", length: "50,3mm", actualTime: "8p40'", calcTime: "8p40'", actualAmpe: "0,5A - 1,0A", calcAmpe: "0.5 - 1.0A", actualSpeed: "240 mm²/p", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=85
                    { H: 85, material: "30HRC", passes: [
                        { Ton: 70, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 61, maxSpeed: "150Hz", offset: "0,1025", actualOffset: "0,1025", calcOffset: "0,1034", length: "65,6mm", actualTime: "48p", calcTime: "47p43'", actualAmpe: "3,6A - 3,7A", calcAmpe: "3.6A", actualSpeed: "55-65 mm²/p", calcSpeedH40: "55 mm²/p" },
                        { Ton: 20, Toff: 6, IP: 3, Wire: 2, Volt: "H", VF: 36, maxSpeed: "100Hz", offset: "0,030", actualOffset: "0,030", calcOffset: "0,0274", length: "65,6mm", actualTime: "10p24'", calcTime: "10p56'", actualAmpe: "0,5A - 1,0A", calcAmpe: "0.5 - 1.0A", actualSpeed: "240 mm²/p", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=140
                    { H: 140, material: "HB<200", passes: [
                        { Ton: 120, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "60Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,0992", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,8A", calcAmpe: "3.6A", actualSpeed: "--", calcSpeedH40: "34 mm²/p" },
                        { Ton: 25, Toff: 7, IP: 2, Wire: 2, Volt: "L", VF: 25, maxSpeed: "100Hz", offset: "0,030", actualOffset: "0,030", calcOffset: "0,0344", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "< 0,2A", calcAmpe: "< 0.2A", actualSpeed: "--", calcSpeedH40: "240 mm²/p" }
                    ]},
                    // H=165 (STT 2P-12 - Mẫu chuẩn xưởng duy nhất)
                    { H: 165, material: "30HRC", passes: [
                        { Ton: 135, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "60Hz", offset: "0,1075", actualOffset: "0,1075", calcOffset: "0,1068", length: "43,6mm", actualTime: "1h17'", calcTime: "1h16p", actualAmpe: "2,8A - 3,0A", calcAmpe: "2.9A", actualSpeed: "15-35 mm²/p", calcSpeedH40: "23 mm²/p" },
                        { Ton: 40, Toff: 7, IP: 3, Wire: 2, Volt: "H", VF: 36, maxSpeed: "80Hz", offset: "0,015", actualOffset: "0,015", calcOffset: "0,0192", length: "43,6mm", actualTime: "9p", calcTime: "9p05'", actualAmpe: "0,5A - 1,5A", calcAmpe: "0.5 - 1.5A", actualSpeed: "190 mm²/p", calcSpeedH40: "192 mm²/p" }
                    ]}
                ],
                3: [],
                4: [],
                5: [
                    // H=12 (SCM440, Cắt lấy chày)
                    { H: 12, material: "30HRC", passes: [
                        { Ton: 20, Toff: 5, IP: 3, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz", offset: "0,093", actualOffset: "0,093", calcOffset: "0,0988", length: "128mm", actualTime: "19p50'", calcTime: "19p50'", actualAmpe: "4A", calcAmpe: "3.6A", actualSpeed: "275-285 mm²/p", calcSpeedH40: "258 mm²/p" },
                        { Ton: 14, Toff: 5, IP: 2, Wire: 2, Volt: "L", VF: 42, maxSpeed: "140Hz", offset: "0,018", actualOffset: "0,018", calcOffset: "0,0154", length: "128mm", actualTime: "16p", calcTime: "15p14'", actualAmpe: "0,3A - 0,5A", calcAmpe: "< 0.2A", actualSpeed: "232-340 mm²/p", calcSpeedH40: "336 mm²/p" },
                        { Ton: 6, Toff: 8, IP: 1, Wire: 3, Volt: "L", VF: 35, maxSpeed: "120Hz", offset: "0,009", actualOffset: "0,009", calcOffset: "0,009", length: "128mm", actualTime: "--", calcTime: "17p47'", actualAmpe: "< 0,2A", calcAmpe: "< 0.2A", actualSpeed: "--", calcSpeedH40: "288 mm²/p" },
                        { Ton: 2, Toff: 12, IP: 1, Wire: 3, Volt: "L", VF: 25, maxSpeed: "100Hz", offset: "0,004", actualOffset: "0,004", calcOffset: "0,004", length: "128mm", actualTime: "--", calcTime: "21p20'", actualAmpe: "< 0,1A", calcAmpe: "< 0.1A", actualSpeed: "--", calcSpeedH40: "240 mm²/p" },
                        { Ton: 1, Toff: 16, IP: 1, Wire: 3, Volt: "L", VF: 20, maxSpeed: "80Hz", offset: "0,002", actualOffset: "0,002", calcOffset: "0,002", length: "128mm", actualTime: "--", calcTime: "26p40'", actualAmpe: "~ 0,05A", calcAmpe: "~ 0.05A", actualSpeed: "--", calcSpeedH40: "192 mm²/p" }
                    ]}
                ],
                6: []
            };

            let wsLibCurrentTab = 1;

            function renderWsLibSubTab(tabPass) {
                wsLibCurrentTab = tabPass;
                const libBodyContainer = document.getElementById('ws-lib-subtab-content');
                if (!libBodyContainer) return;

                // Update tab buttons active class
                const tabBtns = document.querySelectorAll('.ws-lib-tab-btn');
                tabBtns.forEach(btn => {
                    const p = parseInt(btn.dataset.tabPass, 10);
                    if (p === tabPass) btn.classList.add('active');
                    else btn.classList.remove('active');
                });

                const rawJobs = WS_LIB_BENCHMARK_JOBS[tabPass] || [];
                
                // 1. Tự động loại bỏ các bài cắt không thực hiện được (Không cắt được)
                const validJobs = rawJobs.filter(job => !job.passes.some(p => p.calcSpeed === "Không cắt được"));

                // 2. Tự động sắp xếp tuần tự theo chiều dày H tăng dần (Ascending Sort)
                const sortedJobs = [...validJobs].sort((a, b) => a.H - b.H);

                if (sortedJobs.length === 0) {
                    libBodyContainer.innerHTML = `
                        <div class="ws-lib-empty-state">
                            <i class="fa fa-clipboard-list"></i>
                            <h4 style="margin: 0 0 8px 0; color: #f1f5f9; font-size: 15px;">Chưa có dữ liệu thực nghiệm xưởng cho chế độ ${tabPass} Pass</h4>
                            <p style="font-size: 12px; color: #94a3b8; max-width: 500px; margin: 0 auto;">Khi bạn thực hiện bài cắt mới tại xưởng và cung cấp kết quả đo kiểm, dữ liệu sẽ được chuẩn hóa và tự động sắp xếp ngay vào bảng này.</p>
                        </div>
                    `;
                    return;
                }

                let subtabNoteHtml = '';
                if (tabPass === 1) {
                    subtabNoteHtml = `
                        <div style="margin-bottom: 10px; font-size: 12px; color: #94a3b8; display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
                            <span style="display: inline-flex; align-items: center; gap: 5px;"><span class="h-badge">H</span> Mẫu cắt 1 Pass chuẩn</span>
                            <span style="display: inline-flex; align-items: center; gap: 5px;"><span class="h-badge h-badge-multipass">H</span> Mẫu quy đổi từ Pass 1 (Cắt nhiều Pass có đo kiểm kích thước sau P1)</span>
                        </div>
                    `;
                }

                let bannerHtml = '';
                if (tabPass === 5) {
                    bannerHtml = `
                        <div class="ws-lib-status-banner" style="background: rgba(34, 197, 94, 0.12); border-color: rgba(34, 197, 94, 0.35); color: #4ade80;">
                            <i class="fa fa-check-circle"></i>
                            <span><strong>Đã hoàn thành kiểm chứng thực nghiệm 5 Pass tại xưởng (H=12mm, SCM440):</strong> Cắt chày chu vi 128mm, tổng thời gian 1h45p. Đo Panme: P1=54,08mm &rarr; P2=54,045mm &rarr; P5=54,030mm (to hơn lập trình 0,030mm). Offset Pass 1 chuẩn hiệu chỉnh: <strong>0,093mm</strong>.</span>
                        </div>
                    `;
                }

                // Render rows with alternating zebra striping per job, H badge on Pass 1 only
                let tableRowsHtml = '';
                sortedJobs.forEach((job, jobIdx) => {
                    const jobClass = jobIdx % 2 === 0 ? 'job-even' : 'job-odd';
                    job.passes.forEach((p, passIdx) => {
                        const matLabel = passIdx === 0 ? job.material : '';
                        const hBadgeClass = job.fromMultiPass ? 'h-badge h-badge-multipass' : 'h-badge';
                        const hTitle = job.fromMultiPass ? ' title="Quy đổi từ Pass 1 (Cắt nhiều Pass có đo kiểm vách sau P1)"' : '';
                        const hLabel = passIdx === 0 ? `<span class="${hBadgeClass}"${hTitle}>${job.H}</span>` : '';
                        const voltClass = p.Volt === 'H' || p.Volt === 'High' ? 'col-volt-h' : 'col-volt-l';

                        
                        let diffStr = '--';
                        let diffStyle = 'color: #94a3b8; font-weight: 600;';
                        const actStr = p.actualOffset || p.offset || '';
                        const calcStr = p.calcOffset || '';
                        if (actStr && calcStr && actStr !== '--' && calcStr !== '--') {
                            const actVal = parseFloat(actStr.replace(',', '.'));
                            const calcVal = parseFloat(calcStr.replace(',', '.'));
                            if (!isNaN(actVal) && !isNaN(calcVal)) {
                                const diff = actVal - calcVal;
                                const absDiff = Math.abs(diff);
                                if (absDiff < 0.00005) {
                                    diffStr = '0,0000';
                                    diffStyle = 'color: #4ade80; font-weight: 700; background: rgba(74, 222, 128, 0.1);';
                                } else {
                                    const sign = diff > 0 ? '+' : '-';
                                    diffStr = sign + absDiff.toFixed(4).replace('.', ',');
                                    const absUm = absDiff * 1000;
                                    if (absUm <= 3.5) {
                                        diffStyle = 'color: #4ade80; font-weight: 700; background: rgba(74, 222, 128, 0.1);';
                                    } else if (absUm <= 7.0) {
                                        diffStyle = 'color: #38bdf8; font-weight: 700; background: rgba(56, 189, 248, 0.1);';
                                    } else {
                                        diffStyle = 'color: #fbbf24; font-weight: 700; background: rgba(251, 191, 36, 0.1);';
                                    }
                                }
                            }
                        }

                        tableRowsHtml += `
                            <tr class="${jobClass}">
                                <td class="col-mat">${matLabel}</td>
                                <td class="col-h">${hLabel}</td>
                                <td>${p.Ton}</td>
                                <td>${p.Toff}</td>
                                <td>${p.IP}</td>
                                <td>${p.Wire}</td>
                                <td class="${voltClass}">${p.Volt}</td>
                                <td>${p.VF}</td>
                                <td><strong>${p.maxSpeed}</strong></td>
                                <td class="col-offset-act">${p.actualOffset || p.offset}</td>
                                <td class="col-offset-calc">${p.calcOffset || '--'}</td>
                                <td class="col-offset-diff" style="${diffStyle}" title="Sai số = Offset thực tế - Offset tính toán">${diffStr}</td>
                                <td>${p.length}</td>
                                <td class="col-time-act">${p.actualTime || p.time || '--'}</td>
                                <td class="col-time-calc" style="color: #38bdf8; font-weight: 600;">${p.calcTime || '--'}</td>
                                <td class="col-ampe-act" style="color: #f59e0b; font-weight: 600;">${p.actualAmpe || p.ampe || '--'}</td>
                                <td class="col-ampe-calc" style="color: #fbbf24; font-weight: 500;">${p.calcAmpe || '--'}</td>
                                <td class="col-speed-act" style="color: #38bdf8; font-weight: 500;">${p.actualSpeed || '--'}</td>
                                <td class="col-speed-h40" style="color: var(--accent-amber); font-weight: 600;">${p.calcSpeedH40}</td>
                            </tr>
                        `;
                    });
                });

                libBodyContainer.innerHTML = `
                    ${bannerHtml}
                    ${subtabNoteHtml}
                    <div class="ws-lib-table-container">
                        <table class="ws-lib-data-table">
                            <thead>
                                <tr>
                                    <th>Vật Liệu</th>
                                    <th>H</th>
                                    <th>Pon</th>
                                    <th>Poff</th>
                                    <th>IP</th>
                                    <th>Wire</th>
                                    <th>Volt</th>
                                    <th>VF</th>
                                    <th>Max Speed</th>
                                    <th>Offset thực tế</th>
                                    <th>Offset tính toán</th>
                                    <th>Sai số</th>
                                    <th>chiều dài cắt</th>
                                    <th>thời gian thực</th>
                                    <th>thời gian tính</th>
                                    <th>A thực tế</th>
                                    <th>A tính toán</th>
                                    <th>Fc thực tế</th>
                                    <th>Fc tính (H40)</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${tableRowsHtml}
                            </tbody>
                        </table>
                    </div>
                `;
            }

            const workshopLibContainer = document.getElementById('ws-workshop-library-container');
            if (workshopLibContainer) {
                workshopLibContainer.innerHTML = `
                    <div class="workshop-lib-header" id="ws-lib-toggle-btn" style="cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: var(--bg-card); padding: 10px 15px; border-radius: 6px; border-left: 4px solid var(--accent);">
                        <h4 style="margin: 0; color: var(--accent); font-size: 1.1em; display: flex; align-items: center; gap: 8px;"><i class="fa fa-book"></i> THƯ VIỆN THÔNG SỐ CẮT THỰC TẾ XƯỞNG (BENCHMARK GROUND TRUTH)</h4>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <span class="lib-offline-badge" style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; padding: 4px 10px; border-radius: 14px; background: rgba(192, 132, 252, 0.18); border: 1px solid rgba(192, 132, 252, 0.45); color: #d8b4fe; font-weight: 600; font-size: 11px;"><span>6 Ch&#7871; &#272;&#7897; C&#7855;t</span><svg id="ws-lib-toggle-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); transform: rotate(0deg); color: #c084fc; display: inline-block;"><polyline points="6 9 12 15 18 9"></polyline></svg></span>
                        </div>
                    </div>
                    <div id="ws-lib-content" style="margin-top: 15px; display: none;">
                        <div class="ws-lib-tabs-nav">
                            <button class="ws-lib-tab-btn active" data-tab-pass="1">1 Pass <span class="ws-lib-tab-count">15 bài</span></button>
                            <button class="ws-lib-tab-btn" data-tab-pass="2">2 Pass <span class="ws-lib-tab-count">9 bài</span></button>
                            <button class="ws-lib-tab-btn" data-tab-pass="3">3 Pass <span class="ws-lib-tab-count">0</span></button>
                            <button class="ws-lib-tab-btn" data-tab-pass="4">4 Pass <span class="ws-lib-tab-count">0</span></button>
                            <button class="ws-lib-tab-btn" data-tab-pass="5">5 Pass <span class="ws-lib-tab-count">1 bài</span></button>
                            <button class="ws-lib-tab-btn" data-tab-pass="6">6 Pass <span class="ws-lib-tab-count">0</span></button>
                        </div>
                        <div id="ws-lib-subtab-content">
                            <!-- Injected by JavaScript -->
                        </div>
                    </div>
                `;

                // Initial render of sub-tab 1
                renderWsLibSubTab(1);

                // Add toggle collapse logic
                const toggleBtn = document.getElementById('ws-lib-toggle-btn');
                const libContent = document.getElementById('ws-lib-content');
                const libIcon = document.getElementById('ws-lib-toggle-icon');
                if (toggleBtn && libContent && libIcon) {
                    toggleBtn.addEventListener('click', () => {
                        if (libContent.style.display === 'none') {
                            libContent.style.display = '';
                            libIcon.style.transform = 'rotate(180deg)';
                        } else {
                            libContent.style.display = 'none';
                            libIcon.style.transform = 'rotate(0deg)';
                        }
                    });
                }

                // Add sub-tab click events
                const tabBtns = document.querySelectorAll('.ws-lib-tab-btn');
                tabBtns.forEach(btn => {
                    btn.addEventListener('click', () => {
                        const passNum = parseInt(btn.dataset.tabPass, 10);
                        renderWsLibSubTab(passNum);
                    });
                });
            }

    // =========================================================================
    // 8. TAB 3: PHÒNG THÍ NGHIỆM & NGHIÊN CỨU VF (1 PASS TỰ DO)
    // =========================================================================
    const vfResearchState = {
        material: 'SCM440',
        H: 40,
        Ton: 36,
        Po: 5,
        IP: 4,
        Volt: 'High',
        VF: 65,
        wireRadius: 0.090 // Dây Moly Φ0.18 mm
    };

    // Hệ số mô hình vật lý nhiệt động học thực nghiệm EDM (Tab 3: Chuẩn hóa 100% bản chất vật lý & Tối ưu hóa đa biến)
    const VF_C0 = 0.00200;          // Hang so mang cach dien ban dau (+2.00 um)
    const VF_K_ELEC = 0.00070;      // Nang luong xung don toi uu (mm/sqrt(us*A))
    const VF_K_VF = 0.00210;        // He so bu tre buoc tien VF (+2.10 um / 10 vach VF so voi chuan 55)
    const VF_K_VIBR = 0.00350;      // Rung uon co hoc day Moly (mm)
    const VF_K_H_CONF = 0.00650;    // He so gioi han ap luc thuy tinh ranh sau phoi cao (mm)
    const VF_K_SPD = 0.00550;       // He so bu giam toc phoi sau (Speed < 150Hz khi H >= 110mm)
    const VF_K_SEC = 0.160;         // He so danh lua thu cap theo mat xi deo tich tu (mm)
    const VF_H_THRESH = 63.0;       // Nguong thau voi phun kep (H <= 63mm xoi sach phoi)
    const VF_PO_THRESH = 8.0;       // Nguong chu ky nghi Po xa phoi (Po <= 7 sinh nghen mat xi)
    const VF_S_EXP = 0.65;          // Luy thua suy giam do sau ranh nen mat xi

    function calcBaseSparkGap(H, Ton, IP, Volt, material = 'SCM440', speed = 150) {
        const isHard = (material === 'SCM440' || material === '30HRC');
        const u_ratio = (Volt === 'High' || Volt === 'H') ? 1.0 : 0.815;
        const d_elec = VF_K_ELEC * Math.sqrt(Math.max(1, Ton) * Math.max(1, IP)) * u_ratio;
        const d_h_conf = - VF_K_H_CONF * (H / 100.0);
        let d_vibr, gap, d_sec, d_spd;

        if (H <= 170) {
            d_vibr = VF_K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);
            d_spd = (H >= 110 && speed < 150) ? - VF_K_SPD * ((150.0 - speed) / 100.0) * Math.pow(H / 100.0, 1.2) : 0.0;
            const h_starve = Math.max(0.0, (H - VF_H_THRESH) / 100.0);
            const po_shortage = Math.max(0.0, (VF_PO_THRESH - 5.0) / 10.0); // Po chuan = 5
            const mat_boost = isHard ? 1.0 : 2.60;
            d_sec = VF_K_SEC * Math.pow(h_starve, VF_S_EXP) * po_shortage * mat_boost;
            gap = VF_C0 + d_elec + d_h_conf + d_vibr + d_spd + d_sec;
        } else {
            const gap170 = 0.0187;
            const targetGap300 = 0.0250;
            gap = gap170 + (H - 170) * (targetGap300 - gap170) / (300 - 170);
            d_vibr = gap - (VF_C0 + d_elec + d_h_conf);
            d_sec = 0.0;
            d_spd = 0.0;
        }

        return {
            c0: VF_C0,
            u_ratio: u_ratio,
            d_elec: d_elec,
            d_h_conf: d_h_conf,
            d_vibr: d_vibr,
            d_spd: d_spd,
            d_sec: d_sec,
            gap: gap,
            offset: 0.090 + gap,
            kerf: 0.180 + 2.0 * gap
        };
    }

    function calcVFSparkGap(H, Ton, IP, Volt, VF, Po = 5, material = 'SCM440', speed = 150) {
        const base = calcBaseSparkGap(H, Ton, IP, Volt, material, speed);
        let d_vf, d_sec_vf, d_po;
        const isHard = (material === 'SCM440' || material === '30HRC');

        if (H <= 170) {
            d_vf = VF_K_VF * ((VF - 55.0) / 10.0);
            const h_starve = Math.max(0.0, (H - VF_H_THRESH) / 100.0);
            const po_shortage_vf = Math.max(0.0, (VF_PO_THRESH - Po) / 10.0);
            const mat_boost = isHard ? 1.0 : 2.60;
            d_sec_vf = VF_K_SEC * Math.pow(h_starve, VF_S_EXP) * po_shortage_vf * mat_boost;
            d_po = d_sec_vf - base.d_sec; // Do lech bu theo chu ky Po thuc te
        } else {
            d_vf = VF_K_VF * 0.5 * ((VF - 65.0) / 10.0);
            d_sec_vf = 0.0;
            d_po = 0.0;
        }
        const gap_vf = base.c0 + base.d_elec + base.d_h_conf + base.d_vibr + base.d_spd + d_vf + d_sec_vf;
        const diff_um = (gap_vf - base.gap) * 1000.0;

        // Động học phát xung theo công thức Toff mới (Chuẩn máy AutoCut)
        const toff = Ton * (Po + 1); // μs
        const cycle = Ton + toff;   // Ton * (Po + 2) μs
        const freq_hz = Math.round(1000000 / cycle);
        const freq_khz = (freq_hz / 1000).toFixed(2);
        const duty = Ton / cycle;   // 1 / (Po + 2)
        const duty_pct = (duty * 100).toFixed(1);

        const u_arc = (Volt === 'High' || Volt === 'H') ? 27 : 22;
        const i_peak = IP * 2.8;
        const power_watts = u_arc * i_peak * duty;
        const calculatedAmpe = calcTheoreticalAmpe(IP, Po, H, Volt);
        const ampe_est = calculatedAmpe.toFixed(1);

        const Cm = (material === 'SCM420' || material === 'HB<200') ? 0.0140 : 0.0140;
        const B = 0.23;
        const eta_eff = 0.78;
        const fc_est = Math.round((60 * Cm * power_watts * eta_eff) / B);

        return {
            ...base,
            Po: Po,
            d_sec_vf: d_sec_vf,
            d_vf: d_vf,
            d_po: d_po,
            d_po_um: d_po * 1000.0,
            gap_vf: gap_vf,
            offset_vf: 0.090 + gap_vf,
            kerf_vf: 0.180 + 2.0 * gap_vf,
            diff_um: diff_um,
            toff: toff,
            cycle: cycle,
            freq_khz: freq_khz,
            duty_pct: duty_pct,
            ampe_est: ampe_est,
            fc_est: fc_est
        };
    }

    function renderResearchVF() {
        const H = parseFloat(vfResearchState.H) || 40;
        const Ton = parseFloat(vfResearchState.Ton) || 36;
        const Po = parseFloat(vfResearchState.Po) || 5;
        const IP = parseFloat(vfResearchState.IP) || 4;
        const Volt = vfResearchState.Volt || 'High';
        const VF = parseFloat(vfResearchState.VF) || 65;
        const material = vfResearchState.material || 'SCM440';
        const isHard = (material === 'SCM440' || material === '30HRC');

        const res = calcVFSparkGap(H, Ton, IP, Volt, VF, Po, material);

        // 0. CẬP NHẬT THẺ ĐỘNG LỰC HỌC XUNG (CHUẨN TOFF MỚI)
        const elDutyTag = document.getElementById('vf-pulse-duty-tag');
        const elOutToff = document.getElementById('vf-out-toff');
        const elOutCycle = document.getElementById('vf-out-cycle');
        const elOutFreq = document.getElementById('vf-out-freq');
        const elOutAmpe = document.getElementById('vf-out-ampe');
        const elOutFc = document.getElementById('vf-out-fc');

        if (elDutyTag) elDutyTag.textContent = 'η = ' + res.duty_pct + '%';
        if (elOutToff) elOutToff.textContent = res.toff + ' μs';
        if (elOutCycle) elOutCycle.textContent = res.cycle + ' μs';
        if (elOutFreq) elOutFreq.textContent = res.freq_khz + ' kHz';
        if (elOutAmpe) elOutAmpe.textContent = '~' + res.ampe_est + ' A';
        if (elOutFc) elOutFc.textContent = '~' + res.fc_est + ' mm²/p';

        // 1. CÔNG THỨC VẬT LÝ (KHÔNG VF, PO CHUẨN = 5)
        const elGapBase = document.getElementById('vf-out-gap-base');
        const elGapBaseUm = document.getElementById('vf-out-gap-base-um');
        const elOffBase = document.getElementById('vf-out-offset-base');
        const elKerfBase = document.getElementById('vf-out-kerf-base');

        if (elGapBase) elGapBase.textContent = res.gap.toFixed(4) + ' mm';
        if (elGapBaseUm) elGapBaseUm.textContent = '(' + (res.gap * 1000.0).toFixed(2) + ' μm)';
        if (elOffBase) elOffBase.textContent = res.offset.toFixed(4) + ' mm';
        if (elKerfBase) elKerfBase.textContent = 'Rãnh cắt W = ' + res.kerf.toFixed(4) + ' mm';

        // 2. CÔNG THỨC MỚI (TÍCH HỢP VF & CHU KỲ PO)
        const elTagDvf = document.getElementById('vf-tag-dvf');
        const elGapNew = document.getElementById('vf-out-gap-new');
        const elGapNewUm = document.getElementById('vf-out-gap-new-um');
        const elOffNew = document.getElementById('vf-out-offset-new');
        const elKerfNew = document.getElementById('vf-out-kerf-new');

        const signStr = res.diff_um >= 0 ? '+' : '';
        if (elTagDvf) elTagDvf.textContent = signStr + res.diff_um.toFixed(2) + ' μm';
        if (elGapNew) elGapNew.textContent = res.gap_vf.toFixed(4) + ' mm';
        if (elGapNewUm) elGapNewUm.textContent = '(' + (res.gap_vf * 1000.0).toFixed(2) + ' μm)';
        if (elOffNew) elOffNew.textContent = res.offset_vf.toFixed(4) + ' mm';
        if (elKerfNew) elKerfNew.textContent = 'Rãnh cắt W = ' + res.kerf_vf.toFixed(4) + ' mm';

        // 3. THẺ ĐÁNH GIÁ CHÊNH LỆCH & Ý NGHĨA VẬT LÝ
        const elDiffBadge = document.getElementById('vf-diff-badge');
        const elInsightText = document.getElementById('vf-insight-text');

        if (elDiffBadge) {
            elDiffBadge.textContent = 'Δ = ' + signStr + res.diff_um.toFixed(2) + ' μm';
            if (Math.abs(res.diff_um) < 0.05) {
                elDiffBadge.style.background = 'rgba(16, 185, 129, 0.2)';
                elDiffBadge.style.color = '#10b981';
                elDiffBadge.style.border = '1px solid #10b981';
            } else if (res.diff_um > 0) {
                elDiffBadge.style.background = 'rgba(245, 158, 11, 0.2)';
                elDiffBadge.style.color = '#f59e0b';
                elDiffBadge.style.border = '1px solid #f59e0b';
            } else {
                elDiffBadge.style.background = 'rgba(56, 189, 248, 0.2)';
                elDiffBadge.style.color = '#38bdf8';
                elDiffBadge.style.border = '1px solid #38bdf8';
            }
        }

        if (elInsightText) {
            let insightHtml = '';
            // Phân tích thành phần VF:
            if (Math.abs(res.d_vf * 1000.0) < 0.05) {
                insightHtml += '<strong>⚡ VF = 55 (Mốc trung bình tham chiếu 50-55):</strong> Bước tiến Servo hài hòa lý tưởng ($d_{\\text{vf}} = 0.00\\,\\mu\\text{m}$).';
            } else if (res.d_vf > 0) {
                insightHtml += '<strong>⚡ VF = ' + VF + ' &gt; 55 (Bàn tiến chậm / Dây ngâm tia lửa):</strong> Servo dè dặt ngâm dây lâu $\\implies$ nhiệt tích tụ khoét sâu thêm <strong style="color: var(--accent-amber);">+' + (res.d_vf * 1000).toFixed(2) + ' μm</strong>.';
            } else {
                insightHtml += '<strong>⚡ VF = ' + VF + ' &lt; 55 (Bàn tiến nhanh / Ép Servo):</strong> Dây lướt nhanh làm giảm thời gian truyền nhiệt $\\implies$ lớp cào hụt đi <strong style="color: var(--accent-cyan);">' + Math.abs(res.d_vf * 1000).toFixed(2) + ' μm</strong>.';
            }

            // Phân tích thành phần Po / Chu kỳ xung:
            if (Math.abs(res.d_po * 1000.0) < 0.05) {
                insightHtml += '<br><strong>🔄 Po = 5 (Chuẩn xưởng):</strong> Chu kỳ xả xỉ đạt trạng thái cân bằng lý tưởng ($d_{\\text{po}} = 0.00\\,\\mu\\text{m}$, Poff = ' + res.toff + ' μs).';
            } else if (res.d_po > 0) {
                insightHtml += '<br><strong>🔄 Po = ' + Po + ' &lt; 5 (Poff ngắn = ' + res.toff + ' μs / f = ' + res.freq_khz + ' kHz):</strong> Nước chưa kịp thổi sạch xỉ $\\implies$ mạt sắt gây <strong>đánh lửa thứ cấp</strong> làm nở rãnh cắt thêm <strong style="color: #f43f5e;">+' + (res.d_po * 1000).toFixed(2) + ' μm</strong> (nguy cơ sọc vách &amp; đứt dây tăng).';
            } else {
                insightHtml += '<br><strong>🔄 Po = ' + Po + ' &gt; 5 (Poff dài = ' + res.toff + ' μs / f = ' + res.freq_khz + ' kHz):</strong> Xối xỉ cực sạch, tia lửa êm không phóng bạt $\\implies$ rãnh cắt co gọn lại <strong style="color: var(--accent-cyan);">' + (res.d_po * 1000).toFixed(2) + ' μm</strong> (bề mặt mịn hơn, nhưng tốc độ cắt giảm còn ~' + res.fc_est + ' mm²/p).';
            }

            if (res.d_sec_vf > 0.0005) {
                insightHtml += '<br><strong>🔥 Đánh lửa thứ cấp do nén mùn xỉ (+' + (res.d_sec_vf * 1000).toFixed(2) + ' μm):</strong> Khe hẹp tích tụ mùn xỉ kích nổ phóng điện vách phụ, hệ thống đã tự động bù vào Offset để triệt tiêu sai số âm.';
            }

            if (res.d_low > 0) {
                insightHtml += '<br><strong>🔹 Chế độ Volt Low (22V):</strong> Bổ sung màng điện môi êm dịu $+4.50\\,\\mu\\text{m}$, bảo toàn kích thước không bị hụt khi cắt hạ áp.';
            }

            if (H > 170) {
                insightHtml += '<br><strong>🏔️ Phân vùng Phôi siêu dày (H > 170mm):</strong> Áp dụng cơ chế hội tụ xưởng Rule 17, triệt tiêu sai số rung uốn dây mất kiểm soát, đưa Offset bám sát chuẩn $0.1150\\,\\text{mm}$.';
            }

            insightHtml += '<br><strong>🎯 Tổng sai lệch: $\\Delta = ' + signStr + res.diff_um.toFixed(2) + '\\,\\mu\\text{m} \\implies$ Offset đề xuất: <span style="color: var(--accent-amber);">' + res.offset_vf.toFixed(4) + ' mm</span>.</strong>';
            elInsightText.innerHTML = insightHtml;
        }

        // 4. BẢNG BÓC TÁCH CHI TIẾT TỪNG THÀNH PHẦN VẬT LÝ
        const tbody = document.getElementById('vf-breakdown-tbody');
        if (tbody) {
            const isHigh = (Volt === 'High' || Volt === 'H');
            const signVf = res.d_vf >= 0 ? '+' : '';
            const signPo = res.d_po >= 0 ? '+' : '';
            tbody.innerHTML = `
                <tr>
                    <td><strong>C<sub>0</sub></strong> (Màng cách điện ban đầu)</td>
                    <td>Điện trở suất dung dịch nhũ tương &amp; ion hóa ban đầu</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.c0 * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.c0 * 1000).toFixed(2)} μm</td>
                </tr>
                <tr>
                    <td><strong>d<sub>elec</sub></strong> (Bộc phá xung điện theo Volt)</td>
                    <td>Năng lượng đơn xung: K<sub>elec</sub> &times; &radic;(Ton &times; IP) &times; U<sub>ratio</sub> (${isHigh ? 'Volt High 27V (1.0x)' : 'Volt Low 22V (0.815x) co tia lửa'})</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_elec * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_elec * 1000).toFixed(2)} μm</td>
                </tr>
                <tr>
                    <td><strong>d<sub>h_conf</sub></strong> (Khả năng bung tia lửa phôi cao)</td>
                    <td>Áp lực thủy tĩnh &amp; nén xỉ rãnh sâu giam hãm plasma: -K<sub>h_conf</sub> &times; (H/100)</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">${(res.d_h_conf * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">${(res.d_h_conf * 1000).toFixed(2)} μm</td>
                </tr>
                <tr>
                    <td><strong>d<sub>vibr</sub></strong> (Rung uốn cơ học dây Moly)</td>
                    <td>${H <= 170 ? 'Xung lực nổ plasma làm võng dây: K_vibr &times; (H/100)² &times; (IP/5)' : 'Kiến trúc Phân vùng Kép Rule 17: Hội tụ êm về chuẩn xưởng 0.1150 mm'}</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="background: rgba(244, 63, 94, 0.06);">
                    <td><strong style="color: #f43f5e;">d<sub>sec</sub></strong> (Đánh lửa thứ cấp do nghẽn xỉ dẻo)</td>
                    <td>Kích hoạt khi H &gt; 63mm (lõi đói áp lực xả) và Po &le; 7: K<sub>sec</sub> &times; (h<sub>starve</sub>)<sup>0.65</sup> &times; po<sub>shortage</sub> &times; K<sub>mat</sub></td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">+${(res.d_sec * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e; font-weight: 700;">+${(res.d_sec_vf * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="background: rgba(245, 158, 11, 0.08); border-top: 1px dashed var(--accent-amber);">
                    <td><strong style="color: var(--accent-amber);">d<sub>vf</sub></strong> (Hiệu ứng trễ bước tiến VF)</td>
                    <td>Thời gian ngâm tia lửa do tốc độ tiến bàn máy: K<sub>vf</sub> &times; (VF - 55)/10</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--text-muted);">0.00 μm (VF chuẩn 55)</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-weight: 700;">${signVf + (res.d_vf * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="font-weight: 700; background: rgba(0,0,0,0.3); border-top: 2px solid var(--border-color);">
                    <td>TỔNG LƯỢNG CÀO PHÔI (&delta;)</td>
                    <td>Khoảng cách từ mép dây Moly đến vách phôi thép đặc</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight); font-size: 13px;">${(res.gap * 1000).toFixed(2)} μm<br><span style="font-size: 11px; font-weight: 400; color: var(--text-secondary);">${res.gap.toFixed(4)} mm</span></td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-size: 13px;">${(res.gap_vf * 1000).toFixed(2)} μm<br><span style="font-size: 11px; font-weight: 400; color: var(--text-secondary);">${res.gap_vf.toFixed(4)} mm</span></td>
                </tr>
                <tr style="font-weight: 800; background: rgba(0, 240, 255, 0.08); border-top: 1px solid var(--accent-cyan);">
                    <td style="color: var(--accent-cyan);">OFFSET BÙ DAO 1 PASS (O<sub>1P</sub>)</td>
                    <td>R<sub>dây</sub> (0.090 mm) + Lượng cào phôi (&delta;)</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-cyan); font-size: 15px;">${res.offset.toFixed(4)} mm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber); font-size: 15px;">${res.offset_vf.toFixed(4)} mm</td>
                </tr>
            `;
        }
    }

    function bindResearchVFEvents() {
        const inputH = document.getElementById('vf-input-h');
        const sliderH = document.getElementById('vf-slider-h');
        const inputTon = document.getElementById('vf-input-ton');
        const inputPo = document.getElementById('vf-input-po');
        const inputIP = document.getElementById('vf-input-ip');
        const inputVF = document.getElementById('vf-input-vf');
        const sliderVF = document.getElementById('vf-slider-vf');
        const matBtns = document.querySelectorAll('#vf-mat-selector .vf-mat-btn');
        const voltBtns = document.querySelectorAll('#vf-volt-selector .vf-volt-btn');

        if (inputH && sliderH) {
            inputH.addEventListener('input', () => {
                const val = parseFloat(inputH.value) || 40;
                vfResearchState.H = val;
                sliderH.value = Math.min(300, Math.max(5, val));
                renderResearchVF();
            });
            sliderH.addEventListener('input', () => {
                const val = parseFloat(sliderH.value) || 40;
                vfResearchState.H = val;
                inputH.value = val;
                renderResearchVF();
            });
        }

        if (inputTon) {
            inputTon.addEventListener('input', () => {
                vfResearchState.Ton = parseFloat(inputTon.value) || 36;
                renderResearchVF();
            });
        }

        if (inputPo) {
            inputPo.addEventListener('input', () => {
                vfResearchState.Po = parseFloat(inputPo.value) || 5;
                renderResearchVF();
            });
        }

        if (inputIP) {
            inputIP.addEventListener('input', () => {
                vfResearchState.IP = parseFloat(inputIP.value) || 4;
                renderResearchVF();
            });
        }

        if (inputVF && sliderVF) {
            inputVF.addEventListener('input', () => {
                const val = parseFloat(inputVF.value) || 65;
                vfResearchState.VF = val;
                sliderVF.value = Math.min(85, Math.max(20, val));
                renderResearchVF();
        updateTab1SyncPreview();
            });
            sliderVF.addEventListener('input', () => {
                const val = parseFloat(sliderVF.value) || 65;
                vfResearchState.VF = val;
                inputVF.value = val;
                renderResearchVF();
        updateTab1SyncPreview();
            });
        }

        matBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                matBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                vfResearchState.material = btn.dataset.mat;
                renderResearchVF();
        updateTab1SyncPreview();
            });
        });

        voltBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                voltBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                vfResearchState.Volt = btn.dataset.volt;
                renderResearchVF();
        updateTab1SyncPreview();
            });
        });

                // NÚT LẤY THÔNG SỐ ĐẦU VÀO TỪ TAB 1 (TRA CỨU THÔNG SỐ CẮT)
        const btnSyncTab1 = document.getElementById('btn-sync-from-tab1');
        if (btnSyncTab1) {
            btnSyncTab1.addEventListener('click', () => {
                const wsRows = generateWorkshopRows(state);
                if (!wsRows || wsRows.length === 0) return;
                const r1 = wsRows[0];
                const ov = (state.wsCustomOverrides && state.wsCustomOverrides[0]) || {};

                const H = state.thickness || 40;
                const material = (state.wsMaterial === 'SCM420') ? 'SCM420' : 'SCM440';
                const Pon = ov.ti !== undefined ? parseFloat(ov.ti) : (parseFloat(r1.ti) || 36);
                const Poff = ov.Po !== undefined ? parseFloat(ov.Po) : (parseFloat(r1.Po) || 5);
                const IP = ov.IP !== undefined ? parseFloat(ov.IP) : (parseFloat(r1.IP) || 4);
                const Volt = ov.Voltage !== undefined ? ov.Voltage : ((r1.Voltage === 'Low' || r1.Voltage === 'L') ? 'Low' : 'High');
                const VF = ov.VF !== undefined ? parseFloat(ov.VF) : (parseFloat(r1.VF) || 55);

                // 1. Cập nhật state nội bộ của Tab 2
                vfResearchState.material = material;
                vfResearchState.H = H;
                vfResearchState.Ton = Pon;
                vfResearchState.Po = Poff;
                vfResearchState.IP = IP;
                vfResearchState.Volt = Volt;
                vfResearchState.VF = VF;

                // 2. Cập nhật các ô input & slider trên giao diện Tab 2
                if (inputH) inputH.value = H;
                if (sliderH) sliderH.value = Math.min(300, Math.max(5, H));
                if (inputTon) inputTon.value = Pon;
                if (inputPo) inputPo.value = Poff;
                if (inputIP) inputIP.value = IP;
                if (inputVF) inputVF.value = VF;
                if (sliderVF) sliderVF.value = Math.min(85, Math.max(20, VF));

                // Cập nhật nút Vật Liệu
                if (matBtns) {
                    matBtns.forEach(btn => {
                        if (btn.dataset.mat === material) {
                            btn.classList.add('active');
                        } else {
                            btn.classList.remove('active');
                        }
                    });
                }

                // Cập nhật nút Volt
                if (voltBtns) {
                    voltBtns.forEach(btn => {
                        if (btn.dataset.volt === Volt) {
                            btn.classList.add('active');
                        } else {
                            btn.classList.remove('active');
                        }
                    });
                }

                // 3. Tính toán và hiển thị ngay lập tức kết quả Bù dao Offset
                renderResearchVF();

                // 4. Hiệu ứng phản hồi trên nút
                const origHtml = btnSyncTab1.innerHTML;
                btnSyncTab1.innerHTML = '<span>✅ Đã Nạp Thông Số!</span>';
                btnSyncTab1.style.background = '#10b981';
                setTimeout(() => {
                    btnSyncTab1.innerHTML = origHtml;
                    btnSyncTab1.style.background = '';
                }, 1800);

                // Cập nhật dòng preview
                updateTab1SyncPreview();

                // Hiển thị toast thông báo
                const matText = material === 'SCM420' ? 'SCM420 (Thép mềm)' : 'SCM440 (Thép cứng)';
                showToast(`✅ Đã nạp từ Tab Tra Cứu: ${matText} | H=${H}mm | Pon=${Pon} | Poff=${Poff} | IP=${IP} | ${Volt} | VF=${VF}`);
            });
        }
    }

    // Cập nhật dòng preview thông số hiện tại của Tab 1 ở nút đồng bộ Tab 2
    function updateTab1SyncPreview() {
        const previewEl = document.getElementById('vf-sync-preview-text');
        if (!previewEl) return;
        const wsRows = generateWorkshopRows(state);
        if (!wsRows || wsRows.length === 0) return;
        const r1 = wsRows[0];
        const ov = (state.wsCustomOverrides && state.wsCustomOverrides[0]) || {};
        const H = state.thickness || 40;
        const material = (state.wsMaterial === 'SCM420') ? 'SCM420' : 'SCM440';
        const Pon = ov.ti !== undefined ? ov.ti : r1.ti;
        const Poff = ov.Po !== undefined ? ov.Po : r1.Po;
        const IP = ov.IP !== undefined ? ov.IP : r1.IP;
        const Volt = ov.Voltage !== undefined ? ov.Voltage : r1.Voltage;
        const VF = ov.VF !== undefined ? ov.VF : r1.VF;
        previewEl.innerHTML = `Hiện tại ở Tab 1: <strong style="color:var(--accent-amber)">${material} | H=${H}mm | Pon=${Pon} | Poff=${Poff} | IP=${IP} | ${Volt} | VF=${VF}</strong> (Bấm nút bên để nạp)`;
    }


    function initResearchVF() {
        bindResearchVFEvents();
        renderResearchVF();
        updateTab1SyncPreview();
    }

    // INITIAL RENDER
    updateStrategyDisplay(state.strategyLevel);
    updateWsStrategyDisplay(state.wsStrategyLevel);
    render();
    initResearchVF();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}





