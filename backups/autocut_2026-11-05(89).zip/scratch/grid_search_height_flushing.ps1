# ==============================================================================
# OPTIMIZATION OF 2 NEW PARAMETERS: HEIGHT CONFINEMENT & SLAG FLUSHING
# ==============================================================================

$dataset = @(
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110 },
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225 },
    @{ id='STT 23';  H=200; Ton=120; Po=10; IP=6; Volt='High'; VF=65; mat='SCM420'; actual=0.0180 },
    @{ id='STT 20';  H=290; Ton=135; Po=10; IP=6; Volt='High'; VF=75; mat='SCM440'; actual=0.0200 },
    @{ id='STT 14';  H=300; Ton=120; Po=9;  IP=6; Volt='High'; VF=65; mat='SCM440'; actual=0.0250 }
)

# Test function
function Evaluate-Model($C0, $K_elec, $d_low, $K_vibr, $K_vf, $K_h_limit, $K_slag_secondary) {
    $sumAbsErr = 0
    $sumAbsErr440 = 0
    $sumAbsErr420 = 0
    $count440 = 0
    $count420 = 0

    foreach ($item in $dataset) {
        $H = $item.H
        $Ton = $item.Ton
        $Po = $item.Po
        $IP = $item.IP
        $Volt = $item.Volt
        $VF = $item.VF
        $mat = $item.mat
        $isHard = ($mat -eq 'SCM440' -or $mat -eq '30HRC')

        # 1. Nang luong phong dien ho quang co ban
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $K_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low_val = if ($Volt -eq 'Low' -or $Volt -eq 'L') { $d_low } else { 0.0 }
        $d_vf_val = $K_vf * (($VF - 55.0) / 10.0)
        $d_vibr_val = $K_vibr * [Math]::Pow($H / 100.0, 1.8) * ($IP / 5.0)

        # 2. THONG SO 1: KHA NANG PHA KHE THEO CHIEU CAO PHOI (Height Gap Breakdown Limit)
        # Khi H tang, mat do nang luong E/H giam va ap luc thuy tinh nen plasma, khien khe kho pha rong
        $d_h_limit = - $K_h_limit * [Math]::Pow($H / 100.0, 1.2)

        # 3. THONG SO 2: THOAT PHOI KHO & DANH LUA THU CAP (Slag Flushing & Secondary Sparking)
        # Khi H tang ket hop Po ngan (Po < 9), phoi khong thoat kip gay danh lua thu cap phong ra vach
        $mat_fac = if ($isHard) { 0.85 } else { 1.15 } # SCM420 phoi bet dinh hon
        $po_shortage = [Math]::Max(0.0, (9.0 - $Po) / 10.0) # thieu hut thoi gian nghi Po
        $d_slag_secondary = $K_slag_secondary * [Math]::Pow($H / 100.0, 1.5) * $po_shortage * $mat_fac

        $calc_gap = $C0 + $d_elec + $d_low_val + $d_vf_val + $d_vibr_val + $d_h_limit + $d_slag_secondary

        $err = [Math]::Abs($calc_gap - $item.actual) * 1000
        $sumAbsErr += $err
        if ($isHard) {
            $sumAbsErr440 += $err
            $count440++
        } else {
            $sumAbsErr420 += $err
            $count420++
        }
    }

    $mae = $sumAbsErr / $dataset.Count
    $mae440 = $sumAbsErr440 / $count440
    $mae420 = $sumAbsErr420 / $count420
    return @{ MAE=$mae; MAE440=$mae440; MAE420=$mae420 }
}

# Grid search for best coefficients
$best = @{ MAE=999; C0=0; K_elec=0; K_h=0; K_slag=0 }

$C0_range = @(0.0030, 0.0035, 0.0040)
$K_elec_range = @(0.00080, 0.00090, 0.00100)
$d_low_range = @(0.0040, 0.0045)
$K_vibr_range = @(0.0020, 0.0030)
$K_vf_range = @(0.0021)
$K_h_limit_range = @(0.0020, 0.0030, 0.0040, 0.0050)
$K_slag_range = @(0.0100, 0.0150, 0.0200, 0.0250)

foreach ($c0 in $C0_range) {
    foreach ($ke in $K_elec_range) {
        foreach ($kh in $K_h_limit_range) {
            foreach ($ks in $K_slag_range) {
                $res = Evaluate-Model $c0 $ke 0.0045 0.0025 0.0021 $kh $ks
                if ($res.MAE -lt $best.MAE) {
                    $best.MAE = $res.MAE
                    $best.MAE440 = $res.MAE440
                    $best.MAE420 = $res.MAE420
                    $best.C0 = $c0
                    $best.K_elec = $ke
                    $best.K_h = $kh
                    $best.K_slag = $ks
                }
            }
        }
    }
}

Write-Host "BEST PARAMETERS FOUND:"
Write-Host ("  MAE Total: {0:F2} um (SCM440: {1:F2} um, SCM420: {2:F2} um)" -f $best.MAE, $best.MAE440, $best.MAE420)
Write-Host ("  C0: {0:F5}, K_elec: {1:F5}, K_h_limit: {2:F5}, K_slag_secondary: {3:F5}" -f $best.C0, $best.K_elec, $best.K_h, $best.K_slag)
