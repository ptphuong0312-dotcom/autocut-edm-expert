import math

dataset_full = [
    # name, H, Ton, Po, IP, Volt, VF, max_hz, mat, actual_gap
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 150, 'SCM440', 0.0110],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 150, 'SCM420', 0.0050],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 200, 'SCM440', 0.0080],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 180, 'SCM440', 0.0080],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 150, 'SCM420', 0.0050],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 150, 'SCM420', 0.0080],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 100, 'SCM440', 0.0070],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 187, 'SCM420', 0.0220],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 150, 'SCM440', 0.0125],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 150, 'SCM420', 0.0280],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 150, 'SCM440', 0.0235],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 150, 'SCM420', 0.0150],
    ['STT 7',  140, 120, 8, 5, 'High', 55,  50, 'SCM420', 0.0050],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 100, 'SCM420', 0.0120],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 154, 'SCM420', 0.0300],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70,  60, 'SCM440', 0.0225],
    ['STT 23', 200, 120, 10, 6, 'High', 65,  60, 'SCM420', 0.0180],
    ['STT 20', 290, 135, 10, 6, 'High', 75,  50, 'SCM440', 0.0200],
    ['STT 14', 300, 120, 9, 6, 'High', 65,  50, 'SCM440', 0.0250]
]

# Random search with pure python to optimize a unified equation
import random

random.seed(42)

def eval_candidate(params):
    c0, k_elec, k_conf, k_vibr, k_vf, k_po, k_sec, s_thresh, p_exp, mat_ratio = params
    errs = []
    diffs = []
    for r in dataset_full:
        name, H, Ton, Po, IP, Volt, VF, max_hz, mat, act = r
        isHard = (mat == 'SCM440' or mat == '30HRC')
        km = 1.0 if isHard else mat_ratio
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        
        # Physical terms
        d_elec = k_elec * math.sqrt(Ton * IP) * u_ratio
        d_low = 0.00450 if (Volt == 'Low' or Volt == 'L') else 0.0
        d_conf = - k_conf * (H / 100.0)
        d_vibr = k_vibr * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = k_vf * ((VF - 55.0) / 10.0)
        d_po = - k_po * ((Po - 5.0) / 10.0)
        
        # Secondary sparking from Slag Density
        # Slag accumulation index:
        s_idx = (Ton * IP / (Po * 30.0)) * (H / 100.0) * km
        if s_idx > s_thresh:
            d_sec = k_sec * math.pow(s_idx - s_thresh, p_exp)
        else:
            d_sec = 0.0
            
        if H <= 170:
            calc = c0 + d_elec + d_low + d_conf + d_vibr + d_vf + d_po + d_sec
        else:
            g170 = c0 + (k_elec * math.sqrt(Ton * IP)) - (k_conf * 1.70) + (k_vibr * math.pow(1.70, 2) * (IP / 5.0)) + d_sec
            calc = g170 + (H - 170) * (0.0250 - g170) / (300 - 170)
            calc += k_vf * 0.5 * ((VF - 65.0) / 10.0) - k_po * 0.5 * ((Po - 9.0) / 10.0)
            
        diff_um = (calc - act) * 1000.0
        errs.append(abs(diff_um))
        diffs.append((name, H, mat, act*1000, calc*1000, diff_um, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    max_e = max(errs)
    return mae, max_e, diffs

best_score = 999.0
best_params = None
best_diffs = None

# Let's run a Monte Carlo / local search
for _ in range(50000):
    c0 = random.uniform(0.0025, 0.0055)
    k_elec = random.uniform(0.0005, 0.0012)
    k_conf = random.uniform(0.005, 0.025)
    k_vibr = random.uniform(0.002, 0.006)
    k_vf = random.uniform(0.0010, 0.0030)
    k_po = random.uniform(0.0005, 0.0025)
    k_sec = random.uniform(0.005, 0.025)
    s_thresh = random.uniform(0.3, 0.9)
    p_exp = random.uniform(0.8, 1.8)
    mat_ratio = random.uniform(1.0, 1.35)
    
    p = (c0, k_elec, k_conf, k_vibr, k_vf, k_po, k_sec, s_thresh, p_exp, mat_ratio)
    mae, max_e, diffs = eval_candidate(p)
    # We want low MAE and low Max Error (penalize max_e > 15)
    score = mae + 0.3 * max_e
    if score < best_score:
        best_score = score
        best_params = p
        best_diffs = diffs
        print(f"Iter {_}: MAE = {mae:.2f} um, Max Error = {max_e:.2f} um")

mae, max_e, diffs = eval_candidate(best_params)
print("\n" + "=" * 80)
print(f"FINAL BEST UNIFIED MODEL WITH SECONDARY SPARKING:")
print(f"MAE: {mae:.2f} um (was 6.00 um)")
print(f"Max Error: {max_e:.2f} um (was 20.27 um)")
print(f"Parameters: C0={best_params[0]:.5f}, k_elec={best_params[1]:.5f}, k_conf={best_params[2]:.5f}, k_vibr={best_params[3]:.5f}")
print(f"k_vf={best_params[4]:.5f}, k_po={best_params[5]:.5f}, k_sec={best_params[6]:.5f}, s_thresh={best_params[7]:.3f}, p_exp={best_params[8]:.2f}, mat_ratio={best_params[9]:.2f}")
print("=" * 80)
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 80)
for d in diffs:
    sign = '+' if d[5] >= 0 else ''
    print(f"{d[0]:<8} | {d[1]:>3} | {d[2]:<6} | {d[3]:>7.1f} | {d[4]:>7.1f} | {sign + f'{d[5]:.1f}':>10} | {d[6]:>+10.1f}")
