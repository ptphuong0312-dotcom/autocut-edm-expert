# Script kiểm toán độ lệch của Tab 2 hiện tại so với dữ liệu thực nghiệm xưởng (cả SCM420 và SCM440)
# Định nghĩa các bài cắt 1 Pass hợp lệ từ Data Bank (loại trừ Vùng tham khảo C)

$jobs = @(
    @{ id = "1P-5P01"; mat = "SCM440"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; actualOffset = 0.1010; delta = 0.0110 },
    @{ id = "STT 22";  mat = "SCM420"; H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 1";   mat = "SCM440"; H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 2";   mat = "SCM440"; H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 3";   mat = "SCM420"; H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 18";  mat = "SCM420"; H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 6";   mat = "SCM440"; H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; actualOffset = 0.0970; delta = 0.0070 },
    @{ id = "STT 16";  mat = "SCM420"; H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1120; delta = 0.0220 },
    @{ id = "1P-2P10"; mat = "SCM440"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; actualOffset = 0.1025; delta = 0.0125 },
    @{ id = "STT 21";  mat = "SCM420"; H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1180; delta = 0.0280 },
    @{ id = "STT 17";  mat = "SCM440"; H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; actualOffset = 0.1135; delta = 0.0235 },
    @{ id = "STT 19";  mat = "SCM420"; H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; actualOffset = 0.1050; delta = 0.0150 },
    @{ id = "STT 7";   mat = "SCM420"; H = 140; Ton = 120; Po = 8; IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 12";  mat = "SCM420"; H = 140; Ton = 100; Po = 9; IP = 6; Volt = "High"; VF = 60; actualOffset = 0.1020; delta = 0.0120 },
    @{ id = "STT 15";  mat = "SCM420"; H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1200; delta = 0.0300 },
    @{ id = "1P-2P12"; mat = "SCM440"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1125; delta = 0.0225 },
    @{ id = "STT 23";  mat = "SCM420"; H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1080; delta = 0.0180 },
    @{ id = "STT 20";  mat = "SCM440"; H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; actualOffset = 0.1100; delta = 0.0200 },
    @{ id = "STT 14";  mat = "SCM440"; H = 300; Ton = 120; Po = 9; IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1150; delta = 0.0250 }
)

# Công thức Tab 2 hiện tại trong app.js
function Calc-Tab2-Gap($H, $Ton, $IP, $Volt, $isHard) {
    $C0 = 0.00280
    $K_ELEC = 0.00100
    $DELTA_LOW = 0.00450
    $K_SLAG = 0.02300
    $K_VIBR = 0.00390
    
    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $K_ELEC * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low = if ($Volt -eq 'Low' -or $Volt -eq 'L') { $DELTA_LOW } else { 0.0 }
        $ip_fac = [Math]::Max(1.0, $IP / 4.0)
        $d_slag = - $K_SLAG * ($H / 100.0) / $ip_fac
        $d_vibr = $K_VIBR * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        return $C0 + $d_elec + $d_low + $d_slag + $d_vibr
    } else {
        # Phân vùng 2 (H > 170): Hội tụ xưởng
        $baseGap = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        return $baseGap
    }
}

Write-Output "=== BẢNG KIỂM TOÁN HIỆN TẠI CỦA TAB 2 TRÊN TẤT CẢ CÁC BÀI THỰC TẾ ==="
$totalErr420 = 0; $count420 = 0
$totalErr440 = 0; $count440 = 0

foreach ($job in $jobs) {
    $isHard = ($job.mat -eq "SCM440")
    $gapCalc = Calc-Tab2-Gap $job.H $job.Ton $job.IP $job.Volt $isHard
    $offsetCalc = 0.090 + $gapCalc
    $errUm = ($offsetCalc - $job.actualOffset) * 1000
    $absErrUm = [Math]::Abs($errUm)
    
    if ($job.mat -eq "SCM420") {
        $totalErr420 += $absErrUm
        $count420++
    } else {
        $totalErr440 += $absErrUm
        $count440++
    }
    
    $tag = if ($job.mat -eq "SCM420") { "[SCM420 HB<200]" } else { "[SCM440 30HRC ]" }
    Write-Output ("{0} {1,-8} H={2,3}mm Ton={3,3} Po={4,2} IP={5} Volt={6,-4} -> Offset Thực: {7:F4} | Tab2 Tính: {8:F4} | Lệch: {9,6:F1} um" -f $tag, $job.id, $job.H, $job.Ton, $job.Po, $job.IP, $job.Volt, $job.actualOffset, $offsetCalc, $errUm)
}

Write-Output ""
Write-Output ("MAE SCM420 (HB<200) (n={0}): {1:F2} um" -f $count420, ($totalErr420 / $count420))
Write-Output ("MAE SCM440 (28-32HRC) (n={0}): {1:F2} um" -f $count440, ($totalErr440 / $count440))
Write-Output ("MAE Toàn bộ (n={0}): {1:F2} um" -f ($count420 + $count440), (($totalErr420 + $totalErr440) / ($count420 + $count440)))
