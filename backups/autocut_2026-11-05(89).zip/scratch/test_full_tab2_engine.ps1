# Test full Tab 2 engine across all strategy levels and passes
function Test-Tab2-Engine($H, $mat, $passes = 1, $lvl = 4) {
    $isHard = ($mat -eq "SCM440")
    $C0 = 0.00350
    $K_ELEC = 0.00100
    $DELTA_LOW = 0.00450
    $K_SLAG = 0.02000
    $K_VIBR = 0.00390
    $K_RZ = 0.00120
    $K_VF = 0.00210
    $K_PO = 0.00120
    $slag_mat = if ($isHard) { 1.0 } else { 0.80 }

    $baseVolt = if ($H -le 15) { 'Low' } else { 'High' }

    if ($H -le 170) {
        if ($isHard) {
            if ($H -le 15) { $baseTon = [Math]::Round(16 + ($H - 5) * (20 - 16) / (15 - 5)) }
            elseif ($H -le 30) { $baseTon = [Math]::Round(20 + ($H - 15) * (32 - 20) / (30 - 15)) }
            elseif ($H -le 60) { $baseTon = [Math]::Round(32 + ($H - 30) * (50 - 32) / (60 - 30)) }
            elseif ($H -le 100) { $baseTon = [Math]::Round(50 + ($H - 60) * (82 - 50) / (100 - 60)) }
            elseif ($H -le 140) { $baseTon = [Math]::Round(82 + ($H - 100) * (120 - 82) / (140 - 100)) }
            elseif ($H -le 165) { $baseTon = [Math]::Round(120 + ($H - 140) * (135 - 120) / (165 - 140)) }
            else { $baseTon = 135 }
        } else {
            if ($H -le 15) { $baseTon = [Math]::Round(14 + ($H - 5) * (18 - 14) / (15 - 5)) }
            elseif ($H -le 30) { $baseTon = [Math]::Round(18 + ($H - 15) * (28 - 18) / (30 - 15)) }
            elseif ($H -le 60) { $baseTon = [Math]::Round(28 + ($H - 30) * (44 - 28) / (60 - 30)) }
            elseif ($H -le 100) { $baseTon = [Math]::Round(44 + ($H - 60) * (72 - 44) / (100 - 60)) }
            elseif ($H -le 140) { $baseTon = [Math]::Round(72 + ($H - 100) * (110 - 72) / (140 - 100)) }
            else { $baseTon = 120 }
        }

        $isMulti = ($passes -ge 3)
        if (-not $isMulti) {
            if ($H -le 15) { $baseIP = 3; $basePo = 6 }
            elseif ($H -le 30) { $baseIP = 3; $basePo = 7 }
            elseif ($H -le 60) { $baseIP = 4; $basePo = 8 }
            elseif ($H -le 100) { $baseIP = 4; $basePo = 7 }
            else {
                if ($H -le 120) { $baseIP = 5; $basePo = 8 }
                elseif ($H -le 140) { $baseIP = 5; $basePo = 9 }
                elseif ($H -le 155) { $baseIP = 6; $basePo = 10 }
                else { $baseIP = 6; $basePo = 11 }
            }
        } else {
            if ($H -le 15) { $baseIP = 4; $basePo = 5 }
            elseif ($H -le 30) { $baseIP = 4; $basePo = 7 }
            elseif ($H -le 60) { $baseIP = 4; $basePo = 6 }
            elseif ($H -le 100) { $baseIP = 5; $basePo = if ($H -le 80) { 7 } else { 8 } }
            else {
                if ($H -le 120) { $baseIP = 5; $basePo = 8 }
                elseif ($H -le 140) { $baseIP = 5; $basePo = 9 }
                elseif ($H -le 155) { $baseIP = 6; $basePo = 10 }
                else { $baseIP = 6; $basePo = 11 }
            }
        }

        $vfMax = if ($isHard) { 65 } else { 60 }
        $vfMin = if ($isHard) { 55 } else { 50 }
        if ($H -le 40) { $baseVF = $vfMax }
        elseif ($H -le 100) { $baseVF = [Math]::Round($vfMax - ($H - 40) * ($vfMax - $vfMin) / (100 - 40)) }
        elseif ($H -le 160) { $baseVF = [Math]::Round($vfMin + ($H - 100) * (70 - $vfMin) / (160 - 100)) }
        else { $baseVF = 70 }

        $u_ratio_base = if ($baseVolt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec_base = $K_ELEC * [Math]::Sqrt($baseTon * $baseIP) * $u_ratio_base
        $d_low_base = if ($baseVolt -eq 'Low') { $DELTA_LOW } else { 0.0 }
        $ip_fac_base = [Math]::Max(1.0, $baseIP / 4.0)
        $d_slag_base = - $K_SLAG * ($H / 100.0) * $slag_mat / $ip_fac_base
        $d_vibr_base = $K_VIBR * [Math]::Pow($H / 100.0, 2) * ($baseIP / 5.0)
        $d_vf_base = $K_VF * (($baseVF - 55.0) / 10.0)
        $d_po_base = - $K_PO * (($basePo - 5.0) / 10.0)
        $baseGap = $C0 + $d_elec_base + $d_low_base + $d_slag_base + $d_vibr_base + $d_vf_base + $d_po_base

    } else {
        $baseTon = if ($isHard) { 135 } else { 120 }
        $baseIP = 6
        $basePo = [Math]::Round(11 + ($H - 170) * (12 - 11) / (300 - 170))
        $baseVF = [Math]::Min(72, [Math]::Round(70 + ($H - 170) * (72 - 70) / (300 - 170)))
        $baseGap = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }

    # Strategy level
    if ($lvl -eq 4) {
        $Ton = $baseTon; $Po = $basePo; $IP = $baseIP; $Volt = $baseVolt; $VF = $baseVF
    } elseif ($lvl -eq 3) {
        $Ton = [Math]::Max(8, $baseTon - 6); $Po = $basePo + 2; $IP = $baseIP; $Volt = $baseVolt; $VF = [Math]::Max(25, $baseVF - 5)
    } elseif ($lvl -eq 2) {
        $Ton = [Math]::Max(8, $baseTon - 12); $IP = [Math]::Max(1, $baseIP - 1); $Po = $basePo + 1; $Volt = if ($H -le 40) { 'Low' } else { $baseVolt }; $VF = [Math]::Max(25, $baseVF - 10)
    } elseif ($lvl -eq 1) {
        $Ton = [Math]::Max(6, $baseTon - 18); $IP = [Math]::Max(1, $baseIP - 2); $Po = $basePo + 3; $Volt = 'Low'; $VF = [Math]::Max(20, $baseVF - 15)
    } elseif ($lvl -eq 5) {
        $Ton = $baseTon + 6; $Po = [Math]::Max(3, $basePo - 1); $IP = $baseIP; $Volt = $baseVolt; $VF = [Math]::Min(85, $baseVF + 5)
    } elseif ($lvl -eq 6) {
        $Ton = $baseTon + 14; $Po = [Math]::Max(3, $basePo - 2); $IP = $baseIP; $Volt = 'High'; $VF = [Math]::Min(88, $baseVF + 10)
    } else {
        $Ton = $baseTon + 22
        if ($H -le 60 -and $baseIP -le 4) { $IP = $baseIP + 1; $Po = [Math]::Max(3, $basePo - 1) }
        else { $IP = $baseIP; $Po = [Math]::Max(3, $basePo - 3) }
        $Volt = 'High'; $VF = [Math]::Min(90, $baseVF + 15)
    }

    if ($H -le 170) {
        $u_ratio_actual = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec_actual = $K_ELEC * [Math]::Sqrt($Ton * $IP) * $u_ratio_actual
        $d_low_actual = if ($Volt -eq 'Low') { $DELTA_LOW } else { 0.0 }
        $ip_fac_actual = [Math]::Max(1.0, $IP / 4.0)
        $d_slag_actual = - $K_SLAG * ($H / 100.0) * $slag_mat / $ip_fac_actual
        $d_vibr_actual = $K_VIBR * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_vf_actual = $K_VF * (($VF - 55.0) / 10.0)
        $d_po_actual = - $K_PO * (($Po - 5.0) / 10.0)
        $gap = $C0 + $d_elec_actual + $d_low_actual + $d_slag_actual + $d_vibr_actual + $d_vf_actual + $d_po_actual
    } else {
        $stratGapMods = @{ 1 = -0.009; 2 = -0.006; 3 = -0.003; 4 = 0.0; 5 = 0.003; 6 = 0.006; 7 = 0.010 }
        $gap = $baseGap + $stratGapMods[$lvl]
    }

    $O1 = 0.090 + $gap

    # Pass 2
    if ($isHard) {
        if ($H -le 20) { $p2_ton = 12 }
        elseif ($H -le 60) { $p2_ton = 16 }
        elseif ($H -le 120) { $p2_ton = 20 }
        elseif ($H -le 140) { $p2_ton = 24 }
        elseif ($H -le 165) { $p2_ton = [Math]::Round(24 + ($H - 140) * (40 - 24) / (165 - 140)) }
        else { $p2_ton = 40 }
    } else {
        if ($H -le 20) { $p2_ton = 10 }
        elseif ($H -le 60) { $p2_ton = 14 }
        elseif ($H -le 120) { $p2_ton = 18 }
        elseif ($H -le 140) { $p2_ton = 22 }
        else { $p2_ton = 36 }
    }

    $p2_po = if ($isHard) { if ($H -le 40) { 5 } elseif ($H -le 120) { 6 } else { 7 } } else { if ($H -le 40) { 6 } else { 7 } }
    $p2_ip = if ($H -le 60) { 2 } else { 3 }
    $p2_volt = if ($H -le 40) { 'Low' } else { 'High' }

    if ($H -le 170) {
        $u_p1 = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $Rz_p1 = $K_RZ * [Math]::Sqrt($Ton * $IP) * $u_p1
        $u_p2 = if ($p2_volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec_p2 = $K_ELEC * [Math]::Sqrt($p2_ton * $p2_ip) * $u_p2
        $d_low_p2 = if ($p2_volt -eq 'Low') { $DELTA_LOW } else { 0.0 }
        $delta_2_calc = $C0 + $d_elec_p2 + $d_low_p2 - $K_SLAG * ($H / 100.0) * $slag_mat / ($p2_ip / 4.0)

        $maxCeilingO2 = if ($H -le 60) { 0.025 } else { [Math]::Max(0.015, 0.025 - ($H - 60) * (0.025 - 0.015) / (165 - 60)) }
        $O2 = [Math]::Max(0.015, [Math]::Min($Rz_p1 + [Math]::Max(0.005, [Math]::Min(0.015, $delta_2_calc)), $maxCeilingO2))
    } else {
        $O2 = 0.015
    }

    # Ampe
    $duty = 1.0 / ($Po + 2)
    $i_peak = $IP * 2.8
    $u_arc = if ($Volt -eq 'Low') { 22 } else { 27 }
    $ampe = $i_peak * $duty * 2.6667 * ($u_arc / 27)

    return @{
        H = $H; mat = $mat; Ton = $Ton; Po = $Po; IP = $IP; Volt = $Volt; VF = $VF;
        gap = $gap; O1 = $O1; O2 = $O2; ampe = $ampe
    }
}

Write-Host "=== TEST SMOOTH CONTINUITY FOR SCM440 (28-32 HRC) ==="
$testH = @(5, 10, 15, 20, 30, 40, 50, 60, 75, 85, 95, 100, 120, 140, 160, 165, 170, 180, 200, 250, 300)
foreach ($h in $testH) {
    $r = Test-Tab2-Engine $h "SCM440" 1 4
    Write-Host ("H={0,3} Ton={1,3} Po={2,2} IP={3} Volt={4,-4} VF={5,2} -> Gap={6,5:F1}um O1={7:F4} O2={8:F4} Ampe={9,3:F1}A" -f $h, $r.Ton, $r.Po, $r.IP, $r.Volt, $r.VF, ($r.gap*1000), $r.O1, $r.O2, $r.ampe)
}

Write-Host ""
Write-Host "=== TEST SMOOTH CONTINUITY FOR SCM420 (HB < 200) ==="
foreach ($h in $testH) {
    $r = Test-Tab2-Engine $h "SCM420" 1 4
    Write-Host ("H={0,3} Ton={1,3} Po={2,2} IP={3} Volt={4,-4} VF={5,2} -> Gap={6,5:F1}um O1={7:F4} O2={8:F4} Ampe={9,3:F1}A" -f $h, $r.Ton, $r.Po, $r.IP, $r.Volt, $r.VF, ($r.gap*1000), $r.O1, $r.O2, $r.ampe)
}
