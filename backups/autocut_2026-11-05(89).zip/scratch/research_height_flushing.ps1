# ==============================================================================
# RESEARCH SCRIPT: HEIGHT BREAKDOWN & SLAG FLUSHING DYNAMICS
# AUTHOR: AutoCut Servo EDM Expert (Deep Research on SirPhuong's Direction)
# ==============================================================================

$dataset = @(
    @{ id='1P-5P01'; grp='1P Quy doi 5P-01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110; desc='Chay P1 5P' },
    @{ id='STT 22';  grp='1P SCM420 chay L'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050; desc='Chay L chuan' },
    @{ id='STT 1';   grp='1P Chuan goc';     H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; desc='Chay to 0.034' },
    @{ id='STT 2';   grp='1P Chuan goc';     H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; desc='Chay to 0.034' },
    @{ id='STT 3';   grp='1P SCM420 chay';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; desc='Chay to 0.046' },
    @{ id='STT 18';  grp='1P SCM420 chay';   H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080; desc='Chay nho 0.010' },
    @{ id='STT 6';   grp='1P SCM440 chay L'; H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070; desc='Chay L chuan' },
    @{ id='STT 16';  grp='1P SCM420 coi';    H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220; desc='Coi to 0.040' },
    @{ id='1P-2P10'; grp='1P Quy doi 2P-10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125; desc='Coi P1 2P' },
    @{ id='STT 21';  grp='1P SCM420 coi';    H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280; desc='Coi chuan' },
    @{ id='STT 17';  grp='1P SCM440 coi';    H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235; desc='Coi lon 0.045' },
    @{ id='STT 19';  grp='1P SCM420 chay';   H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150; desc='Chay chuan' },
    @{ id='STT 7';   grp='1P SCM420 chay';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; desc='Chay chuan' },
    @{ id='STT 12';  grp='1P SCM420 chay';   H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120; desc='Chay to 0.036' },
    @{ id='STT 15';  grp='1P SCM420 coi';    H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300; desc='Coi to 0.026' },
    @{ id='1P-2P12'; grp='1P Quy doi 2P-12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225; desc='Coi P1 2P' },
    @{ id='STT 23';  grp='1P SCM420 sieu day';H=200;Ton=120; Po=10; IP=6; Volt='High'; VF=65; mat='SCM420'; actual=0.0180; desc='Coi sieu day' },
    @{ id='STT 20';  grp='1P SCM440 sieu day';H=290;Ton=135; Po=10; IP=6; Volt='High'; VF=75; mat='SCM440'; actual=0.0200; desc='Coi sieu day' },
    @{ id='STT 14';  grp='1P SCM440 moc 300'; H=300;Ton=120; Po=9;  IP=6; Volt='High'; VF=65; mat='SCM440'; actual=0.0250; desc='Coi moc 300' }
)

Write-Host "=========================================================================================="
Write-Host "PHAN TICH DONG DU LIEU THUC TE: KHOANG CACH PHOI CAO VA HIEN TUONG THOAT PHOI"
Write-Host "=========================================================================================="

foreach ($item in $dataset) {
    $ratio = ($item.actual * 1000)
    Write-Host ("{0,-8} | H={1,3}mm | {2,-6} | Ton={3,3} | Po={4,2} | IP={5} | Volt={6,-4} | VF={7,2} | delta_thuc={8,5:F1} um | {9}" -f $item.id, $item.H, $item.mat, $item.Ton, $item.Po, $item.IP, $item.Volt, $item.VF, $ratio, $item.desc)
}
