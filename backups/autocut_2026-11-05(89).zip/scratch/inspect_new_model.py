import math

dataset = [
    # name, grp, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', '1P (Quy đổi 5P-01)', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  '1P (SCM420 chày L)',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   '1P (Chuẩn gốc)',      30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   '1P (Chuẩn gốc)',      40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   '1P (SCM420 chày)',    63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  '1P (SCM420 chày)',    63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   '1P (SCM440 chày L)',  68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  '1P (SCM420 cối)',     75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', '1P (Quy đổi 2P-10)',  85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  '1P (SCM420 cối)',     90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  '1P (SCM440 cối)',     95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19',  '1P (SCM420 chày)',   110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',   '1P (SCM420 chày)',   140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12',  '1P (SCM420 chày)',   140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15',  '1P (SCM420 cối)',    160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', '1P (Quy đổi 2P-12)', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23',  '1P (SCM420 siêu dày)', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20',  '1P (SCM440 siêu dày)', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14',  '1P (SCM440 mốc 300)', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

def calc_new(H, Ton, Po, IP, Volt, VF, mat):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    k_mat = 1.0 if isHard else 1.25
    k_ampe = 2.2857 if isHard else 2.8571
    itb = (6.4 * IP / (1 + Po)) * k_ampe
    rho_slag = (itb / (Po + 2.0)) * (H / 100.0)
    d_sec = 0.0150 * math.pow(rho_slag, 1.8) * k_mat
    
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = 0.00075 * math.sqrt(Ton * IP) * u_ratio
        d_low = 0.0045 if (Volt == 'Low' or Volt == 'L') else 0.0
        d_conf = - 0.0100 * (H / 100.0)
        d_vibr = 0.0035 * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = 0.0022 * ((VF - 55.0) / 10.0)
        d_po = - 0.0010 * ((Po - 5.0) / 10.0)
        return 0.0035 + d_elec + d_low + d_conf + d_vibr + d_vf + d_po + d_sec
    else:
        g170 = 0.0035 + (0.00075 * math.sqrt(Ton * IP)) - (0.0100 * 1.70) + (0.0035 * math.pow(1.70, 2) * (IP / 5.0)) + d_sec
        calc_g = g170 + (H - 170) * (0.0250 - g170) / (300 - 170)
        d_vf = 0.0022 * 0.5 * ((VF - 65.0) / 10.0)
        d_po = - 0.0010 * 0.5 * ((Po - 9.0) / 10.0)
        return calc_g + d_vf + d_po

print(f"{'STT':<8} | {'H':>3} | {'Ton':>3} | {'Po':>2} | {'IP':>2} | {'mat':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>10}")
print("-" * 75)
errs = []
for r in dataset:
    g = calc_new(r[2], r[3], r[4], r[5], r[6], r[7], r[8])
    diff = (g - r[9]) * 1000
    errs.append(abs(diff))
    print(f"{r[0]:<8} | {r[2]:>3} | {r[3]:>3} | {r[4]:>2} | {r[5]:>2} | {r[8]:<6} | {r[9]*1000:>7.1f} | {g*1000:>7.1f} | {diff:>+10.1f}")

print("=" * 75)
print(f"MAE: {sum(errs)/len(errs):.2f} um | Max: {max(errs):.2f} um")
