# Test continuous boundary transition at H=170
function Test-Continuous-Transition($H, $mat) {
    $isHard = ($mat -eq "SCM440")
    $C0 = 0.00350
    $K_ELEC = 0.00100
    $DELTA_LOW = 0.00450
    $K_SLAG = 0.02000
    $K_VIBR = 0.00390
    $K_VF = 0.00210
    $K_PO = 0.00120
    $slag_mat = if ($isHard) { 1.0 } else { 0.80 }

    if ($H -le 170) {
        $Ton = if ($isHard) { 135 } else { 120 }
        $IP = 6; $Po = 11; $Volt = 'High'; $VF = 70
        $u_ratio = 1.0
        $d_elec = $K_ELEC * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low = 0.0
        $ip_fac = [Math]::Max(1.0, $IP / 4.0)
        $d_slag = - $K_SLAG * ($H / 100.0) * $slag_mat / $ip_fac
        $d_vibr = $K_VIBR * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_vf = $K_VF * (($VF - 55.0) / 10.0)
        $d_po = - $K_PO * (($Po - 5.0) / 10.0)
        $gap = $C0 + $d_elec + $d_low + $d_slag + $d_vibr + $d_vf + $d_po
    } else {
        $Ton = if ($isHard) { 135 } else { 120 }
        $IP = 6; $Po = [Math]::Round(11 + ($H - 170) * (12 - 11) / (300 - 170))
        $VF = [Math]::Min(72, [Math]::Round(70 + ($H - 170) * (72 - 70) / (300 - 170)))
        
        # Continuous boundary interpolation:
        $d_elec170 = $K_ELEC * [Math]::Sqrt($Ton * $IP) * 1.0
        $ip_fac170 = [Math]::Max(1.0, $IP / 4.0)
        $d_slag170 = - $K_SLAG * 1.70 * $slag_mat / $ip_fac170
        $d_vibr170 = $K_VIBR * [Math]::Pow(1.70, 2) * ($IP / 5.0)
        $d_vf170 = $K_VF * ((70 - 55.0) / 10.0)
        $d_po170 = - $K_PO * ((11 - 5.0) / 10.0)
        $gap170 = $C0 + $d_elec170 + $d_slag170 + $d_vibr170 + $d_vf170 + $d_po170
        $targetGap300 = 0.0250

        $gap = $gap170 + ($H - 170) * ($targetGap300 - $gap170) / (300 - 170)
    }

    return @{ H = $H; O1 = 0.090 + $gap; gap = $gap }
}

Write-Host "SCM440 boundary transition:"
foreach ($h in @(160, 165, 168, 169, 170, 171, 172, 175, 180, 200, 250, 290, 300)) {
    $r = Test-Continuous-Transition $h "SCM440"
    Write-Host ("H={0,3} -> Gap={1,5:F2}um | O1={2:F4}" -f $h, ($r.gap*1000), $r.O1)
}

Write-Host ""
Write-Host "SCM420 boundary transition:"
foreach ($h in @(160, 165, 168, 169, 170, 171, 172, 175, 180, 200, 250, 290, 300)) {
    $r = Test-Continuous-Transition $h "SCM420"
    Write-Host ("H={0,3} -> Gap={1,5:F2}um | O1={2:F4}" -f $h, ($r.gap*1000), $r.O1)
}
