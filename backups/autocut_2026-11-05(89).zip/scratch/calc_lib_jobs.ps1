# Tinh toan thong so cap nhat cho WS_LIB_BENCHMARK_JOBS[1]
$jobs = @(
    @{ id = "1P-5P01"; mat = "30HRC";  H = 12; Ton = 20; Toff = 5; IP = 3; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "150Hz"; actualOffset = "0,101"; actualAmpe = "4A";           actualSpeed = "275-285 mm²/p"; length = "128mm"; actualTime = "19p50'"; isHard = $true;  fromMulti = $true },
    @{ id = "STT 22";  mat = "HB<200"; H = 12; Ton = 16; Toff = 6; IP = 3; Wire = 1; Volt = "L"; VF = 60; maxSpeed = "150Hz"; actualOffset = "0,095"; actualAmpe = "2,5A - 2,7A"; actualSpeed = "--";            length = "--";    actualTime = "--";     isHard = $false; fromMulti = $false },
    @{ id = "STT 1";   mat = "30HRC";  H = 30; Ton = 32; Toff = 5; IP = 4; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "200Hz"; actualOffset = "0,098"; actualAmpe = "4,45A - 4,5A";  actualSpeed = "165-175 mm²/p"; length = "30mm";  actualTime = "8p40'";  isHard = $true;  fromMulti = $false },
    @{ id = "STT 2";   mat = "30HRC";  H = 40; Ton = 36; Toff = 5; IP = 4; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "180Hz"; actualOffset = "0,098"; actualAmpe = "4,35A - 4,4A";  actualSpeed = "130-140 mm²/p"; length = "30mm";  actualTime = "9p36'";  isHard = $true;  fromMulti = $false },
    @{ id = "STT 3";   mat = "HB<200"; H = 63; Ton = 44; Toff = 7; IP = 5; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "150Hz"; actualOffset = "0,095"; actualAmpe = "4,1A - 4,2A";   actualSpeed = "75-85 mm²/p";   length = "27mm";  actualTime = "14p20'"; isHard = $false; fromMulti = $false },
    @{ id = "STT 18";  mat = "HB<200"; H = 63; Ton = 44; Toff = 8; IP = 4; Wire = 1; Volt = "H"; VF = 57; maxSpeed = "150Hz"; actualOffset = "0,098"; actualAmpe = "3,3A - 3,4A";   actualSpeed = "50-65 mm²/p";   length = "22,3mm"; actualTime = "17p40'"; isHard = $false; fromMulti = $false },
    @{ id = "STT 6";   mat = "30HRC";  H = 68; Ton = 70; Toff = 7; IP = 3; Wire = 1; Volt = "L"; VF = 50; maxSpeed = "100Hz"; actualOffset = "0,097"; actualAmpe = "2,4A - 2,6A";   actualSpeed = "--";            length = "--";    actualTime = "--";     isHard = $true;  fromMulti = $false },
    @{ id = "STT 16";  mat = "HB<200"; H = 75; Ton = 55; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 54; maxSpeed = "187Hz"; actualOffset = "0,112"; actualAmpe = "3,4A - 3,5A";   actualSpeed = "50-65 mm²/p";   length = "50,3mm"; actualTime = "1h13'";  isHard = $false; fromMulti = $false },
    @{ id = "1P-2P10"; mat = "30HRC";  H = 85; Ton = 70; Toff = 8; IP = 5; Wire = 1; Volt = "H"; VF = 61; maxSpeed = "150Hz"; actualOffset = "0,1025"; actualAmpe = "3,6A - 3,7A";  actualSpeed = "55-65 mm²/p";   length = "65,6mm"; actualTime = "48p";    isHard = $true;  fromMulti = $true },
    @{ id = "STT 21";  mat = "HB<200"; H = 90; Ton = 80; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 54; maxSpeed = "150Hz"; actualOffset = "0,118"; actualAmpe = "3,5A - 3,6A";   actualSpeed = "50-60 mm²/p";   length = "--";    actualTime = "--";     isHard = $false; fromMulti = $false },
    @{ id = "STT 17";  mat = "30HRC";  H = 95; Ton = 82; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "150Hz"; actualOffset = "0,1135"; actualAmpe = "3,6A - 3,7A";  actualSpeed = "35-45 mm²/p";   length = "76mm";  actualTime = "1h15'";  isHard = $true;  fromMulti = $false },
    @{ id = "STT 19";  mat = "HB<200"; H = 110; Ton = 100; Toff = 10; IP = 5; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "150Hz"; actualOffset = "0,105"; actualAmpe = "2,7A - 2,8A"; actualSpeed = "30-40 mm²/p"; length = "--"; actualTime = "--"; isHard = $false; fromMulti = $false },
    @{ id = "STT 7";   mat = "HB<200"; H = 140; Ton = 120; Toff = 8;  IP = 5; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "50Hz";  actualOffset = "0,095"; actualAmpe = "3,5A - 3,8A"; actualSpeed = "--";            length = "--";    actualTime = "--";     isHard = $false; fromMulti = $false },
    @{ id = "STT 12";  mat = "HB<200"; H = 140; Ton = 100; Toff = 9;  IP = 6; Wire = 1; Volt = "H"; VF = 60; maxSpeed = "100Hz"; actualOffset = "0,102"; actualAmpe = "3,7A - 3,8A"; actualSpeed = "30-40 mm²/p"; length = "28,4mm"; actualTime = "36p"; isHard = $false; fromMulti = $false },
    @{ id = "STT 15";  mat = "HB<200"; H = 160; Ton = 120; Toff = 11; IP = 6; Wire = 1; Volt = "H"; VF = 70; maxSpeed = "154Hz"; actualOffset = "0,120"; actualAmpe = "2,8A - 3A";    actualSpeed = "18-28 mm²/p"; length = "32,3mm"; actualTime = "59p";    isHard = $false; fromMulti = $false },
    @{ id = "1P-2P12"; mat = "30HRC";  H = 165; Ton = 135; Toff = 11; IP = 6; Wire = 1; Volt = "H"; VF = 70; maxSpeed = "60Hz";  actualOffset = "0,1125"; actualAmpe = "2,8A - 3,0A"; actualSpeed = "15-35 mm²/p"; length = "43,6mm"; actualTime = "1h17'"; isHard = $true; fromMulti = $true },
    @{ id = "STT 23";  mat = "HB<200"; H = 200; Ton = 120; Toff = 10; IP = 6; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "60Hz";  actualOffset = "0,108"; actualAmpe = "--";           actualSpeed = "--";            length = "--";    actualTime = "--";     isHard = $false; fromMulti = $false },
    @{ id = "STT 20";  mat = "30HRC";  H = 290; Ton = 135; Toff = 10; IP = 6; Wire = 1; Volt = "H"; VF = 75; maxSpeed = "50Hz";  actualOffset = "0,110"; actualAmpe = "--";           actualSpeed = "--";            length = "--";    actualTime = "--";     isHard = $true;  fromMulti = $false },
    @{ id = "STT 14";  mat = "30HRC";  H = 300; Ton = 120; Toff = 9;  IP = 6; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "50Hz";  actualOffset = "0,115"; actualAmpe = "3,7A - 3,9A"; actualSpeed = "12-20 mm²/p"; length = "76,1mm"; actualTime = "3h";     isHard = $true;  fromMulti = $false }
)

Write-Output "=== CAP NHAT THONG SO CHO WS_LIB_BENCHMARK_JOBS[1] ==="

foreach ($j in $jobs) {
    $H = $j.H
    $Ton = $j.Ton
    $Po = $j.Toff
    $IP = $j.IP
    $Volt = $j.Volt
    $VF = $j.VF
    $isHard = $j.isHard

    # Gap
    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = 0.00100 * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $dl = if ($Volt -eq 'L') { 0.00450 } else { 0.0 }
        $ip_fac = [Math]::Max(1.0, $IP / 4.0)
        $sm = if ($isHard) { 1.0 } else { 0.80 }
        $d_slag = - 0.02000 * ($H / 100.0) * $sm / $ip_fac
        $d_vibr = 0.00390 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_vf = 0.00210 * (($VF - 55.0) / 10.0)
        $d_po = - 0.00120 * (($Po - 5.0) / 10.0)
        $gap = 0.00350 + $d_elec + $dl + $d_slag + $d_vibr + $d_vf + $d_po
    } else {
        $gap = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }

    $offsetCalc = 0.090 + $gap
    $calcOffsetStr = $offsetCalc.ToString("F4").Replace('.', ',')

    # Ampe
    $duty = 1.0 / ($Po + 2)
    $i_peak = $IP * 2.8
    $u_arc = if ($Volt -eq 'L') { 22 } else { 27 }
    $ampeCalc = $i_peak * $duty * 2.6667 * ($u_arc / 27)
    $calcAmpeStr = $ampeCalc.ToString("F1") + "A"

    # Toc do
    $eta_eff = if ($isHard) { 0.85 } else { 0.78 }
    $eta_eff *= [Math]::Pow([Math]::Max(1, $Ton) / 50.0, 0.38)
    if ($Ton -gt 80) { $eta_eff = [Math]::Min(0.92, $eta_eff) }
    if ($isHard) {
        if ($H -gt 80) { $eta_eff *= [Math]::Max(0.65, 1.0 - ($H - 80) * 0.0010) }
    } else {
        if ($H -gt 50) { $eta_eff *= [Math]::Max(0.55, 1.0 - ($H - 50) * 0.0016) }
    }
    $power_watts = $u_arc * $i_peak * $duty
    $Cm = 0.0140
    $mrr_vol = 60 * $Cm * $power_watts * $eta_eff
    $B = 0.23
    $speedArea = [Math]::Round($mrr_vol / $B)
    $feedRate = ($speedArea / $H)
    $speedAreaH40 = [Math]::Round($feedRate * 40)
    $calcSpeedH40Str = $speedAreaH40.ToString() + " mm²/p"

    # Thoi gian
    $calcTimeStr = "--"
    if ($j.length -ne "--") {
        $lenMm = [double]($j.length.Replace("mm","").Replace(",","."))
        $timeMins = $lenMm / $feedRate
        $m = [Math]::Floor($timeMins)
        $s = [Math]::Round(($timeMins - $m) * 60)
        if ($m -ge 60) {
            $h = [Math]::Floor($m / 60)
            $remM = $m % 60
            $calcTimeStr = "${h}h" + $(if ($remM -gt 0) { "${remM}p" } else { "" })
        } else {
            $calcTimeStr = "${m}p" + $(if ($s -gt 0) { "${s}'" } else { "" })
        }
    }

    # Sai lech offset
    $actVal = [double]($j.actualOffset.Replace(',', '.'))
    $errUm = ($offsetCalc - $actVal) * 1000

    Write-Output ("H={0,3} {1,-6} | Act={2} Calc={3} | Err={4,5:F1}um | Ampe={5,5} | SpeedH40={6,10} | Time={7,7}" -f $H, $j.mat, $j.actualOffset, $calcOffsetStr, $errUm, $calcAmpeStr, $calcSpeedH40Str, $calcTimeStr)
}
