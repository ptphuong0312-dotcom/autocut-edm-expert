$logPath = "C:\Users\NCC\.gemini\antigravity\brain\4b156ce5-5660-42ba-a98e-0a4b70713617\.system_generated\logs\transcript.jsonl"
$lines = Get-Content $logPath
foreach ($line in $lines) {
    if ($line -match '"step_index":(1011|1012)') {
        $json = $line | ConvertFrom-Json
        Write-Output "=== Step $($json.step_index) [$($json.type)] ==="
        if ($json.content) {
            Write-Output $json.content
        }
    }
}
