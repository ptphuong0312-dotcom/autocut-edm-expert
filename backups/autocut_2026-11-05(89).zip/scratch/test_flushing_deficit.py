import math

dataset = [
    # name, grp, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', '1P (Quy đổi 5P-01)', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  '1P (SCM420 chày L)',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   '1P (Chuẩn gốc)',      30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   '1P (Chuẩn gốc)',      40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   '1P (SCM420 chày)',    63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  '1P (SCM420 chày)',    63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   '1P (SCM440 chày L)',  68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  '1P (SCM420 cối)',     75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', '1P (Quy đổi 2P-10)',  85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  '1P (SCM420 cối)',     90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  '1P (SCM440 cối)',     95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19',  '1P (SCM420 chày)',   110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',   '1P (SCM420 chày)',   140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12',  '1P (SCM420 chày)',   140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15',  '1P (SCM420 cối)',    160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', '1P (Quy đổi 2P-12)', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23',  '1P (SCM420 siêu dày)', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20',  '1P (SCM440 siêu dày)', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14',  '1P (SCM440 mốc 300)', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

# Baseline formula
def calc_base(H, Ton, Po, IP, Volt, VF, mat):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = 0.00092 * math.sqrt(Ton * IP) * u_ratio
        d_low = 0.00450 if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - 0.02000 * (H / 100.0) * sm / ip_fac
        d_vibr = 0.00390 * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = 0.00210 * ((VF - 55.0) / 10.0)
        d_po = - 0.00120 * ((Po - 5.0) / 10.0)
        return 0.00360 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po
    else:
        gap170 = 0.00360 + (0.00092 * math.sqrt(Ton * IP) * 1.0) + (- 0.02000 * 1.70 * sm / max(1.0, IP / 4.0)) + (0.00390 * math.pow(1.70, 2) * (IP / 5.0))
        gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
        d_vf = 0.00210 * 0.5 * ((VF - 65.0) / 10.0)
        d_po = - 0.00120 * 0.5 * ((Po - 9.0) / 10.0)
        return gapBase + d_vf + d_po

# Now test adding Secondary Sparking when Po is insufficient for height H:
# Flushing deficit: deficit = max(0, Po_crit(H) - Po)
# where Po_crit(H) is the critical pause time required to evacuate chips from a deep slot.
# For example, Po_crit = 5.0 + 3.0 * (H / 100)
# When Po < Po_crit, chips accumulate: d_sec = K_sec * deficit * (Ton / 50) * (mat_factor)

def test_flushing_deficit(k_sec, h_slope, ton_pow=1.0):
    errs = []
    diffs = []
    for r in dataset:
        H, Ton, Po, IP, Volt, VF, mat, act = r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]
        base = calc_base(H, Ton, Po, IP, Volt, VF, mat)
        
        # Critical Po for this height
        po_crit = 4.5 + h_slope * (H / 100.0)
        deficit = max(0.0, po_crit - Po)
        
        isHard = (mat == 'SCM440' or mat == '30HRC')
        k_mat = 1.0 if isHard else 1.25
        
        # Secondary sparking from trapped slag
        d_sec = k_sec * math.pow(deficit, 1.5) * math.pow(Ton / 50.0, ton_pow) * k_mat
        
        calc = base + d_sec
        diff_um = (calc - act) * 1000.0
        errs.append(abs(diff_um))
        diffs.append((r[0], H, mat, act*1000, base*1000, calc*1000, diff_um, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    max_err = max(errs)
    return mae, max_err, diffs

best_res = None
best_mae = 999.0
for k_sec in [0.003, 0.005, 0.007, 0.009, 0.011, 0.013, 0.015]:
    for h_slope in [3.0, 3.5, 4.0, 4.5, 5.0]:
        for ton_pow in [0.5, 1.0, 1.5]:
            mae, max_err, diffs = test_flushing_deficit(k_sec, h_slope, ton_pow)
            if mae < best_mae:
                best_mae = mae
                best_res = (k_sec, h_slope, ton_pow, mae, max_err, diffs)

print(f"Optimal Flushing Deficit Model:")
print(f"k_sec: {best_res[0]}, h_slope: {best_res[1]}, ton_pow: {best_res[2]}")
print(f"MAE: {best_res[3]:.2f} um (was 6.00 um)")
print(f"Max Error: {best_res[4]:.2f} um (was 20.27 um)")
print("\nDetailed table:")
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Base':>7} | {'+SlagCalc':>9} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 80)
for d in best_res[5]:
    print(f"{d[0]:<8} | {d[1]:>3} | {d[2]:<6} | {d[3]:>7.1f} | {d[4]:>7.1f} | {d[5]:>9.1f} | {d[6]:>+10.1f} | {d[7]:>+10.1f}")
