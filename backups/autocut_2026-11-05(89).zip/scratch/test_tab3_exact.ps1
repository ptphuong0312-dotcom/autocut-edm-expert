# Test exact Tab 3 parameters on all 19 benchmark jobs
$jobs = @(
    # SCM440 (28-32 HRC) - 9 bài
    @{ id = "1P-5P01"; mat = "SCM440"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; actualOffset = 0.1010; delta = 0.0110 },
    @{ id = "STT 1";   mat = "SCM440"; H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 2";   mat = "SCM440"; H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 6";   mat = "SCM440"; H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; actualOffset = 0.0970; delta = 0.0070 },
    @{ id = "1P-2P10"; mat = "SCM440"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; actualOffset = 0.1025; delta = 0.0125 },
    @{ id = "STT 17";  mat = "SCM440"; H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; actualOffset = 0.1135; delta = 0.0235 },
    @{ id = "1P-2P12"; mat = "SCM440"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1125; delta = 0.0225 },
    @{ id = "STT 20";  mat = "SCM440"; H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; actualOffset = 0.1100; delta = 0.0200 },
    @{ id = "STT 14";  mat = "SCM440"; H = 300; Ton = 120; Po = 9;  IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1150; delta = 0.0250 },

    # SCM420 (HB < 200) - 10 bài
    @{ id = "STT 22";  mat = "SCM420"; H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 3";   mat = "SCM420"; H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 18";  mat = "SCM420"; H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 16";  mat = "SCM420"; H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1120; delta = 0.0220 },
    @{ id = "STT 21";  mat = "SCM420"; H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1180; delta = 0.0280 },
    @{ id = "STT 19";  mat = "SCM420"; H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; actualOffset = 0.1050; delta = 0.0150 },
    @{ id = "STT 7";   mat = "SCM420"; H = 140; Ton = 120; Po = 8;  IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 12";  mat = "SCM420"; H = 140; Ton = 100; Po = 9;  IP = 6; Volt = "High"; VF = 60; actualOffset = 0.1020; delta = 0.0120 },
    @{ id = "STT 15";  mat = "SCM420"; H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1200; delta = 0.0300 },
    @{ id = "STT 23";  mat = "SCM420"; H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1080; delta = 0.0180 }
)

$err420 = 0; $n420 = 0
$err440 = 0; $n440 = 0

foreach ($j in $jobs) {
    $H = $j.H
    $Ton = $j.Ton
    $IP = $j.IP
    $Po = $j.Po
    $Volt = $j.Volt
    $VF = $j.VF
    $isHard = ($j.mat -eq "SCM440")

    $u_ratio = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
    $d_elec = 0.00092 * [Math]::Sqrt($Ton * $IP) * $u_ratio
    $d_low = if ($Volt -eq 'Low') { 0.00450 } else { 0.0 }
    $ip_fac = [Math]::Max(1.0, $IP / 4.0)
    $sm = if ($isHard) { 1.0 } else { 0.80 }
    $d_slag = - 0.02000 * ($H / 100.0) * $sm / $ip_fac

    if ($H -le 170) {
        $d_vibr = 0.00390 * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $gapBase = 0.00360 + $d_elec + $d_low + $d_slag + $d_vibr
        $d_vf = 0.00210 * (($VF - 55.0) / 10.0)
        $d_po = - 0.00120 * (($Po - 5.0) / 10.0)
        $gap = $gapBase + $d_vf + $d_po
    } else {
        $gap170 = 0.00360 + $d_elec + $d_low + (- 0.02000 * 1.70 * $sm / $ip_fac) + (0.00390 * [Math]::Pow(1.70, 2) * ($IP / 5.0))
        $gap = $gap170 + ($H - 170) * (0.0250 - $gap170) / (300 - 170)
        $d_vf = 0.00210 * 0.5 * (($VF - 65.0) / 10.0)
        $d_po = - 0.00120 * 0.5 * (($Po - 9.0) / 10.0)
        $gap += ($d_vf + $d_po)
    }

    $offsetCalc = 0.090 + $gap
    $err = ($offsetCalc - $j.actualOffset) * 1000

    if ($isHard) { $err440 += [Math]::Abs($err); $n440++ }
    else { $err420 += [Math]::Abs($err); $n420++ }

    $actStr = $j.actualOffset.ToString("F4")
    $calcStr = $offsetCalc.ToString("F4")
    $errStr = $err.ToString("+0.0;-0.0")
    Write-Host ("{0,-6} {1,-8} H={2,3} | Thuc={3} | Tinh={4} | Lech={5,6} um" -f $j.mat, $j.id, $H, $actStr, $calcStr, $errStr)
}

Write-Host ""
Write-Host ("MAE SCM420={0:F2} um | SCM440={1:F2} um | All={2:F2} um" -f ($err420/$n420), ($err440/$n440), (($err420+$err440)/($n420+$n440)))
