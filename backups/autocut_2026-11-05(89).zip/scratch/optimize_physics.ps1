# Thử nghiệm cấu trúc hàm d_slag và d_vibr
function Evaluate-Custom($c0, $ke, $dl, $ks_power, $ks_coeff, $sm420, $kv_coeff, $kv_power, $kvf, $kpo) {
    $jobs = @(
        @{ id = "1P-5P01"; mat = "SCM440"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; actualOffset = 0.1010; delta = 0.0110 },
        @{ id = "STT 1";   mat = "SCM440"; H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
        @{ id = "STT 2";   mat = "SCM440"; H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
        @{ id = "STT 6";   mat = "SCM440"; H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; actualOffset = 0.0970; delta = 0.0070 },
        @{ id = "1P-2P10"; mat = "SCM440"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; actualOffset = 0.1025; delta = 0.0125 },
        @{ id = "STT 17";  mat = "SCM440"; H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; actualOffset = 0.1135; delta = 0.0235 },
        @{ id = "1P-2P12"; mat = "SCM440"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1125; delta = 0.0225 },
        @{ id = "STT 20";  mat = "SCM440"; H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; actualOffset = 0.1100; delta = 0.0200 },
        @{ id = "STT 14";  mat = "SCM440"; H = 300; Ton = 120; Po = 9;  IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1150; delta = 0.0250 },

        @{ id = "STT 22";  mat = "SCM420"; H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; actualOffset = 0.0950; delta = 0.0050 },
        @{ id = "STT 3";   mat = "SCM420"; H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
        @{ id = "STT 18";  mat = "SCM420"; H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; actualOffset = 0.0980; delta = 0.0080 },
        @{ id = "STT 16";  mat = "SCM420"; H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1120; delta = 0.0220 },
        @{ id = "STT 21";  mat = "SCM420"; H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1180; delta = 0.0280 },
        @{ id = "STT 19";  mat = "SCM420"; H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; actualOffset = 0.1050; delta = 0.0150 },
        @{ id = "STT 7";   mat = "SCM420"; H = 140; Ton = 120; Po = 8;  IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
        @{ id = "STT 12";  mat = "SCM420"; H = 140; Ton = 100; Po = 9;  IP = 6; Volt = "High"; VF = 60; actualOffset = 0.1020; delta = 0.0120 },
        @{ id = "STT 15";  mat = "SCM420"; H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1200; delta = 0.0300 },
        @{ id = "STT 23";  mat = "SCM420"; H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1080; delta = 0.0180 }
    )

    $err420 = 0; $n420 = 0
    $err440 = 0; $n440 = 0

    foreach ($j in $jobs) {
        $H = $j.H
        $Ton = $j.Ton
        $IP = $j.IP
        $Po = $j.Po
        $Volt = $j.Volt
        $VF = $j.VF
        $isHard = ($j.mat -eq "SCM440")

        $gap = 0
        if ($H -le 170) {
            $u_ratio = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
            $d_elec = $ke * [Math]::Sqrt($Ton * $IP) * $u_ratio
            $dl = if ($Volt -eq 'Low') { $dl } else { 0.0 }
            $ip_fac = [Math]::Max(1.0, $IP / 4.0)
            $sm = if ($isHard) { 1.0 } else { $sm420 }
            $d_slag = - $ks_coeff * [Math]::Pow($H / 100.0, $ks_power) * $sm / $ip_fac
            $d_vibr = $kv_coeff * [Math]::Pow($H / 100.0, $kv_power) * ($IP / 5.0)
            $d_vf = $kvf * (($VF - 55.0) / 10.0)
            $d_po = - $kpo * (($Po - 5.0) / 10.0)
            $gap = $c0 + $d_elec + $dl + $d_slag + $d_vibr + $d_vf + $d_po
        } else {
            $gap = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
        }

        $offsetCalc = 0.090 + $gap
        $err = [Math]::Abs(($offsetCalc - $j.actualOffset) * 1000)

        if ($isHard) {
            $err440 += $err
            $n440++
        } else {
            $err420 += $err
            $n420++
        }
    }

    $mae420 = $err420 / $n420
    $mae440 = $err440 / $n440
    $maeAll = ($err420 + $err440) / ($n420 + $n440)

    return @{ mae420 = $mae420; mae440 = $mae440; maeAll = $maeAll }
}

Write-Output "--- Exploring smaller K_slag or different powers ---"
foreach ($ks in @(0.000, 0.005, 0.008, 0.010, 0.012, 0.015)) {
    foreach ($c0 in @(0.0010, 0.0015, 0.0020, 0.0025, 0.0028)) {
        foreach ($ke in @(0.0009, 0.0010, 0.0011)) {
            $res = Evaluate-Custom $c0 $ke 0.00450 1.0 $ks 0.80 0.00390 2.0 0.00210 0.00120
            if ($res.maeAll -lt 5.2) {
                Write-Output ("ks={0:F4} c0={1:F4} ke={2:F4} -> All={3:F2}um (420={4:F2} 440={5:F2})" -f $ks, $c0, $ke, $res.maeAll, $res.mae420, $res.mae440)
            }
        }
    }
}
# Check top 10 models
$results = @()
foreach ($ks in @(0.000, 0.005, 0.008, 0.010, 0.012, 0.015, 0.020)) {
    foreach ($c0 in @(0.0010, 0.0020, 0.0028, 0.0035)) {
        foreach ($ke in @(0.0008, 0.0009, 0.0010, 0.0011)) {
            foreach ($sm in @(0.60, 0.70, 0.80, 0.90, 1.00)) {
                $res = Evaluate-Custom $c0 $ke 0.00450 1.0 $ks $sm 0.00390 2.0 0.00210 0.00120
                $results += [PSCustomObject]@{
                    ks = $ks; c0 = $c0; ke = $ke; sm = $sm;
                    maeAll = $res.maeAll; mae420 = $res.mae420; mae440 = $res.mae440
                }
            }
        }
    }
}

$top10 = $results | Sort-Object maeAll | Select-Object -First 10
foreach ($t in $top10) {
    Write-Output ("ks={0:F3} c0={1:F4} ke={2:F4} sm={3:F2} -> All={4:F2}um (SCM420={5:F2} SCM440={6:F2})" -f $t.ks, $t.c0, $t.ke, $t.sm, $t.maeAll, $t.mae420, $t.mae440)
}
