$logPath = "C:\Users\NCC\.gemini\antigravity\brain\4b156ce5-5660-42ba-a98e-0a4b70713617\.system_generated\logs\transcript.jsonl"
$lines = Get-Content $logPath
$i = 0
foreach ($line in $lines) {
    if ($line -match '"type":"USER_INPUT"') {
        $json = $line | ConvertFrom-Json
        $i++
        Write-Output "=== [$i] Step $($json.step_index) ==="
        Write-Output $json.content
    }
}
