$jobs = @(
    # SCM440 (28-32 HRC) - 9 bài
    @{ id = "1P-5P01"; mat = "SCM440"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; actualOffset = 0.1010; delta = 0.0110 },
    @{ id = "STT 1";   mat = "SCM440"; H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 2";   mat = "SCM440"; H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 6";   mat = "SCM440"; H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; actualOffset = 0.0970; delta = 0.0070 },
    @{ id = "1P-2P10"; mat = "SCM440"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; actualOffset = 0.1025; delta = 0.0125 },
    @{ id = "STT 17";  mat = "SCM440"; H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; actualOffset = 0.1135; delta = 0.0235 },
    @{ id = "1P-2P12"; mat = "SCM440"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1125; delta = 0.0225 },
    @{ id = "STT 20";  mat = "SCM440"; H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; actualOffset = 0.1100; delta = 0.0200 },
    @{ id = "STT 14";  mat = "SCM440"; H = 300; Ton = 120; Po = 9;  IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1150; delta = 0.0250 },

    # SCM420 (HB < 200) - 10 bài
    @{ id = "STT 22";  mat = "SCM420"; H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 3";   mat = "SCM420"; H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 18";  mat = "SCM420"; H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; actualOffset = 0.0980; delta = 0.0080 },
    @{ id = "STT 16";  mat = "SCM420"; H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1120; delta = 0.0220 },
    @{ id = "STT 21";  mat = "SCM420"; H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; actualOffset = 0.1180; delta = 0.0280 },
    @{ id = "STT 19";  mat = "SCM420"; H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; actualOffset = 0.1050; delta = 0.0150 },
    @{ id = "STT 7";   mat = "SCM420"; H = 140; Ton = 120; Po = 8;  IP = 5; Volt = "High"; VF = 55; actualOffset = 0.0950; delta = 0.0050 },
    @{ id = "STT 12";  mat = "SCM420"; H = 140; Ton = 100; Po = 9;  IP = 6; Volt = "High"; VF = 60; actualOffset = 0.1020; delta = 0.0120 },
    @{ id = "STT 15";  mat = "SCM420"; H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; actualOffset = 0.1200; delta = 0.0300 },
    @{ id = "STT 23";  mat = "SCM420"; H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; actualOffset = 0.1080; delta = 0.0180 }
)

function Calc-Gap($j, $c0, $ke, $dl, $ks, $sm420, $kv, $kvf, $kpo) {
    $H = $j.H
    $Ton = $j.Ton
    $IP = $j.IP
    $Po = $j.Po
    $Volt = $j.Volt
    $VF = $j.VF
    $isHard = ($j.mat -eq "SCM440")

    if ($H -le 170) {
        $u_ratio = if ($Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $ke * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $dl_term = if ($Volt -eq 'Low') { $dl } else { 0.0 }
        $ip_fac = [Math]::Max(1.0, $IP / 4.0)
        $sm = if ($isHard) { 1.0 } else { $sm420 }
        $d_slag = - $ks * ($H / 100.0) * $sm / $ip_fac
        $d_vibr = $kv * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)
        $d_vf = $kvf * (($VF - 55.0) / 10.0)
        $d_po = - $kpo * (($Po - 5.0) / 10.0)
        return $c0 + $d_elec + $dl_term + $d_slag + $d_vibr + $d_vf + $d_po
    } else {
        return 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }
}

Write-Host "=== SO SANH 3 MO HINH TREN 19 BAI CAT THUC TE ==="

$mae1_420 = 0; $mae1_440 = 0
$mae2_420 = 0; $mae2_440 = 0
$mae3_420 = 0; $mae3_440 = 0
$n420 = 0; $n440 = 0

foreach ($j in $jobs) {
    # M1: Tab 2 hiện tại
    $gap1 = if ($j.H -le 170) {
        $u = if ($j.Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        0.00280 + 0.00100 * [Math]::Sqrt($j.Ton * $j.IP) * $u + (if ($j.Volt -eq 'Low') { 0.00450 } else { 0.0 }) - 0.02300 * ($j.H / 100.0) / [Math]::Max(1.0, $j.IP / 4.0) + 0.00390 * [Math]::Pow($j.H / 100.0, 2) * ($j.IP / 5.0)
    } else {
        0.0187 + ($j.H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }
    $o1 = 0.090 + $gap1
    $err1 = ($o1 - $j.actualOffset) * 1000

    # M2: Tab 3 Chuẩn
    $gap2 = Calc-Gap $j 0.00350 0.00100 0.00450 0.02000 0.80 0.00390 0.00210 0.00120
    $o2 = 0.090 + $gap2
    $err2 = ($o2 - $j.actualOffset) * 1000

    # M3: Refined Rule 10
    $gap3 = Calc-Gap $j 0.00200 0.00090 0.00450 0.01200 0.80 0.00390 0.00210 0.00120
    $o3 = 0.090 + $gap3
    $err3 = ($o3 - $j.actualOffset) * 1000

    $isHard = ($j.mat -eq "SCM440")
    if ($isHard) {
        $mae1_440 += [Math]::Abs($err1)
        $mae2_440 += [Math]::Abs($err2)
        $mae3_440 += [Math]::Abs($err3)
        $n440++
    } else {
        $mae1_420 += [Math]::Abs($err1)
        $mae2_420 += [Math]::Abs($err2)
        $mae3_420 += [Math]::Abs($err3)
        $n420++
    }

    $actStr = $j.actualOffset.ToString("F4")
    $e1Str = $err1.ToString("+0.0;-0.0")
    $e2Str = $err2.ToString("+0.0;-0.0")
    $e3Str = $err3.ToString("+0.0;-0.0")

    Write-Host ("{0,-6} {1,-8} H={2,3} | Thuc={3} | M1_HienTai: {4,6}um | M2_Tab3: {5,6}um | M3_Refined: {6,6}um" -f $j.mat, $j.id, $j.H, $actStr, $e1Str, $e2Str, $e3Str)
}

Write-Host ""
Write-Host "--- TONG KET MAE ---"
Write-Host ("M1 (Tab 2 Hien tai): SCM420={0:F2} um | SCM440={1:F2} um | All={2:F2} um" -f ($mae1_420/$n420), ($mae1_440/$n440), (($mae1_420+$mae1_440)/($n420+$n440)))
Write-Host ("M2 (Tab 3 Chuan):    SCM420={0:F2} um | SCM440={1:F2} um | All={2:F2} um" -f ($mae2_420/$n420), ($mae2_440/$n440), (($mae2_420+$mae2_440)/($n420+$n440)))
Write-Host ("M3 (Refined R10):    SCM420={0:F2} um | SCM440={1:F2} um | All={2:F2} um" -f ($mae3_420/$n420), ($mae3_440/$n440), (($mae3_420+$mae3_440)/($n420+$n440)))
