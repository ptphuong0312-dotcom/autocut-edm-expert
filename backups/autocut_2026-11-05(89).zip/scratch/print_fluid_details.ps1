# Print detailed breakdown of Optimal Physical Fluid Model
$dataset = @(
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225; I=2.9 }
)

$C0 = 0.00250
$K_elec = 0.00070
$d_low = 0.00450
$K_vf = 0.00210
$K_vibr = 0.00350
$K_h_confinement = 0.01200
$K_secondary = 0.03000

Write-Host "=================================================================================================================================="
Write-Host "CHI TIET PHAN TICH: KHA NANG PHA KHE KHO THEO H VA MAT DO XIC DANH LUA THU CAP"
Write-Host "=================================================================================================================================="
Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2} | d_elec | d_h_lim | rho_xỉ | d_secondary | delta_calc | delta_thuc | Sai lech" -f "STT", "H", "Thep", "Ton", "Po", "IP", "Volt", "VF")
Write-Host ("-" * 130)

foreach ($it in $dataset) {
    $isHard = ($it.mat -eq 'SCM440')
    $u_ratio = if ($it.Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
    $d_elec = $K_elec * [Math]::Sqrt($it.Ton * $it.IP) * $u_ratio
    $d_low_val = if ($it.Volt -eq 'Low') { $d_low } else { 0.0 }
    $d_vf_val = $K_vf * (($it.VF - 55.0) / 10.0)
    $d_vibr_val = $K_vibr * [Math]::Pow($it.H / 100.0, 2) * ($it.IP / 5.0)

    # 1. Khả năng phá khe suy giảm theo H (Height Confinement)
    $d_conf = - $K_h_confinement * ($it.H / 100.0)

    # 2. Mật độ tích tụ xỉ & Đánh lửa thứ cấp do khó thoát phoi
    $rho = ($it.I / ($it.Po + 2.0)) * ($it.H / 100.0)
    $mat_k = if ($isHard) { 1.0 } else { 1.25 }
    $d_sec = $K_secondary * [Math]::Pow($rho, 1.8) * $mat_k

    $calc = $C0 + $d_elec + $d_low_val + $d_vf_val + $d_vibr_val + $d_conf + $d_sec
    $diff = ($calc - $it.actual) * 1000
    $sign = if ($diff -ge 0) { '+' } else { '' }

    Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2} | {8,5:F1}  | {9,6:F1}  | {10,5:F3}  | {11,8:F1}  | {12,7:F1} um | {13,7:F1} um | {14,7} um" -f `
        $it.id, $it.H, $it.mat, $it.Ton, $it.Po, $it.IP, $it.Volt, $it.VF, ($d_elec*1000), ($d_conf*1000), $rho, ($d_sec*1000), ($calc*1000), ($it.actual*1000), ($sign + $diff.ToString("F1")))
}
