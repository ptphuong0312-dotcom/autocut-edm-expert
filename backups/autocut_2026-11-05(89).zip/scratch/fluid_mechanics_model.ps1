# Test Fluid Mechanics & Discharge Physics model
$dataset = @(
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225; I=2.9 }
)

Write-Host "ANALYZING SLAG DENSITY INDEX: rho = (I / (Po + 2)) * (H / 100)"
Write-Host "----------------------------------------------------------------------"
foreach ($it in $dataset) {
    $rho = ($it.I / ($it.Po + 2)) * ($it.H / 100.0)
    $ratio = ($it.actual * 1000)
    Write-Host ("{0,-8} | H={1,3}mm | Po={2,2} | I={3,3:F1}A | rho_slag={4,5:F3} | delta_thuc={5,5:F1} um" -f $it.id, $it.H, $it.Po, $it.I, $rho, $ratio)
}
