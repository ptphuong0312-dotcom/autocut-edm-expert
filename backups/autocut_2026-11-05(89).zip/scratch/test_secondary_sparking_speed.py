import math

dataset_full = [
    # name, H, Ton, Po, IP, Volt, VF, max_hz, mat, actual_gap
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 150, 'SCM440', 0.0110],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 150, 'SCM420', 0.0050],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 200, 'SCM440', 0.0080],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 180, 'SCM440', 0.0080],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 150, 'SCM420', 0.0050],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 150, 'SCM420', 0.0080],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 100, 'SCM440', 0.0070],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 187, 'SCM420', 0.0220],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 150, 'SCM440', 0.0125],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 150, 'SCM420', 0.0280],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 150, 'SCM440', 0.0235],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 150, 'SCM420', 0.0150],
    ['STT 7',  140, 120, 8, 5, 'High', 55,  50, 'SCM420', 0.0050],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 100, 'SCM420', 0.0120],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 154, 'SCM420', 0.0300],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70,  60, 'SCM440', 0.0225],
    ['STT 23', 200, 120, 10, 6, 'High', 65,  60, 'SCM420', 0.0180],
    ['STT 20', 290, 135, 10, 6, 'High', 75,  50, 'SCM440', 0.0200],
    ['STT 14', 300, 120, 9, 6, 'High', 65,  50, 'SCM440', 0.0250]
]

# Baseline calculation
def calc_baseline(H, Ton, Po, IP, Volt, VF, mat):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = 0.00092 * math.sqrt(Ton * IP) * u_ratio
        d_low = 0.00450 if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - 0.02000 * (H / 100.0) * sm / ip_fac
        d_vibr = 0.00390 * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = 0.00210 * ((VF - 55.0) / 10.0)
        d_po = - 0.00120 * ((Po - 5.0) / 10.0)
        return 0.00360 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po
    else:
        gap170 = 0.00360 + (0.00092 * math.sqrt(Ton * IP) * 1.0) + (- 0.02000 * 1.70 * sm / max(1.0, IP / 4.0)) + (0.00390 * math.pow(1.70, 2) * (IP / 5.0))
        gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
        d_vf = 0.00210 * 0.5 * ((VF - 65.0) / 10.0)
        d_po = - 0.00120 * 0.5 * ((Po - 9.0) / 10.0)
        return gapBase + d_vf + d_po

# Model with Secondary Sparking + Speed Throttling
# Slag density index rho_slag = (Ton * IP / (Po * 50)) * (H / 100) * (max_hz / 100)
# Notice: When max_hz is 50Hz (throttled), debris clears better and no surging -> low secondary sparks!
# When max_hz is 150-187Hz with large Ton in medium height -> intense secondary sparking!

def calc_secondary_model(k_sec, p_exp=1.0, mat_fac=1.20):
    errs = []
    diffs = []
    for r in dataset_full:
        name, H, Ton, Po, IP, Volt, VF, max_hz, mat, act = r
        base = calc_baseline(H, Ton, Po, IP, Volt, VF, mat)
        
        isHard = (mat == 'SCM440' or mat == '30HRC')
        km = 1.0 if isHard else mat_fac
        
        if H <= 170:
            # Slag density that produces secondary sparks
            # High Ton * IP / Po gives high debris.
            # (max_hz / 100) scales with how fast the table is pushed
            slag_intensity = (Ton * IP / (Po * 30.0)) * (H / 100.0) * (max_hz / 120.0) * km
            
            # Secondary sparking only triggers when slag intensity exceeds safe threshold (~ 0.8)
            if slag_intensity > 0.80:
                d_sec = k_sec * math.pow(slag_intensity - 0.80, p_exp)
            else:
                d_sec = 0.0
            calc = base + d_sec
        else:
            d_sec = 0.0
            calc = base
            
        diff_um = (calc - act) * 1000.0
        errs.append(abs(diff_um))
        diffs.append((name, H, mat, act*1000, base*1000, calc*1000, diff_um, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    max_err = max(errs)
    return mae, max_err, diffs

best_k = None
best_mae = 999.0
for k in [0.004, 0.006, 0.008, 0.010, 0.012, 0.014, 0.016, 0.018]:
    for p in [0.8, 1.0, 1.2]:
        for mf in [1.0, 1.15, 1.25]:
            m, me, d = calc_secondary_model(k, p, mf)
            if m < best_mae:
                best_mae = m
                best_k = (k, p, mf, m, me, d)

print(f"Optimal Model with Slag Density & Secondary Sparking:")
print(f"k_sec = {best_k[0]:.4f}, p_exp = {best_k[1]}, mat_fac = {best_k[2]}")
print(f"MAE: {best_k[3]:.2f} um (was 6.00 um) -> REDUCED BY {6.00 - best_k[3]:.2f} um!")
print(f"Max Error: {best_k[4]:.2f} um (was 20.27 um) -> REDUCED BY {20.27 - best_k[4]:.2f} um!")
print("\n" + "=" * 90)
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Base (cũ)':>10} | {'MỚI':>8} | {'Sai số (um)':>12} | {'d_sec (um)':>10}")
print("-" * 90)
for d in best_k[5]:
    sign = '+' if d[6] >= 0 else ''
    print(f"{d[0]:<8} | {d[1]:>3} | {d[2]:<6} | {d[3]:>7.1f} | {d[4]:>10.1f} | {d[5]:>8.1f} | {sign + f'{d[6]:.1f}':>12} | {d[7]:>+10.1f}")
