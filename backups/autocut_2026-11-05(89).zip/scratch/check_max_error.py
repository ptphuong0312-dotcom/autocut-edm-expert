import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'WS_LIB_BENCHMARK_JOBS\s*=\s*\{\s*1:\s*\[(.*?)\]\s*,\s*2:', text, re.DOTALL)
if m:
    block = m.group(1)
    lines = block.strip().split('\n')
    records = []
    current_h = None
    current_mat = None
    current_comment = ""
    for line in lines:
        line_clean = line.strip()
        if line_clean.startswith('//'):
            current_comment = line_clean
            continue
        h_m = re.search(r'H:\s*(\d+)', line_clean)
        if h_m:
            current_h = int(h_m.group(1))
        mat_m = re.search(r'material:\s*"([^"]+)"', line_clean)
        if mat_m:
            current_mat = mat_m.group(1)
        
        p_m = re.search(r'offset:\s*"([^"]+)",\s*actualOffset:\s*"([^"]+)",\s*calcOffset:\s*"([^"]+)"', line_clean)
        if p_m:
            act_off_str = p_m.group(2).replace(',', '.')
            calc_off_str = p_m.group(3).replace(',', '.')
            act_off = float(act_off_str)
            calc_off = float(calc_off_str)
            diff_um = (calc_off - act_off) * 1000
            records.append((current_comment, current_h, current_mat, act_off, calc_off, diff_um))

    print(f"Parsed {len(records)} benchmark jobs in WS_LIB_BENCHMARK_JOBS[1]:\n")
    print(f"{'Ghi chú / STT':<40} | {'H':>3} | {'Vật liệu':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>9}")
    print("-" * 85)
    max_err = 0
    max_rec = None
    for r in records:
        cmt, h, mat, act, calc, diff = r
        if abs(diff) > max_err:
            max_err = abs(diff)
            max_rec = r
        # Clean comment
        short_cmt = cmt.replace('//', '').strip()
        print(f"{short_cmt:<40} | {h:>3} | {mat:<6} | {act:>7.4f} | {calc:>7.4f} | {diff:>+8.1f} um")
    
    print("=" * 85)
    print(f"Sai số lớn nhất (Max Absolute Error): {max_err:.1f} um ({max_err/1000:.4f} mm)")
    print(f"Tại bài cắt: {max_rec[0]} (H={max_rec[1]}, {max_rec[2]}): Actual={max_rec[3]}, Calc={max_rec[4]}, Lệch={max_rec[5]:+.1f} um")
