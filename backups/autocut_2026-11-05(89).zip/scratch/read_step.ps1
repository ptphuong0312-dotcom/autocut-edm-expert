$path = "C:\Users\NCC\.gemini\antigravity\brain\4b156ce5-5660-42ba-a98e-0a4b70713617\.system_generated\logs\transcript.jsonl"
$lines = Get-Content $path
foreach ($line in $lines) {
    $json = $line | ConvertFrom-Json
    if ($json.step_index -ge 942 -and $json.step_index -le 948) {
        Write-Output ("Step {0}: tool_calls={1} thinking={2}" -f $json.step_index, ($json.tool_calls | ConvertTo-Json -Compress), ($json.thinking.Substring(0, [Math]::Min(200, $json.thinking.Length))))
    }
}
