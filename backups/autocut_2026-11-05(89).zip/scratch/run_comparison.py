import math

benchmarks = [
    {'name': '5P-01_P1', 'H': 12, 'mat': 'SCM440', 'Ton': 20, 'Po': 5, 'IP': 3, 'Volt': 'High', 'VF': 65, 'delta_real': 0.0110},
    {'name': 'STT 22', 'H': 12, 'mat': 'SCM420', 'Ton': 16, 'Po': 6, 'IP': 3, 'Volt': 'Low', 'VF': 60, 'delta_real': 0.0050},
    {'name': 'STT 1', 'H': 30, 'mat': 'SCM440', 'Ton': 32, 'Po': 5, 'IP': 4, 'Volt': 'High', 'VF': 65, 'delta_real': 0.0080},
    {'name': 'STT 2', 'H': 40, 'mat': 'SCM440', 'Ton': 36, 'Po': 5, 'IP': 4, 'Volt': 'High', 'VF': 65, 'delta_real': 0.0080},
    {'name': 'STT 3', 'H': 63, 'mat': 'SCM420', 'Ton': 44, 'Po': 7, 'IP': 5, 'Volt': 'High', 'VF': 55, 'delta_real': 0.0050},
    {'name': 'STT 18', 'H': 63, 'mat': 'SCM420', 'Ton': 44, 'Po': 8, 'IP': 4, 'Volt': 'High', 'VF': 57, 'delta_real': 0.0080},
    {'name': 'STT 6', 'H': 68, 'mat': 'SCM440', 'Ton': 70, 'Po': 7, 'IP': 3, 'Volt': 'Low', 'VF': 50, 'delta_real': 0.0070},
    {'name': 'STT 16', 'H': 75, 'mat': 'SCM420', 'Ton': 55, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 54, 'delta_real': 0.0220},
    {'name': '2P-10_P1', 'H': 85, 'mat': 'SCM440', 'Ton': 70, 'Po': 8, 'IP': 5, 'Volt': 'High', 'VF': 61, 'delta_real': 0.0125},
    {'name': 'STT 21', 'H': 90, 'mat': 'SCM420', 'Ton': 80, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 54, 'delta_real': 0.0280},
    {'name': 'STT 17', 'H': 95, 'mat': 'SCM440', 'Ton': 82, 'Po': 7, 'IP': 4, 'Volt': 'High', 'VF': 55, 'delta_real': 0.0235},
    {'name': 'STT 19', 'H': 110, 'mat': 'SCM420', 'Ton': 100, 'Po': 10, 'IP': 5, 'Volt': 'High', 'VF': 65, 'delta_real': 0.0150},
    {'name': 'STT 7', 'H': 140, 'mat': 'SCM420', 'Ton': 120, 'Po': 8, 'IP': 5, 'Volt': 'High', 'VF': 55, 'delta_real': 0.0050},
    {'name': 'STT 12', 'H': 140, 'mat': 'SCM420', 'Ton': 100, 'Po': 9, 'IP': 6, 'Volt': 'High', 'VF': 60, 'delta_real': 0.0120},
    {'name': 'STT 15', 'H': 160, 'mat': 'SCM420', 'Ton': 120, 'Po': 11, 'IP': 6, 'Volt': 'High', 'VF': 70, 'delta_real': 0.0300},
    {'name': '2P-12_P1', 'H': 165, 'mat': 'SCM440', 'Ton': 135, 'Po': 11, 'IP': 6, 'Volt': 'High', 'VF': 70, 'delta_real': 0.0225},
]

C0 = 0.00360
K_ELEC = 0.00092
DELTA_LOW = 0.00450
K_SLAG = 0.02000
K_VIBR = 0.00390
K_VF = 0.00210
K_PO = 0.00120

K_SEC = 0.00400
S_THRESH = 0.40

print("| Name | H | Mat | Ton | Po | IP | d_sec (um) | Old Delta | New Delta | Real | Old Err | New Err |")
print("|---|---|---|---|---|---|---|---|---|---|---|---|")

old_errs = []
new_errs = []

for b in benchmarks:
    isHard = (b['mat'] == 'SCM440')
    u_ratio = 1.0 if b['Volt'] == 'High' else (22.0 / 27.0)
    d_elec = K_ELEC * math.sqrt(b['Ton'] * b['IP']) * u_ratio
    d_low = DELTA_LOW if b['Volt'] == 'Low' else 0.0
    ip_fac = max(1.0, b['IP'] / 4.0)
    slag_mat = 1.0 if isHard else 0.80
    d_slag = - K_SLAG * (b['H'] / 100.0) * slag_mat / ip_fac
    d_vibr = K_VIBR * math.pow(b['H'] / 100.0, 2) * (b['IP'] / 5.0)
    d_vf = K_VF * ((b['VF'] - 55.0) / 10.0)
    d_po = - K_PO * ((b['Po'] - 5.0) / 10.0)
    
    delta_old = C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po
    
    # Secondary sparking
    s_mat = 1.0 if isHard else 1.18
    s_raw = ((b['Ton'] * b['IP']) / (math.pow(b['Po'], 1.3) * 15.0)) * (b['H'] / 100.0) * s_mat
    if b['H'] <= 170 and s_raw > S_THRESH:
        d_sec = K_SEC * (s_raw - S_THRESH) / (1.0 + 0.3 * math.pow(b['H'] / 100.0, 2))
    else:
        d_sec = 0.0
        
    delta_new = delta_old + d_sec
    
    err_old = abs(delta_old - b['delta_real']) * 1000.0
    err_new = abs(delta_new - b['delta_real']) * 1000.0
    old_errs.append(err_old)
    new_errs.append(err_new)
    
    print(f"| {b['name']} | {b['H']} | {b['mat']} | {b['Ton']} | {b['Po']} | {b['IP']} | {d_sec*1000:+.2f} | {delta_old*1000:.1f} | {delta_new*1000:.1f} | {b['delta_real']*1000:.1f} | {err_old:.1f} | {err_new:.1f} |")

print(f"\nOld MAE: {sum(old_errs)/len(old_errs):.2f} um | Max Err: {max(old_errs):.2f} um")
print(f"New MAE: {sum(new_errs)/len(new_errs):.2f} um | Max Err: {max(new_errs):.2f} um")
