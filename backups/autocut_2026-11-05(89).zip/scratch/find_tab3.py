import re

with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'id=["\']tab-vf-research["\'].*?</section>', text, re.DOTALL)
if m:
    section = m.group(0)
    print("Found section, length:", len(section))
    ids = re.findall(r'id=["\']([^"\']+)["\']', section)
    print("IDs in tab-vf-research:\n", ids)
