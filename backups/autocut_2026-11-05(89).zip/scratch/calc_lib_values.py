import math

dataset = [
    # name, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['5P-01_P1', 12, 20, 5, 3, 'High', 65, '30HRC', 0.0110, 0.1010],
    ['STT 22',   12, 16, 6, 3, 'Low',  60, 'HB<200', 0.0050, 0.0950],
    ['STT 1',    30, 32, 5, 4, 'High', 65, '30HRC', 0.0080, 0.0980],
    ['STT 2',    40, 36, 5, 4, 'High', 65, '30HRC', 0.0080, 0.0980],
    ['STT 3',    63, 44, 7, 5, 'High', 55, 'HB<200', 0.0050, 0.0950],
    ['STT 18',   63, 44, 8, 4, 'High', 57, 'HB<200', 0.0080, 0.0980],
    ['STT 6',    68, 70, 7, 3, 'Low',  50, '30HRC', 0.0070, 0.0970],
    ['STT 16',   75, 55, 7, 4, 'High', 54, 'HB<200', 0.0220, 0.1120],
    ['2P-10_P1', 85, 70, 8, 5, 'High', 61, '30HRC', 0.0125, 0.1025],
    ['STT 21',   90, 80, 7, 4, 'High', 54, 'HB<200', 0.0280, 0.1180],
    ['STT 17',   95, 82, 7, 4, 'High', 55, '30HRC', 0.0235, 0.1135],
    ['STT 19',  110, 100, 10, 5, 'High', 65, 'HB<200', 0.0150, 0.1050],
    ['STT 7',   140, 120, 8, 5, 'High', 55, 'HB<200', 0.0050, 0.0950],
    ['STT 12',  140, 100, 9, 6, 'High', 60, 'HB<200', 0.0120, 0.1020],
    ['STT 15',  160, 120, 11, 6, 'High', 70, 'HB<200', 0.0300, 0.1200],
    ['2P-12_P1', 165, 135, 11, 6, 'High', 70, '30HRC', 0.0225, 0.1125],
    ['STT 23',  200, 120, 10, 6, 'High', 65, 'HB<200', 0.0180, 0.1080],
    ['STT 20',  290, 135, 10, 6, 'High', 75, '30HRC', 0.0200, 0.1100],
    ['STT 14',  300, 120, 9, 6, 'High', 65, '30HRC', 0.0250, 0.1150]
]

C0 = 0.00360
K_ELEC = 0.00092
DELTA_LOW = 0.00450
K_SLAG = 0.02000
K_VIBR = 0.00390
K_VF = 0.00210
K_PO = 0.00120

K_SEC = 0.00400
S_THRESH = 0.20

for r in dataset:
    name, H, Ton, Po, IP, Volt, VF, mat, act_gap, act_o1 = r
    isHard = (mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    km = 1.0 if isHard else 1.25
    
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
        d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
        d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = K_VF * ((VF - 55.0) / 10.0)
        d_po = - K_PO * ((Po - 5.0) / 10.0)
        
        s_raw = (Ton * IP / (Po * 25.0)) * (H / 100.0) * km
        if s_raw > S_THRESH:
            d_sec = K_sec = K_SEC * (s_raw - S_THRESH) / (1.0 + 1.5 * math.pow(H / 100.0, 2))
        else:
            d_sec = 0.0
            
        g = C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec
    else:
        gap170 = C0 + (K_ELEC * math.sqrt(Ton * IP) * 1.0) + (- K_SLAG * 1.70 * sm / max(1.0, IP / 4.0)) + (K_VIBR * math.pow(1.70, 2) * (IP / 5.0))
        gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
        d_vf = K_VF * 0.5 * ((VF - 65.0) / 10.0)
        d_po = - K_PO * 0.5 * ((Po - 9.0) / 10.0)
        g = gapBase + d_vf + d_po
        d_sec = 0.0
        
    o1 = 0.090 + g
    calc_str = f"{o1:.4f}".replace('.', ',')
    print(f"{name:<10}: calcOffset = \"{calc_str}\" (o1={o1:.4f}, gap={g*1000:.2f}um, d_sec={d_sec*1000:+.2f}um)")
