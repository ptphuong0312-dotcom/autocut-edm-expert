import math

dataset = [
    # name, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',  140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

C0 = 0.00360
K_ELEC = 0.00092
DELTA_LOW = 0.00450
K_SLAG = 0.02000
K_VIBR = 0.00390
K_VF = 0.00210
K_PO = 0.00120

def eval_sec(k_sec, s_thresh, p_h_damp, s_mat_ratio):
    errs = []
    diffs = []
    for r in dataset:
        name, H, Ton, Po, IP, Volt, VF, mat, act_gap, act_o1 = r
        isHard = (mat == 'SCM440' or mat == '30HRC')
        sm = 1.0 if isHard else 0.80
        km = 1.0 if isHard else s_mat_ratio
        
        if H <= 170:
            u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
            d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
            d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
            ip_fac = max(1.0, IP / 4.0)
            d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
            d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
            d_vf = K_VF * ((VF - 55.0) / 10.0)
            d_po = - K_PO * ((Po - 5.0) / 10.0)
            
            # Secondary sparking
            # Notice: debris generation is proportional to (Ton * IP) / Po
            # Flushing difficulty in narrow kerf increases with H up to ~100mm,
            # but for H > 100mm servo slows down (VF increases) so debris per unit travel doesn't explode.
            # Damping term: 1.0 + p_h_damp * (H/100)^2
            s_raw = (Ton * IP / (Po * 25.0)) * (H / 100.0) * km
            if s_raw > s_thresh:
                d_sec = k_sec * (s_raw - s_thresh) / (1.0 + p_h_damp * math.pow(H / 100.0, 2))
            else:
                d_sec = 0.0
            
            calc_gap = C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec
        else:
            gap170 = C0 + (K_ELEC * math.sqrt(Ton * IP) * 1.0) + (- K_SLAG * 1.70 * sm / max(1.0, IP / 4.0)) + (K_VIBR * math.pow(1.70, 2) * (IP / 5.0))
            gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
            d_vf = K_VF * 0.5 * ((VF - 65.0) / 10.0)
            d_po = - K_PO * 0.5 * ((Po - 9.0) / 10.0)
            d_sec = 0.0
            calc_gap = gapBase + d_vf + d_po
            
        diff_um = (calc_gap - act_gap) * 1000.0
        errs.append(abs(diff_um))
        diffs.append((name, H, mat, act_gap*1000, calc_gap*1000, diff_um, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    max_e = max(errs)
    return mae, max_e, diffs

best_score = 999.0
best_cfg = None

for k_sec in [0.001, 0.0015, 0.002, 0.0025, 0.003, 0.0035, 0.004]:
    for s_thresh in [0.2, 0.3, 0.4, 0.5, 0.6]:
        for p_h_damp in [0.5, 0.8, 1.0, 1.2, 1.5, 2.0]:
            for s_mat in [1.0, 1.15, 1.20, 1.25]:
                mae, max_e, diffs = eval_sec(k_sec, s_thresh, p_h_damp, s_mat)
                score = mae + 0.3 * max_e
                if score < best_score:
                    best_score = score
                    best_cfg = (k_sec, s_thresh, p_h_damp, s_mat, mae, max_e, diffs)

k_sec, s_thresh, p_h_damp, s_mat, mae, max_e, diffs = best_cfg
print(f"BEST CONFIG: k_sec={k_sec:.5f}, s_thresh={s_thresh:.2f}, p_h_damp={p_h_damp:.2f}, s_mat={s_mat:.2f}")
print(f"MAE: {mae:.2f} um (Original: 6.00 um) | Max Error: {max_e:.2f} um (Original: 20.27 um)")
print("-" * 75)
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 75)
for d in diffs:
    name, H, mat, act, calc, diff, d_sec = d
    sign = '+' if diff >= 0 else ''
    print(f"{name:<8} | {H:>3} | {mat:<6} | {act:>7.1f} | {calc:>7.1f} | {sign + f'{diff:.1f}':>10} | {d_sec:>+10.2f}")
