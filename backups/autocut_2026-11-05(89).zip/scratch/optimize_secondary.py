import math

dataset = [
    # name, grp, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', '1P (Quy đổi 5P-01)', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  '1P (SCM420 chày L)',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   '1P (Chuẩn gốc)',      30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   '1P (Chuẩn gốc)',      40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   '1P (SCM420 chày)',    63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  '1P (SCM420 chày)',    63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   '1P (SCM440 chày L)',  68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  '1P (SCM420 cối)',     75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', '1P (Quy đổi 2P-10)',  85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  '1P (SCM420 cối)',     90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  '1P (SCM440 cối)',     95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19',  '1P (SCM420 chày)',   110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',   '1P (SCM420 chày)',   140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12',  '1P (SCM420 chày)',   140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15',  '1P (SCM420 cối)',    160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', '1P (Quy đổi 2P-12)', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23',  '1P (SCM420 siêu dày)', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20',  '1P (SCM440 siêu dày)', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14',  '1P (SCM440 mốc 300)', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

# Let's test a model that includes Secondary Sparking due to Slag Density!
# Slag density rho_slag = (Itb / (Po + 2)) * (H / 100)
# Notice: When rho_slag is high, secondary sparks occur and widen the kerf: + d_sec
# Meanwhile, height confinement still limits the expansion: - d_h

def evaluate_model(C0, k_elec, k_low, k_conf, k_vibr, k_vf, k_po, k_sec, p_exp=1.8, mat_ratio=1.25):
    errs = []
    errs440 = []
    errs420 = []
    
    for r in dataset:
        H, Ton, Po, IP, Volt, VF, mat, act_gap = r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]
        isHard = (mat == 'SCM440' or mat == '30HRC')
        k_mat = 1.0 if isHard else mat_ratio
        
        # Calculate Itb
        k_ampe = 2.2857 if isHard else 2.8571
        itb = (6.4 * IP / (1 + Po)) * k_ampe
        
        # Slag accumulation index
        rho_slag = (itb / (Po + 2.0)) * (H / 100.0)
        
        # Secondary sparking term
        d_sec = k_sec * math.pow(rho_slag, p_exp) * k_mat
        
        if H <= 170:
            u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
            d_elec = k_elec * math.sqrt(Ton * IP) * u_ratio
            d_low = k_low if (Volt == 'Low' or Volt == 'L') else 0.0
            d_conf = - k_conf * (H / 100.0)
            d_vibr = k_vibr * math.pow(H / 100.0, 2) * (IP / 5.0)
            d_vf = k_vf * ((VF - 55.0) / 10.0)
            d_po = - k_po * ((Po - 5.0) / 10.0)
            calc_g = C0 + d_elec + d_low + d_conf + d_vibr + d_vf + d_po + d_sec
        else:
            # Ultra thick
            g170 = C0 + (k_elec * math.sqrt(Ton * IP)) - (k_conf * 1.70) + (k_vibr * math.pow(1.70, 2) * (IP / 5.0)) + d_sec
            calc_g = g170 + (H - 170) * (0.0250 - g170) / (300 - 170)
            d_vf = k_vf * 0.5 * ((VF - 65.0) / 10.0)
            d_po = - k_po * 0.5 * ((Po - 9.0) / 10.0)
            calc_g += d_vf + d_po
            
        diff_um = abs(calc_g - act_gap) * 1000.0
        errs.append(diff_um)
        if isHard:
            errs440.append(diff_um)
        else:
            errs420.append(diff_um)
            
    mae = sum(errs) / len(errs)
    mae440 = sum(errs440) / len(errs440)
    mae420 = sum(errs420) / len(errs420)
    max_err = max(errs)
    return mae, mae440, mae420, max_err

# Grid search / optimization
best_mae = 999.0
best_params = None

# Search around physically reasonable ranges
for C0 in [0.0030, 0.0035, 0.0040, 0.0045]:
    for k_elec in [0.0006, 0.0008, 0.0009, 0.0010]:
        for k_conf in [0.005, 0.008, 0.010, 0.012, 0.015]:
            for k_sec in [0.005, 0.010, 0.015, 0.020, 0.025, 0.030]:
                for k_vf in [0.0015, 0.0020, 0.0025]:
                    for mat_ratio in [1.0, 1.15, 1.25]:
                        mae, mae440, mae420, max_err = evaluate_model(
                            C0=C0, k_elec=k_elec, k_low=0.0045, k_conf=k_conf, 
                            k_vibr=0.0035, k_vf=k_vf, k_po=0.0010, k_sec=k_sec,
                            p_exp=1.8, mat_ratio=mat_ratio
                        )
                        if mae < best_mae:
                            best_mae = mae
                            best_params = (C0, k_elec, k_conf, k_sec, k_vf, mat_ratio, mae, mae440, mae420, max_err)

print("BEST MODEL FOUND:")
print(f"C0: {best_params[0]:.5f}, k_elec: {best_params[1]:.5f}, k_conf: {best_params[2]:.5f}, k_sec: {best_params[3]:.5f}, k_vf: {best_params[4]:.5f}, mat_ratio: {best_params[5]:.2f}")
print(f"Global MAE: {best_params[6]:.2f} um (was 6.00 um)")
print(f"SCM440 MAE: {best_params[7]:.2f} um (was 3.71 um)")
print(f"SCM420 MAE: {best_params[8]:.2f} um (was 8.06 um)")
print(f"Max Error:  {best_params[9]:.2f} um (was 20.27 um)")
