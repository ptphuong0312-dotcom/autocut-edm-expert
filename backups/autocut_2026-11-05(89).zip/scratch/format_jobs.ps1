# Tao noi dung cap nhat cho WS_LIB_BENCHMARK_JOBS[1]
$jobs = @(
    # H=12 30HRC
    @{ H = 12; mat = "30HRC"; fromMulti = $true; Ton = 20; Toff = 5; IP = 3; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "150Hz"; actOff = "0,101"; calcOff = "0,1010"; len = "128mm"; actTime = "19p50'"; calcTime = "19p50'"; actAmpe = "4A"; calcAmpe = "3.2A"; actSpd = "275-285 mm²/p"; calcSpdH40 = "237 mm²/p" },
    # H=12 HB<200
    @{ H = 12; mat = "HB<200"; fromMulti = $false; Ton = 16; Toff = 6; IP = 3; Wire = 1; Volt = "L"; VF = 60; maxSpeed = "150Hz"; actOff = "0,095"; calcOff = "0,1027"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "2,5A - 2,7A"; calcAmpe = "2.3A"; actSpd = "--"; calcSpdH40 = "143 mm²/p" },
    # H=30 30HRC
    @{ H = 30; mat = "30HRC"; fromMulti = $false; Ton = 32; Toff = 5; IP = 4; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "200Hz"; actOff = "0,098"; calcOff = "0,1012"; len = "30mm"; actTime = "8p40'"; calcTime = "7p58'"; actAmpe = "4,45A - 4,5A"; calcAmpe = "4.3A"; actSpd = "165-175 mm²/p"; calcSpdH40 = "151 mm²/p" },
    # H=40 30HRC
    @{ H = 40; mat = "30HRC"; fromMulti = $false; Ton = 36; Toff = 5; IP = 4; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "180Hz"; actOff = "0,098"; calcOff = "0,1001"; len = "30mm"; actTime = "9p36'"; calcTime = "10p10'"; actAmpe = "4,35A - 4,4A"; calcAmpe = "4.3A"; actSpd = "130-140 mm²/p"; calcSpdH40 = "118 mm²/p" },
    # H=63 HB<200 STT 3
    @{ H = 63; mat = "HB<200"; fromMulti = $false; Ton = 44; Toff = 7; IP = 5; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "150Hz"; actOff = "0,095"; calcOff = "0,1016"; len = "27mm"; actTime = "14p20'"; calcTime = "15p11'"; actAmpe = "4,1A - 4,2A"; calcAmpe = "4.1A"; actSpd = "75-85 mm²/p"; calcSpdH40 = "71 mm²/p" },
    # H=63 HB<200 STT 18
    @{ H = 63; mat = "HB<200"; fromMulti = $false; Ton = 44; Toff = 8; IP = 4; Wire = 1; Volt = "H"; VF = 57; maxSpeed = "150Hz"; actOff = "0,098"; calcOff = "0,0980"; len = "22,3mm"; actTime = "17p40'"; calcTime = "17p34'"; actAmpe = "3,3A - 3,4A"; calcAmpe = "3.0A"; actSpd = "50-65 mm²/p"; calcSpdH40 = "51 mm²/p" },
    # H=68 30HRC
    @{ H = 68; mat = "30HRC"; fromMulti = $false; Ton = 70; Toff = 7; IP = 3; Wire = 1; Volt = "L"; VF = 50; maxSpeed = "100Hz"; actOff = "0,097"; calcOff = "0,0960"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "2,4A - 2,6A"; calcAmpe = "2.0A"; actSpd = "--"; calcSpdH40 = "42 mm²/p" },
    # H=75 HB<200
    @{ H = 75; mat = "HB<200"; fromMulti = $false; Ton = 55; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 54; maxSpeed = "187Hz"; actOff = "0,112"; calcOff = "0,0976"; len = "50,3mm"; actTime = "1h13'"; calcTime = "39p43'"; actAmpe = "3,4A - 3,5A"; calcAmpe = "3.3A"; actSpd = "50-65 mm²/p"; calcSpdH40 = "51 mm²/p" },
    # H=85 30HRC
    @{ H = 85; mat = "30HRC"; fromMulti = $true; Ton = 70; Toff = 8; IP = 5; Wire = 1; Volt = "H"; VF = 61; maxSpeed = "150Hz"; actOff = "0,1025"; calcOff = "0,1023"; len = "65,6mm"; actTime = "48p"; calcTime = "41p55'"; actAmpe = "3,6A - 3,7A"; calcAmpe = "3.7A"; actSpd = "55-65 mm²/p"; calcSpdH40 = "63 mm²/p" },
    # H=90 HB<200
    @{ H = 90; mat = "HB<200"; fromMulti = $false; Ton = 80; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 54; maxSpeed = "150Hz"; actOff = "0,118"; calcOff = "0,0991"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "3,5A - 3,6A"; calcAmpe = "3.3A"; actSpd = "50-60 mm²/p"; calcSpdH40 = "48 mm²/p" },
    # H=95 30HRC
    @{ H = 95; mat = "30HRC"; fromMulti = $false; Ton = 82; Toff = 7; IP = 4; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "150Hz"; actOff = "0,1135"; calcOff = "0,0952"; len = "76mm"; actTime = "1h15'"; calcTime = "1h5p"; actAmpe = "3,6A - 3,7A"; calcAmpe = "3.3A"; actSpd = "35-45 mm²/p"; calcSpdH40 = "47 mm²/p" },
    # H=110 HB<200
    @{ H = 110; mat = "HB<200"; fromMulti = $false; Ton = 100; Toff = 10; IP = 5; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "150Hz"; actOff = "0,105"; calcOff = "0,1080"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "2,7A - 2,8A"; calcAmpe = "3.1A"; actSpd = "30-40 mm²/p"; calcSpdH40 = "35 mm²/p" },
    # H=140 HB<200 STT 7
    @{ H = 140; mat = "HB<200"; fromMulti = $false; Ton = 120; Toff = 8; IP = 5; Wire = 1; Volt = "H"; VF = 55; maxSpeed = "50Hz"; actOff = "0,095"; calcOff = "0,1074"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "3,5A - 3,8A"; calcAmpe = "3.7A"; actSpd = "--"; calcSpdH40 = "31 mm²/p" },
    # H=140 HB<200 STT 12
    @{ H = 140; mat = "HB<200"; fromMulti = $false; Ton = 100; Toff = 9; IP = 6; Wire = 1; Volt = "H"; VF = 60; maxSpeed = "100Hz"; actOff = "0,102"; calcOff = "0,1128"; len = "28,4mm"; actTime = "36p"; calcTime = "33p25'"; actAmpe = "3,7A - 3,8A"; calcAmpe = "4.1A"; actSpd = "30-40 mm²/p"; calcSpdH40 = "34 mm²/p" },
    # H=160 HB<200
    @{ H = 160; mat = "HB<200"; fromMulti = $false; Ton = 120; Toff = 11; IP = 6; Wire = 1; Volt = "H"; VF = 70; maxSpeed = "154Hz"; actOff = "0,120"; calcOff = "0,1177"; len = "32,3mm"; actTime = "59p"; calcTime = "53p17'"; actAmpe = "2,8A - 3A"; calcAmpe = "3.4A"; actSpd = "18-28 mm²/p"; calcSpdH40 = "24 mm²/p" },
    # H=165 30HRC
    @{ H = 165; mat = "30HRC"; fromMulti = $true; Ton = 135; Toff = 11; IP = 6; Wire = 1; Volt = "H"; VF = 70; maxSpeed = "60Hz"; actOff = "0,1125"; calcOff = "0,1151"; len = "43,6mm"; actTime = "1h17'"; calcTime = "1h7p"; actAmpe = "2,8A - 3,0A"; calcAmpe = "3.4A"; actSpd = "15-35 mm²/p"; calcSpdH40 = "26 mm²/p" },
    # H=200 HB<200
    @{ H = 200; mat = "HB<200"; fromMulti = $false; Ton = 120; Toff = 10; IP = 6; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "60Hz"; actOff = "0,108"; calcOff = "0,1102"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "--"; calcAmpe = "3.7A"; actSpd = "--"; calcSpdH40 = "19 mm²/p" },
    # H=290 30HRC
    @{ H = 290; mat = "30HRC"; fromMulti = $false; Ton = 135; Toff = 10; IP = 6; Wire = 1; Volt = "H"; VF = 75; maxSpeed = "50Hz"; actOff = "0,110"; calcOff = "0,1145"; len = "--"; actTime = "--"; calcTime = "--"; actAmpe = "--"; calcAmpe = "3.7A"; actSpd = "--"; calcSpdH40 = "14 mm²/p" },
    # H=300 30HRC
    @{ H = 300; mat = "30HRC"; fromMulti = $false; Ton = 120; Toff = 9; IP = 6; Wire = 1; Volt = "H"; VF = 65; maxSpeed = "50Hz"; actOff = "0,115"; calcOff = "0,1150"; len = "76,1mm"; actTime = "3h"; calcTime = "3h31p"; actAmpe = "3,7A - 3,9A"; calcAmpe = "4.1A"; actSpd = "12-20 mm²/p"; calcSpdH40 = "14 mm²/p" }
)

foreach ($j in $jobs) {
    $multiStr = if ($j.fromMulti) { 'fromMultiPass: true, ' } else { '' }
    $line = '                    { H: ' + $j.H + ', material: "' + $j.mat + '", ' + $multiStr + 'passes: [{ Ton: ' + $j.Ton + ', Toff: ' + $j.Toff + ', IP: ' + $j.IP + ', Wire: ' + $j.Wire + ', Volt: "' + $j.Volt + '", VF: ' + $j.VF + ', maxSpeed: "' + $j.maxSpeed + '", offset: "' + $j.actOff + '", actualOffset: "' + $j.actOff + '", calcOffset: "' + $j.calcOff + '", length: "' + $j.len + '", actualTime: "' + $j.actTime + '", calcTime: "' + $j.calcTime + '", actualAmpe: "' + $j.actAmpe + '", calcAmpe: "' + $j.calcAmpe + '", actualSpeed: "' + $j.actSpd + '", calcSpeedH40: "' + $j.calcSpdH40 + '" }] },'
    Write-Output $line
}
