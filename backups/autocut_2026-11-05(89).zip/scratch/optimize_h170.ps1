# ==============================================================================
# DEEP OPTIMIZATION ON H <= 170MM (RULE 17) FOR 2 NEW PARAMETERS
# ==============================================================================

$dataset = @(
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110 },
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225 }
)

function Test-Parameters($C0, $K_elec, $d_low, $K_vibr, $K_vf, $K_h_confinement, $K_flush_secondary) {
    $errors = @()
    $err440 = @()
    $err420 = @()

    foreach ($item in $dataset) {
        $H = $item.H
        $Ton = $item.Ton
        $Po = $item.Po
        $IP = $item.IP
        $Volt = $item.Volt
        $VF = $item.VF
        $mat = $item.mat
        $isHard = ($mat -eq 'SCM440' -or $mat -eq '30HRC')

        # 1. Năng lượng hồ quang
        $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $K_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
        $d_low_val = if ($Volt -eq 'Low' -or $Volt -eq 'L') { $d_low } else { 0.0 }
        $d_vf_val = $K_vf * (($VF - 55.0) / 10.0)
        $d_vibr_val = $K_vibr * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)

        # 2. THÔNG SỐ 1 (SirPhuong): Khả năng phá khe suy giảm khi phôi cao (Height Confinement)
        # Năng lượng phóng điện bị phân tán dọc chiều cao H, áp lực thủy tĩnh rãnh sâu ép chặt kênh hồ quang
        $d_h_confinement = - $K_h_confinement * [Math]::Pow($H / 100.0, 1.2)

        # 3. THÔNG SỐ 2 (SirPhuong): Thoát phoi khó & Đánh lửa thứ cấp theo chiều cao phôi (Slag Flushing)
        # Khi phôi cao (H >= 70mm), nếu Po ngắn (Po <= 7), phoi không thoát kịp gây đánh lửa thứ cấp
        $mat_factor = if ($isHard) { 1.0 } else { 1.30 } # SCM420 phoi dẻo bết dính hơn 30%
        # Áp lực dòng nước suy giảm khi H tăng: mức độ tích tụ xỉ tỷ lệ với (H/100)
        # Thời gian nghỉ Po thiếu hụt: (8.5 - Po)
        $po_defect = [Math]::Max(0.0, (8.5 - $Po) / 10.0)
        $d_flush_secondary = $K_flush_secondary * [Math]::Pow($H / 100.0, 1.5) * $po_defect * $mat_factor

        $calc_gap = $C0 + $d_elec + $d_low_val + $d_vf_val + $d_vibr_val + $d_h_confinement + $d_flush_secondary

        $err = [Math]::Abs($calc_gap - $item.actual) * 1000
        $errors += $err
        if ($isHard) { $err440 += $err } else { $err420 += $err }
    }

    $mae = ($errors | Measure-Object -Average).Average
    $mae440 = ($err440 | Measure-Object -Average).Average
    $mae420 = ($err420 | Measure-Object -Average).Average
    return @{ MAE=$mae; MAE440=$mae440; MAE420=$mae420 }
}

$best = @{ MAE=999 }

for ($c0 = 0.0030; $c0 -le 0.0045; $c0 += 0.0003) {
    for ($ke = 0.0008; $ke -le 0.0011; $ke += 0.00005) {
        for ($kh = 0.0020; $kh -le 0.0080; $kh += 0.0010) {
            for ($kf = 0.0150; $kf -le 0.0450; $kf += 0.0050) {
                $r = Test-Parameters $c0 $ke 0.0045 0.0035 0.0021 $kh $kf
                if ($r.MAE -lt $best.MAE) {
                    $best.MAE = $r.MAE
                    $best.MAE440 = $r.MAE440
                    $best.MAE420 = $r.MAE420
                    $best.c0 = $c0
                    $best.ke = $ke
                    $best.kh = $kh
                    $best.kf = $kf
                }
            }
        }
    }
}

Write-Host "OPTIMAL RESULT FOR H <= 170MM:"
Write-Host ("  MAE Total: {0:F2} um (SCM440: {1:F2} um, SCM420: {2:F2} um)" -f $best.MAE, $best.MAE440, $best.MAE420)
Write-Host ("  C0 = {0:F5}, K_elec = {1:F5}" -f $best.c0, $best.ke)
Write-Host ("  K_h_confinement (Kho pha khe theo H) = {0:F5}" -f $best.kh)
Write-Host ("  K_flush_secondary (Thoat phoi kho gay danh lua thu cap) = {0:F5}" -f $best.kf)
