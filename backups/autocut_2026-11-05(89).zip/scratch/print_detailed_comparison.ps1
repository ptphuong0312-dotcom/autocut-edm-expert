# Print detailed comparison of every cut
$dataset = @(
    @{ id='1P-5P01'; grp='1P Quy doi 5P-01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110; desc='Chay P1 5P' },
    @{ id='STT 22';  grp='1P SCM420 chay L'; H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050; desc='Chay L chuan' },
    @{ id='STT 1';   grp='1P Chuan goc';     H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; desc='Chay to 0.034' },
    @{ id='STT 2';   grp='1P Chuan goc';     H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; desc='Chay to 0.034' },
    @{ id='STT 3';   grp='1P SCM420 chay';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; desc='Chay to 0.046' },
    @{ id='STT 18';  grp='1P SCM420 chay';   H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080; desc='Chay nho 0.010' },
    @{ id='STT 6';   grp='1P SCM440 chay L'; H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070; desc='Chay L chuan' },
    @{ id='STT 16';  grp='1P SCM420 coi';    H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220; desc='Coi to 0.040' },
    @{ id='1P-2P10'; grp='1P Quy doi 2P-10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125; desc='Coi P1 2P' },
    @{ id='STT 21';  grp='1P SCM420 coi';    H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280; desc='Coi chuan' },
    @{ id='STT 17';  grp='1P SCM440 coi';    H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235; desc='Coi lon 0.045' },
    @{ id='STT 19';  grp='1P SCM420 chay';   H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150; desc='Chay chuan' },
    @{ id='STT 7';   grp='1P SCM420 chay';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; desc='Chay chuan' },
    @{ id='STT 12';  grp='1P SCM420 chay';   H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120; desc='Chay to 0.036' },
    @{ id='STT 15';  grp='1P SCM420 coi';    H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300; desc='Coi to 0.026' },
    @{ id='1P-2P12'; grp='1P Quy doi 2P-12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225; desc='Coi P1 2P' }
)

$C0 = 0.00300
$K_elec = 0.00080
$d_low = 0.00450
$K_vf = 0.00210
$K_vibr = 0.00350
$K_h_confinement = 0.00800
$K_flush_secondary = 0.01500

Write-Host "=========================================================================================================================="
Write-Host "CHI TIET PHAN TICH: KHA NANG PHA KHE KHO THEO H VA THOAT PHOI KHO THEO H"
Write-Host "=========================================================================================================================="
Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2} | d_elec | d_h_lim | d_flush | delta_calc | delta_thuc | Sai lech" -f "STT", "H", "Thep", "Ton", "Po", "IP", "Volt", "VF")
Write-Host ("-" * 122)

foreach ($item in $dataset) {
    $H = $item.H
    $Ton = $item.Ton
    $Po = $item.Po
    $IP = $item.IP
    $Volt = $item.Volt
    $VF = $item.VF
    $mat = $item.mat
    $isHard = ($mat -eq 'SCM440' -or $mat -eq '30HRC')

    $u_ratio = if ($Volt -eq 'High' -or $Volt -eq 'H') { 1.0 } else { 22.0 / 27.0 }
    $d_elec = $K_elec * [Math]::Sqrt($Ton * $IP) * $u_ratio
    $d_low_val = if ($Volt -eq 'Low' -or $Volt -eq 'L') { $d_low } else { 0.0 }
    $d_vf_val = $K_vf * (($VF - 55.0) / 10.0)
    $d_vibr_val = $K_vibr * [Math]::Pow($H / 100.0, 2) * ($IP / 5.0)

    # 1. Khả năng phá khe khó theo H (Height Confinement)
    $d_h_confinement = - $K_h_confinement * [Math]::Pow($H / 100.0, 1.2)

    # 2. Thoát phoi khó & Đánh lửa thứ cấp theo H & Po
    $mat_factor = if ($isHard) { 1.0 } else { 1.30 }
    $po_defect = [Math]::Max(0.0, (8.5 - $Po) / 10.0)
    $d_flush_secondary = $K_flush_secondary * [Math]::Pow($H / 100.0, 1.5) * $po_defect * $mat_factor

    $calc_gap = $C0 + $d_elec + $d_low_val + $d_vf_val + $d_vibr_val + $d_h_confinement + $d_flush_secondary
    $diff = ($calc_gap - $item.actual) * 1000
    $sign = if ($diff -ge 0) { '+' } else { '' }

    Write-Host ("{0,-8} | {1,3}mm | {2,-6} | {3,3}/{4,2}/{5} | {6,-4}/{7,2} | {8,5:F1}  | {9,6:F1}  | {10,6:F1}  | {11,7:F1} um | {12,7:F1} um | {13,7} um" -f `
        $item.id, $H, $mat, $Ton, $Po, $IP, $Volt, $VF, ($d_elec*1000), ($d_h_confinement*1000), ($d_flush_secondary*1000), ($calc_gap*1000), ($item.actual*1000), ($sign + $diff.ToString("F1")))
}
