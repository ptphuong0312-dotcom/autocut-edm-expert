import math

dataset = [
    # name, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',  140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

C0 = 0.00360
K_ELEC = 0.00092
DELTA_LOW = 0.00450
K_SLAG = 0.02000
K_VIBR = 0.00390
K_VF = 0.00210
K_PO = 0.00120

# Secondary sparking parameters
K_SECONDARY = 0.00575
SLAG_THRESH = 0.306
SLAG_EXP = 0.84

def calc_new_gap(H, Ton, Po, IP, Volt, VF, mat):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    k_mat_sec = 1.0 if isHard else 1.18
    
    # Slag density index
    slag_idx = (Ton * IP / (Po * 30.0)) * (H / 100.0) * k_mat_sec
    d_sec = K_SECONDARY * math.pow(slag_idx - SLAG_THRESH, SLAG_EXP) if (H <= 170 and slag_idx > SLAG_THRESH) else 0.0
    
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
        d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
        d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = K_VF * ((VF - 55.0) / 10.0)
        d_po = - K_PO * ((Po - 5.0) / 10.0)
        return C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec, d_sec
    else:
        gap170 = C0 + (K_ELEC * math.sqrt(Ton * IP) * 1.0) + (- K_SLAG * 1.70 * sm / max(1.0, IP / 4.0)) + (K_VIBR * math.pow(1.70, 2) * (IP / 5.0))
        gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
        d_vf = K_VF * 0.5 * ((VF - 65.0) / 10.0)
        d_po = - K_PO * 0.5 * ((Po - 9.0) / 10.0)
        return gapBase + d_vf + d_po, 0.0

print(f"{'STT':<8} | {'H':>3} | {'Ton':>3} | {'Po':>2} | {'IP':>2} | {'mat':<6} | {'Actual_O1':>9} | {'New_O1_calc':>11} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 88)
errs = []
errs440 = []
errs420 = []
for r in dataset:
    name, H, Ton, Po, IP, Volt, VF, mat, act_gap, act_o1 = r
    gap, d_sec = calc_new_gap(H, Ton, Po, IP, Volt, VF, mat)
    calc_o1 = 0.090 + gap
    diff_um = (calc_o1 - act_o1) * 1000.0
    errs.append(abs(diff_um))
    if mat == 'SCM440':
        errs440.append(abs(diff_um))
    else:
        errs420.append(abs(diff_um))
    sign = '+' if diff_um >= 0 else ''
    print(f"{name:<8} | {H:>3} | {Ton:>3} | {Po:>2} | {IP:>2} | {mat:<6} | {act_o1:>9.4f} | {calc_o1:>11.4f} | {sign + f'{diff_um:.1f}':>10} | {d_sec*1000:>+10.2f}")

print("=" * 88)
print(f"Toàn cục 19 bài cắt: MAE = {sum(errs)/len(errs):.2f} um, Max Error = {max(errs):.2f} um")
print(f"SCM440 (n={len(errs440)}): MAE = {sum(errs440)/len(errs440):.2f} um")
print(f"SCM420 (n={len(errs420)}): MAE = {sum(errs420)/len(errs420):.2f} um")
