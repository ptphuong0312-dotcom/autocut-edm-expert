import math

dataset = [
    # name, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',  140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

# Let's test a targeted Secondary Sparking formulation:
# Secondary sparking occurs when debris generation rate exceeds flushing rate.
# The flushing deficit is: (Ton / (Po * 8)) * (H / 100)
# But in deep cuts H >= 140 with Po >= 9, flushing is assisted by servo slowdown.
# What if secondary sparking factor uses:
# S = (Ton * IP / (Po**1.5 * 10)) * (H / 100)

def test_config(c0, k_elec, k_slag, k_vibr, k_vf, k_po, k_sec, s_thresh=0.5):
    errs = []
    errs440 = []
    errs420 = []
    diffs = []
    
    for r in dataset:
        name, H, Ton, Po, IP, Volt, VF, mat, act_gap, act_o1 = r
        isHard = (mat == 'SCM440' or mat == '30HRC')
        sm = 1.0 if isHard else 0.80
        km = 1.0 if isHard else 1.20
        
        # Slag index: Notice Po in denominator
        # For H=75, Ton=55, Po=7, IP=4: (55*4 / (7**1.3 * 8)) * 0.75 * 1.20 = 1.88
        # For H=90, Ton=80, Po=7, IP=4: (80*4 / (7**1.3 * 8)) * 0.90 * 1.20 = 3.29
        # For H=140, Ton=120, Po=8, IP=5: (120*5 / (8**1.3 * 8)) * 1.40 * 1.20 = 8.5
        # To prevent H >= 140 from over-blowing, secondary sparking saturates or scales with (H/100) * exp(-H/200)
        # Physical saturation: the slot cannot widen past the sparking threshold!
        s_raw = (Ton * IP / (math.pow(Po, 1.3) * 15.0)) * (H / 100.0) * km
        # Saturation function: tanh or capped
        s_eff = math.tanh(s_raw / 2.0)
        if s_raw > s_thresh:
            d_sec = k_sec * (s_raw - s_thresh) / (1.0 + 0.3 * (H / 100.0)**2)
        else:
            d_sec = 0.0
            
        if H <= 170:
            u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
            d_elec = k_elec * math.sqrt(Ton * IP) * u_ratio
            d_low = 0.00450 if (Volt == 'Low' or Volt == 'L') else 0.0
            ip_fac = max(1.0, IP / 4.0)
            d_slag = - k_slag * (H / 100.0) * sm / ip_fac
            d_vibr = k_vibr * math.pow(H / 100.0, 2) * (IP / 5.0)
            d_vf = k_vf * ((VF - 55.0) / 10.0)
            d_po = - k_po * ((Po - 5.0) / 10.0)
            calc_gap = c0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec
        else:
            g170 = c0 + (k_elec * math.sqrt(Ton * IP) * 1.0) + (- k_slag * 1.70 * sm / max(1.0, IP / 4.0)) + (k_vibr * math.pow(1.70, 2) * (IP / 5.0)) + d_sec
            calc_gap = g170 + (H - 170) * (0.0250 - g170) / (300 - 170)
            calc_gap += k_vf * 0.5 * ((VF - 65.0) / 10.0) - k_po * 0.5 * ((Po - 9.0) / 10.0)
            
        diff_um = (calc_gap - act_gap) * 1000.0
        errs.append(abs(diff_um))
        if isHard:
            errs440.append(abs(diff_um))
        else:
            errs420.append(abs(diff_um))
        diffs.append((name, H, mat, act_gap*1000, calc_gap*1000, diff_um, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    mae440 = sum(errs440) / len(errs440)
    mae420 = sum(errs420) / len(errs420)
    max_e = max(errs)
    return mae, mae440, mae420, max_e, diffs

import random
random.seed(123)

best_mae = 999.0
best_cfg = None

for _ in range(30000):
    c0 = random.uniform(0.0032, 0.0042)
    k_elec = random.uniform(0.00080, 0.00105)
    k_slag = random.uniform(0.015, 0.025)
    k_vibr = random.uniform(0.0030, 0.0045)
    k_vf = random.uniform(0.0018, 0.0024)
    k_po = random.uniform(0.0008, 0.0015)
    k_sec = random.uniform(0.003, 0.012)
    s_thresh = random.uniform(0.3, 0.8)
    
    mae, mae440, mae420, max_e, diffs = test_config(c0, k_elec, k_slag, k_vibr, k_vf, k_po, k_sec, s_thresh)
    
    # Combined score
    score = mae + 0.35 * max_e + 0.3 * mae440
    if score < best_mae:
        best_mae = score
        best_cfg = (c0, k_elec, k_slag, k_vibr, k_vf, k_po, k_sec, s_thresh, mae, mae440, mae420, max_e, diffs)

c0, k_elec, k_slag, k_vibr, k_vf, k_po, k_sec, s_thresh, mae, mae440, mae420, max_e, diffs = best_cfg
print("FOUND OPTIMAL CONFIGURATION:")
print(f"C0 = {c0:.5f}, K_ELEC = {k_elec:.5f}, K_SLAG = {k_slag:.5f}, K_VIBR = {k_vibr:.5f}")
print(f"K_VF = {k_vf:.5f}, K_PO = {k_po:.5f}, K_SEC = {k_sec:.5f}, S_THRESH = {s_thresh:.3f}")
print(f"MAE toàn cục: {mae:.2f} um  (Gốc: 6.00 um)")
print(f"MAE SCM440:   {mae440:.2f} um  (Gốc: 3.71 um)")
print(f"MAE SCM420:   {mae420:.2f} um  (Gốc: 8.06 um)")
print(f"Max Error:    {max_e:.2f} um  (Gốc: 20.27 um)")
print("\n" + "=" * 80)
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 80)
for d in diffs:
    sign = '+' if d[5] >= 0 else ''
    print(f"{d[0]:<8} | {d[1]:>3} | {d[2]:<6} | {d[3]:>7.1f} | {d[4]:>7.1f} | {sign + f'{d[5]:.1f}':>10} | {d[6]:>+10.1f}")
