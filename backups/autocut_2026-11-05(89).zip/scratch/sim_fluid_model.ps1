# Combined Physical Model: Height Breakdown Limit & Slag Flushing Dynamics
$dataset = @(
    @{ id='1P-5P01'; H=12;  Ton=20;  Po=5;  IP=3; Volt='High'; VF=65; mat='SCM440'; actual=0.0110; I=3.2 },
    @{ id='STT 22';  H=12;  Ton=16;  Po=6;  IP=3; Volt='Low';  VF=60; mat='SCM420'; actual=0.0050; I=2.6 },
    @{ id='STT 1';   H=30;  Ton=32;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 2';   H=40;  Ton=36;  Po=5;  IP=4; Volt='High'; VF=65; mat='SCM440'; actual=0.0080; I=4.4 },
    @{ id='STT 3';   H=63;  Ton=44;  Po=7;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=4.1 },
    @{ id='STT 18';  H=63;  Ton=44;  Po=8;  IP=4; Volt='High'; VF=57; mat='SCM420'; actual=0.0080; I=3.3 },
    @{ id='STT 6';   H=68;  Ton=70;  Po=7;  IP=3; Volt='Low';  VF=50; mat='SCM440'; actual=0.0070; I=2.5 },
    @{ id='STT 16';  H=75;  Ton=55;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0220; I=3.4 },
    @{ id='1P-2P10'; H=85;  Ton=70;  Po=8;  IP=5; Volt='High'; VF=61; mat='SCM440'; actual=0.0125; I=3.6 },
    @{ id='STT 21';  H=90;  Ton=80;  Po=7;  IP=4; Volt='High'; VF=54; mat='SCM420'; actual=0.0280; I=3.5 },
    @{ id='STT 17';  H=95;  Ton=82;  Po=7;  IP=4; Volt='High'; VF=55; mat='SCM440'; actual=0.0235; I=3.6 },
    @{ id='STT 19';  H=110; Ton=100; Po=10; IP=5; Volt='High'; VF=65; mat='SCM420'; actual=0.0150; I=2.7 },
    @{ id='STT 7';   H=140; Ton=120; Po=8;  IP=5; Volt='High'; VF=55; mat='SCM420'; actual=0.0050; I=3.6 },
    @{ id='STT 12';  H=140; Ton=100; Po=9;  IP=6; Volt='High'; VF=60; mat='SCM420'; actual=0.0120; I=3.8 },
    @{ id='STT 15';  H=160; Ton=120; Po=11; IP=6; Volt='High'; VF=70; mat='SCM420'; actual=0.0300; I=2.9 },
    @{ id='1P-2P12'; H=165; Ton=135; Po=11; IP=6; Volt='High'; VF=70; mat='SCM440'; actual=0.0225; I=2.9 }
)

function Sim-Model($C0, $K_elec, $K_h_confinement, $K_secondary) {
    $errors = @()
    $err440 = @()
    $err420 = @()

    foreach ($it in $dataset) {
        $isHard = ($it.mat -eq 'SCM440')
        $u_ratio = if ($it.Volt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $K_elec * [Math]::Sqrt($it.Ton * $it.IP) * $u_ratio
        $d_low = if ($it.Volt -eq 'Low') { 0.00450 } else { 0.0 }
        $d_vf = 0.00210 * (($it.VF - 55.0) / 10.0)
        $d_vibr = 0.00350 * [Math]::Pow($it.H / 100.0, 2) * ($it.IP / 5.0)

        # 1. Khả năng phá khe suy giảm theo H (Height Confinement)
        $d_conf = - $K_h_confinement * ($it.H / 100.0)

        # 2. Mật độ tích tụ xỉ & Đánh lửa thứ cấp do khó thoát phoi
        $rho = ($it.I / ($it.Po + 2.0)) * ($it.H / 100.0)
        $mat_k = if ($isHard) { 1.0 } else { 1.25 }
        $d_sec = $K_secondary * [Math]::Pow($rho, 1.8) * $mat_k

        $calc = $C0 + $d_elec + $d_low + $d_vf + $d_vibr + $d_conf + $d_sec
        $diff = [Math]::Abs($calc - $it.actual) * 1000
        $errors += $diff
        if ($isHard) { $err440 += $diff } else { $err420 += $diff }
    }

    $mae = ($errors | Measure-Object -Average).Average
    $mae440 = ($err440 | Measure-Object -Average).Average
    $mae420 = ($err420 | Measure-Object -Average).Average
    return @{ MAE=$mae; MAE440=$mae440; MAE420=$mae420 }
}

$opt = @{ MAE=999 }
for ($c = 0.0025; $c -le 0.0045; $c += 0.0003) {
    for ($ke = 0.0007; $ke -le 0.0011; $ke += 0.00005) {
        for ($kh = 0.0030; $kh -le 0.0150; $kh += 0.0010) {
            for ($ks = 0.0300; $ks -le 0.1200; $ks += 0.0100) {
                $r = Sim-Model $c $ke $kh $ks
                if ($r.MAE -lt $opt.MAE) {
                    $opt.MAE = $r.MAE
                    $opt.MAE440 = $r.MAE440
                    $opt.MAE420 = $r.MAE420
                    $opt.c = $c
                    $opt.ke = $ke
                    $opt.kh = $kh
                    $opt.ks = $ks
                }
            }
        }
    }
}

Write-Host "OPTIMAL PHYSICAL FLUID MODEL:"
Write-Host ("  MAE Total: {0:F2} um (SCM440: {1:F2} um, SCM420: {2:F2} um)" -f $opt.MAE, $opt.MAE440, $opt.MAE420)
Write-Host ("  C0 = {0:F5}, K_elec = {1:F5}" -f $opt.c, $opt.ke)
Write-Host ("  K_h_confinement = {0:F5}" -f $opt.kh)
Write-Host ("  K_secondary = {0:F5}" -f $opt.ks)
