function Simulate-Tab2($H, $isHard, $stratLvl = 4) {
    $baseVolt = if ($H -le 15) { 'Low' } else { 'High' }
    
    if ($H -le 170) {
        if ($isHard) {
            if ($H -le 15) { $baseTon = [Math]::Round(16 + ($H - 5) * (20 - 16) / (15 - 5)) }
            elseif ($H -le 30) { $baseTon = [Math]::Round(20 + ($H - 15) * (32 - 20) / (30 - 15)) }
            elseif ($H -le 60) { $baseTon = [Math]::Round(32 + ($H - 30) * (50 - 32) / (60 - 30)) }
            elseif ($H -le 100) { $baseTon = [Math]::Round(50 + ($H - 60) * (82 - 50) / (100 - 60)) }
            elseif ($H -le 140) { $baseTon = [Math]::Round(82 + ($H - 100) * (120 - 82) / (140 - 100)) }
            elseif ($H -le 165) { $baseTon = [Math]::Round(120 + ($H - 140) * (135 - 120) / (165 - 140)) }
            else { $baseTon = 135 }
        } else {
            if ($H -le 15) { $baseTon = [Math]::Round(14 + ($H - 5) * (18 - 14) / (15 - 5)) }
            elseif ($H -le 30) { $baseTon = [Math]::Round(18 + ($H - 15) * (28 - 18) / (30 - 15)) }
            elseif ($H -le 60) { $baseTon = [Math]::Round(28 + ($H - 30) * (44 - 28) / (60 - 30)) }
            elseif ($H -le 100) { $baseTon = [Math]::Round(44 + ($H - 60) * (72 - 44) / (100 - 60)) }
            elseif ($H -le 140) { $baseTon = [Math]::Round(72 + ($H - 100) * (110 - 72) / (140 - 100)) }
            else { $baseTon = 120 }
        }

        if ($H -le 15) { $baseIP = 3; $basePo = 6 }
        elseif ($H -le 30) { $baseIP = 3; $basePo = 7 }
        elseif ($H -le 60) { $baseIP = 4; $basePo = 8 }
        elseif ($H -le 100) { $baseIP = 4; $basePo = 7 }
        else {
            if ($H -le 120) { $baseIP = 5; $basePo = 8 }
            elseif ($H -le 140) { $baseIP = 5; $basePo = 9 }
            elseif ($H -le 155) { $baseIP = 6; $basePo = 10 }
            else { $baseIP = 6; $basePo = 11 }
        }

        $vfMax = if ($isHard) { 65 } else { 60 }
        $vfMin = if ($isHard) { 55 } else { 50 }
        if ($H -le 40) { $baseVF = $vfMax }
        elseif ($H -le 100) { $baseVF = [Math]::Round($vfMax - ($H - 40) * ($vfMax - $vfMin) / (100 - 40)) }
        elseif ($H -le 160) { $baseVF = [Math]::Round($vfMin + ($H - 100) * (70 - $vfMin) / (160 - 100)) }
        else { $baseVF = 70 }

        $C0 = 0.00280
        $K_ELEC = 0.00100
        $DELTA_LOW = 0.00450
        $K_SLAG = 0.02300
        $K_VIBR = 0.00390
        
        $u_ratio = if ($baseVolt -eq 'High') { 1.0 } else { 22.0 / 27.0 }
        $d_elec = $K_ELEC * [Math]::Sqrt($baseTon * $baseIP) * $u_ratio
        $d_low = if ($baseVolt -eq 'Low') { $DELTA_LOW } else { 0.0 }
        $ip_fac = [Math]::Max(1.0, $baseIP / 4.0)
        $d_slag = - $K_SLAG * ($H / 100.0) / $ip_fac
        $d_vibr = $K_VIBR * [Math]::Pow($H / 100.0, 2) * ($baseIP / 5.0)
        $gap = $C0 + $d_elec + $d_low + $d_slag + $d_vibr

    } else {
        $baseTon = if ($isHard) { 135 } else { 120 }
        $baseIP = 6
        $basePo = [Math]::Round(11 + ($H - 170) * (12 - 11) / (300 - 170))
        $baseVF = [Math]::Min(72, [Math]::Round(70 + ($H - 170) * (72 - 70) / (300 - 170)))
        $gap = 0.0187 + ($H - 170) * (0.0250 - 0.0187) / (300 - 170)
    }

    $O1 = 0.090 + $gap
    $duty = 1.0 / ($basePo + 2)
    $u_arc = if ($baseVolt -eq 'Low') { 22 } else { 27 }
    $i_peak = $baseIP * 2.8
    $ampe = $i_peak * $duty * 2.6667 * ($u_arc / 27)

    return @{
        H = $H; isHard = $isHard; Ton = $baseTon; Po = $basePo; IP = $baseIP;
        Volt = $baseVolt; VF = $baseVF; gap = $gap; O1 = $O1; ampe = $ampe
    }
}

Write-Output "=== SIMULATION TAB 2 ==="
$testH = @(10, 12, 20, 30, 40, 50, 60, 63, 75, 85, 90, 95, 100, 110, 120, 140, 160, 165, 200, 290, 300)
Write-Output "--- SCM440 (28-32 HRC) ---"
foreach ($h in $testH) {
    $res = Simulate-Tab2 $h $true
    Write-Output ("H={0,3}mm Ton={1,3} Po={2,2} IP={3} Volt={4,-4} VF={5,2} -> Gap={6,5:F1}um O1={7:F4} Ampe={8,3:F1}A" -f $h, $res.Ton, $res.Po, $res.IP, $res.Volt, $res.VF, ($res.gap*1000), $res.O1, $res.ampe)
}

Write-Output ""
Write-Output "--- SCM420 (HB < 200) ---"
foreach ($h in $testH) {
    $res = Simulate-Tab2 $h $false
    Write-Output ("H={0,3}mm Ton={1,3} Po={2,2} IP={3} Volt={4,-4} VF={5,2} -> Gap={6,5:F1}um O1={7:F4} Ampe={8,3:F1}A" -f $h, $res.Ton, $res.Po, $res.IP, $res.Volt, $res.VF, ($res.gap*1000), $res.O1, $res.ampe)
}
