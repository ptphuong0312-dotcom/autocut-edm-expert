import os
import re

ws = r"d:\OneDrive\Antigravity\Cat_Day_EDM"

# 1. Update app.js
app_path = os.path.join(ws, "app.js")
with open(app_path, "r", encoding="utf-8") as f:
    app_js = f.read()

# 1.1 Add K_SEC and S_THRESH to generateWorkshopRows
target_consts = """        const K_PO = 0.00120;        // Hệ số chu kỳ & xả xỉ Po (mm / 10 nấc Po lệch so với chuẩn 5)
        const slag_mat = isHard ? 1.0 : 0.80; // SCM420 phoi bết dính nhưng cào thoáng hơn (+1.8 - 4μm), giảm độ ghìm xỉ"""

repl_consts = """        const K_PO = 0.00120;        // Hệ số chu kỳ & xả xỉ Po (mm / 10 nấc Po lệch so với chuẩn 5)
        const K_SEC = 0.00400;       // Hệ số đánh lửa thứ cấp theo mật độ mùn xỉ tích tụ (mm)
        const S_THRESH = 0.20;       // Ngưỡng mật độ mùn xỉ kích hoạt đánh lửa thứ cấp
        const slag_mat = isHard ? 1.0 : 0.80; // SCM420 phoi bết dính nhưng cào thoáng hơn (+1.8 - 4μm), giảm độ ghìm xỉ"""

assert target_consts in app_js, "Target consts not found in app.js"
app_js = app_js.replace(target_consts, repl_consts, 1)

# 1.2 Update baseGap calculation
target_basegap = """            const d_vf_base = K_VF * ((baseVF - 55.0) / 10.0);
            const d_po_base = - K_PO * ((basePo - 5.0) / 10.0);
            baseGap = C0 + d_elec_base + d_low_base + d_slag_base + d_vibr_base + d_vf_base + d_po_base;"""

repl_basegap = """            const d_vf_base = K_VF * ((baseVF - 55.0) / 10.0);
            const d_po_base = - K_PO * ((basePo - 5.0) / 10.0);
            const s_mat_base = isHard ? 1.0 : 1.25;
            const s_raw_base = ((baseTon * baseIP) / (basePo * 25.0)) * (H / 100.0) * s_mat_base;
            const d_sec_base = s_raw_base > S_THRESH ? (K_SEC * (s_raw_base - S_THRESH)) / (1.0 + 1.5 * Math.pow(H / 100.0, 2)) : 0.0;
            baseGap = C0 + d_elec_base + d_low_base + d_slag_base + d_vibr_base + d_vf_base + d_po_base + d_sec_base;"""

assert target_basegap in app_js, "Target basegap not found in app.js"
app_js = app_js.replace(target_basegap, repl_basegap, 1)

# 1.3 Update gap calculation
target_gap = """            const d_vf_actual = K_VF * ((VF - 55.0) / 10.0);
            const d_po_actual = - K_PO * ((Po - 5.0) / 10.0);
            gap = C0 + d_elec_actual + d_low_actual + d_slag_actual + d_vibr_actual + d_vf_actual + d_po_actual;"""

repl_gap = """            const d_vf_actual = K_VF * ((VF - 55.0) / 10.0);
            const d_po_actual = - K_PO * ((Po - 5.0) / 10.0);
            const s_mat_actual = isHard ? 1.0 : 1.25;
            const s_raw_actual = ((Ton * IP) / (Po * 25.0)) * (H / 100.0) * s_mat_actual;
            const d_sec_actual = s_raw_actual > S_THRESH ? (K_SEC * (s_raw_actual - S_THRESH)) / (1.0 + 1.5 * Math.pow(H / 100.0, 2)) : 0.0;
            gap = C0 + d_elec_actual + d_low_actual + d_slag_actual + d_vibr_actual + d_vf_actual + d_po_actual + d_sec_actual;"""

assert target_gap in app_js, "Target gap not found in app.js"
app_js = app_js.replace(target_gap, repl_gap, 1)

# 1.4 Update CURRENT_VERSION
target_ver = 'const CURRENT_VERSION = "3.5.52";'
repl_ver = 'const CURRENT_VERSION = "3.5.53";'
assert target_ver in app_js, "Target version not found in app.js"
app_js = app_js.replace(target_ver, repl_ver, 1)

# 1.5 Update Tab 3 constants
target_tab3_consts = """    const VF_K_VF = 0.00210;        // Hệ số bù trễ bước tiến VF (+2.10 μm / 10 vạch VF so với chuẩn 55)
    const VF_K_PO = 0.00120;        // Hệ số chu kỳ & xả xỉ Po (mm / 10 nấc Po lệch so với chuẩn 5)"""

repl_tab3_consts = """    const VF_K_VF = 0.00210;        // Hệ số bù trễ bước tiến VF (+2.10 μm / 10 vạch VF so với chuẩn 55)
    const VF_K_PO = 0.00120;        // Hệ số chu kỳ & xả xỉ Po (mm / 10 nấc Po lệch so với chuẩn 5)
    const VF_K_SEC = 0.00400;       // Hệ số đánh lửa thứ cấp theo mật độ mùn xỉ tích tụ (mm)
    const VF_S_THRESH = 0.20;       // Ngưỡng mật độ mùn xỉ kích hoạt đánh lửa thứ cấp"""

assert target_tab3_consts in app_js, "Target Tab 3 consts not found in app.js"
app_js = app_js.replace(target_tab3_consts, repl_tab3_consts, 1)

# 1.6 Update calcBaseSparkGap
target_base_fn = """        if (H <= 170) {
            // Phân vùng 1 (H <= 170mm): Phương trình liên tục thuần túy
            d_vibr = VF_K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);
            gap = VF_C0 + d_elec + d_low + d_slag + d_vibr;
        } else {
            // Phân vùng 2 (H > 170mm): Đồng bộ Kiến trúc Phân vùng Kép Rule 17 (Hội tụ xưởng về 0.1150mm tại H=300mm)
            const gap170 = VF_C0 + d_elec + d_low + (- VF_K_SLAG * 1.70 * slag_mat / ip_fac) + (VF_K_VIBR * Math.pow(1.70, 2) * (IP / 5.0));
            const targetGap300 = 0.0250;
            gap = gap170 + (H - 170) * (targetGap300 - gap170) / (300 - 170);
            d_vibr = gap - (VF_C0 + d_elec + d_low + d_slag);
        }

        return {
            c0: VF_C0,
            u_ratio: u_ratio,
            d_elec: d_elec,
            d_low: d_low,
            d_slag: d_slag,
            d_vibr: d_vibr,
            gap: gap,
            offset: 0.090 + gap,
            kerf: 0.180 + 2.0 * gap
        };"""

repl_base_fn = """        let d_sec;
        if (H <= 170) {
            // Phân vùng 1 (H <= 170mm): Phương trình liên tục thuần túy
            d_vibr = VF_K_VIBR * Math.pow(H / 100.0, 2) * (IP / 5.0);
            const s_mat = isHard ? 1.0 : 1.25;
            const s_raw = ((Ton * IP) / (5.0 * 25.0)) * (H / 100.0) * s_mat; // Po chuẩn = 5
            d_sec = s_raw > VF_S_THRESH ? (VF_K_SEC * (s_raw - VF_S_THRESH)) / (1.0 + 1.5 * Math.pow(H / 100.0, 2)) : 0.0;
            gap = VF_C0 + d_elec + d_low + d_slag + d_vibr + d_sec;
        } else {
            // Phân vùng 2 (H > 170mm): Đồng bộ Kiến trúc Phân vùng Kép Rule 17 (Hội tụ xưởng về 0.1150mm tại H=300mm)
            const gap170 = VF_C0 + d_elec + d_low + (- VF_K_SLAG * 1.70 * slag_mat / ip_fac) + (VF_K_VIBR * Math.pow(1.70, 2) * (IP / 5.0));
            const targetGap300 = 0.0250;
            gap = gap170 + (H - 170) * (targetGap300 - gap170) / (300 - 170);
            d_vibr = gap - (VF_C0 + d_elec + d_low + d_slag);
            d_sec = 0.0;
        }

        return {
            c0: VF_C0,
            u_ratio: u_ratio,
            d_elec: d_elec,
            d_low: d_low,
            d_slag: d_slag,
            d_vibr: d_vibr,
            d_sec: d_sec,
            gap: gap,
            offset: 0.090 + gap,
            kerf: 0.180 + 2.0 * gap
        };"""

assert target_base_fn in app_js, "Target base_fn not found in app.js"
app_js = app_js.replace(target_base_fn, repl_base_fn, 1)

# 1.7 Update calcVFSparkGap
target_vf_fn = """    function calcVFSparkGap(H, Ton, IP, Volt, VF, Po = 5, material = 'SCM440') {
        const base = calcBaseSparkGap(H, Ton, IP, Volt, material);
        let d_vf, d_po;
        if (H <= 170) {
            d_vf = VF_K_VF * ((VF - 55.0) / 10.0);
            d_po = - VF_K_PO * ((Po - 5.0) / 10.0);
        } else {
            // Ở phôi siêu dày H > 170mm, chuẩn xưởng là VF=65, Po=9
            d_vf = VF_K_VF * 0.5 * ((VF - 65.0) / 10.0);
            d_po = - VF_K_PO * 0.5 * ((Po - 9.0) / 10.0);
        }
        const gap_vf = base.gap + d_vf + d_po;
        const diff_um = (d_vf + d_po) * 1000.0;"""

repl_vf_fn = """    function calcVFSparkGap(H, Ton, IP, Volt, VF, Po = 5, material = 'SCM440') {
        const base = calcBaseSparkGap(H, Ton, IP, Volt, material);
        let d_vf, d_po, d_sec_vf;
        const isHard = (material === 'SCM440' || material === '30HRC');
        const s_mat = isHard ? 1.0 : 1.25;

        if (H <= 170) {
            d_vf = VF_K_VF * ((VF - 55.0) / 10.0);
            d_po = - VF_K_PO * ((Po - 5.0) / 10.0);
            const s_raw_vf = ((Ton * IP) / (Math.max(1, Po) * 25.0)) * (H / 100.0) * s_mat;
            d_sec_vf = s_raw_vf > VF_S_THRESH ? (VF_K_SEC * (s_raw_vf - VF_S_THRESH)) / (1.0 + 1.5 * Math.pow(H / 100.0, 2)) : 0.0;
        } else {
            // Ở phôi siêu dày H > 170mm, chuẩn xưởng là VF=65, Po=9
            d_vf = VF_K_VF * 0.5 * ((VF - 65.0) / 10.0);
            d_po = - VF_K_PO * 0.5 * ((Po - 9.0) / 10.0);
            d_sec_vf = 0.0;
        }
        const gap_vf = base.c0 + base.d_elec + base.d_low + base.d_slag + base.d_vibr + d_vf + d_po + d_sec_vf;
        const diff_um = (gap_vf - base.gap) * 1000.0;"""

assert target_vf_fn in app_js, "Target vf_fn not found in app.js"
app_js = app_js.replace(target_vf_fn, repl_vf_fn, 1)

# Add d_sec_vf to calcVFSparkGap return object:
target_vf_return = """        return {
            ...base,
            Po: Po,"""

repl_vf_return = """        return {
            ...base,
            Po: Po,
            d_sec_vf: d_sec_vf,"""

assert target_vf_return in app_js, "Target vf_return not found in app.js"
app_js = app_js.replace(target_vf_return, repl_vf_return, 1)

# 1.8 Add d_sec_vf insight text in renderResearchVF
target_insight = """            if (res.d_low > 0) {
                insightHtml += '<br><strong>🔹 Chế độ Volt Low (22V):</strong> Bổ sung màng điện môi êm dịu $+4.50\\\\,\\\\mu\\\\text{m}$, bảo toàn kích thước không bị hụt khi cắt hạ áp.';
            }"""

repl_insight = """            if (res.d_sec_vf > 0.0005) {
                insightHtml += '<br><strong>🔥 Đánh lửa thứ cấp do nén mùn xỉ (+' + (res.d_sec_vf * 1000).toFixed(2) + ' μm):</strong> Khe hẹp tích tụ mùn xỉ kích nổ phóng điện vách phụ, hệ thống đã tự động bù vào Offset để triệt tiêu sai số âm.';
            }

            if (res.d_low > 0) {
                insightHtml += '<br><strong>🔹 Chế độ Volt Low (22V):</strong> Bổ sung màng điện môi êm dịu $+4.50\\\\,\\\\mu\\\\text{m}$, bảo toàn kích thước không bị hụt khi cắt hạ áp.';
            }"""

assert target_insight in app_js, "Target insight not found in app.js"
app_js = app_js.replace(target_insight, repl_insight, 1)

# 1.9 Add d_sec breakdown row in vf-breakdown-tbody
target_tbody_row = """                <tr>
                    <td><strong>d<sub>vibr</sub></strong> (Rung uốn cơ học dây Moly)</td>
                    <td>${H <= 170 ? 'Xung lực nổ plasma làm võng dây: K_vibr &times; (H/100)² &times; (IP/5)' : 'Kiến trúc Phân vùng Kép Rule 17: Hội tụ êm về chuẩn xưởng 0.1150 mm'}</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="background: rgba(245, 158, 11, 0.08); border-top: 1px dashed var(--accent-amber);">"""

repl_tbody_row = """                <tr>
                    <td><strong>d<sub>vibr</sub></strong> (Rung uốn cơ học dây Moly)</td>
                    <td>${H <= 170 ? 'Xung lực nổ plasma làm võng dây: K_vibr &times; (H/100)² &times; (IP/5)' : 'Kiến trúc Phân vùng Kép Rule 17: Hội tụ êm về chuẩn xưởng 0.1150 mm'}</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--border-highlight);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: var(--accent-amber);">+${(res.d_vibr * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="background: rgba(244, 63, 94, 0.06);">
                    <td><strong style="color: #f43f5e;">d<sub>sec</sub></strong> (Đánh lửa thứ cấp do nén mùn xỉ)</td>
                    <td>Mùn xỉ nén rãnh hẹp kích nổ phóng điện vách phụ: K<sub>sec</sub> &times; (S - S<sub>th</sub>)/(1 + 1.5&times;(H/100)²)</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e;">+${(res.d_sec * 1000).toFixed(2)} μm</td>
                    <td style="text-align: right; font-family: var(--font-mono); color: #f43f5e; font-weight: 700;">+${(res.d_sec_vf * 1000).toFixed(2)} μm</td>
                </tr>
                <tr style="background: rgba(245, 158, 11, 0.08); border-top: 1px dashed var(--accent-amber);">"""

assert target_tbody_row in app_js, "Target tbody_row not found in app.js"
app_js = app_js.replace(target_tbody_row, repl_tbody_row, 1)

# 1.10 Update WS_LIB_BENCHMARK_JOBS[1] calcOffset values
# Old values:
lib_replacements = [
    ('calcOffset: "0,1010"', 'calcOffset: "0,1005"'),  # 5P-01
    ('calcOffset: "0,1027"', 'calcOffset: "0,1023"'),  # STT 22
    ('calcOffset: "0,1012"', 'calcOffset: "0,1008"'),  # STT 1
    # STT 2 stays "0,1001"
    ('calcOffset: "0,1016"', 'calcOffset: "0,1025"'),  # STT 3
    ('calcOffset: "0,0980"', 'calcOffset: "0,0983"'),  # STT 18
    ('calcOffset: "0,0960"', 'calcOffset: "0,0966"'),  # STT 6
    ('calcOffset: "0,0976"', 'calcOffset: "0,0987"'),  # STT 16
    ('calcOffset: "0,1023"', 'calcOffset: "0,1034"'),  # 2P-10
    ('calcOffset: "0,0991"', 'calcOffset: "0,1011"'),  # STT 21
    ('calcOffset: "0,0952"', 'calcOffset: "0,0965"'),  # STT 17
    ('calcOffset: "0,1080"', 'calcOffset: "0,1099"'),  # STT 19
    ('calcOffset: "0,1074"', 'calcOffset: "0,1106"'),  # STT 7
    ('calcOffset: "0,1128"', 'calcOffset: "0,1155"'),  # STT 12
    ('calcOffset: "0,1177"', 'calcOffset: "0,1198"'),  # STT 15
    ('calcOffset: "0,1151"', 'calcOffset: "0,1166"'),  # 2P-12
    ('calcOffset: "0,1102"', 'calcOffset: "0,1139"'),  # STT 23
    ('calcOffset: "0,1145"', 'calcOffset: "0,1157"'),  # STT 20
    # STT 14 stays "0,1150"
]

for old_val, new_val in lib_replacements:
    assert old_val in app_js, f"Could not find {old_val} in app.js"
    app_js = app_js.replace(old_val, new_val, 1)

with open(app_path, "w", encoding="utf-8") as f:
    f.write(app_js)
print("[OK] app.js updated successfully")

# 2. Update version.json
ver_path = os.path.join(ws, "version.json")
import json
with open(ver_path, "r", encoding="utf-8") as f:
    vdata = json.load(f)

vdata["version"] = "3.5.53"
vdata["releaseDate"] = "2026-11-05"
vdata["description"] = "Tích hợp tham số vật lý Đánh lửa thứ cấp theo Mật độ mùn xỉ (d_sec) vào Tab 2 & Tab 3; giảm sai số cực đại toàn cục xưởng từ 20.3 μm xuống 17.0 μm; tối ưu độ chính xác phôi dày H75-H165."

with open(ver_path, "w", encoding="utf-8") as f:
    json.dump(vdata, f, ensure_ascii=False, indent=2)
print("[OK] version.json updated to v3.5.53")

# 3. Update sw.js
sw_path = os.path.join(ws, "sw.js")
with open(sw_path, "r", encoding="utf-8") as f:
    sw_js = f.read()

sw_js = sw_js.replace("autocut-v3.5.52", "autocut-v3.5.53", 1)
with open(sw_path, "w", encoding="utf-8") as f:
    f.write(sw_js)
print("[OK] sw.js updated to autocut-v3.5.53")

# 4. Update index.html
html_path = os.path.join(ws, "index.html")
with open(html_path, "r", encoding="utf-8") as f:
    index_html = f.read()

index_html = index_html.replace("style.css?v=3.5.52", "style.css?v=3.5.53", 1)
index_html = index_html.replace("app.js?v=3.5.52", "app.js?v=3.5.53", 1)
index_html = index_html.replace(
    "v3.5.52 (Tách Biệt &amp; Hiệu Chuẩn Lại Tab 2 Thép SCM420 vs SCM440)",
    "v3.5.53 (Tích Hợp Đánh Lửa Thứ Cấp Theo Mật Độ Mùn Xỉ)",
    1
)
with open(html_path, "w", encoding="utf-8") as f:
    f.write(index_html)
print("[OK] index.html updated to v3.5.53")

# 5. Update scripts/audit_spark_gap.py
audit_path = os.path.join(ws, "scripts", "audit_spark_gap.py")
with open(audit_path, "r", encoding="utf-8") as f:
    audit_py = f.read()

target_audit_calc = """def calc_gap(H, Ton, Po, IP, Volt, VF, mat='SCM440'):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
        d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
        d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = K_VF * ((VF - 55.0) / 10.0)
        d_po = - K_PO * ((Po - 5.0) / 10.0)
        return C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po"""

repl_audit_calc = """K_SEC = 0.00400
S_THRESH = 0.20

def calc_gap(H, Ton, Po, IP, Volt, VF, mat='SCM440'):
    isHard = (mat == 'SCM440' or mat == '30HRC')
    sm = 1.0 if isHard else 0.80
    km = 1.0 if isHard else 1.25
    if H <= 170:
        u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
        d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
        d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
        ip_fac = max(1.0, IP / 4.0)
        d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
        d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
        d_vf = K_VF * ((VF - 55.0) / 10.0)
        d_po = - K_PO * ((Po - 5.0) / 10.0)
        
        s_raw = ((Ton * IP) / (Po * 25.0)) * (H / 100.0) * km
        d_sec = (K_SEC * (s_raw - S_THRESH)) / (1.0 + 1.5 * math.pow(H / 100.0, 2)) if s_raw > S_THRESH else 0.0
        return C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec"""

audit_py = audit_py.replace("v3.5.52", "v3.5.53")
assert target_audit_calc in audit_py, "Target audit calc not found in audit_spark_gap.py"
audit_py = audit_py.replace(target_audit_calc, repl_audit_calc, 1)

with open(audit_path, "w", encoding="utf-8") as f:
    f.write(audit_py)
print("[OK] scripts/audit_spark_gap.py updated to v3.5.53 with d_sec")
