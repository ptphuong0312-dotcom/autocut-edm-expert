$path = "app.js"
$lines = [IO.File]::ReadAllLines($path, [Text.Encoding]::UTF8)
for ($i = 2450; $i -lt 2465; $i++) {
    if ($lines[$i].Trim() -eq "}" -and $lines[$i-1].Trim() -eq "" -and $lines[$i-3].Contains("Đã loại bỏ hệ số ghìm tiến")) {
        Write-Host "Found extra brace at line ${i}"
        $lines[$i] = "                // (ghim tien removed)"
        break
    }
}
[IO.File]::WriteAllLines($path, $lines, [Text.Encoding]::UTF8)
Write-Host "Fixed brace!"
