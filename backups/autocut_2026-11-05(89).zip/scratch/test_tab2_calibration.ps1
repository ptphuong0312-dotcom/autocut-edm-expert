# Phân tích dữ liệu thực nghiệm xưởng cho 2 nhóm vật liệu
# SCM420 (HB < 200) và SCM440 (28-32 HRC)

$scm420_jobs = @(
    @{ id = "STT 22";  H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; Hz = 150; actualOffset = 0.0950; delta = 0.0050; actualAmpe = 2.6 },
    @{ id = "STT 3";   H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; Hz = 150; actualOffset = 0.0950; delta = 0.0050; actualAmpe = 4.15 },
    @{ id = "STT 18";  H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; Hz = 150; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 3.35 },
    @{ id = "STT 16";  H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; Hz = 187; actualOffset = 0.1120; delta = 0.0220; actualAmpe = 3.45 },
    @{ id = "STT 21";  H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; Hz = 150; actualOffset = 0.1180; delta = 0.0280; actualAmpe = 3.55 },
    @{ id = "STT 19";  H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; Hz = 150; actualOffset = 0.1050; delta = 0.0150; actualAmpe = 2.75 },
    @{ id = "STT 7";   H = 140; Ton = 120; Po = 8; IP = 5; Volt = "High"; VF = 55; Hz = 50;  actualOffset = 0.0950; delta = 0.0050; actualAmpe = 3.65 },
    @{ id = "STT 12";  H = 140; Ton = 100; Po = 9; IP = 6; Volt = "High"; VF = 60; Hz = 100; actualOffset = 0.1020; delta = 0.0120; actualAmpe = 3.75 },
    @{ id = "STT 15";  H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; Hz = 154; actualOffset = 0.1200; delta = 0.0300; actualAmpe = 2.9 },
    @{ id = "STT 23";  H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; Hz = 60;  actualOffset = 0.1080; delta = 0.0180; actualAmpe = 3.7 }
)

$scm440_jobs = @(
    @{ id = "1P-5P01"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; Hz = 150; actualOffset = 0.1010; delta = 0.0110; actualAmpe = 4.0 },
    @{ id = "STT 1";   H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; Hz = 200; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 4.45 },
    @{ id = "STT 2";   H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; Hz = 180; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 4.35 },
    @{ id = "STT 6";   H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; Hz = 100; actualOffset = 0.0970; delta = 0.0070; actualAmpe = 2.5 },
    @{ id = "1P-2P10"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; Hz = 150; actualOffset = 0.1025; delta = 0.0125; actualAmpe = 3.65 },
    @{ id = "STT 17";  H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; Hz = 150; actualOffset = 0.1135; delta = 0.0235; actualAmpe = 3.65 },
    @{ id = "1P-2P12"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; Hz = 60;  actualOffset = 0.1125; delta = 0.0225; actualAmpe = 2.9 },
    @{ id = "STT 20";  H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; Hz = 50;  actualOffset = 0.1100; delta = 0.0200; actualAmpe = 3.5 },
    @{ id = "STT 14";  H = 300; Ton = 120; Po = 9; IP = 6; Volt = "High"; VF = 65; Hz = 50;  actualOffset = 0.1150; delta = 0.0250; actualAmpe = 3.8 }
)

Write-Output "=== 1. PHÂN TÍCH ĐẶC TÍNH DÒNG ĐIỆN AMPE THỰC TẾ ==="
Write-Output "SCM420:"
foreach ($j in $scm420_jobs) {
    $duty = 1.0 / ($j.Po + 2)
    $i_peak = $j.IP * 2.8
    $u_ratio = if ($j.Volt -eq "Low") { 22.0 / 27.0 } else { 1.0 }
    $ampeTab2 = $i_peak * $duty * 2.6667 * $u_ratio
    $ratio = $j.actualAmpe / $ampeTab2
    Write-Output ("  {0,-8} H={1,3} IP={2} Po={3,2} Volt={4,-4} -> Thực: {5,4:F1}A | Tab2: {6,4:F1}A | Tỷ lệ Thực/Tab2: {7,4:F2}" -f $j.id, $j.H, $j.IP, $j.Po, $j.Volt, $j.actualAmpe, $ampeTab2, $ratio)
}

Write-Output ""
Write-Output "SCM440:"
foreach ($j in $scm440_jobs) {
    $duty = 1.0 / ($j.Po + 2)
    $i_peak = $j.IP * 2.8
    $u_ratio = if ($j.Volt -eq "Low") { 22.0 / 27.0 } else { 1.0 }
    $ampeTab2 = $i_peak * $duty * 2.6667 * $u_ratio
    $ratio = $j.actualAmpe / $ampeTab2
    Write-Output ("  {0,-8} H={1,3} IP={2} Po={3,2} Volt={4,-4} -> Thực: {5,4:F1}A | Tab2: {6,4:F1}A | Tỷ lệ Thực/Tab2: {7,4:F2}" -f $j.id, $j.H, $j.IP, $j.Po, $j.Volt, $j.actualAmpe, $ampeTab2, $ratio)
}
