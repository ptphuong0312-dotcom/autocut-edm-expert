import os
import zipfile
from datetime import datetime

ws = r"d:\OneDrive\Antigravity\Cat_Day_EDM"
backup_dir = os.path.join(ws, "backups")
os.makedirs(backup_dir, exist_ok=True)

zip_name = "autocut_2026-11-05(89).zip"
zip_path = os.path.join(backup_dir, zip_name)

# Files to exclude from zip (e.g. .git, backups, node_modules)
exclude_dirs = {'.git', 'backups', 'node_modules', '.gemini'}

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(ws):
        # filter out excluded dirs
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, ws)
            zf.write(full_path, rel_path)

print(f"[OK] Backup created: {zip_path} ({os.path.getsize(zip_path)} bytes)")
