import math

dataset = [
    # name, H, Ton, Po, IP, Volt, VF, mat, actual_gap, actual_O1
    ['1P-5P01', 12, 20, 5, 3, 'High', 65, 'SCM440', 0.0110, 0.1010],
    ['STT 22',  12, 16, 6, 3, 'Low',  60, 'SCM420', 0.0050, 0.0950],
    ['STT 1',   30, 32, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 2',   40, 36, 5, 4, 'High', 65, 'SCM440', 0.0080, 0.0980],
    ['STT 3',   63, 44, 7, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 18',  63, 44, 8, 4, 'High', 57, 'SCM420', 0.0080, 0.0980],
    ['STT 6',   68, 70, 7, 3, 'Low',  50, 'SCM440', 0.0070, 0.0970],
    ['STT 16',  75, 55, 7, 4, 'High', 54, 'SCM420', 0.0220, 0.1120],
    ['1P-2P10', 85, 70, 8, 5, 'High', 61, 'SCM440', 0.0125, 0.1025],
    ['STT 21',  90, 80, 7, 4, 'High', 54, 'SCM420', 0.0280, 0.1180],
    ['STT 17',  95, 82, 7, 4, 'High', 55, 'SCM440', 0.0235, 0.1135],
    ['STT 19', 110, 100, 10, 5, 'High', 65, 'SCM420', 0.0150, 0.1050],
    ['STT 7',  140, 120, 8, 5, 'High', 55, 'SCM420', 0.0050, 0.0950],
    ['STT 12', 140, 100, 9, 6, 'High', 60, 'SCM420', 0.0120, 0.1020],
    ['STT 15', 160, 120, 11, 6, 'High', 70, 'SCM420', 0.0300, 0.1200],
    ['1P-2P12', 165, 135, 11, 6, 'High', 70, 'SCM440', 0.0225, 0.1125],
    ['STT 23', 200, 120, 10, 6, 'High', 65, 'SCM420', 0.0180, 0.1080],
    ['STT 20', 290, 135, 10, 6, 'High', 75, 'SCM440', 0.0200, 0.1100],
    ['STT 14', 300, 120, 9, 6, 'High', 65, 'SCM440', 0.0250, 0.1150]
]

C0 = 0.00360
K_ELEC = 0.00092
DELTA_LOW = 0.00450
K_SLAG = 0.02000
K_VIBR = 0.00390
K_VF = 0.00210
K_PO = 0.00120

def test_flushing_deficit_model(k_sec, po_base=4.0, po_slope=4.5, ton_scale=50.0):
    errs = []
    errs440 = []
    errs420 = []
    diffs = []
    for r in dataset:
        name, H, Ton, Po, IP, Volt, VF, mat, act_gap, act_o1 = r
        isHard = (mat == 'SCM440' or mat == '30HRC')
        sm = 1.0 if isHard else 0.80
        km = 1.0 if isHard else 1.25
        
        if H <= 170:
            u_ratio = 1.0 if (Volt == 'High' or Volt == 'H') else (22.0 / 27.0)
            d_elec = K_ELEC * math.sqrt(Ton * IP) * u_ratio
            d_low = DELTA_LOW if (Volt == 'Low' or Volt == 'L') else 0.0
            ip_fac = max(1.0, IP / 4.0)
            d_slag = - K_SLAG * (H / 100.0) * sm / ip_fac
            d_vibr = K_VIBR * math.pow(H / 100.0, 2) * (IP / 5.0)
            d_vf = K_VF * ((VF - 55.0) / 10.0)
            d_po = - K_PO * ((Po - 5.0) / 10.0)
            
            # Flushing safe threshold:
            po_safe = po_base + po_slope * (H / 100.0)
            deficit = max(0.0, po_safe - Po)
            
            # Secondary sparking only when deficit > 0:
            # Ton / ton_scale scales with debris volume
            d_sec = k_sec * deficit * (Ton / ton_scale) * km
            calc_g = C0 + d_elec + d_low + d_slag + d_vibr + d_vf + d_po + d_sec
        else:
            gap170 = C0 + (K_ELEC * math.sqrt(Ton * IP) * 1.0) + (- K_SLAG * 1.70 * sm / max(1.0, IP / 4.0)) + (K_VIBR * math.pow(1.70, 2) * (IP / 5.0))
            gapBase = gap170 + (H - 170) * (0.0250 - gap170) / (300 - 170)
            d_vf = K_VF * 0.5 * ((VF - 65.0) / 10.0)
            d_po = - K_PO * 0.5 * ((Po - 9.0) / 10.0)
            d_sec = 0.0
            calc_g = gapBase + d_vf + d_po
            
        diff = (calc_g - act_gap) * 1000.0
        errs.append(abs(diff))
        if isHard:
            errs440.append(abs(diff))
        else:
            errs420.append(abs(diff))
        diffs.append((name, H, mat, act_gap*1000, calc_g*1000, diff, d_sec*1000))
        
    mae = sum(errs) / len(errs)
    mae440 = sum(errs440) / len(errs440)
    mae420 = sum(errs420) / len(errs420)
    max_e = max(errs)
    return mae, mae440, mae420, max_e, diffs

# Grid search
best_score = 999.0
best_res = None
for k_sec in [0.002, 0.003, 0.004, 0.005, 0.006, 0.007]:
    for po_base in [3.0, 3.5, 4.0, 4.5]:
        for po_slope in [3.5, 4.0, 4.5, 5.0]:
            for ton_scale in [40.0, 50.0, 60.0]:
                mae, mae440, mae420, max_e, diffs = test_flushing_deficit_model(k_sec, po_base, po_slope, ton_scale)
                # We want SCM440 <= 4.0 and max_e minimized
                score = mae + 0.3 * max_e + 0.2 * mae440
                if score < best_score:
                    best_score = score
                    best_res = (k_sec, po_base, po_slope, ton_scale, mae, mae440, mae420, max_e, diffs)

k_sec, po_base, po_slope, ton_scale, mae, mae440, mae420, max_e, diffs = best_res
print("BEST FLUSHING DEFICIT / SECONDARY SPARKING MODEL:")
print(f"k_sec = {k_sec:.5f}, po_base = {po_base}, po_slope = {po_slope}, ton_scale = {ton_scale}")
print(f"MAE toàn cục: {mae:.2f} um  (Gốc: 6.00 um)")
print(f"MAE SCM440:   {mae440:.2f} um  (Gốc: 3.71 um)")
print(f"MAE SCM420:   {mae420:.2f} um  (Gốc: 8.06 um)")
print(f"Max Error:    {max_e:.2f} um  (Gốc: 20.27 um)")
print("\n" + "=" * 80)
print(f"{'STT':<8} | {'H':>3} | {'mat':<6} | {'Actual':>7} | {'Calc':>7} | {'Lệch (um)':>10} | {'d_sec (um)':>10}")
print("-" * 80)
for d in diffs:
    sign = '+' if d[5] >= 0 else ''
    print(f"{d[0]:<8} | {d[1]:>3} | {d[2]:<6} | {d[3]:>7.1f} | {d[4]:>7.1f} | {sign + f'{d[5]:.1f}':>10} | {d[6]:>+10.1f}")
