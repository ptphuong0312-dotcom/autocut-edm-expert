$lines = [System.Collections.Generic.List[string]]([IO.File]::ReadAllLines("app.js", [Text.Encoding]::UTF8))
Write-Host "Line 2459 before: $($lines[2459])"
$lines.RemoveAt(2459)
$lines.RemoveAt(2458)
$lines.RemoveAt(2457)
[IO.File]::WriteAllLines("app.js", $lines, [Text.Encoding]::UTF8)
Write-Host "Removed lines 2457-2459!"
