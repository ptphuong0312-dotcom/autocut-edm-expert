$jobs = @(
    @{ name='1P-5P01'; H=12; mat='SCM440'; Ton=20; Po=5; IP=3; Volt='High'; VF=65; act=0.1010 },
    @{ name='STT 1';   H=30; mat='SCM440'; Ton=32; Po=5; IP=4; Volt='High'; VF=65; act=0.0980 },
    @{ name='STT 2';   H=40; mat='SCM440'; Ton=36; Po=5; IP=4; Volt='High'; VF=65; act=0.0980 },
    @{ name='STT 6';   H=68; mat='SCM440'; Ton=70; Po=7; IP=3; Volt='Low';  VF=50; act=0.0970 },
    @{ name='1P-2P10'; H=85; mat='SCM440'; Ton=70; Po=8; IP=5; Volt='High'; VF=61; act=0.1025 },
    @{ name='STT 17';  H=95; mat='SCM440'; Ton=82; Po=7; IP=4; Volt='High'; VF=55; act=0.1135 },
    @{ name='1P-2P12'; H=165;mat='SCM440'; Ton=135;Po=11;IP=6; Volt='High'; VF=70; act=0.1125 },
    @{ name='STT 20';  H=290;mat='SCM440'; Ton=135;Po=10;IP=6; Volt='High'; VF=75; act=0.1100 },
    @{ name='STT 14';  H=300;mat='SCM440'; Ton=120;Po=9; IP=6; Volt='High'; VF=65; act=0.1150 },
    @{ name='STT 22';  H=12; mat='SCM420'; Ton=16; Po=6; IP=3; Volt='Low';  VF=60; act=0.0950 },
    @{ name='STT 3';   H=63; mat='SCM420'; Ton=44; Po=7; IP=5; Volt='High'; VF=55; act=0.0950 },
    @{ name='STT 18';  H=63; mat='SCM420'; Ton=44; Po=8; IP=4; Volt='High'; VF=57; act=0.0980 },
    @{ name='STT 16';  H=75; mat='SCM420'; Ton=55; Po=7; IP=4; Volt='High'; VF=54; act=0.1120 },
    @{ name='STT 21';  H=90; mat='SCM420'; Ton=80; Po=7; IP=4; Volt='High'; VF=54; act=0.1180 },
    @{ name='STT 19';  H=110;mat='SCM420'; Ton=100;Po=10;IP=5; Volt='High'; VF=65; act=0.1050 },
    @{ name='STT 7';   H=140;mat='SCM420'; Ton=120;Po=8; IP=5; Volt='High'; VF=55; act=0.0950 },
    @{ name='STT 12';  H=140;mat='SCM420'; Ton=100;Po=9; IP=6; Volt='High'; VF=60; act=0.1020 },
    @{ name='STT 15';  H=160;mat='SCM420'; Ton=120;Po=11;IP=6; Volt='High'; VF=70; act=0.1200 },
    @{ name='STT 23';  H=200;mat='SCM420'; Ton=120;Po=10;IP=6; Volt='High'; VF=65; act=0.1080 }
)

function Calc-Model($c0, $kElec, $kSlag, $kVibr, $dLow, $kVf, $kPo) {
    $err440 = @()
    $err420 = @()
    foreach ($j in $jobs) {
        $isHard = ($j.mat -eq 'SCM440')
        $sm = if ($isHard) { 1.0 } else { 0.80 }
        $H = $j.H
        if ($H -le 170) {
            $u = if ($j.Volt -eq 'Low') { 22.0/27.0 } else { 1.0 }
            $d_elec = $kElec * [Math]::Sqrt($j.Ton * $j.IP) * $u
            $d_low = if ($j.Volt -eq 'Low') { $dLow } else { 0.0 }
            $ip_fac = [Math]::Max(1.0, $j.IP / 4.0)
            $d_slag = - $kSlag * ($H / 100.0) * $sm / $ip_fac
            $d_vibr = $kVibr * [Math]::Pow($H / 100.0, 2) * ($j.IP / 5.0)
            $d_vf = $kVf * (($j.VF - 55.0) / 10.0)
            $d_po = - $kPo * (($j.Po - 5.0) / 10.0)
            $gap = $c0 + $d_elec + $d_low + $d_slag + $d_vibr + $d_vf + $d_po
        } else {
            # H > 170
            $gap170 = $c0 + ($kElec * [Math]::Sqrt($j.Ton * $j.IP) * 1.0) + (- $kSlag * 1.70 * $sm / ([Math]::Max(1.0, $j.IP/4.0))) + ($kVibr * [Math]::Pow(1.70, 2) * ($j.IP/5.0))
            $gapBase = $gap170 + ($H - 170) * (0.0250 - $gap170) / (300 - 170)
            $d_vf = $kVf * 0.5 * (($j.VF - 65.0) / 10.0)
            $d_po = - $kPo * 0.5 * (($j.Po - 9.0) / 10.0)
            $gap = $gapBase + $d_vf + $d_po
        }
        $calcO = 0.090 + $gap
        $err = [Math]::Abs($calcO - $j.act) * 1000.0
        if ($isHard) { $err440 += $err } else { $err420 += $err }
    }
    $m440 = ($err440 | Measure-Object -Average).Average
    $m420 = ($err420 | Measure-Object -Average).Average
    $mAll = (($err440 + $err420) | Measure-Object -Average).Average
    return @{ m440=$m440; m420=$m420; mAll=$mAll }
}

$opt1 = Calc-Model 0.00360 0.00092 0.02000 0.00390 0.00450 0.00210 0.00120
Write-Host ('Tab 3 Exact (0.00360, 0.00092): SCM440={0:F2}um | SCM420={1:F2}um | All={2:F2}um' -f $opt1.m440, $opt1.m420, $opt1.mAll)

$opt2 = Calc-Model 0.00350 0.00100 0.02000 0.00390 0.00450 0.00210 0.00120
Write-Host ('Config 2    (0.00350, 0.00100): SCM440={0:F2}um | SCM420={1:F2}um | All={2:F2}um' -f $opt2.m440, $opt2.m420, $opt2.mAll)

$opt3 = Calc-Model 0.00280 0.00100 0.02300 0.00390 0.00450 0.0 0.0
Write-Host ('Current Tab2 (no VF/Po/slag_mat): SCM440={0:F2}um | SCM420={1:F2}um | All={2:F2}um' -f $opt3.m440, $opt3.m420, $opt3.mAll)
