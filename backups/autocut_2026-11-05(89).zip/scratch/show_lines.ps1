$lines = [IO.File]::ReadAllLines("app.js", [Text.Encoding]::UTF8)
for ($i = 2455; $i -le 2465; $i++) {
    Write-Host "${i}: '$($lines[$i])'"
}
