# Phân tích chi tiết 19 bài cắt thực tế (Thư viện Web App)
$jobs = @(
    # SCM440 (28-32 HRC) - 9 bài
    @{ id = "1P-5P01"; mat = "SCM440"; H = 12; Ton = 20; Po = 5; IP = 3; Volt = "High"; VF = 65; Hz = 150; actualOffset = 0.1010; delta = 0.0110; actualAmpe = 4.0;  actualSpeed = 280 },
    @{ id = "STT 1";   mat = "SCM440"; H = 30; Ton = 32; Po = 5; IP = 4; Volt = "High"; VF = 65; Hz = 200; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 4.48; actualSpeed = 170 },
    @{ id = "STT 2";   mat = "SCM440"; H = 40; Ton = 36; Po = 5; IP = 4; Volt = "High"; VF = 65; Hz = 180; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 4.38; actualSpeed = 135 },
    @{ id = "STT 6";   mat = "SCM440"; H = 68; Ton = 70; Po = 7; IP = 3; Volt = "Low";  VF = 50; Hz = 100; actualOffset = 0.0970; delta = 0.0070; actualAmpe = 2.5;  actualSpeed = 43 },
    @{ id = "1P-2P10"; mat = "SCM440"; H = 85; Ton = 70; Po = 8; IP = 5; Volt = "High"; VF = 61; Hz = 150; actualOffset = 0.1025; delta = 0.0125; actualAmpe = 3.65; actualSpeed = 60 },
    @{ id = "STT 17";  mat = "SCM440"; H = 95; Ton = 82; Po = 7; IP = 4; Volt = "High"; VF = 55; Hz = 150; actualOffset = 0.1135; delta = 0.0235; actualAmpe = 3.65; actualSpeed = 40 },
    @{ id = "1P-2P12"; mat = "SCM440"; H = 165; Ton = 135; Po = 11; IP = 6; Volt = "High"; VF = 70; Hz = 60;  actualOffset = 0.1125; delta = 0.0225; actualAmpe = 2.9;  actualSpeed = 25 },
    @{ id = "STT 20";  mat = "SCM440"; H = 290; Ton = 135; Po = 10; IP = 6; Volt = "High"; VF = 75; Hz = 50;  actualOffset = 0.1100; delta = 0.0200; actualAmpe = 3.5;  actualSpeed = 18 },
    @{ id = "STT 14";  mat = "SCM440"; H = 300; Ton = 120; Po = 9;  IP = 6; Volt = "High"; VF = 65; Hz = 50;  actualOffset = 0.1150; delta = 0.0250; actualAmpe = 3.8;  actualSpeed = 16 },

    # SCM420 (HB < 200) - 10 bài
    @{ id = "STT 22";  mat = "SCM420"; H = 12; Ton = 16; Po = 6; IP = 3; Volt = "Low";  VF = 60; Hz = 150; actualOffset = 0.0950; delta = 0.0050; actualAmpe = 2.6;  actualSpeed = 147 },
    @{ id = "STT 3";   mat = "SCM420"; H = 63; Ton = 44; Po = 7; IP = 5; Volt = "High"; VF = 55; Hz = 150; actualOffset = 0.0950; delta = 0.0050; actualAmpe = 4.15; actualSpeed = 80 },
    @{ id = "STT 18";  mat = "SCM420"; H = 63; Ton = 44; Po = 8; IP = 4; Volt = "High"; VF = 57; Hz = 150; actualOffset = 0.0980; delta = 0.0080; actualAmpe = 3.35; actualSpeed = 57.5 },
    @{ id = "STT 16";  mat = "SCM420"; H = 75; Ton = 55; Po = 7; IP = 4; Volt = "High"; VF = 54; Hz = 187; actualOffset = 0.1120; delta = 0.0220; actualAmpe = 3.45; actualSpeed = 57.5 },
    @{ id = "STT 21";  mat = "SCM420"; H = 90; Ton = 80; Po = 7; IP = 4; Volt = "High"; VF = 54; Hz = 150; actualOffset = 0.1180; delta = 0.0280; actualAmpe = 3.55; actualSpeed = 55 },
    @{ id = "STT 19";  mat = "SCM420"; H = 110; Ton = 100; Po = 10; IP = 5; Volt = "High"; VF = 65; Hz = 150; actualOffset = 0.1050; delta = 0.0150; actualAmpe = 2.75; actualSpeed = 35 },
    @{ id = "STT 7";   mat = "SCM420"; H = 140; Ton = 120; Po = 8;  IP = 5; Volt = "High"; VF = 55; Hz = 50;  actualOffset = 0.0950; delta = 0.0050; actualAmpe = 3.65; actualSpeed = 34 },
    @{ id = "STT 12";  mat = "SCM420"; H = 140; Ton = 100; Po = 9;  IP = 6; Volt = "High"; VF = 60; Hz = 100; actualOffset = 0.1020; delta = 0.0120; actualAmpe = 3.75; actualSpeed = 35 },
    @{ id = "STT 15";  mat = "SCM420"; H = 160; Ton = 120; Po = 11; IP = 6; Volt = "High"; VF = 70; Hz = 154; actualOffset = 0.1200; delta = 0.0300; actualAmpe = 2.9;  actualSpeed = 23 },
    @{ id = "STT 23";  mat = "SCM420"; H = 200; Ton = 120; Po = 10; IP = 6; Volt = "High"; VF = 65; Hz = 60;  actualOffset = 0.1080; delta = 0.0180; actualAmpe = 3.7;  actualSpeed = 20 }
)

Write-Output "=== TẬP DỮ LIỆU THỰC NGHIỆM 19 BÀI CẮT XƯỞNG ==="
foreach ($j in $jobs) {
    Write-Output ("{0,-6} {1,-8} H={2,3} Ton={3,3} Po={4,2} IP={5} Volt={6,-4} VF={7,2} Hz={8,3} -> Offset={9:F4} delta={10,5:F1}um Ampe={11,4:F1}A Speed={12,5:F1}" -f $j.mat, $j.id, $j.H, $j.Ton, $j.Po, $j.IP, $j.Volt, $j.VF, $j.Hz, $j.actualOffset, ($j.delta * 1000), $j.actualAmpe, $j.actualSpeed)
}
