import re

with open('app.js', 'r', encoding='utf-8') as f:
    text = f.read()

for pass_num in [1, 2, 5]:
    sub_m = re.search(rf'{pass_num}:\s*\[(.*?)\]\s*,\s*(?:\d|\}})', text, re.DOTALL)
    if sub_m:
        sub_block = sub_m.group(1)
        matches = re.findall(r'offset:\s*"([^"]+)",\s*actualOffset:\s*"([^"]+)",\s*calcOffset:\s*"([^"]+)"', sub_block)
        errs = []
        for off, act, calc in matches:
            a = float(act.replace(',', '.'))
            c = float(calc.replace(',', '.'))
            diff = (c - a) * 1000
            errs.append((abs(diff), diff, a, c))
        if errs:
            max_e = max(errs, key=lambda x: x[0])
            avg_e = sum(x[0] for x in errs) / len(errs)
            print(f"Pass {pass_num}: {len(errs)} items | Max Error = {max_e[0]:.1f} um ({max_e[1]:+.1f} um, Act={max_e[2]}, Calc={max_e[3]}) | MAE = {avg_e:.2f} um")
