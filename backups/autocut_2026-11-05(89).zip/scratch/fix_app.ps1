[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$appPath = "app.js"
$content = [IO.File]::ReadAllText($appPath, [Text.Encoding]::UTF8)

# 1. Fix line around 2457-2460
$oldBlock = "                // Đã loại bỏ hệ số ghìm tiến nhân tạo: SCM420 H>=70 cắt thực tế 50-65 mm2/p`r`n`r`n`r`n                }"
$newBlock = "                // Đã loại bỏ hệ số ghìm tiến nhân tạo: SCM420 H>=70 cắt thực tế 50-65 mm2/p"

if ($content.Contains($oldBlock)) {
    $content = $content.Replace($oldBlock, $newBlock)
    Write-Host "Replaced old speed block successfully!"
} else {
    Write-Host "Old speed block not matched exactly, checking regex..."
    $regex = [regex]"// Đã loại bỏ hệ số ghìm tiến nhân tạo: SCM420 H>=70 cắt thực tế 50-65 mm2/p\r?\n\s*\r?\n\s*\r?\n\s*\}"
    if ($regex.IsMatch($content)) {
        $content = $regex.Replace($content, "// Đã loại bỏ hệ số ghìm tiến nhân tạo: SCM420 H>=70 cắt thực tế 50-65 mm2/p")
        Write-Host "Replaced via regex successfully!"
    } else {
        Write-Host "Warning: regex also did not match!"
    }
}

# 2. Update WS_LIB_BENCHMARK_JOBS[1]
$targetHeader = "                1: ["
$endMarker = "                2: ["

$startIndex = $content.IndexOf($targetHeader)
$endIndex = $content.IndexOf($endMarker)

if ($startIndex -ge 0 -and $endIndex -gt $startIndex) {
    $newJobs = @"
                1: [
                    // H=12 (Quy đổi từ Pass 1 bài cắt 5P-01 có đo kiểm vách P1)
                    { H: 12, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 20, Toff: 5, IP: 3, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz", offset: "0,101", actualOffset: "0,101", calcOffset: "0,1010", length: "128mm", actualTime: "19p50'", calcTime: "19p50'", actualAmpe: "4A", calcAmpe: "3.2A", actualSpeed: "275-285 mm²/p", calcSpeedH40: "237 mm²/p" }] },
                    // H=12 (SCM420, STT 22 - Cắt chày 1 Pass Volt Low)
                    { H: 12, material: "HB<200", passes: [{ Ton: 16, Toff: 6, IP: 3, Wire: 1, Volt: "L", VF: 60, maxSpeed: "150Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,1027", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,5A - 2,7A", calcAmpe: "2.3A", actualSpeed: "--", calcSpeedH40: "143 mm²/p" }] },
                    // H=30 (SCM440, STT 1 - Chuẩn gốc 1 Pass)
                    { H: 30, material: "30HRC", passes: [{ Ton: 32, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "200Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,1012", length: "30mm", actualTime: "8p40'", calcTime: "7p58'", actualAmpe: "4,45A - 4,5A", calcAmpe: "4.3A", actualSpeed: "165-175 mm²/p", calcSpeedH40: "151 mm²/p" }] },
                    // H=40 (SCM440, STT 2 - Chuẩn gốc 1 Pass)
                    { H: 40, material: "30HRC", passes: [{ Ton: 36, Toff: 5, IP: 4, Wire: 1, Volt: "H", VF: 65, maxSpeed: "180Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,1001", length: "30mm", actualTime: "9p36'", calcTime: "10p10'", actualAmpe: "4,35A - 4,4A", calcAmpe: "4.3A", actualSpeed: "130-140 mm²/p", calcSpeedH40: "118 mm²/p" }] },
                    // H=63 (SCM420, STT 3 - Cắt chày 1 Pass)
                    { H: 63, material: "HB<200", passes: [{ Ton: 44, Toff: 7, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,1016", length: "27mm", actualTime: "14p20'", calcTime: "15p11'", actualAmpe: "4,1A - 4,2A", calcAmpe: "4.1A", actualSpeed: "75-85 mm²/p", calcSpeedH40: "71 mm²/p" }] },
                    // H=63 (SCM420, STT 18 - Cắt chày 1 Pass)
                    { H: 63, material: "HB<200", passes: [{ Ton: 44, Toff: 8, IP: 4, Wire: 1, Volt: "H", VF: 57, maxSpeed: "150Hz", offset: "0,098", actualOffset: "0,098", calcOffset: "0,0980", length: "22,3mm", actualTime: "17p40'", calcTime: "17p34'", actualAmpe: "3,3A - 3,4A", calcAmpe: "3.0A", actualSpeed: "50-65 mm²/p", calcSpeedH40: "51 mm²/p" }] },
                    // H=68 (SCM440, STT 6 - Cắt chày Volt Low)
                    { H: 68, material: "30HRC", passes: [{ Ton: 70, Toff: 7, IP: 3, Wire: 1, Volt: "L", VF: 50, maxSpeed: "100Hz", offset: "0,097", actualOffset: "0,097", calcOffset: "0,0960", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,4A - 2,6A", calcAmpe: "2.0A", actualSpeed: "--", calcSpeedH40: "42 mm²/p" }] },
                    // H=75 (SCM420, STT 16 - Cắt cối 1 Pass)
                    { H: 75, material: "HB<200", passes: [{ Ton: 55, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "187Hz", offset: "0,112", actualOffset: "0,112", calcOffset: "0,0976", length: "50,3mm", actualTime: "1h13'", calcTime: "39p43'", actualAmpe: "3,4A - 3,5A", calcAmpe: "3.3A", actualSpeed: "50-65 mm²/p", calcSpeedH40: "51 mm²/p" }] },
                    // H=85 (Quy đổi từ Pass 1 bài cắt 2P-10 có đo kiểm vách P1)
                    { H: 85, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 70, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 61, maxSpeed: "150Hz", offset: "0,1025", actualOffset: "0,1025", calcOffset: "0,1023", length: "65,6mm", actualTime: "48p", calcTime: "41p55'", actualAmpe: "3,6A - 3,7A", calcAmpe: "3.7A", actualSpeed: "55-65 mm²/p", calcSpeedH40: "63 mm²/p" }] },
                    // H=90 (SCM420, STT 21 - Cắt cối 1 Pass)
                    { H: 90, material: "HB<200", passes: [{ Ton: 80, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 54, maxSpeed: "150Hz", offset: "0,118", actualOffset: "0,118", calcOffset: "0,0991", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,6A", calcAmpe: "3.3A", actualSpeed: "50-60 mm²/p", calcSpeedH40: "48 mm²/p" }] },
                    // H=95 (SCM440, STT 17 - Cắt cối 1 Pass)
                    { H: 95, material: "30HRC", passes: [{ Ton: 82, Toff: 7, IP: 4, Wire: 1, Volt: "H", VF: 55, maxSpeed: "150Hz", offset: "0,1135", actualOffset: "0,1135", calcOffset: "0,0952", length: "76mm", actualTime: "1h15'", calcTime: "1h5p", actualAmpe: "3,6A - 3,7A", calcAmpe: "3.3A", actualSpeed: "35-45 mm²/p", calcSpeedH40: "47 mm²/p" }] },
                    // H=110 (SCM420, STT 19 - Cắt chày 1 Pass)
                    { H: 110, material: "HB<200", passes: [{ Ton: 100, Toff: 10, IP: 5, Wire: 1, Volt: "H", VF: 65, maxSpeed: "150Hz", offset: "0,105", actualOffset: "0,105", calcOffset: "0,1080", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "2,7A - 2,8A", calcAmpe: "3.1A", actualSpeed: "30-40 mm²/p", calcSpeedH40: "35 mm²/p" }] },
                    // H=140 (SCM420, STT 7 - Cắt chày 1 Pass)
                    { H: 140, material: "HB<200", passes: [{ Ton: 120, Toff: 8, IP: 5, Wire: 1, Volt: "H", VF: 55, maxSpeed: "50Hz", offset: "0,095", actualOffset: "0,095", calcOffset: "0,1074", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "3,5A - 3,8A", calcAmpe: "3.7A", actualSpeed: "--", calcSpeedH40: "31 mm²/p" }] },
                    // H=140 (SCM420, STT 12 - Cắt chày 1 Pass)
                    { H: 140, material: "HB<200", passes: [{ Ton: 100, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 60, maxSpeed: "100Hz", offset: "0,102", actualOffset: "0,102", calcOffset: "0,1128", length: "28,4mm", actualTime: "36p", calcTime: "33p25'", actualAmpe: "3,7A - 3,8A", calcAmpe: "4.1A", actualSpeed: "30-40 mm²/p", calcSpeedH40: "34 mm²/p" }] },
                    // H=160 (SCM420, STT 15 - Cắt cối 1 Pass)
                    { H: 160, material: "HB<200", passes: [{ Ton: 120, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "154Hz", offset: "0,120", actualOffset: "0,120", calcOffset: "0,1177", length: "32,3mm", actualTime: "59p", calcTime: "53p17'", actualAmpe: "2,8A - 3A", calcAmpe: "3.4A", actualSpeed: "18-28 mm²/p", calcSpeedH40: "24 mm²/p" }] },
                    // H=165 (Quy đổi từ Pass 1 bài cắt 2P-12 có đo kiểm vách P1)
                    { H: 165, material: "30HRC", fromMultiPass: true, passes: [{ Ton: 135, Toff: 11, IP: 6, Wire: 1, Volt: "H", VF: 70, maxSpeed: "60Hz", offset: "0,1125", actualOffset: "0,1125", calcOffset: "0,1151", length: "43,6mm", actualTime: "1h17'", calcTime: "1h7p", actualAmpe: "2,8A - 3,0A", calcAmpe: "3.4A", actualSpeed: "15-35 mm²/p", calcSpeedH40: "26 mm²/p" }] },
                    // H=200 (SCM420, STT 23 - Cắt cối 1 Pass phôi siêu dày)
                    { H: 200, material: "HB<200", passes: [{ Ton: 120, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "60Hz", offset: "0,108", actualOffset: "0,108", calcOffset: "0,1102", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "--", calcAmpe: "3.7A", actualSpeed: "--", calcSpeedH40: "19 mm²/p" }] },
                    // H=290 (SCM440, STT 20 - Cắt cối 1 Pass phôi siêu dày)
                    { H: 290, material: "30HRC", passes: [{ Ton: 135, Toff: 10, IP: 6, Wire: 1, Volt: "H", VF: 75, maxSpeed: "50Hz", offset: "0,110", actualOffset: "0,110", calcOffset: "0,1145", length: "--", actualTime: "--", calcTime: "--", actualAmpe: "--", calcAmpe: "3.7A", actualSpeed: "--", calcSpeedH40: "14 mm²/p" }] },
                    // H=300 (SCM440, STT 14 - Cắt cối 1 Pass mốc biên)
                    { H: 300, material: "30HRC", passes: [{ Ton: 120, Toff: 9, IP: 6, Wire: 1, Volt: "H", VF: 65, maxSpeed: "50Hz", offset: "0,115", actualOffset: "0,115", calcOffset: "0,1150", length: "76,1mm", actualTime: "3h", calcTime: "3h31p", actualAmpe: "3,7A - 3,9A", calcAmpe: "4.1A", actualSpeed: "12-20 mm²/p", calcSpeedH40: "14 mm²/p" }] }
                ],
"@
    $content = $content.Substring(0, $startIndex) + $newJobs + "`r`n" + $content.Substring($endIndex)
    Write-Host "Replaced WS_LIB_BENCHMARK_JOBS[1] successfully!"
} else {
    Write-Host "Error: Could not locate WS_LIB_BENCHMARK_JOBS[1] markers!"
}

[IO.File]::WriteAllText($appPath, $content, [Text.Encoding]::UTF8)
Write-Host "app.js updated successfully!"
