# 📖 TỪ ĐIỂN CÁC ĐỊNH NGHĨA & THUẬT NGỮ CẮT DÊY EDM (AutoCut)
*Tài liệu đúc kết từ quá trình thực nghiệm và tinh chỉnh giữa Thợ máy & AI.*
*Trạng thái: Đóng khung tạm thời (Chờ thực nghiệm kiểm chứng thêm).*

---

### 1. CÁC THÔNG SỐ ĐIỆN CƠ BẢN
*   **Ton / ti (Độ rộng xung - Pulse Width):** Thời gian dòng điện phóng ra (µs). Ton càng lớn, tia lửa càng mạnh, cắt càng nhanh, rãnh cắt càng rộng, nhưng bề mặt phôi càng rỗ và dây Molypden càng nhanh mòn.
*   **Toff / Po (Thời gian nghỉ - Pulse Off):** Hệ số nhân thời gian nghỉ. Thời gian nghỉ thực tế = Toff * Ton. Quyết định khoảng thời gian xối nước làm mát để đẩy xỉ ra ngoài. Toff càng lớn, cắt càng an toàn (ít đứt dây), nhưng dòng Ampe bị tụt và tốc độ chậm.
*   **IP (Ống công suất / Dòng đỉnh):** Số lượng van công suất mở (1 đến 6). Quyết định cường độ dòng điện cực đại của mỗi tia lửa.
*   **Volt (Điện áp):** High (Điện áp cao) giúp tia lửa dễ mồi qua khoảng cách xa (thích hợp phôi dày), Low (Điện áp thấp) cho tia lửa ngắn (thích hợp cắt tinh Pass 2, 3).
*   **VF (Biến tần / V-F Tracking):** Tần số cấp cho mô-tơ bước/servo điều khiển mâm máy tiến/lùi. 
    *   **VF thấp:** Tần số chậm, mâm máy tiến rón rén, dễ lùi dao khi kẹt xỉ (chống đứt dây nhưng cắt chậm).
    *   **VF cao:** Tần số nhanh, mâm máy tiến hung hãn, lỳ lợm ép thẳng vào phôi. Thích hợp khi rãnh cắt đã được thông thoáng.

### 2. CÁC KHÁI NIỆM ĐO LƯỜNG & BỀ MẶT
*   **Khả năng cào phôi (True Spark Gap):** Khoảng cách thực tế mà tia lửa có thể phóng ra và làm bốc hơi kim loại. Được tính bằng: (Offset lý thuyết - Bán kính dây) - Sai số thực tế. 
    *   *Nguyên tắc sinh tử:* Không bao giờ được nhập lượng chừa phôi (Remain) cho các Pass cắt tinh lớn hơn "Khả năng cào phôi" của bộ điện đó.
*   **Độ nhám bề mặt (Rz vs Ra):** Tia lửa EDM tạo ra bề mặt "lỗ chỗ miệng núi lửa". 
    *   **Thước Panme** chỉ đo được các "Đỉnh núi".
    *   **Lý thuyết điện trường** tính toán tới tận "Đáy núi".
    *   Hiệu số giữa Đáy và Đỉnh chính là độ sâu rãnh (Rz). Nhiệm vụ của Pass cắt tinh (Pass 2, 3...) là gọt sạch đi lớp Rz này.

### 3. CÁC HIỆN TƯỢNG VẬT LÝ THỰC CHIẾN
*   **Điểm nghẽn 2 giờ (2-Hour Choke Point):** Hiện tượng xảy ra khi cắt phôi siêu dày (>200mm). Sau khoảng 2 tiếng, dây mòn đi làm rãnh cắt hẹp lại, cộng với xỉ đùn ứ nghẹn ở tâm phôi do nước không xối tới, khiến máy khựng lại không thể tiến thêm.
*   **Chiến thuật "Mìn phá băng & Lệnh xung phong":** Giải pháp cho Điểm nghẽn 2 giờ. Tăng mạnh Ton (Ví dụ lên 110) để nổ tung mở rộng rãnh cắt, kết hợp tăng mạnh VF (Ví dụ lên 65) để ép mâm máy hung hãn lướt qua vùng kẹt xỉ.
*   **Bụng phình (Hình tang trống):** Ở phôi siêu dày, lực đẩy tia lửa và áp lực nước làm sợi dây bị võng ở giữa. Phải hãm chậm tốc độ ở các góc cua hoặc cuối đường cắt để dây kịp đánh lửa "vớt" lại phần bụng võng.
### 4. B� ?N V?T L� KH?I SI�U D�Y (H > 100mm)
*   **S? ph� s?n c?a Ton tuy?n t�nh:** ? ph�i si�u d�y (VD: H=140), l� thuy?t Ton nh? (52-80) ho�n to�n v� d?ng v� kh�ng d?y du?c x?. B?t bu?c ph?i d�ng "M�n ph� bang" Ton si�u l?n (100-120).
*   **�u?ng cong Kh? nang c�o h�nh ch? U:** Kh? nang c�o ph�i gi?m d?n t? 12mm d?n 80mm do k?t x?. Nhung t? 100mm tr? l�n, do ph?i d�ng Ton kh?ng l?, s?c n? l�m r�nh c?t n? r?ng ra, khi?n "kh? nang c�o" tang ngu?c tr? l?i (V� d? H=140 do du?c Gap = 0.012mm).
*   **Ngh?ch l� Kh�ng b�o b?ng ? Ton kh?ng l?:** R?t b?t ng? l� c?t H=140 b?ng Ton 100-120 l?i KH�NG b? hi?n tu?ng b�o b?ng/nh? b?ng. Gi?i th�ch v?t l�: Qu? bom Ton kh?ng l? t?o ra r�nh c?t c?c r?ng, tri?t ti�u ho�n to�n ma s�t co h?c gi?a d�y v� v�ch th�p. D�y tr�i t? do trong r�nh r?ng. T?c d? ti?n dao (VF) l? l?m nhung ch?m (0.25 mm/ph�t) gi�p tia l?a c� d? th?i gian "g?m" ph?ng v�ch ph�i tru?c khi d�y k?p b? v�ng.

### 5. GHI CH� QUAN TR?NG V? TAB 1 (CH? �? TI�U CHU?N H�NG)
*   **Th?c tr?ng:** Qua c�c d? li?u th?c nghi?m (d?c bi?t l� ph�i si�u d�y H=140, H=300), d� c� b?ng ch?ng r� r�ng cho th?y Ch? d? c?t ti�u chu?n c?a H�ng AutoCut (hi?n th? t?i Tab 1) l� **KH�NG CH�NH X�C** v� thi?u t�nh th?c ti?n (V� d?: H�ng d? xu?t Ton qu� nh? cho ph�i d�y, d?n d?n k?t x? v� l�i dao).
*   **Ch? th? ��ng bang:** TUY?T �?I KH�NG �U?C s?a d?i thu?t to�n c?a Tab 1. Tab 1 du?c gi? nguy�n tr?ng th�i "L� thuy?t H�ng" d? l�m thu?c do d?i chi?u.
*   **H�nh d?ng Tuong lai:** Ch? khi n�o c� L?NH TR?C TI?P t? Th? m�y (User), H? th?ng AI m?i du?c ph�p d?p di x�y l?i to�n b? Tab 1 d? bi?n n� th�nh Chu?n Th?c T?.
